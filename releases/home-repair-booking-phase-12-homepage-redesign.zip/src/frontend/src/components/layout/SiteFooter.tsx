import { Link } from "react-router-dom"

type SiteFooterProps = {
  databaseConnected: boolean | null
}

export function SiteFooter({ databaseConnected }: SiteFooterProps) {
  let statusText = "Hệ thống sẵn sàng"
  if (databaseConnected === true) statusText = "Cơ sở dữ liệu sẵn sàng"
  if (databaseConnected === false) statusText = "Chưa kết nối cơ sở dữ liệu"

  return (
    <footer style={{ background: "#ffffff", borderTop: "1px solid #e2e8f0", paddingTop: "52px", paddingBottom: "32px", marginTop: "auto" }}>
      <div style={{ maxWidth: "1340px", margin: "0 auto", padding: "0 20px" }}>
        {/* MAIN 5-COLUMN FOOTER GRID (MATCHING HOMEPAGE SCREENSHOT) */}
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "1.3fr 1fr 1fr 1.2fr 1fr",
            gap: "32px",
            marginBottom: "40px",
          }}
        >
          {/* COL 1: LOGO & ABOUT */}
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "14px" }}>
              <div style={{ width: "32px", height: "32px", borderRadius: "10px", background: "#2563eb", display: "flex", alignItems: "center", justifyContent: "center" }}>
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
                  <rect x="5" y="2" width="14" height="20" rx="3" ry="3" />
                  <line x1="12" y1="18" x2="12.01" y2="18" />
                </svg>
              </div>
              <strong style={{ fontSize: "1.3rem", fontWeight: 800, letterSpacing: "-0.03em", color: "#0f172a" }}>
                Phone<span style={{ color: "#2563eb" }}>Repair</span>
              </strong>
            </div>

            <p style={{ margin: 0, color: "#64748b", fontSize: "0.85rem", lineHeight: 1.6, maxWidth: "260px" }}>
              Hệ thống đặt lịch sửa chữa nhà cửa uy tín hàng đầu Việt Nam.
              <br />
              Sửa đúng – Dùng bền hơn.
            </p>
          </div>

          {/* COL 2: LIÊN KẾT NHANH */}
          <div>
            <strong style={{ display: "block", fontSize: "0.92rem", color: "#0f172a", marginBottom: "16px" }}>
              Liên kết nhanh
            </strong>
            <ul style={{ listStyle: "none", padding: 0, margin: 0, display: "flex", flexDirection: "column", gap: "10px", fontSize: "0.86rem" }}>
              <li>
                <Link to="/" style={{ color: "#64748b" }}>Trang chủ</Link>
              </li>
              <li>
                <Link to="/services" style={{ color: "#64748b" }}>Dịch vụ</Link>
              </li>
              <li>
                <Link to="/pricing" style={{ color: "#64748b" }}>Bảng giá</Link>
              </li>
            </ul>
          </div>

          {/* COL 3: DỊCH VỤ */}
          <div>
            <strong style={{ display: "block", fontSize: "0.92rem", color: "#0f172a", marginBottom: "16px" }}>
              Dịch vụ
            </strong>
            <ul style={{ listStyle: "none", padding: 0, margin: 0, display: "flex", flexDirection: "column", gap: "10px", fontSize: "0.86rem" }}>
              <li>
                <Link to="/pricing" style={{ color: "#64748b" }}>Thay màn hình</Link>
              </li>
              <li>
                <Link to="/pricing" style={{ color: "#64748b" }}>Thay pin</Link>
              </li>
              <li>
                <Link to="/pricing" style={{ color: "#64748b" }}>Sửa cổng sạc</Link>
              </li>
              <li>
                <Link to="/pricing" style={{ color: "#64748b" }}>Sửa camera</Link>
              </li>
              <li>
                <Link to="/pricing" style={{ color: "#64748b" }}>Vệ sinh máy</Link>
              </li>
            </ul>
          </div>

          {/* COL 4: HỖ TRỢ KHÁCH HÀNG */}
          <div>
            <strong style={{ display: "block", fontSize: "0.92rem", color: "#0f172a", marginBottom: "16px" }}>
              Hỗ trợ khách hàng
            </strong>
            <ul style={{ listStyle: "none", padding: 0, margin: 0, display: "flex", flexDirection: "column", gap: "10px", fontSize: "0.86rem" }}>
              <li>
                <Link to="/booking" style={{ color: "#64748b" }}>Hướng dẫn đặt lịch</Link>
              </li>
              <li>
                <Link to="/support" style={{ color: "#64748b" }}>Chính sách bảo hành</Link>
              </li>
              <li>
                <Link to="/support" style={{ color: "#64748b" }}>Chính sách đổi trả</Link>
              </li>
              <li>
                <Link to="/support" style={{ color: "#64748b" }}>Câu hỏi thường gặp</Link>
              </li>
              <li>
                <Link to="/support" style={{ color: "#64748b" }}>Liên hệ</Link>
              </li>
            </ul>
          </div>

          {/* COL 5: KẾT NỐI VỚI CHÚNG TÔI */}
          <div>
            <strong style={{ display: "block", fontSize: "0.92rem", color: "#0f172a", marginBottom: "16px" }}>
              Kết nối với chúng tôi
            </strong>
            <div style={{ display: "flex", gap: "12px", alignItems: "center" }}>
              <a href="#facebook" style={{ width: "34px", height: "34px", borderRadius: "50%", background: "#eff6ff", color: "#1877F2", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "0.95rem" }} title="Facebook">
                📘
              </a>
              <a href="#youtube" style={{ width: "34px", height: "34px", borderRadius: "50%", background: "#fef2f2", color: "#ef4444", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "0.95rem" }} title="YouTube">
                ▶️
              </a>
              <a href="#tiktok" style={{ width: "34px", height: "34px", borderRadius: "50%", background: "#f1f5f9", color: "#0f172a", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "0.95rem" }} title="TikTok">
                🎵
              </a>
              <a href="#zalo" style={{ width: "34px", height: "34px", borderRadius: "50%", background: "#e0f2fe", color: "#0284c7", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "0.8rem", fontWeight: 800 }} title="Zalo">
                Zalo
              </a>
            </div>
          </div>
        </div>

        {/* BOTTOM COPYRIGHT & POLICY ROW */}
        <div
          style={{
            borderTop: "1px solid #f1f5f9",
            paddingTop: "24px",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            flexWrap: "wrap",
            gap: "14px",
            fontSize: "0.82rem",
            color: "#94a3b8",
          }}
        >
          <div>
            © 2024 HomeRepair. Tất cả quyền được bảo lưu.
          </div>

          <div style={{ display: "flex", alignItems: "center", gap: "20px" }}>
            <Link to="/support" style={{ color: "#94a3b8" }}>Điều khoản sử dụng</Link>
            <span>|</span>
            <Link to="/support" style={{ color: "#94a3b8" }}>Chính sách bảo mật</Link>
            <span>|</span>
            <Link to="/support" style={{ color: "#94a3b8" }}>Sitemap</Link>
          </div>

          <div style={{ display: "inline-flex", alignItems: "center", gap: "6px" }}>
            <span
              style={{
                width: "8px",
                height: "8px",
                borderRadius: "50%",
                background: databaseConnected ? "#16a34a" : "#ca8a04",
              }}
            />
            <span>{statusText}</span>
          </div>
        </div>
      </div>
    </footer>
  )
}
