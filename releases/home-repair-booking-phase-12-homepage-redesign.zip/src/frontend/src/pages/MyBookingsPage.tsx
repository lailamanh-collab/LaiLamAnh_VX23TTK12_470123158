import { useEffect, useState } from "react"
import { Link } from "react-router-dom"
import { myBookings, statusLabel, type BookingSummary } from "../api/bookings"
import { useAuth } from "../auth/AuthContext"

const filters = [
  { id: "", label: "Tất cả" },
  { id: "pending", label: "Chờ xác nhận" },
  { id: "inprogress", label: "Đang xử lý" },
  { id: "completed", label: "Hoàn thành" },
  { id: "cancelled", label: "Đã hủy" },
]

export function MyBookingsPage() {
  const { token } = useAuth()
  const [filter, setFilter] = useState("")
  const [rows, setRows] = useState<BookingSummary[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!token) return
    setLoading(true)
    myBookings(token, filter)
      .then(setRows)
      .catch(() => setRows([]))
      .finally(() => setLoading(false))
  }, [token, filter])

  function getStatusBadgeClass(status: string) {
    switch (status) {
      case "Pending":
        return "badge badge-pending"
      case "Confirmed":
        return "badge badge-confirmed"
      case "Received":
        return "badge badge-received"
      case "Inspecting":
        return "badge badge-inspecting"
      case "Repairing":
        return "badge badge-repairing"
      case "Completed":
        return "badge badge-completed"
      case "Cancelled":
        return "badge badge-cancelled"
      default:
        return "badge"
    }
  }

  return (
    <main className="page">
      <section className="section-head" style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: "12px" }}>
        <div>
          <h1>Lịch hẹn của tôi</h1>
          <p className="section-intro">Theo dõi tiến độ và quản lý tất cả các lịch sửa chữa của bạn.</p>
        </div>
        <Link className="btn" to="/booking">
          + Đặt lịch mới
        </Link>
      </section>

      {/* Filter Tabs */}
      <div className="filter-row" style={{ marginTop: "16px" }}>
        {filters.map((item) => (
          <button
            key={item.id}
            type="button"
            className={filter === item.id ? "slot slot-selected" : "slot"}
            onClick={() => setFilter(item.id)}
            style={{ fontWeight: filter === item.id ? 700 : 500 }}
          >
            {item.label}
          </button>
        ))}
      </div>

      {loading ? (
        <p className="muted" style={{ margin: "24px 0" }}>Đang tải danh sách lịch hẹn...</p>
      ) : rows.length === 0 ? (
        <div className="card" style={{ textAlign: "center", padding: "40px 20px", marginTop: "20px" }}>
          <p style={{ fontSize: "1.1rem", margin: "0 0 12px", color: "var(--color-muted)" }}>
            {filter ? "Không có lịch hẹn nào trong mục này." : "Bạn chưa có lịch hẹn sửa chữa nào."}
          </p>
          <Link className="btn" to="/booking">
            Đặt lịch sửa điện thoại ngay
          </Link>
        </div>
      ) : (
        <div className="result-list" style={{ marginTop: "20px" }}>
          {rows.map((row) => (
            <Link
              key={row.id}
              to={`/my-bookings/${row.id}`}
              className="card"
              style={{ display: "flex", flexDirection: "column", gap: "10px", transition: "transform 0.15s ease", cursor: "pointer" }}
            >
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <strong style={{ fontSize: "1.1rem", color: "var(--color-accent-strong)" }}>
                  {row.bookingCode}
                </strong>
                <span className={getStatusBadgeClass(row.status)}>
                  {statusLabel[row.status] ?? row.status}
                </span>
              </div>

              <div>
                <strong style={{ fontSize: "1.05rem" }}>{row.brandName} {row.phoneModelName}</strong>
                <p style={{ margin: "4px 0 0", color: "var(--color-muted)", fontSize: "0.9rem" }}>
                  📍 {row.branchName}
                </p>
                <p style={{ margin: "2px 0 0", color: "var(--color-muted)", fontSize: "0.9rem" }}>
                  ⏰ Ngày {row.appointmentDate} lúc {row.slotStart}
                </p>
              </div>

              <div style={{ borderTop: "1px solid var(--color-line)", paddingTop: "8px", marginTop: "auto", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <span style={{ fontSize: "0.9rem", color: "var(--color-muted)" }}>
                  Tạm tính: <strong style={{ color: "var(--color-ink)" }}>{new Intl.NumberFormat("vi-VN").format(row.estimatedTotal)} đ</strong>
                </span>
                <span style={{ color: "var(--color-accent)", fontWeight: 600, fontSize: "0.85rem" }}>
                  Chi tiết →
                </span>
              </div>
            </Link>
          ))}
        </div>
      )}
    </main>
  )
}
