import { useEffect, useState } from "react"
import { useNavigate } from "react-router-dom"
import { getBranches, type Branch } from "../api/branches"

interface BranchItem extends Branch {
  distance: string
  image: string
  district: string
  rating: number
  hasParking: boolean
  featuredServices: Array<{ name: string; icon: string }>
  mapCoordinates: { x: number; y: number }
}

const FALLBACK_BRANCHES: BranchItem[] = [
  {
    id: 1,
    name: "PhoneRepair Quận 1",
    address: "123 Nguyễn Huệ, Quận 1, TP.HCM",
    phone: "028 1234 5678",
    capacityPerSlot: 4,
    slotMinutes: 30,
    isActive: true,
    openingHours: [],
    distance: "2.1 km",
    image: "https://images.unsplash.com/photo-1550009158-9ebf69173e03?auto=format&fit=crop&w=400&q=80",
    district: "Quận 1",
    rating: 4.9,
    hasParking: true,
    featuredServices: [
      { name: "Thay màn hình", icon: "📱" },
      { name: "Thay pin", icon: "🔋" },
      { name: "Sửa camera", icon: "📷" },
      { name: "Sửa loa", icon: "🔊" },
      { name: "Vệ sinh máy", icon: "🪄" },
    ],
    mapCoordinates: { x: 58, y: 50 },
  },
  {
    id: 2,
    name: "PhoneRepair Quận 3",
    address: "456 Võ Thị Sáu, Quận 3, TP.HCM",
    phone: "028 2345 6789",
    capacityPerSlot: 4,
    slotMinutes: 30,
    isActive: true,
    openingHours: [],
    distance: "3.5 km",
    image: "https://images.unsplash.com/photo-1581092921461-eab62e97a780?auto=format&fit=crop&w=400&q=80",
    district: "Quận 3",
    rating: 4.8,
    hasParking: true,
    featuredServices: [
      { name: "Thay màn hình", icon: "📱" },
      { name: "Thay pin", icon: "🔋" },
      { name: "Sửa sạc", icon: "⚡" },
      { name: "Sửa Face ID", icon: "⊡" },
      { name: "Vệ sinh máy", icon: "🪄" },
    ],
    mapCoordinates: { x: 49, y: 48 },
  },
  {
    id: 3,
    name: "PhoneRepair Quận 7",
    address: "789 Nguyễn Văn Linh, Quận 7, TP.HCM",
    phone: "028 3456 7890",
    capacityPerSlot: 4,
    slotMinutes: 30,
    isActive: true,
    openingHours: [],
    distance: "5.3 km",
    image: "https://images.unsplash.com/photo-1517430816045-df4b7de81d39?auto=format&fit=crop&w=400&q=80",
    district: "Quận 7",
    rating: 4.9,
    hasParking: true,
    featuredServices: [
      { name: "Thay màn hình", icon: "📱" },
      { name: "Thay pin", icon: "🔋" },
      { name: "Sửa loa", icon: "🔊" },
      { name: "Vệ sinh máy", icon: "🪄" },
    ],
    mapCoordinates: { x: 81, y: 60 },
  },
  {
    id: 4,
    name: "PhoneRepair Thủ Đức",
    address: "789 Võ Văn Ngân, TP. Thủ Đức, TP.HCM",
    phone: "028 3456 7890",
    capacityPerSlot: 4,
    slotMinutes: 30,
    isActive: true,
    openingHours: [],
    distance: "7.8 km",
    image: "https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=400&q=80",
    district: "TP. Thủ Đức",
    rating: 4.8,
    hasParking: true,
    featuredServices: [
      { name: "Thay màn hình", icon: "📱" },
      { name: "Thay pin", icon: "🔋" },
      { name: "Sửa camera", icon: "📷" },
      { name: "Sửa micro", icon: "🎙️" },
    ],
    mapCoordinates: { x: 80, y: 17 },
  },
  {
    id: 5,
    name: "PhoneRepair Tân Bình",
    address: "321 Cộng Hòa, Quận Tân Bình, TP.HCM",
    phone: "028 6789 1234",
    capacityPerSlot: 4,
    slotMinutes: 30,
    isActive: true,
    openingHours: [],
    distance: "6.2 km",
    image: "https://images.unsplash.com/photo-1512496015851-a90fb38ba796?auto=format&fit=crop&w=400&q=80",
    district: "Tân Bình",
    rating: 4.7,
    hasParking: true,
    featuredServices: [
      { name: "Thay màn hình", icon: "📱" },
      { name: "Thay pin", icon: "🔋" },
      { name: "Vệ sinh máy", icon: "🪄" },
    ],
    mapCoordinates: { x: 34, y: 35 },
  },
  {
    id: 6,
    name: "PhoneRepair Gò Vấp",
    address: "654 Quang Trung, Quận Gò Vấp, TP.HCM",
    phone: "028 6789 5678",
    capacityPerSlot: 4,
    slotMinutes: 30,
    isActive: true,
    openingHours: [],
    distance: "8.1 km",
    image: "https://images.unsplash.com/photo-1519389950473-47ba0277781c?auto=format&fit=crop&w=400&q=80",
    district: "Gò Vấp",
    rating: 4.8,
    hasParking: true,
    featuredServices: [
      { name: "Thay màn hình", icon: "📱" },
      { name: "Thay pin", icon: "🔋" },
      { name: "Sửa loa", icon: "🔊" },
      { name: "Sửa sạc", icon: "⚡" },
    ],
    mapCoordinates: { x: 45, y: 16 },
  },
]

export function BranchesPage() {
  const navigate = useNavigate()
  const [branches, setBranches] = useState<BranchItem[]>(FALLBACK_BRANCHES)
  const [selectedBranchId, setSelectedBranchId] = useState<number>(1)
  const [searchKeyword, setSearchKeyword] = useState("")
  const [selectedCity, setSelectedCity] = useState("TP. Hồ Chí Minh")
  const [selectedService, setSelectedService] = useState("all")
  const [mapMode, setMapMode] = useState<"map" | "satellite">("map")
  const [zoomLevel, setZoomLevel] = useState(1)

  useEffect(() => {
    getBranches()
      .then((serverBranches) => {
        if (serverBranches && serverBranches.length > 0) {
          const enriched: BranchItem[] = serverBranches.map((b, index) => {
            const fallback = FALLBACK_BRANCHES.find((f) => f.id === b.id) || FALLBACK_BRANCHES[index % FALLBACK_BRANCHES.length]
            return {
              ...b,
              distance: fallback?.distance || `${(index + 1) * 2}.1 km`,
              image: fallback?.image || FALLBACK_BRANCHES[0].image,
              district: fallback?.district || "TP.HCM",
              rating: fallback?.rating || 4.9,
              hasParking: fallback?.hasParking ?? true,
              featuredServices: fallback?.featuredServices || FALLBACK_BRANCHES[0].featuredServices,
              mapCoordinates: fallback?.mapCoordinates || { x: 30 + (index % 4) * 15, y: 30 + (index % 3) * 15 },
            }
          })
          setBranches(enriched)
          if (enriched[0]) setSelectedBranchId(enriched[0].id)
        }
      })
      .catch(() => {})
  }, [])

  const filteredBranches = branches.filter((b) => {
    const matchKeyword =
      b.name.toLowerCase().includes(searchKeyword.toLowerCase()) ||
      b.address.toLowerCase().includes(searchKeyword.toLowerCase()) ||
      b.district.toLowerCase().includes(searchKeyword.toLowerCase())
    return matchKeyword
  })

  const selectedBranch = branches.find((b) => b.id === selectedBranchId) || branches[0] || FALLBACK_BRANCHES[0]

  const handleSelectBranch = (branchId: number) => {
    setSelectedBranchId(branchId)
  }

  const handleBookAtBranch = (branchId: number) => {
    navigate(`/booking?branchId=${branchId}`)
  }

  return (
    <main style={{ background: "#f8fafc", minHeight: "100vh", paddingBottom: "50px" }}>
      {/* 1. HERO HEADER WITH SAIGON SKYLINE BACKGROUND (MATCHING SCREENSHOT) */}
      <section
        style={{
          background: "linear-gradient(180deg, rgba(239, 246, 255, 0.90) 0%, rgba(248, 250, 252, 0.96) 100%), url('https://images.unsplash.com/photo-1583417319070-4a69db38a482?auto=format&fit=crop&w=1600&q=80') center/cover no-repeat",
          padding: "44px 20px 36px",
          borderBottom: "1px solid #e2e8f0",
          marginBottom: "24px",
        }}
      >
        <div style={{ maxWidth: "1340px", margin: "0 auto" }}>
          <h1 style={{ fontSize: "2.35rem", fontWeight: 800, color: "#0f172a", margin: "0 0 10px", letterSpacing: "-0.03em" }}>
            Hệ thống chi nhánh PhoneRepair
          </h1>
          <p style={{ fontSize: "1rem", color: "#475569", margin: "0 0 28px", lineHeight: 1.5 }}>
            Tìm chi nhánh gần bạn nhất tại TP. Hồ Chí Minh để được hỗ trợ nhanh chóng, chuyên nghiệp
          </p>

          {/* 4 FEATURE PILLS IN A ROW */}
          <div style={{ display: "flex", flexWrap: "wrap", gap: "16px" }}>
            {/* Pill 1 */}
            <div
              style={{
                background: "#ffffff",
                border: "1px solid #e2e8f0",
                borderRadius: "999px",
                padding: "8px 18px",
                display: "flex",
                alignItems: "center",
                gap: "10px",
                boxShadow: "0 2px 6px rgba(15,23,42,0.03)",
              }}
            >
              <div style={{ width: "26px", height: "26px", borderRadius: "50%", background: "#eff6ff", color: "#2563eb", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "0.85rem" }}>
                📍
              </div>
              <div style={{ fontSize: "0.86rem" }}>
                <strong style={{ color: "#0f172a" }}>Nhiều chi nhánh</strong>
                <span style={{ color: "#64748b", marginLeft: "6px" }}>thuận tiện di chuyển</span>
              </div>
            </div>

            {/* Pill 2 */}
            <div
              style={{
                background: "#ffffff",
                border: "1px solid #e2e8f0",
                borderRadius: "999px",
                padding: "8px 18px",
                display: "flex",
                alignItems: "center",
                gap: "10px",
                boxShadow: "0 2px 6px rgba(15,23,42,0.03)",
              }}
            >
              <div style={{ width: "26px", height: "26px", borderRadius: "50%", background: "#eff6ff", color: "#0284c7", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "0.85rem" }}>
                🕒
              </div>
              <div style={{ fontSize: "0.86rem" }}>
                <strong style={{ color: "#0f172a" }}>Giờ mở cửa linh hoạt</strong>
                <span style={{ color: "#64748b", marginLeft: "6px" }}>8:00 - 20:00 hàng ngày</span>
              </div>
            </div>

            {/* Pill 3 */}
            <div
              style={{
                background: "#ffffff",
                border: "1px solid #e2e8f0",
                borderRadius: "999px",
                padding: "8px 18px",
                display: "flex",
                alignItems: "center",
                gap: "10px",
                boxShadow: "0 2px 6px rgba(15,23,42,0.03)",
              }}
            >
              <div style={{ width: "26px", height: "26px", borderRadius: "50%", background: "#eff6ff", color: "#16a34a", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "0.85rem" }}>
                🛡️
              </div>
              <div style={{ fontSize: "0.86rem" }}>
                <strong style={{ color: "#0f172a" }}>Kỹ thuật viên chuyên nghiệp</strong>
                <span style={{ color: "#64748b", marginLeft: "6px" }}>Tại tất cả chi nhánh</span>
              </div>
            </div>

            {/* Pill 4 */}
            <div
              style={{
                background: "#ffffff",
                border: "1px solid #e2e8f0",
                borderRadius: "999px",
                padding: "8px 18px",
                display: "flex",
                alignItems: "center",
                gap: "10px",
                boxShadow: "0 2px 6px rgba(15,23,42,0.03)",
              }}
            >
              <div style={{ width: "26px", height: "26px", borderRadius: "50%", background: "#fef9c3", color: "#eab308", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "0.85rem" }}>
                ⭐
              </div>
              <div style={{ fontSize: "0.86rem" }}>
                <strong style={{ color: "#0f172a" }}>Dịch vụ đồng nhất</strong>
                <span style={{ color: "#64748b", marginLeft: "6px" }}>Chất lượng toàn hệ thống</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 2. SEARCH & FILTER TOOLBAR (MATCHING SCREENSHOT) */}
      <div style={{ maxWidth: "1340px", margin: "0 auto 24px", padding: "0 20px" }}>
        <div
          style={{
            background: "#ffffff",
            border: "1px solid #e2e8f0",
            borderRadius: "16px",
            padding: "12px 16px",
            display: "grid",
            gridTemplateColumns: "2.4fr 1.3fr 1.3fr 1fr",
            gap: "14px",
            alignItems: "center",
            boxShadow: "0 4px 14px rgba(15,23,42,0.03)",
          }}
        >
          {/* SEARCH INPUT */}
          <div style={{ position: "relative", display: "flex", alignItems: "center" }}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#94a3b8" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" style={{ position: "absolute", left: "14px" }}>
              <circle cx="11" cy="11" r="8" />
              <line x1="21" y1="21" x2="16.65" y2="16.65" />
            </svg>
            <input
              type="text"
              placeholder="Tìm kiếm chi nhánh, quận, địa chỉ..."
              value={searchKeyword}
              onChange={(e) => setSearchKeyword(e.target.value)}
              style={{
                width: "100%",
                height: "44px",
                padding: "0 14px 0 42px",
                borderRadius: "10px",
                border: "1px solid #cbd5e1",
                background: "#f8fafc",
                fontSize: "0.88rem",
                color: "#0f172a",
                outline: "none",
              }}
            />
          </div>

          {/* CITY DROPDOWN */}
          <div style={{ position: "relative" }}>
            <select
              value={selectedCity}
              onChange={(e) => setSelectedCity(e.target.value)}
              style={{
                width: "100%",
                height: "44px",
                padding: "0 14px",
                borderRadius: "10px",
                border: "1px solid #cbd5e1",
                background: "#f8fafc",
                fontSize: "0.88rem",
                color: "#0f172a",
                fontWeight: 600,
                outline: "none",
                cursor: "pointer",
              }}
            >
              <option value="TP. Hồ Chí Minh">📍 TP. Hồ Chí Minh</option>
              <option value="Hà Nội">📍 Hà Nội</option>
              <option value="Đà Nẵng">📍 Đà Nẵng</option>
            </select>
          </div>

          {/* SERVICE DROPDOWN */}
          <div style={{ position: "relative" }}>
            <select
              value={selectedService}
              onChange={(e) => setSelectedService(e.target.value)}
              style={{
                width: "100%",
                height: "44px",
                padding: "0 14px",
                borderRadius: "10px",
                border: "1px solid #cbd5e1",
                background: "#f8fafc",
                fontSize: "0.88rem",
                color: "#0f172a",
                fontWeight: 600,
                outline: "none",
                cursor: "pointer",
              }}
            >
              <option value="all">⚙️ Tất cả dịch vụ</option>
              <option value="screen">Thay màn hình</option>
              <option value="battery">Thay pin</option>
              <option value="camera">Sửa camera</option>
              <option value="clean">Vệ sinh máy</option>
            </select>
          </div>

          {/* SEARCH BUTTON */}
          <button
            type="button"
            style={{
              height: "44px",
              padding: "0 24px",
              borderRadius: "10px",
              background: "#2563eb",
              color: "#ffffff",
              border: "none",
              fontWeight: 700,
              fontSize: "0.9rem",
              cursor: "pointer",
              boxShadow: "0 2px 8px rgba(37,99,235,0.25)",
              whiteSpace: "nowrap",
            }}
          >
            Tìm chi nhánh
          </button>
        </div>
      </div>

      {/* 3. MAIN 2-COLUMN SPLIT VIEW: LIST (LEFT) & MAP + DETAILS (RIGHT) */}
      <div style={{ maxWidth: "1340px", margin: "0 auto", padding: "0 20px" }}>
        <div style={{ display: "grid", gridTemplateColumns: "520px 1fr", gap: "24px", alignItems: "flex-start" }}>
          {/* LEFT LIST COLUMN */}
          <div>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "14px" }}>
              <strong style={{ fontSize: "1.05rem", color: "#0f172a" }}>
                Danh sách chi nhánh tại TP. Hồ Chí Minh ({filteredBranches.length} chi nhánh)
              </strong>
              <span style={{ fontSize: "0.84rem", color: "#64748b" }}>
                Sắp xếp: <strong style={{ color: "#0f172a" }}>Gần nhất ⌄</strong>
              </span>
            </div>

            <div style={{ display: "flex", flexDirection: "column", gap: "14px" }}>
              {filteredBranches.map((b) => {
                const isSelected = b.id === selectedBranchId
                return (
                  <article
                    key={b.id}
                    onClick={() => handleSelectBranch(b.id)}
                    style={{
                      background: "#ffffff",
                      border: isSelected ? "1.5px solid #2563eb" : "1px solid #e2e8f0",
                      borderRadius: "16px",
                      padding: "14px",
                      display: "flex",
                      gap: "14px",
                      boxShadow: isSelected ? "0 4px 16px rgba(37,99,235,0.12)" : "0 2px 8px rgba(15,23,42,0.02)",
                      cursor: "pointer",
                      transition: "all 0.15s ease",
                    }}
                  >
                    <img
                      src={b.image}
                      alt={b.name}
                      style={{
                        width: "115px",
                        height: "90px",
                        borderRadius: "10px",
                        objectFit: "cover",
                        flexShrink: 0,
                      }}
                    />

                    <div style={{ flex: 1, display: "flex", flexDirection: "column", justifyContent: "space-between" }}>
                      <div>
                        <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: "8px", marginBottom: "4px" }}>
                          <h2 style={{ fontSize: "0.98rem", fontWeight: 800, color: "#0f172a", margin: 0 }}>
                            {b.name}
                          </h2>
                          <span
                            style={{
                              fontSize: "0.76rem",
                              fontWeight: 700,
                              color: "#2563eb",
                              background: "#eff6ff",
                              padding: "2px 8px",
                              borderRadius: "6px",
                              display: "inline-flex",
                              alignItems: "center",
                              gap: "3px",
                              whiteSpace: "nowrap",
                            }}
                          >
                            ↗ {b.distance}
                          </span>
                        </div>

                        <div style={{ fontSize: "0.78rem", color: "#64748b", display: "flex", flexDirection: "column", gap: "2px" }}>
                          <div>📍 {b.address}</div>
                          <div>🕒 08:00 - 20:00 (T2 - CN)</div>
                          <div>📞 {b.phone}</div>
                        </div>
                      </div>

                      <div style={{ display: "flex", gap: "8px", marginTop: "10px" }}>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation()
                            handleSelectBranch(b.id)
                          }}
                          style={{
                            padding: "6px 14px",
                            borderRadius: "8px",
                            background: "#2563eb",
                            color: "#ffffff",
                            border: "none",
                            fontSize: "0.78rem",
                            fontWeight: 700,
                            cursor: "pointer",
                          }}
                        >
                          Xem chi tiết
                        </button>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation()
                            handleBookAtBranch(b.id)
                          }}
                          style={{
                            padding: "6px 14px",
                            borderRadius: "8px",
                            background: "#ffffff",
                            color: "#2563eb",
                            border: "1px solid #cbd5e1",
                            fontSize: "0.78rem",
                            fontWeight: 700,
                            cursor: "pointer",
                            display: "inline-flex",
                            alignItems: "center",
                            gap: "4px",
                          }}
                        >
                          <span>↗</span>
                          <span>Chọn chi nhánh</span>
                        </button>
                      </div>
                    </div>
                  </article>
                )
              })}
            </div>
          </div>

          {/* RIGHT MAP COLUMN WITH STYLED PINS & FLOATING PREVIEW CARD */}
          <div
            style={{
              background: "#ffffff",
              border: "1px solid #e2e8f0",
              borderRadius: "18px",
              overflow: "hidden",
              boxShadow: "0 2px 10px rgba(15,23,42,0.03)",
            }}
          >
            {/* MAP CANVAS AREA */}
            <div style={{ position: "relative", width: "100%", height: "360px", overflow: "hidden", background: "#e8f1f5" }}>
              {/* MAP TABS (BẢN ĐỒ / VỆ TINH) */}
              <div
                style={{
                  position: "absolute",
                  top: "14px",
                  left: "14px",
                  zIndex: 20,
                  background: "#ffffff",
                  borderRadius: "8px",
                  padding: "3px",
                  display: "flex",
                  boxShadow: "0 2px 8px rgba(0,0,0,0.12)",
                }}
              >
                <button
                  type="button"
                  onClick={() => setMapMode("map")}
                  style={{
                    padding: "4px 12px",
                    borderRadius: "6px",
                    border: "none",
                    background: mapMode === "map" ? "#2563eb" : "transparent",
                    color: mapMode === "map" ? "#ffffff" : "#475569",
                    fontSize: "0.78rem",
                    fontWeight: 700,
                    cursor: "pointer",
                  }}
                >
                  Bản đồ
                </button>
                <button
                  type="button"
                  onClick={() => setMapMode("satellite")}
                  style={{
                    padding: "4px 12px",
                    borderRadius: "6px",
                    border: "none",
                    background: mapMode === "satellite" ? "#2563eb" : "transparent",
                    color: mapMode === "satellite" ? "#ffffff" : "#475569",
                    fontSize: "0.78rem",
                    fontWeight: 700,
                    cursor: "pointer",
                  }}
                >
                  Vệ tinh
                </button>
              </div>

              {/* MAP ZOOM CONTROLS */}
              <div
                style={{
                  position: "absolute",
                  bottom: "16px",
                  right: "14px",
                  zIndex: 20,
                  background: "#ffffff",
                  borderRadius: "8px",
                  boxShadow: "0 4px 12px rgba(0,0,0,0.15)",
                  display: "flex",
                  flexDirection: "column",
                  overflow: "hidden",
                }}
              >
                <button
                  type="button"
                  onClick={() => setZoomLevel((z) => Math.min(z + 0.15, 1.45))}
                  style={{ width: "32px", height: "32px", border: "none", background: "#ffffff", fontSize: "1.1rem", cursor: "pointer", color: "#334155" }}
                  title="Phóng to"
                >
                  +
                </button>
                <div style={{ height: "1px", background: "#e2e8f0" }} />
                <button
                  type="button"
                  onClick={() => setZoomLevel((z) => Math.max(z - 0.15, 0.85))}
                  style={{ width: "32px", height: "32px", border: "none", background: "#ffffff", fontSize: "1.1rem", cursor: "pointer", color: "#334155" }}
                  title="Thu nhỏ"
                >
                  −
                </button>
                <div style={{ height: "1px", background: "#e2e8f0" }} />
                <button
                  type="button"
                  onClick={() => setZoomLevel(1)}
                  style={{ width: "32px", height: "32px", border: "none", background: "#ffffff", fontSize: "0.95rem", cursor: "pointer", color: "#2563eb" }}
                  title="Định vị"
                >
                  ⌖
                </button>
              </div>

              {/* VECTOR MAP SVG BACKGROUND (TP.HCM SAIGON RIVER & HIGHWAYS) */}
              <div
                style={{
                  position: "absolute",
                  inset: 0,
                  transform: `scale(${zoomLevel})`,
                  transformOrigin: "center center",
                  transition: "transform 0.25s ease",
                  background: mapMode === "map" ? "#edf5f9" : "#1a2c3a",
                }}
              >
                <svg width="100%" height="100%" viewBox="0 0 800 800" preserveAspectRatio="none">
                  {/* SAIGON RIVER PATH (MATCHING SCREENSHOT) */}
                  <path
                    d="M 50,180 Q 150,130 260,200 T 450,270 T 600,190 T 780,250 T 680,440 T 610,600 T 520,780"
                    fill="none"
                    stroke="#98d2f2"
                    strokeWidth="48"
                    strokeLinecap="round"
                  />
                  <path
                    d="M 260,200 Q 310,310 290,470 T 410,590"
                    fill="none"
                    stroke="#b5e1f7"
                    strokeWidth="28"
                  />

                  {/* ROAD NETWORKS */}
                  <line x1="0" y1="160" x2="800" y2="380" stroke="#ffffff" strokeWidth="6" />
                  <line x1="180" y1="0" x2="340" y2="800" stroke="#ffffff" strokeWidth="8" />
                  <line x1="0" y1="510" x2="800" y2="470" stroke="#ffffff" strokeWidth="10" />
                  <line x1="470" y1="0" x2="510" y2="800" stroke="#ffffff" strokeWidth="7" />
                  <line x1="80" y1="690" x2="710" y2="190" stroke="#ffffff" strokeWidth="5" />

                  {/* DISTRICT LABELS */}
                  <text x="340" y="560" fill="#64748b" fontSize="19" fontWeight="bold">
                    TP. Hồ Chí Minh
                  </text>
                  <text x="590" y="340" fill="#94a3b8" fontSize="13">Bình Thạnh</text>
                  <text x="700" y="380" fill="#94a3b8" fontSize="13">TP. Thủ Đức</text>
                  <text x="620" y="630" fill="#94a3b8" fontSize="13">PHÚ MỸ HƯNG</text>
                  <text x="595" y="440" fill="#94a3b8" fontSize="13">Quận 1</text>
                  <text x="550" y="505" fill="#94a3b8" fontSize="13">Quận 4</text>
                  <text x="490" y="525" fill="#94a3b8" fontSize="13">Quận 10</text>
                  <text x="490" y="545" fill="#94a3b8" fontSize="13">Quận 5</text>
                  <text x="440" y="480" fill="#94a3b8" fontSize="13">Quận 3</text>
                  <text x="210" y="340" fill="#94a3b8" fontSize="13">✈️ Sân bay Tân Sơn Nhất</text>
                </svg>

                {/* MAP PINS */}
                {branches.map((b) => {
                  const isSelected = b.id === selectedBranchId
                  return (
                    <div
                      key={b.id}
                      onClick={() => handleSelectBranch(b.id)}
                      style={{
                        position: "absolute",
                        left: `${b.mapCoordinates.x}%`,
                        top: `${b.mapCoordinates.y}%`,
                        transform: "translate(-50%, -100%)",
                        cursor: "pointer",
                        zIndex: isSelected ? 15 : 10,
                        display: "flex",
                        alignItems: "center",
                        gap: "6px",
                        transition: "all 0.2s ease",
                      }}
                    >
                      <div
                        style={{
                          background: isSelected ? "#ef4444" : "#2563eb",
                          color: "#ffffff",
                          padding: "5px 12px",
                          borderRadius: "20px",
                          fontSize: "0.82rem",
                          fontWeight: 700,
                          boxShadow: isSelected ? "0 8px 20px rgba(239,68,68,0.45)" : "0 4px 12px rgba(37,99,235,0.3)",
                          display: "flex",
                          alignItems: "center",
                          gap: "6px",
                          border: "2px solid #ffffff",
                          transform: isSelected ? "scale(1.15)" : "scale(1)",
                        }}
                      >
                        <svg width="12" height="12" viewBox="0 0 24 24" fill="white">
                          <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z" />
                        </svg>
                        <span>{b.district}</span>
                      </div>
                    </div>
                  )
                })}
              </div>
            </div>

            {/* DOCKED SELECTED BRANCH CARD AT BOTTOM (MATCHING SCREENSHOT) */}
            {selectedBranch && (
              <div style={{ padding: "20px", borderTop: "1px solid #e2e8f0", background: "#ffffff" }}>
                <div style={{ display: "grid", gridTemplateColumns: "150px 1fr", gap: "20px", alignItems: "flex-start", marginBottom: "16px" }}>
                  <img
                    src={selectedBranch.image}
                    alt={selectedBranch.name}
                    style={{
                      width: "150px",
                      height: "115px",
                      borderRadius: "12px",
                      objectFit: "cover",
                    }}
                  />

                  <div>
                    <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "8px" }}>
                      <h3 style={{ fontSize: "1.2rem", fontWeight: 800, margin: 0, color: "#0f172a" }}>
                        {selectedBranch.name}
                      </h3>
                      <span
                        style={{
                          background: "#eff6ff",
                          color: "#2563eb",
                          fontSize: "0.76rem",
                          fontWeight: 700,
                          padding: "3px 10px",
                          borderRadius: "999px",
                          border: "1px solid #bfdbfe",
                          display: "inline-flex",
                          alignItems: "center",
                          gap: "4px",
                        }}
                      >
                        📍 Chi nhánh gần bạn
                      </span>
                    </div>

                    <div style={{ display: "flex", flexWrap: "wrap", gap: "14px", fontSize: "0.82rem", color: "#64748b", marginBottom: "8px" }}>
                      <div>📍 {selectedBranch.address}</div>
                      <div>↗ Cách bạn {selectedBranch.distance}</div>
                    </div>
                    <div style={{ display: "flex", flexWrap: "wrap", gap: "14px", fontSize: "0.82rem", color: "#64748b", marginBottom: "8px" }}>
                      <div>🕒 08:00 - 20:00 (Thứ 2 - Chủ nhật)</div>
                      <div>📞 {selectedBranch.phone}</div>
                      <span style={{ color: "#0284c7", background: "#f0f9ff", border: "1px solid #bae6fd", padding: "2px 8px", borderRadius: "6px", fontSize: "0.75rem", fontWeight: 600 }}>
                        🚗 Có chỗ đỗ xe
                      </span>
                    </div>
                  </div>
                </div>

                {/* 5 HIGHLIGHT SERVICES OF THIS BRANCH */}
                <div style={{ marginBottom: "18px" }}>
                  <span style={{ fontSize: "0.82rem", fontWeight: 700, color: "#0f172a", display: "block", marginBottom: "8px" }}>
                    Dịch vụ nổi bật tại chi nhánh này:
                  </span>
                  <div style={{ display: "flex", gap: "10px", overflowX: "auto" }}>
                    {selectedBranch.featuredServices.map((svc, i) => (
                      <div
                        key={i}
                        style={{
                          width: "90px",
                          height: "72px",
                          background: "#f8fafc",
                          border: "1px solid #e2e8f0",
                          borderRadius: "10px",
                          display: "flex",
                          flexDirection: "column",
                          alignItems: "center",
                          justifyContent: "center",
                          gap: "4px",
                          flexShrink: 0,
                        }}
                      >
                        <span style={{ fontSize: "1.25rem" }}>{svc.icon}</span>
                        <span style={{ fontSize: "0.72rem", color: "#334155", fontWeight: 600, textAlign: "center" }}>
                          {svc.name}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* 2 ACTION BUTTONS */}
                <div style={{ display: "flex", gap: "12px" }}>
                  <button
                    type="button"
                    onClick={() => handleSelectBranch(selectedBranch.id)}
                    style={{
                      flex: 1,
                      height: "40px",
                      borderRadius: "10px",
                      border: "1px solid #cbd5e1",
                      background: "#ffffff",
                      fontSize: "0.86rem",
                      fontWeight: 700,
                      color: "#2563eb",
                      cursor: "pointer",
                      display: "inline-flex",
                      alignItems: "center",
                      justifyContent: "center",
                      gap: "6px",
                    }}
                  >
                    <span>⛶</span>
                    <span>Xem chi tiết chi nhánh</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleBookAtBranch(selectedBranch.id)}
                    style={{
                      flex: 1,
                      height: "40px",
                      borderRadius: "10px",
                      border: "none",
                      background: "#2563eb",
                      color: "#ffffff",
                      fontSize: "0.86rem",
                      fontWeight: 700,
                      cursor: "pointer",
                      display: "inline-flex",
                      alignItems: "center",
                      justifyContent: "center",
                      gap: "8px",
                      boxShadow: "0 4px 12px rgba(37,99,235,0.3)",
                    }}
                  >
                    <span>📅</span>
                    <span>Chọn chi nhánh này</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </main>
  )
}
