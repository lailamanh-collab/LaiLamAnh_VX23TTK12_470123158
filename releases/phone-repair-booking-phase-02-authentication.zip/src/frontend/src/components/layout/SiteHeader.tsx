import { NavLink } from "react-router-dom"
import { useAuth } from "../../auth/AuthContext"

export function SiteHeader() {
  const { user, logout } = useAuth()

  return (
    <header className="site-header">
      <div className="site-header-inner">
        <NavLink to="/" className="brand">
          <span className="brand-mark" aria-hidden="true" />
          PhoneRepair
        </NavLink>
        <nav className="nav" aria-label="Điều hướng chính">
          <NavLink to="/" end className={({ isActive }) => (isActive ? "nav-link nav-link-active" : "nav-link")}>
            Trang chủ
          </NavLink>
          {user ? (
            <>
              {user.role === "Admin" ? (
                <NavLink to="/quan-tri" className={({ isActive }) => (isActive ? "nav-link nav-link-active" : "nav-link")}>
                  Quản trị
                </NavLink>
              ) : null}
              {user.role === "Technician" ? (
                <NavLink to="/ky-thuat-vien" className={({ isActive }) => (isActive ? "nav-link nav-link-active" : "nav-link")}>
                  Công việc
                </NavLink>
              ) : null}
              <NavLink to="/ho-so" className={({ isActive }) => (isActive ? "nav-link nav-link-active" : "nav-link")}>
                {user.fullName}
              </NavLink>
              <button className="btn btn-quiet" type="button" onClick={logout}>
                Đăng xuất
              </button>
            </>
          ) : (
            <>
              <NavLink to="/dang-nhap" className={({ isActive }) => (isActive ? "nav-link nav-link-active" : "nav-link")}>
                Đăng nhập
              </NavLink>
              <NavLink to="/dang-ky" className="btn">
                Đăng ký
              </NavLink>
            </>
          )}
        </nav>
      </div>
    </header>
  )
}
