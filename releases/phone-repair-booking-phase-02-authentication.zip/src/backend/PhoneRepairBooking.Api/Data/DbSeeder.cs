using Microsoft.AspNetCore.Identity;
using PhoneRepairBooking.Api.Domain;

namespace PhoneRepairBooking.Api.Data;

public static class DbSeeder
{
    public static async Task SeedAsync(IServiceProvider services)
    {
        var roles = services.GetRequiredService<RoleManager<IdentityRole>>();
        var users = services.GetRequiredService<UserManager<ApplicationUser>>();

        foreach (var role in AppRoles.All)
        {
            if (!await roles.RoleExistsAsync(role))
            {
                await roles.CreateAsync(new IdentityRole(role));
            }
        }

        await EnsureUserAsync(users, "admin@phonerepair.local", "Quản trị viên", "0901000001", "Admin@12345", AppRoles.Admin);
        await EnsureUserAsync(users, "technician@phonerepair.local", "Kỹ thuật viên demo", "0901000002", "Tech@12345", AppRoles.Technician);
        await EnsureUserAsync(users, "customer@phonerepair.local", "Khách hàng demo", "0901000003", "Customer@12345", AppRoles.Customer);
    }

    private static async Task EnsureUserAsync(
        UserManager<ApplicationUser> users,
        string email,
        string fullName,
        string phone,
        string password,
        string role)
    {
        var user = await users.FindByEmailAsync(email);
        if (user is null)
        {
            user = new ApplicationUser
            {
                UserName = email,
                Email = email,
                FullName = fullName,
                PhoneNumber = phone,
                EmailConfirmed = true,
                IsActive = true,
                CreatedAt = DateTime.UtcNow
            };
            var created = await users.CreateAsync(user, password);
            if (!created.Succeeded)
            {
                throw new InvalidOperationException($"Cannot seed {email}.");
            }
        }

        if (!await users.IsInRoleAsync(user, role))
        {
            await users.AddToRoleAsync(user, role);
        }
    }
}
