import { NavLink } from "react-router-dom"
import { useAuth } from "../../auth/AuthContext"

export function SiteHeader() {
  const { user, logout } = useAuth()

  return (
    <header className="site-header">
      <div className="site-header-inner">
        <NavLink to="/" className="brand">
          <span className="brand-mark" aria-hidden="true" />
          PhoneRepair
        </NavLink>
        <nav className="nav" aria-label="Điều hướng chính">
          <NavLink to="/" end className={({ isActive }) => (isActive ? "nav-link nav-link-active" : "nav-link")}>
            Trang chủ
          </NavLink>
          <NavLink to="/dich-vu" className={({ isActive }) => (isActive ? "nav-link nav-link-active" : "nav-link")}>
            Dịch vụ
          </NavLink>
          <NavLink to="/hang" className={({ isActive }) => (isActive ? "nav-link nav-link-active" : "nav-link")}>
            Hãng
          </NavLink>
          <NavLink to="/dong-may" className={({ isActive }) => (isActive ? "nav-link nav-link-active" : "nav-link")}>
            Dòng máy
          </NavLink>
          <NavLink to="/chi-nhanh" className={({ isActive }) => (isActive ? "nav-link nav-link-active" : "nav-link")}>
            Chi nhánh
          </NavLink>
          <NavLink to="/dat-lich" className={({ isActive }) => (isActive ? "nav-link nav-link-active" : "nav-link")}>
            Đặt lịch
          </NavLink>
          {user ? (
            <>
              {user.role === "Admin" ? (
                <>
                  <NavLink to="/quan-tri/lich-hen" className={({ isActive }) => (isActive ? "nav-link nav-link-active" : "nav-link")}>
                    Lịch hẹn
                  </NavLink>
                  <NavLink to="/quan-tri/khach-hang" className={({ isActive }) => (isActive ? "nav-link nav-link-active" : "nav-link")}>
                    Khách hàng
                  </NavLink>
                  <NavLink to="/quan-tri/cua-hang" className={({ isActive }) => (isActive ? "nav-link nav-link-active" : "nav-link")}>
                    Cửa hàng
                  </NavLink>
                  <NavLink to="/quan-tri/danh-muc" className={({ isActive }) => (isActive ? "nav-link nav-link-active" : "nav-link")}>
                    Danh mục
                  </NavLink>
                </>
              ) : null}
              {user.role === "Customer" ? (
                <NavLink to="/lich-cua-toi" className={({ isActive }) => (isActive ? "nav-link nav-link-active" : "nav-link")}>
                  Lịch của tôi
                </NavLink>
              ) : null}
              {user.role === "Technician" ? (
                <NavLink to="/ky-thuat-vien" className={({ isActive }) => (isActive ? "nav-link nav-link-active" : "nav-link")}>
                  Công việc
                </NavLink>
              ) : null}
              <NavLink to="/ho-so" className={({ isActive }) => (isActive ? "nav-link nav-link-active" : "nav-link")}>
                {user.fullName}
              </NavLink>
              <button className="btn btn-quiet" type="button" onClick={logout}>
                Đăng xuất
              </button>
            </>
          ) : (
            <>
              <NavLink to="/dang-nhap" className={({ isActive }) => (isActive ? "nav-link nav-link-active" : "nav-link")}>
                Đăng nhập
              </NavLink>
              <NavLink to="/dang-ky" className="btn">
                Đăng ký
              </NavLink>
            </>
          )}
        </nav>
      </div>
    </header>
  )
}
