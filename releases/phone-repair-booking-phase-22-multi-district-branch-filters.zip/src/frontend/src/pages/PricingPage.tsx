import { useState } from "react"
import { Link, useNavigate, useSearchParams } from "react-router-dom"
import { iphone16, heroRepair, workshopBg, branchCauGiay, BRAND_LOGOS } from "../assets"

interface PricingRow {
  modelName: string
  modelId?: number
  screenType: string
  badgeLabel: string
  price: number
  warranty: string
  duration: string
}

const DEFAULT_SERIES_PRICES: Record<string, PricingRow[]> = {
  // Apple
  "iPhone 16 Series": [
    { modelName: "iPhone 16 Pro Max", screenType: "Màn hình chính hãng Super Retina XDR", badgeLabel: "Apple", price: 7500000, warranty: "12 tháng", duration: "60 - 90 phút" },
    { modelName: "iPhone 16 Pro", screenType: "Màn hình chính hãng Super Retina XDR", badgeLabel: "Apple", price: 6500000, warranty: "12 tháng", duration: "60 - 90 phút" },
    { modelName: "iPhone 16 Plus", screenType: "Màn hình chính hãng Super Retina XDR", badgeLabel: "Apple", price: 5500000, warranty: "12 tháng", duration: "45 - 60 phút" },
    { modelName: "iPhone 16", screenType: "Màn hình chính hãng Super Retina XDR", badgeLabel: "Apple", price: 4500000, warranty: "12 tháng", duration: "45 - 60 phút" },
  ],
  "iPhone 15 Series": [
    { modelName: "iPhone 15 Pro Max", screenType: "Màn hình chính hãng OLED", badgeLabel: "Apple", price: 6800000, warranty: "12 tháng", duration: "60 - 90 phút" },
    { modelName: "iPhone 15 Pro", screenType: "Màn hình chính hãng OLED", badgeLabel: "Apple", price: 5800000, warranty: "12 tháng", duration: "60 - 90 phút" },
    { modelName: "iPhone 15 Plus", screenType: "Màn hình chính hãng OLED", badgeLabel: "Apple", price: 4800000, warranty: "12 tháng", duration: "45 - 60 phút" },
    { modelName: "iPhone 15", screenType: "Màn hình chính hãng OLED", badgeLabel: "Apple", price: 3900000, warranty: "12 tháng", duration: "45 - 60 phút" },
  ],
  "iPhone 14 Series": [
    { modelName: "iPhone 14 Pro Max", screenType: "Màn hình chính hãng", badgeLabel: "Apple", price: 5900000, warranty: "12 tháng", duration: "60 - 90 phút" },
    { modelName: "iPhone 14 Pro", screenType: "Màn hình chính hãng", badgeLabel: "Apple", price: 5100000, warranty: "12 tháng", duration: "60 - 90 phút" },
    { modelName: "iPhone 14 Plus", screenType: "Màn hình chính hãng", badgeLabel: "Apple", price: 4100000, warranty: "12 tháng", duration: "45 - 60 phút" },
    { modelName: "iPhone 14", screenType: "Màn hình chính hãng", badgeLabel: "Apple", price: 3400000, warranty: "12 tháng", duration: "45 - 60 phút" },
  ],
  "iPhone 13 Series": [
    { modelName: "iPhone 13 Pro Max", screenType: "Màn hình chính hãng", badgeLabel: "Apple", price: 4900000, warranty: "12 tháng", duration: "60 - 90 phút" },
    { modelName: "iPhone 13 Pro", screenType: "Màn hình chính hãng", badgeLabel: "Apple", price: 4200000, warranty: "12 tháng", duration: "60 - 90 phút" },
    { modelName: "iPhone 13", screenType: "Màn hình chính hãng", badgeLabel: "Apple", price: 2900000, warranty: "12 tháng", duration: "45 - 60 phút" },
    { modelName: "iPhone 13 Mini", screenType: "Màn hình chính hãng", badgeLabel: "Apple", price: 2600000, warranty: "12 tháng", duration: "45 - 60 phút" },
  ],
  "iPhone 12 Series": [
    { modelName: "iPhone 12 Pro Max", screenType: "Màn hình chính hãng", badgeLabel: "Apple", price: 3800000, warranty: "12 tháng", duration: "60 - 90 phút" },
    { modelName: "iPhone 12 Pro", screenType: "Màn hình chính hãng", badgeLabel: "Apple", price: 3200000, warranty: "12 tháng", duration: "60 - 90 phút" },
    { modelName: "iPhone 12", screenType: "Màn hình chính hãng", badgeLabel: "Apple", price: 2400000, warranty: "12 tháng", duration: "45 - 60 phút" },
  ],
  "iPhone 11 Series": [
    { modelName: "iPhone 11 Pro Max", screenType: "Màn hình chính hãng", badgeLabel: "Apple", price: 2800000, warranty: "12 tháng", duration: "45 - 60 phút" },
    { modelName: "iPhone 11 Pro", screenType: "Màn hình chính hãng", badgeLabel: "Apple", price: 2300000, warranty: "12 tháng", duration: "45 - 60 phút" },
    { modelName: "iPhone 11", screenType: "Màn hình chính hãng", badgeLabel: "Apple", price: 1650000, warranty: "12 tháng", duration: "45 - 60 phút" },
  ],
  "iPhone X Series": [
    { modelName: "iPhone XS Max", screenType: "Màn hình chính hãng", badgeLabel: "Apple", price: 1950000, warranty: "12 tháng", duration: "45 - 60 phút" },
    { modelName: "iPhone XS", screenType: "Màn hình chính hãng", badgeLabel: "Apple", price: 1600000, warranty: "12 tháng", duration: "45 - 60 phút" },
    { modelName: "iPhone XR", screenType: "Màn hình chính hãng", badgeLabel: "Apple", price: 1400000, warranty: "12 tháng", duration: "45 - 60 phút" },
    { modelName: "iPhone X", screenType: "Màn hình chính hãng", badgeLabel: "Apple", price: 1500000, warranty: "12 tháng", duration: "45 - 60 phút" },
  ],
  "iPhone 8 Series": [
    { modelName: "iPhone 8 Plus", screenType: "Màn hình chính hãng", badgeLabel: "Apple", price: 950000, warranty: "12 tháng", duration: "30 - 45 phút" },
    { modelName: "iPhone 8", screenType: "Màn hình chính hãng", badgeLabel: "Apple", price: 750000, warranty: "12 tháng", duration: "30 - 45 phút" },
  ],

  // Samsung
  "Galaxy S24 Series": [
    { modelName: "Galaxy S24 Ultra", screenType: "Dynamic AMOLED 2X chính hãng", badgeLabel: "Samsung", price: 6200000, warranty: "12 tháng", duration: "60 - 90 phút" },
    { modelName: "Galaxy S24", screenType: "Dynamic AMOLED 2X chính hãng", badgeLabel: "Samsung", price: 4200000, warranty: "12 tháng", duration: "45 - 60 phút" },
  ],
  "Galaxy S23 Series": [
    { modelName: "Galaxy S23 Ultra", screenType: "Dynamic AMOLED 2X chính hãng", badgeLabel: "Samsung", price: 5400000, warranty: "12 tháng", duration: "60 - 90 phút" },
    { modelName: "Galaxy S23", screenType: "Dynamic AMOLED 2X chính hãng", badgeLabel: "Samsung", price: 3600000, warranty: "12 tháng", duration: "45 - 60 phút" },
  ],
  "Galaxy Z Series": [
    { modelName: "Galaxy Z Fold 5", screenType: "Màn hình gập chính hãng Samsung", badgeLabel: "Samsung", price: 8900000, warranty: "12 tháng", duration: "90 - 120 phút" },
    { modelName: "Galaxy Z Flip 5", screenType: "Màn hình gập chính hãng Samsung", badgeLabel: "Samsung", price: 6500000, warranty: "12 tháng", duration: "60 - 90 phút" },
  ],
  "Galaxy A Series": [
    { modelName: "Galaxy A55 5G", screenType: "Super AMOLED chính hãng", badgeLabel: "Samsung", price: 1900000, warranty: "6 tháng", duration: "30 - 45 phút" },
    { modelName: "Galaxy A54 5G", screenType: "Super AMOLED chính hãng", badgeLabel: "Samsung", price: 1750000, warranty: "6 tháng", duration: "30 - 45 phút" },
  ],

  // Xiaomi
  "Xiaomi 14 Series": [
    { modelName: "Xiaomi 14 Ultra", screenType: "LTPO AMOLED WQHD+ chính hãng", badgeLabel: "Xiaomi", price: 5800000, warranty: "12 tháng", duration: "60 - 90 phút" },
    { modelName: "Xiaomi 14", screenType: "LTPO OLED 1.5K chính hãng", badgeLabel: "Xiaomi", price: 3900000, warranty: "12 tháng", duration: "45 - 60 phút" },
  ],
  "Redmi Note 13 Series": [
    { modelName: "Redmi Note 13 Pro+", screenType: "AMOLED 1.5K 120Hz cong", badgeLabel: "Redmi", price: 2100000, warranty: "6 tháng", duration: "45 - 60 phút" },
    { modelName: "Redmi Note 13", screenType: "AMOLED 120Hz chính hãng", badgeLabel: "Redmi", price: 1350000, warranty: "6 tháng", duration: "30 - 45 phút" },
  ],
  "POCO Series": [
    { modelName: "POCO X6 Pro", screenType: "Flow AMOLED 1.5K 120Hz", badgeLabel: "POCO", price: 2200000, warranty: "6 tháng", duration: "45 - 60 phút" },
    { modelName: "POCO F5 Pro", screenType: "WQHD+ AMOLED 120Hz", badgeLabel: "POCO", price: 2600000, warranty: "6 tháng", duration: "45 - 60 phút" },
  ],

  // Oppo
  "Find X Series": [
    { modelName: "Find X7 Ultra", screenType: "LTPO AMOLED QHD+ chính hãng", badgeLabel: "OPPO", price: 6100000, warranty: "12 tháng", duration: "60 - 90 phút" },
    { modelName: "Find N3 Flip", screenType: "Màn hình gập chính hãng", badgeLabel: "OPPO", price: 5900000, warranty: "12 tháng", duration: "60 - 90 phút" },
  ],
  "Reno 12 Series": [
    { modelName: "Reno 12 Pro", screenType: "AMOLED 120Hz cong bốn cạnh", badgeLabel: "OPPO", price: 2800000, warranty: "6 tháng", duration: "45 - 60 phút" },
    { modelName: "Reno 12", screenType: "AMOLED 120Hz chính hãng", badgeLabel: "OPPO", price: 2400000, warranty: "6 tháng", duration: "45 - 60 phút" },
  ],
  "OPPO A Series": [
    { modelName: "Oppo A79 5G", screenType: "FHD+ 90Hz chính hãng", badgeLabel: "OPPO", price: 1250000, warranty: "6 tháng", duration: "30 - 45 phút" },
    { modelName: "Oppo A58", screenType: "FHD+ Sunlight Display", badgeLabel: "OPPO", price: 1100000, warranty: "6 tháng", duration: "30 - 45 phút" },
  ],

  // Vivo
  "Vivo X Series": [
    { modelName: "Vivo X100 Pro", screenType: "LTPO AMOLED 1.5K ZEISS", badgeLabel: "vivo", price: 5600000, warranty: "12 tháng", duration: "60 - 90 phút" },
    { modelName: "Vivo X90 Pro", screenType: "AMOLED QHD+ ZEISS", badgeLabel: "vivo", price: 4400000, warranty: "12 tháng", duration: "60 - 90 phút" },
  ],
  "Vivo V Series": [
    { modelName: "Vivo V30 Pro", screenType: "AMOLED 120Hz cong chính hãng", badgeLabel: "vivo", price: 2600000, warranty: "6 tháng", duration: "45 - 60 phút" },
    { modelName: "Vivo V30 5G", screenType: "AMOLED 120Hz chính hãng", badgeLabel: "vivo", price: 2300000, warranty: "6 tháng", duration: "45 - 60 phút" },
  ],
  "Vivo Y Series": [
    { modelName: "Vivo Y100 5G", screenType: "AMOLED 120Hz chính hãng", badgeLabel: "vivo", price: 1450000, warranty: "6 tháng", duration: "30 - 45 phút" },
    { modelName: "Vivo Y36", screenType: "FHD+ 90Hz chính hãng", badgeLabel: "vivo", price: 1150000, warranty: "6 tháng", duration: "30 - 45 phút" },
  ],

  // Realme
  "Realme GT Series": [
    { modelName: "Realme GT 5 Pro", screenType: "AMOLED 1.5K 144Hz chính hãng", badgeLabel: "Realme", price: 4100000, warranty: "12 tháng", duration: "45 - 60 phút" },
  ],
  "Realme 12 Series": [
    { modelName: "Realme 12 Pro+ 5G", screenType: "AMOLED 120Hz cong chính hãng", badgeLabel: "Realme", price: 2400000, warranty: "6 tháng", duration: "45 - 60 phút" },
    { modelName: "Realme 12 5G", screenType: "FHD+ 120Hz Sunlight Display", badgeLabel: "Realme", price: 1600000, warranty: "6 tháng", duration: "30 - 45 phút" },
  ],
  "Realme C Series": [
    { modelName: "Realme C67", screenType: "FHD+ 90Hz chính hãng", badgeLabel: "Realme", price: 1150000, warranty: "6 tháng", duration: "30 - 45 phút" },
    { modelName: "Realme C55", screenType: "FHD+ 90Hz chính hãng", badgeLabel: "Realme", price: 1050000, warranty: "6 tháng", duration: "30 - 45 phút" },
  ],

  // Google
  "Pixel 9 Series": [
    { modelName: "Pixel 9 Pro XL", screenType: "Super Actua LTPO OLED chính hãng", badgeLabel: "Google", price: 6700000, warranty: "12 tháng", duration: "60 - 90 phút" },
    { modelName: "Pixel 9", screenType: "Actua OLED 120Hz chính hãng", badgeLabel: "Google", price: 4600000, warranty: "12 tháng", duration: "45 - 60 phút" },
  ],
  "Pixel 8 Series": [
    { modelName: "Pixel 8 Pro", screenType: "Super Actua LTPO OLED chính hãng", badgeLabel: "Google", price: 5200000, warranty: "12 tháng", duration: "60 - 90 phút" },
    { modelName: "Pixel 8", screenType: "Actua OLED 120Hz chính hãng", badgeLabel: "Google", price: 3800000, warranty: "12 tháng", duration: "45 - 60 phút" },
  ],
  "Pixel 7 Series": [
    { modelName: "Pixel 7 Pro", screenType: "LTPO AMOLED 120Hz chính hãng", badgeLabel: "Google", price: 3900000, warranty: "12 tháng", duration: "45 - 60 phút" },
    { modelName: "Pixel 7a", screenType: "OLED 90Hz chính hãng", badgeLabel: "Google", price: 2400000, warranty: "6 tháng", duration: "30 - 45 phút" },
  ],

  // Honor
  "Honor Magic Series": [
    { modelName: "Honor Magic 6 Pro", screenType: "LTPO OLED 120Hz chính hãng", badgeLabel: "Honor", price: 5700000, warranty: "12 tháng", duration: "60 - 90 phút" },
  ],
  "Honor 200 Series": [
    { modelName: "Honor 200 Pro", screenType: "AMOLED 120Hz cong chính hãng", badgeLabel: "Honor", price: 3200000, warranty: "12 tháng", duration: "45 - 60 phút" },
    { modelName: "Honor 200", screenType: "AMOLED 120Hz chính hãng", badgeLabel: "Honor", price: 2600000, warranty: "6 tháng", duration: "45 - 60 phút" },
  ],
  "Honor 90 & X Series": [
    { modelName: "Honor 90 5G", screenType: "AMOLED 120Hz 3840Hz PWM", badgeLabel: "Honor", price: 2200000, warranty: "6 tháng", duration: "45 - 60 phút" },
    { modelName: "Honor X9b 5G", screenType: "AMOLED 1.5K chống rơi vỡ", badgeLabel: "Honor", price: 1850000, warranty: "6 tháng", duration: "30 - 45 phút" },
  ],
}

const BRAND_SERIES_MAP: Record<string, string[]> = {
  Apple: [
    "iPhone 16 Series",
    "iPhone 15 Series",
    "iPhone 14 Series",
    "iPhone 13 Series",
    "iPhone 12 Series",
    "iPhone 11 Series",
    "iPhone X Series",
    "iPhone 8 Series",
  ],
  Samsung: [
    "Galaxy S24 Series",
    "Galaxy S23 Series",
    "Galaxy Z Series",
    "Galaxy A Series",
  ],
  Xiaomi: [
    "Xiaomi 14 Series",
    "Redmi Note 13 Series",
    "POCO Series",
  ],
  Oppo: [
    "Find X Series",
    "Reno 12 Series",
    "OPPO A Series",
  ],
  Vivo: [
    "Vivo X Series",
    "Vivo V Series",
    "Vivo Y Series",
  ],
  Realme: [
    "Realme GT Series",
    "Realme 12 Series",
    "Realme C Series",
  ],
  Google: [
    "Pixel 9 Series",
    "Pixel 8 Series",
    "Pixel 7 Series",
  ],
  Honor: [
    "Honor Magic Series",
    "Honor 200 Series",
    "Honor 90 & X Series",
  ],
}

const BRANDS = [
  { id: "Apple", name: "Apple", logo: "apple" },
  { id: "Samsung", name: "Samsung", logo: "samsung" },
  { id: "Xiaomi", name: "Xiaomi", logo: "xiaomi" },
  { id: "Oppo", name: "Oppo", logo: "oppo" },
  { id: "Vivo", name: "Vivo", logo: "vivo" },
  { id: "Realme", name: "Realme", logo: "realme" },
  { id: "Google", name: "Google", logo: "google" },
  { id: "Honor", name: "Honor", logo: "honor" },
]

export function PricingPage() {
  const navigate = useNavigate()
  const [searchParams] = useSearchParams()
  const serviceParam = searchParams.get("service") || "Thay màn hình"

  const [selectedBrand, setSelectedBrand] = useState("Apple")
  const [selectedSeries, setSelectedSeries] = useState("iPhone 16 Series")
  const [searchModel, setSearchModel] = useState("")
  const [selectedImageIdx, setSelectedImageIdx] = useState(0)

  const galleryImages = [
    iphone16,
    heroRepair,
    workshopBg,
    branchCauGiay,
  ]

  const currentRows = DEFAULT_SERIES_PRICES[selectedSeries] || DEFAULT_SERIES_PRICES["iPhone 16 Series"]

  const filteredRows = currentRows.filter((r) =>
    r.modelName.toLowerCase().includes(searchModel.toLowerCase())
  )

  const formatVndNumber = (price: number) => {
    return price.toLocaleString("vi-VN") + "đ"
  }

  const handleBookModel = (modelName: string) => {
    navigate(`/booking?brand=${encodeURIComponent(selectedBrand)}&modelName=${encodeURIComponent(modelName)}&serviceName=${encodeURIComponent(serviceParam)}`)
  }

  return (
    <main style={{ background: "#f8fafc", minHeight: "100vh", paddingBottom: "60px" }}>
      <div style={{ maxWidth: "1340px", margin: "0 auto", padding: "0 20px" }}>
        {/* 1. BREADCRUMBS ROW (MATCHING SCREENSHOT) */}
        <nav
          style={{
            display: "flex",
            alignItems: "center",
            gap: "8px",
            fontSize: "0.85rem",
            color: "#64748b",
            padding: "16px 0 20px",
          }}
        >
          <Link to="/" style={{ display: "flex", alignItems: "center", color: "#64748b", textDecoration: "none" }}>
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
              <polyline points="9 22 9 12 15 12 15 22" />
            </svg>
          </Link>
          <span style={{ color: "#cbd5e1" }}>›</span>
          <Link to="/" style={{ color: "#64748b", textDecoration: "none" }}>Trang chủ</Link>
          <span style={{ color: "#cbd5e1" }}>›</span>
          <Link to="/services" style={{ color: "#64748b", textDecoration: "none" }}>Dịch vụ sửa chữa</Link>
          <span style={{ color: "#cbd5e1" }}>›</span>
          <strong style={{ color: "#0f172a", fontWeight: 700 }}>Thay màn hình</strong>
        </nav>

        {/* 2. TOP HERO CARD (3 COLUMNS MATCHING SCREENSHOT) */}
        <section
          style={{
            background: "#ffffff",
            border: "1px solid #e2e8f0",
            borderRadius: "20px",
            padding: "26px",
            display: "grid",
            gridTemplateColumns: "250px 1fr 340px",
            gap: "24px",
            boxShadow: "0 2px 12px rgba(15,23,42,0.04)",
            marginBottom: "28px",
            alignItems: "stretch",
          }}
        >
          {/* COLUMN 1: MEDIA GALLERY */}
          <div>
            <div
              style={{
                position: "relative",
                width: "100%",
                height: "195px",
                borderRadius: "14px",
                overflow: "hidden",
                boxShadow: "0 4px 14px rgba(0,0,0,0.08)",
              }}
            >
              <img
                src={galleryImages[selectedImageIdx]}
                alt="Thay màn hình điện thoại"
                style={{
                  width: "100%",
                  height: "100%",
                  objectFit: "cover",
                }}
              />
              {/* Play video overlay icon */}
              <div
                style={{
                  position: "absolute",
                  inset: 0,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  pointerEvents: "none",
                }}
              >
                <div
                  style={{
                    width: "44px",
                    height: "44px",
                    borderRadius: "50%",
                    background: "rgba(255, 255, 255, 0.9)",
                    backdropFilter: "blur(6px)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    boxShadow: "0 4px 16px rgba(0,0,0,0.25)",
                    color: "#2563eb",
                    fontSize: "1.1rem",
                    paddingLeft: "3px",
                  }}
                >
                  ▶
                </div>
              </div>
            </div>

            {/* THUMBNAIL ROW */}
            <div style={{ display: "flex", gap: "8px", marginTop: "10px" }}>
              {galleryImages.slice(0, 4).map((img, i) => (
                <div
                  key={i}
                  onClick={() => setSelectedImageIdx(i)}
                  style={{
                    width: "48px",
                    height: "48px",
                    borderRadius: "8px",
                    overflow: "hidden",
                    cursor: "pointer",
                    border: selectedImageIdx === i ? "2px solid #2563eb" : "1px solid #e2e8f0",
                    transition: "all 0.15s ease",
                  }}
                >
                  <img src={img} alt={`Thumb ${i}`} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
                </div>
              ))}
              <div
                onClick={() => setSelectedImageIdx(3)}
                style={{
                  width: "48px",
                  height: "48px",
                  borderRadius: "8px",
                  background: "#f1f5f9",
                  border: "1px solid #e2e8f0",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  fontSize: "0.76rem",
                  fontWeight: 700,
                  color: "#475569",
                  cursor: "pointer",
                }}
              >
                +3 ảnh
              </div>
            </div>
          </div>

          {/* COLUMN 2: CENTER INFO & 4 PILLARS */}
          <div style={{ display: "flex", flexDirection: "column", justifyContent: "space-between", minWidth: 0 }}>
            <div>
              <h1 style={{ fontSize: "2.1rem", fontWeight: 800, color: "#0f172a", margin: "0 0 10px", letterSpacing: "-0.03em" }}>
                Thay màn hình điện thoại
              </h1>
              <p style={{ fontSize: "0.95rem", color: "#64748b", margin: "0 0 24px", lineHeight: 1.6 }}>
                Thay màn hình chính hãng, linh kiện chất lượng cao cho tất cả các dòng điện thoại. Kỹ thuật viên giàu kinh nghiệm, quy trình minh bạch, lấy ngay chỉ với vài bước.
              </p>
            </div>

            {/* 4 QUALITY PILLARS */}
            <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: "12px", paddingTop: "8px" }}>
              {/* Pillar 1 */}
              <div style={{ minWidth: 0 }}>
                <div style={{ width: "36px", height: "36px", borderRadius: "8px", background: "#eff6ff", color: "#2563eb", display: "flex", alignItems: "center", justifyContent: "center", marginBottom: "8px" }}>
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#2563eb" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
                    <path d="M9 12l2 2 4-4" />
                  </svg>
                </div>
                <strong style={{ display: "block", fontSize: "0.84rem", color: "#0f172a", fontWeight: 700, marginBottom: "2px", lineHeight: 1.3 }}>
                  Linh kiện chính hãng
                </strong>
                <span style={{ fontSize: "0.74rem", color: "#64748b" }}>Cam kết chất lượng</span>
              </div>

              {/* Pillar 2 */}
              <div style={{ minWidth: 0 }}>
                <div style={{ width: "36px", height: "36px", borderRadius: "8px", background: "#eff6ff", color: "#2563eb", display: "flex", alignItems: "center", justifyContent: "center", marginBottom: "8px" }}>
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#2563eb" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
                    <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2" />
                  </svg>
                </div>
                <strong style={{ display: "block", fontSize: "0.84rem", color: "#0f172a", fontWeight: 700, marginBottom: "2px", lineHeight: 1.3 }}>
                  Lấy ngay 30 - 60p
                </strong>
                <span style={{ fontSize: "0.74rem", color: "#64748b" }}>Không giữ máy lâu</span>
              </div>

              {/* Pillar 3 */}
              <div style={{ minWidth: 0 }}>
                <div style={{ width: "36px", height: "36px", borderRadius: "8px", background: "#eff6ff", color: "#2563eb", display: "flex", alignItems: "center", justifyContent: "center", marginBottom: "8px" }}>
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#2563eb" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M6 3h12l4 6-10 13L2 9z" />
                    <path d="M2 9h20" />
                  </svg>
                </div>
                <strong style={{ display: "block", fontSize: "0.84rem", color: "#0f172a", fontWeight: 700, marginBottom: "2px", lineHeight: 1.3 }}>
                  KTV chuyên nghiệp
                </strong>
                <span style={{ fontSize: "0.74rem", color: "#64748b" }}>Tay nghề cao</span>
              </div>

              {/* Pillar 4 */}
              <div style={{ minWidth: 0 }}>
                <div style={{ width: "36px", height: "36px", borderRadius: "8px", background: "#eff6ff", color: "#2563eb", display: "flex", alignItems: "center", justifyContent: "center", marginBottom: "8px" }}>
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#2563eb" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
                  </svg>
                </div>
                <strong style={{ display: "block", fontSize: "0.84rem", color: "#0f172a", fontWeight: 700, marginBottom: "2px", lineHeight: 1.3 }}>
                  Bảo hành đến 12T
                </strong>
                <span style={{ fontSize: "0.74rem", color: "#64748b" }}>Hỗ trợ tận tâm</span>
              </div>
            </div>
          </div>

          {/* COLUMN 3: RIGHT CTA ACTION BOX */}
          <div
            style={{
              background: "#ffffff",
              border: "1px solid #e2e8f0",
              borderRadius: "16px",
              padding: "20px",
              display: "flex",
              flexDirection: "column",
              justifyContent: "space-between",
              boxShadow: "0 4px 16px rgba(15,23,42,0.03)",
            }}
          >
            <div>
              {/* TOP: PRICE ROW & GREEN BADGE */}
              <div
                style={{
                  display: "flex",
                  alignItems: "flex-start",
                  justifyContent: "space-between",
                  gap: "12px",
                  marginBottom: "16px",
                }}
              >
                <div>
                  <span style={{ fontSize: "0.8rem", color: "#64748b", display: "block", marginBottom: "3px" }}>
                    Giá dịch vụ từ
                  </span>
                  <div style={{ fontSize: "1.95rem", fontWeight: 900, color: "#2563eb", letterSpacing: "-0.02em", lineHeight: 1 }}>
                    1.500.000đ
                  </div>
                </div>

                <div
                  style={{
                    background: "#ecfdf5",
                    border: "1px solid #a7f3d0",
                    borderRadius: "10px",
                    padding: "6px 12px",
                    display: "flex",
                    alignItems: "center",
                    gap: "6px",
                    flexShrink: 0,
                  }}
                >
                  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#059669" strokeWidth="2.8" strokeLinecap="round" strokeLinejoin="round">
                    <polyline points="20 6 9 17 4 12" />
                  </svg>
                  <div>
                    <strong style={{ display: "block", fontSize: "0.76rem", color: "#059669", lineHeight: 1.2 }}>
                      Chính hãng
                    </strong>
                    <span style={{ fontSize: "0.7rem", color: "#047857", whiteSpace: "nowrap" }}>
                      Bảo hành đến 12T
                    </span>
                  </div>
                </div>
              </div>

              {/* BIG SOLID BLUE CTA BUTTON */}
              <Link
                to={`/booking?serviceName=${encodeURIComponent(serviceParam)}`}
                style={{
                  width: "100%",
                  padding: "12px 16px",
                  background: "#2563eb",
                  color: "#ffffff",
                  borderRadius: "12px",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  gap: "10px",
                  textDecoration: "none",
                  boxShadow: "0 4px 14px rgba(37,99,235,0.3)",
                  marginBottom: "16px",
                }}
              >
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" style={{ flexShrink: 0 }}>
                  <rect x="3" y="4" width="18" height="18" rx="2" ry="2" />
                  <line x1="16" y1="2" x2="16" y2="6" />
                  <line x1="8" y1="2" x2="8" y2="6" />
                  <line x1="3" y1="10" x2="21" y2="10" />
                </svg>
                <div style={{ textAlign: "left" }}>
                  <div style={{ fontWeight: 800, fontSize: "0.95rem", lineHeight: 1.2 }}>Đặt lịch sửa chữa</div>
                  <div style={{ fontSize: "0.72rem", opacity: 0.9 }}>Chọn chi nhánh, thời gian phù hợp</div>
                </div>
              </Link>
            </div>

            {/* 3 TILES AT BOTTOM - CLEAN, BEAUTIFUL, BALANCED */}
            <div
              style={{
                display: "grid",
                gridTemplateColumns: "repeat(3, 1fr)",
                gap: "8px",
                borderTop: "1px solid #f1f5f9",
                paddingTop: "14px",
              }}
            >
              {/* Tile 1 */}
              <div
                style={{
                  background: "#f8fafc",
                  border: "1px solid #e2e8f0",
                  borderRadius: "10px",
                  padding: "8px 4px",
                  textAlign: "center",
                }}
              >
                <div style={{ fontSize: "0.95rem", marginBottom: "2px" }}>📞</div>
                <div style={{ fontSize: "0.68rem", color: "#64748b", marginBottom: "1px", whiteSpace: "nowrap" }}>
                  Tư vấn miễn phí
                </div>
                <strong style={{ fontSize: "0.76rem", color: "#0f172a", fontWeight: 800, whiteSpace: "nowrap" }}>
                  1900 1234
                </strong>
              </div>

              {/* Tile 2 */}
              <div
                style={{
                  background: "#f0fdf4",
                  border: "1px solid #bbf7d0",
                  borderRadius: "10px",
                  padding: "8px 4px",
                  textAlign: "center",
                }}
              >
                <div style={{ fontSize: "0.95rem", marginBottom: "2px" }}>🔍</div>
                <div style={{ fontSize: "0.68rem", color: "#64748b", marginBottom: "1px", whiteSpace: "nowrap" }}>
                  Kiểm tra máy
                </div>
                <strong style={{ fontSize: "0.76rem", color: "#16a34a", fontWeight: 800, whiteSpace: "nowrap" }}>
                  Miễn phí
                </strong>
              </div>

              {/* Tile 3 */}
              <div
                style={{
                  background: "#eff6ff",
                  border: "1px solid #bfdbfe",
                  borderRadius: "10px",
                  padding: "8px 4px",
                  textAlign: "center",
                }}
              >
                <div style={{ fontSize: "0.95rem", marginBottom: "2px" }}>🛡️</div>
                <div style={{ fontSize: "0.68rem", color: "#64748b", marginBottom: "1px", whiteSpace: "nowrap" }}>
                  Cam kết giá
                </div>
                <strong style={{ fontSize: "0.76rem", color: "#2563eb", fontWeight: 800, whiteSpace: "nowrap" }}>
                  Minh bạch
                </strong>
              </div>
            </div>
          </div>
        </section>

        {/* 3. MIDDLE SECTION: PRICING MATRIX BY PHONE MODEL */}
        <section
          style={{
            background: "#ffffff",
            border: "1px solid #e2e8f0",
            borderRadius: "20px",
            padding: "24px",
            boxShadow: "0 2px 10px rgba(15,23,42,0.03)",
            marginBottom: "28px",
          }}
        >
          {/* HEADER ROW */}
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: "16px", marginBottom: "20px" }}>
            <div>
              <h2 style={{ fontSize: "1.35rem", fontWeight: 800, color: "#0f172a", margin: "0 0 4px" }}>
                Bảng giá thay màn hình theo dòng máy
              </h2>
              <p style={{ fontSize: "0.88rem", color: "#64748b", margin: 0 }}>
                Chọn thương hiệu và model điện thoại để xem chi tiết giá và thông tin linh kiện
              </p>
            </div>

            {/* SEARCH MODEL INPUT */}
            <div style={{ position: "relative", width: "280px" }}>
              <svg
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="#94a3b8"
                strokeWidth="2.4"
                strokeLinecap="round"
                strokeLinejoin="round"
                style={{ position: "absolute", left: "14px", top: "12px" }}
              >
                <circle cx="11" cy="11" r="8" />
                <line x1="21" y1="21" x2="16.65" y2="16.65" />
              </svg>
              <input
                type="text"
                placeholder="Tìm kiếm model (ví dụ: iPhone 15)..."
                value={searchModel}
                onChange={(e) => setSearchModel(e.target.value)}
                style={{
                  width: "100%",
                  height: "40px",
                  padding: "0 14px 0 38px",
                  border: "1px solid #cbd5e1",
                  borderRadius: "10px",
                  fontSize: "0.86rem",
                  outline: "none",
                }}
              />
            </div>
          </div>

          {/* BRAND TABS (8 BRANDS MATCHING SCREENSHOT) */}
          <div
            style={{
              display: "flex",
              gap: "10px",
              overflowX: "auto",
              paddingBottom: "16px",
              borderBottom: "1px solid #f1f5f9",
              marginBottom: "22px",
            }}
          >
            {BRANDS.map((brand) => {
              const isActive = selectedBrand === brand.id
              const isWordmark = ["Samsung", "Oppo", "Vivo", "Honor", "Realme"].includes(brand.name)
              return (
                <button
                  key={brand.id}
                  type="button"
                  onClick={() => {
                    setSelectedBrand(brand.id)
                    const seriesList = BRAND_SERIES_MAP[brand.id] || []
                    if (seriesList.length > 0) {
                      setSelectedSeries(seriesList[0])
                    }
                  }}
                  style={{
                    padding: isWordmark ? "8px 20px" : "8px 18px",
                    height: "38px",
                    borderRadius: "10px",
                    border: isActive ? "1.5px solid #2563eb" : "1px solid #e2e8f0",
                    background: isActive ? "#eff6ff" : "#ffffff",
                    color: isActive ? "#2563eb" : "#334155",
                    fontWeight: isActive ? 700 : 500,
                    fontSize: "0.88rem",
                    cursor: "pointer",
                    display: "inline-flex",
                    alignItems: "center",
                    justifyContent: "center",
                    gap: "8px",
                    whiteSpace: "nowrap",
                    transition: "all 0.15s ease",
                  }}
                >
                  {BRAND_LOGOS[brand.name] && (
                    <img
                      src={BRAND_LOGOS[brand.name]}
                      alt={brand.name}
                      style={
                        isWordmark
                          ? { height: "15px", maxWidth: "75px", width: "auto", objectFit: "contain", display: "block" }
                          : { width: "16px", height: "16px", objectFit: "contain", flexShrink: 0 }
                      }
                    />
                  )}
                  {!isWordmark && <span>{brand.name}</span>}
                </button>
              )
            })}
          </div>

          {/* 2-COLUMN SPLIT: SERIES SIDEBAR + MATRIX TABLE */}
          <div style={{ display: "grid", gridTemplateColumns: "210px 1fr", gap: "24px" }}>
            {/* SERIES SIDEBAR */}
            <div>
              <span style={{ fontSize: "0.86rem", fontWeight: 700, color: "#0f172a", display: "block", marginBottom: "12px" }}>
                Dòng máy {selectedBrand}
              </span>

              <div style={{ display: "flex", flexDirection: "column", gap: "4px" }}>
                {(BRAND_SERIES_MAP[selectedBrand] || Object.keys(DEFAULT_SERIES_PRICES)).map((series) => {
                  const isSelected = selectedSeries === series
                  return (
                    <div
                      key={series}
                      onClick={() => setSelectedSeries(series)}
                      style={{
                        padding: "10px 14px",
                        borderRadius: "10px",
                        background: isSelected ? "#eff6ff" : "transparent",
                        color: isSelected ? "#2563eb" : "#475569",
                        fontWeight: isSelected ? 700 : 500,
                        fontSize: "0.86rem",
                        cursor: "pointer",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "space-between",
                        transition: "all 0.15s ease",
                      }}
                    >
                      <span>{series}</span>
                      <span style={{ fontSize: "0.82rem", color: isSelected ? "#2563eb" : "#94a3b8" }}>›</span>
                    </div>
                  )
                })}
              </div>
            </div>

            {/* PRICING TABLE */}
            <div>
              <h3 style={{ fontSize: "1.1rem", fontWeight: 800, color: "#0f172a", margin: "0 0 16px" }}>
                Bảng giá thay màn hình {selectedSeries}
              </h3>

              <div style={{ overflowX: "auto", border: "1px solid #e2e8f0", borderRadius: "12px" }}>
                <table style={{ width: "100%", borderCollapse: "collapse", textAlign: "left", fontSize: "0.86rem" }}>
                  <thead>
                    <tr style={{ background: "#f8fafc", borderBottom: "1px solid #e2e8f0" }}>
                      <th style={{ padding: "12px 16px", color: "#64748b", fontWeight: 600 }}>Model</th>
                      <th style={{ padding: "12px 16px", color: "#64748b", fontWeight: 600 }}>Loại màn hình</th>
                      <th style={{ padding: "12px 16px", color: "#64748b", fontWeight: 600 }}>Giá dịch vụ</th>
                      <th style={{ padding: "12px 16px", color: "#64748b", fontWeight: 600 }}>Bảo hành</th>
                      <th style={{ padding: "12px 16px", color: "#64748b", fontWeight: 600 }}>Thời gian</th>
                      <th style={{ padding: "12px 16px", color: "#64748b", fontWeight: 600, textAlign: "right" }}>Đặt lịch</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredRows.map((row, idx) => (
                      <tr key={idx} style={{ borderBottom: idx < filteredRows.length - 1 ? "1px solid #f1f5f9" : "none" }}>
                        <td style={{ padding: "14px 16px", fontWeight: 700, color: "#0f172a" }}>
                          {row.modelName}
                        </td>
                        <td style={{ padding: "14px 16px" }}>
                          <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                            <span style={{ color: "#334155" }}>{row.screenType}</span>
                            <span
                              style={{
                                fontSize: "0.72rem",
                                fontWeight: 700,
                                background: row.badgeLabel === "Apple" ? "#eff6ff" : "#f0fdf4",
                                color: row.badgeLabel === "Apple" ? "#2563eb" : "#16a34a",
                                border: `1px solid ${row.badgeLabel === "Apple" ? "#bfdbfe" : "#bbf7d0"}`,
                                padding: "2px 8px",
                                borderRadius: "6px",
                              }}
                            >
                              {row.badgeLabel}
                            </span>
                          </div>
                        </td>
                        <td style={{ padding: "14px 16px", fontWeight: 800, color: "#0f172a" }}>
                          {formatVndNumber(row.price)}
                        </td>
                        <td style={{ padding: "14px 16px", color: "#64748b" }}>
                          {row.warranty}
                        </td>
                        <td style={{ padding: "14px 16px", color: "#64748b" }}>
                          {row.duration}
                        </td>
                        <td style={{ padding: "14px 16px", textAlign: "right" }}>
                          <button
                            type="button"
                            onClick={() => handleBookModel(row.modelName)}
                            style={{
                              padding: "6px 16px",
                              borderRadius: "8px",
                              border: "1px solid #2563eb",
                              background: "#ffffff",
                              color: "#2563eb",
                              fontSize: "0.82rem",
                              fontWeight: 700,
                              cursor: "pointer",
                              transition: "all 0.15s ease",
                            }}
                          >
                            Đặt lịch
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </section>

        {/* 4. BOTTOM 3 CARDS: PROCESS, WARRANTY, COMMITMENTS */}
        <section
          style={{
            display: "grid",
            gridTemplateColumns: "1.25fr 1fr 1fr",
            gap: "24px",
          }}
        >
          {/* CARD 1: QUY TRÌNH THAY MÀN HÌNH (HORIZONTAL 4-STEP PIPELINE) */}
          <div
            style={{
              background: "#ffffff",
              border: "1px solid #e2e8f0",
              borderRadius: "20px",
              padding: "24px",
              boxShadow: "0 2px 10px rgba(15,23,42,0.03)",
            }}
          >
            <h3 style={{ fontSize: "1.1rem", fontWeight: 800, color: "#0f172a", margin: "0 0 24px" }}>
              Quy trình thay màn hình
            </h3>

            {/* 4 STEPS HORIZONTAL ROW */}
            <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: "12px", position: "relative" }}>
              {/* Step 1 */}
              <div style={{ textAlign: "center", position: "relative" }}>
                <div
                  style={{
                    width: "28px",
                    height: "28px",
                    borderRadius: "50%",
                    background: "#2563eb",
                    color: "white",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    fontSize: "0.82rem",
                    fontWeight: 800,
                    margin: "0 auto 10px",
                  }}
                >
                  1
                </div>
                <div style={{ width: "32px", height: "32px", borderRadius: "50%", background: "#eff6ff", color: "#2563eb", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 8px" }}>
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#2563eb" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
                    <circle cx="11" cy="11" r="8" />
                    <line x1="21" y1="21" x2="16.65" y2="16.65" />
                  </svg>
                </div>
                <strong style={{ display: "block", fontSize: "0.84rem", color: "#0f172a", marginBottom: "4px" }}>
                  Kiểm tra máy
                </strong>
                <p style={{ fontSize: "0.72rem", color: "#64748b", margin: 0, lineHeight: 1.4 }}>
                  Kỹ thuật viên kiểm tra tình trạng, tư vấn giải pháp
                </p>
              </div>

              {/* Step 2 */}
              <div style={{ textAlign: "center", position: "relative" }}>
                <div
                  style={{
                    width: "28px",
                    height: "28px",
                    borderRadius: "50%",
                    background: "#2563eb",
                    color: "white",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    fontSize: "0.82rem",
                    fontWeight: 800,
                    margin: "0 auto 10px",
                  }}
                >
                  2
                </div>
                <div style={{ width: "32px", height: "32px", borderRadius: "50%", background: "#eff6ff", color: "#2563eb", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 8px" }}>
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#2563eb" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
                    <polyline points="14 2 14 8 20 8" />
                    <line x1="16" y1="13" x2="8" y2="13" />
                    <line x1="16" y1="17" x2="8" y2="17" />
                  </svg>
                </div>
                <strong style={{ display: "block", fontSize: "0.84rem", color: "#0f172a", marginBottom: "4px" }}>
                  Báo giá & xác nhận
                </strong>
                <p style={{ fontSize: "0.72rem", color: "#64748b", margin: 0, lineHeight: 1.4 }}>
                  Báo giá chi tiết, khách hàng xác nhận dịch vụ
                </p>
              </div>

              {/* Step 3 */}
              <div style={{ textAlign: "center", position: "relative" }}>
                <div
                  style={{
                    width: "28px",
                    height: "28px",
                    borderRadius: "50%",
                    background: "#2563eb",
                    color: "white",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    fontSize: "0.82rem",
                    fontWeight: 800,
                    margin: "0 auto 10px",
                  }}
                >
                  3
                </div>
                <div style={{ width: "32px", height: "32px", borderRadius: "50%", background: "#eff6ff", color: "#2563eb", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 8px" }}>
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#2563eb" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z" />
                  </svg>
                </div>
                <strong style={{ display: "block", fontSize: "0.84rem", color: "#0f172a", marginBottom: "4px" }}>
                  Tiến hành thay
                </strong>
                <p style={{ fontSize: "0.72rem", color: "#64748b", margin: 0, lineHeight: 1.4 }}>
                  Thay màn hình bởi kỹ thuật viên chuyên nghiệp
                </p>
              </div>

              {/* Step 4 */}
              <div style={{ textAlign: "center", position: "relative" }}>
                <div
                  style={{
                    width: "28px",
                    height: "28px",
                    borderRadius: "50%",
                    background: "#2563eb",
                    color: "white",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    fontSize: "0.82rem",
                    fontWeight: 800,
                    margin: "0 auto 10px",
                  }}
                >
                  4
                </div>
                <div style={{ width: "32px", height: "32px", borderRadius: "50%", background: "#eff6ff", color: "#2563eb", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 8px" }}>
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#2563eb" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
                    <polyline points="22 4 12 14.01 9 11.01" />
                  </svg>
                </div>
                <strong style={{ display: "block", fontSize: "0.84rem", color: "#0f172a", marginBottom: "4px" }}>
                  Kiểm tra & bàn giao
                </strong>
                <p style={{ fontSize: "0.72rem", color: "#64748b", margin: 0, lineHeight: 1.4 }}>
                  Kiểm tra chất lượng, vệ sinh máy và bàn giao
                </p>
              </div>
            </div>
          </div>

          {/* CARD 2: CHÍNH SÁCH BẢO HÀNH */}
          <div
            style={{
              background: "#ffffff",
              border: "1px solid #e2e8f0",
              borderRadius: "20px",
              padding: "24px",
              boxShadow: "0 2px 10px rgba(15,23,42,0.03)",
              display: "flex",
              flexDirection: "column",
              justifyContent: "space-between",
            }}
          >
            <div>
              <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "18px" }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#2563eb" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
                  <path d="M9 12l2 2 4-4" />
                </svg>
                <h3 style={{ fontSize: "1.1rem", fontWeight: 800, color: "#0f172a", margin: 0 }}>
                  Chính sách bảo hành
                </h3>
              </div>

              <div style={{ display: "flex", flexDirection: "column", gap: "10px", fontSize: "0.84rem", color: "#334155" }}>
                <div style={{ display: "flex", alignItems: "flex-start", gap: "8px" }}>
                  <span style={{ color: "#16a34a", fontWeight: 800, fontSize: "0.95rem" }}>✓</span>
                  <span>Bảo hành từ 3 - 12 tháng tùy loại linh kiện</span>
                </div>
                <div style={{ display: "flex", alignItems: "flex-start", gap: "8px" }}>
                  <span style={{ color: "#16a34a", fontWeight: 800, fontSize: "0.95rem" }}>✓</span>
                  <span>1 đổi 1 nếu có lỗi từ nhà sản xuất</span>
                </div>
                <div style={{ display: "flex", alignItems: "flex-start", gap: "8px" }}>
                  <span style={{ color: "#16a34a", fontWeight: 800, fontSize: "0.95rem" }}>✓</span>
                  <span>Hỗ trợ kỹ thuật miễn phí trong thời gian bảo hành</span>
                </div>
                <div style={{ display: "flex", alignItems: "flex-start", gap: "8px" }}>
                  <span style={{ color: "#16a34a", fontWeight: 800, fontSize: "0.95rem" }}>✓</span>
                  <span>Không bảo hành với lỗi do rơi vỡ, vào nước</span>
                </div>
                <div style={{ display: "flex", alignItems: "flex-start", gap: "8px" }}>
                  <span style={{ color: "#16a34a", fontWeight: 800, fontSize: "0.95rem" }}>✓</span>
                  <span>Bảo hành minh bạch, tra cứu dễ dàng</span>
                </div>
              </div>
            </div>

            {/* LINK TO WARRANTY POLICY */}
            <Link
              to="/support"
              style={{
                marginTop: "20px",
                padding: "10px 14px",
                background: "#f8fafc",
                border: "1px solid #e2e8f0",
                borderRadius: "10px",
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                fontSize: "0.82rem",
                color: "#2563eb",
                fontWeight: 600,
                textDecoration: "none",
              }}
            >
              <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
                  <polyline points="14 2 14 8 20 8" />
                </svg>
                <span>Xem chi tiết chính sách bảo hành</span>
              </div>
              <span>›</span>
            </Link>
          </div>

          {/* CARD 3: CAM KẾT DỊCH VỤ */}
          <div
            style={{
              background: "#ffffff",
              border: "1px solid #e2e8f0",
              borderRadius: "20px",
              padding: "24px",
              boxShadow: "0 2px 10px rgba(15,23,42,0.03)",
            }}
          >
            <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "18px" }}>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#2563eb" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
                <path d="M6 3h12l4 6-10 13L2 9z" />
                <path d="M2 9h20" />
              </svg>
              <h3 style={{ fontSize: "1.1rem", fontWeight: 800, color: "#0f172a", margin: 0 }}>
                Cam kết dịch vụ
              </h3>
            </div>

            <div style={{ display: "flex", flexDirection: "column", gap: "10px", fontSize: "0.84rem", color: "#334155" }}>
              <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#2563eb" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
                </svg>
                <span>Linh kiện chính hãng, nguồn gốc rõ ràng</span>
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#2563eb" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                  <line x1="12" y1="1" x2="12" y2="23" />
                  <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6" />
                </svg>
                <span>Giá cả minh bạch, không phát sinh chi phí</span>
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#2563eb" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
                  <circle cx="12" cy="7" r="4" />
                </svg>
                <span>Kỹ thuật viên giàu kinh nghiệm, tay nghề cao</span>
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#2563eb" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                  <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2" />
                </svg>
                <span>Lấy ngay trong ngày, tiết kiệm thời gian</span>
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#2563eb" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="12" cy="12" r="10" />
                  <polyline points="12 6 12 12 16 14" />
                </svg>
                <span>Vệ sinh máy miễn phí sau khi sửa</span>
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#2563eb" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
                  <circle cx="9" cy="7" r="4" />
                  <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
                  <path d="M16 3.13a4 4 0 0 1 0 7.75" />
                </svg>
                <span>Hỗ trợ tư vấn, chăm sóc khách hàng tận tâm</span>
              </div>
            </div>
          </div>
        </section>
      </div>
    </main>
  )
}
