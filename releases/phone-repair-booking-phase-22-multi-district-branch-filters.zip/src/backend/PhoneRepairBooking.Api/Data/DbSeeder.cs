using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using PhoneRepairBooking.Api.Domain;
using PhoneRepairBooking.Api.Services;

namespace PhoneRepairBooking.Api.Data;

public static class DbSeeder
{
    public static async Task SeedAsync(IServiceProvider services)
    {
        var roles = services.GetRequiredService<RoleManager<IdentityRole>>();
        var users = services.GetRequiredService<UserManager<ApplicationUser>>();

        foreach (var role in AppRoles.All)
        {
            if (!await roles.RoleExistsAsync(role))
            {
                await roles.CreateAsync(new IdentityRole(role));
            }
        }

        await EnsureUserAsync(users, "admin@phonerepair.local", "Quản trị viên", "0901000001", "Admin@12345", AppRoles.Admin);
        await EnsureUserAsync(users, "technician@phonerepair.local", "Kỹ thuật viên demo", "0901000002", "Tech@12345", AppRoles.Technician);
        await EnsureUserAsync(users, "customer@phonerepair.local", "Khách hàng demo", "0901000003", "Customer@12345", AppRoles.Customer);
        await SeedCatalogAsync(services.GetRequiredService<AppDbContext>());
        await EnsureExtendedCatalogAsync(services.GetRequiredService<AppDbContext>());
        await SeedOperationsAsync(services);
    }

    private static async Task SeedOperationsAsync(IServiceProvider services)
    {
        var db = services.GetRequiredService<AppDbContext>();
        var users = services.GetRequiredService<UserManager<ApplicationUser>>();

        var existingNames = await db.Branches.Select(b => b.Name).ToListAsync();
        var branchList = new List<Branch>
        {
            // TP. Hồ Chí Minh
            NewBranch("PhoneRepair Quận 1", "12 Nguyễn Huệ, P. Bến Nghé, Quận 1, TP.HCM", "028 1111 0001"),
            NewBranch("PhoneRepair Quận 3", "368 Cách Mạng Tháng 8, Phường 10, Quận 3, TP.HCM", "028 1111 0003"),
            NewBranch("PhoneRepair Quận 5", "145 Trần Hưng Đạo, Phường 6, Quận 5, TP.HCM", "028 1111 0005"),
            NewBranch("PhoneRepair Quận 7", "45 Nguyễn Văn Linh, Tân Phong, Quận 7, TP.HCM", "028 1111 0007"),
            NewBranch("PhoneRepair Quận 10", "285 Đường 3 Tháng 2, Phường 10, Quận 10, TP.HCM", "028 1111 0010"),
            NewBranch("PhoneRepair Bình Thạnh", "207 Phan Đăng Lưu, Phường 1, Bình Thạnh, TP.HCM", "028 1111 0021"),
            NewBranch("PhoneRepair Gò Vấp", "598 Quang Trung, Phường 11, Gò Vấp, TP.HCM", "028 1111 0022"),
            NewBranch("PhoneRepair Tân Bình", "420 Cộng Hòa, Phường 13, Tân Bình, TP.HCM", "028 1111 0023"),
            NewBranch("PhoneRepair Phú Nhuận", "182 Phan Xích Long, Phường 2, Phú Nhuận, TP.HCM", "028 1111 0024"),
            NewBranch("PhoneRepair Thủ Đức", "89 Võ Văn Ngân, Linh Chiểu, TP. Thủ Đức", "028 1111 0008"),

            // Hà Nội
            NewBranch("PhoneRepair Cầu Giấy", "123 Cầu Giấy, Quan Hoa, Cầu Giấy, Hà Nội", "024 1234 5678"),
            NewBranch("PhoneRepair Đống Đa", "456 Xã Đàn, Nam Đồng, Đống Đa, Hà Nội", "024 2345 6789"),
            NewBranch("PhoneRepair Hai Bà Trưng", "789 Phố Huế, Hàng Bài, Hai Bà Trưng, Hà Nội", "024 3456 7890"),
            NewBranch("PhoneRepair Ba Đình", "567 Đội Cấn, Liễu Giai, Ba Đình, Hà Nội", "024 6789 1234"),
            NewBranch("PhoneRepair Thanh Xuân", "321 Nguyễn Trãi, Thanh Xuân, Hà Nội", "024 3456 1122"),
            NewBranch("PhoneRepair Long Biên", "890 Nguyễn Văn Cừ, Long Biên, Hà Nội", "024 6789 5678"),

            // Đà Nẵng
            NewBranch("PhoneRepair Hải Châu", "152 Hàm Nghi, Thạc Gián, Hải Châu, Đà Nẵng", "0236 3888 123"),
            NewBranch("PhoneRepair Thanh Khê", "345 Điện Biên Phủ, Thanh Khê, Đà Nẵng", "0236 3888 456"),
        };

        var toAdd = branchList.Where(b => !existingNames.Contains(b.Name)).ToList();
        if (toAdd.Count > 0)
        {
            db.Branches.AddRange(toAdd);
            await db.SaveChangesAsync();
        }

        await EnsureUserAsync(users, "technician2@phonerepair.local", "Kỹ thuật viên Quận 7", "0901000004", "Tech2@12345", AppRoles.Technician);
        var first = await users.FindByEmailAsync("technician@phonerepair.local");
        var second = await users.FindByEmailAsync("technician2@phonerepair.local");
        var b1 = await db.Branches.FirstOrDefaultAsync(b => b.Name == "PhoneRepair Quận 1" || b.Name == "PhoneRepair Cầu Giấy");
        var b2 = await db.Branches.FirstOrDefaultAsync(b => b.Name == "PhoneRepair Quận 7" || b.Name == "PhoneRepair Đống Đa");

        if (first is not null && b1 is not null && !await db.Technicians.AnyAsync(t => t.UserId == first.Id))
        {
            db.Technicians.Add(NewTechnician(first.Id, b1.Id));
        }

        if (second is not null && b2 is not null && !await db.Technicians.AnyAsync(t => t.UserId == second.Id))
        {
            db.Technicians.Add(NewTechnician(second.Id, b2.Id));
        }

        await db.SaveChangesAsync();
    }

    private static Branch NewBranch(string name, string address, string phone)
    {
        var branch = new Branch
        {
            Name = name,
            Address = address,
            Phone = phone,
            CapacityPerSlot = 4,
            SlotMinutes = 30,
            IsActive = true,
            CreatedAt = DateTime.UtcNow
        };
        foreach (var hour in BranchService.DefaultHours())
        {
            branch.OpeningHours.Add(new BranchOpeningHour
            {
                DayOfWeek = hour.DayOfWeek,
                IsOpen = hour.IsOpen,
                OpenTime = TimeOnly.Parse(hour.OpenTime),
                CloseTime = TimeOnly.Parse(hour.CloseTime)
            });
        }

        return branch;
    }

    private static Technician NewTechnician(string userId, int branchId)
    {
        var technician = new Technician
        {
            UserId = userId,
            BranchId = branchId,
            IsActive = true,
            CreatedAt = DateTime.UtcNow
        };
        foreach (DayOfWeek day in Enum.GetValues<DayOfWeek>())
        {
            technician.Schedules.Add(new TechnicianSchedule
            {
                DayOfWeek = day,
                IsWorking = day != DayOfWeek.Sunday,
                StartTime = new TimeOnly(8, 0),
                EndTime = new TimeOnly(17, 0)
            });
        }

        return technician;
    }

    private static async Task SeedCatalogAsync(AppDbContext db)
    {
        if (await db.Brands.AnyAsync())
        {
            return;
        }

        var apple = Brand("Apple");
        var samsung = Brand("Samsung");
        var xiaomi = Brand("Xiaomi");
        var oppo = Brand("Oppo");
        db.Brands.AddRange(apple, samsung, xiaomi, oppo);

        var iphone13 = Model(apple, "iPhone 13", 2021);
        var iphone15 = Model(apple, "iPhone 15", 2023);
        var galaxyS24 = Model(samsung, "Galaxy S24", 2024);
        var redmiNote13 = Model(xiaomi, "Redmi Note 13", 2024);
        db.PhoneModels.AddRange(iphone13, iphone15, galaxyS24, redmiNote13);

        var screen = Service("Thay màn hình", PricingType.FixedPrice);
        var battery = Service("Thay pin", PricingType.FixedPrice);
        var speaker = Service("Sửa loa", PricingType.FixedPrice);
        var clean = Service("Vệ sinh thiết bị", PricingType.FixedPrice);
        var noPower = Service("Máy không lên nguồn", PricingType.InspectionRequired);
        var water = Service("Máy bị vào nước", PricingType.InspectionRequired);
        db.RepairServices.AddRange(screen, battery, speaker, clean, noPower, water);

        db.ServicePrices.AddRange(
            Price(iphone13, screen, 2000000),
            Price(iphone15, screen, 3500000),
            Price(galaxyS24, screen, 3000000),
            Price(redmiNote13, screen, 1200000),
            Price(iphone13, battery, 900000),
            Price(iphone15, battery, 1500000),
            Price(galaxyS24, battery, 1100000),
            Price(redmiNote13, battery, 450000),
            Price(iphone15, speaker, 700000),
            Price(iphone15, clean, 300000),
            Price(iphone13, noPower, null),
            Price(iphone15, noPower, null),
            Price(galaxyS24, water, null));

        await db.SaveChangesAsync();
    }

    private static Brand Brand(string name) => new()
    {
        Name = name,
        Slug = Slugger.Make(name),
        IsActive = true,
        CreatedAt = DateTime.UtcNow
    };

    private static PhoneModel Model(Brand brand, string name, int year) => new()
    {
        Brand = brand,
        Name = name,
        Slug = Slugger.Make($"{brand.Name}-{name}"),
        ReleaseYear = year,
        IsActive = true,
        CreatedAt = DateTime.UtcNow
    };

    private static RepairService Service(string name, PricingType pricingType) => new()
    {
        Name = name,
        Slug = Slugger.Make(name),
        PricingType = pricingType,
        IsActive = true,
        CreatedAt = DateTime.UtcNow
    };

    private static ServicePrice Price(PhoneModel model, RepairService service, decimal? amount) => new()
    {
        PhoneModel = model,
        RepairService = service,
        Price = amount,
        IsActive = true
    };

    private static async Task EnsureUserAsync(
        UserManager<ApplicationUser> users,
        string email,
        string fullName,
        string phone,
        string password,
        string role)
    {
        var user = await users.FindByEmailAsync(email);
        if (user is null)
        {
            user = new ApplicationUser
            {
                UserName = email,
                Email = email,
                FullName = fullName,
                PhoneNumber = phone,
                EmailConfirmed = true,
                IsActive = true,
                CreatedAt = DateTime.UtcNow
            };
            var created = await users.CreateAsync(user, password);
            if (!created.Succeeded)
            {
                throw new InvalidOperationException($"Cannot seed {email}.");
            }
        }

        if (!await users.IsInRoleAsync(user, role))
        {
            await users.AddToRoleAsync(user, role);
        }
    }

    private static async Task EnsureExtendedCatalogAsync(AppDbContext db)
    {
        var apple = await db.Brands.FirstOrDefaultAsync(b => b.Name == "Apple");
        if (apple == null)
        {
            apple = Brand("Apple");
            db.Brands.Add(apple);
            await db.SaveChangesAsync();
        }

        string[] extraBrands = ["Vivo", "Realme", "Google", "Honor"];
        foreach (var bName in extraBrands)
        {
            if (!await db.Brands.AnyAsync(b => b.Name == bName))
            {
                db.Brands.Add(Brand(bName));
            }
        }
        await db.SaveChangesAsync();

        var samsung = await db.Brands.FirstOrDefaultAsync(b => b.Name == "Samsung");
        var xiaomi = await db.Brands.FirstOrDefaultAsync(b => b.Name == "Xiaomi");
        var oppo = await db.Brands.FirstOrDefaultAsync(b => b.Name == "Oppo");
        var vivo = await db.Brands.FirstOrDefaultAsync(b => b.Name == "Vivo");
        var realme = await db.Brands.FirstOrDefaultAsync(b => b.Name == "Realme");
        var google = await db.Brands.FirstOrDefaultAsync(b => b.Name == "Google");
        var honor = await db.Brands.FirstOrDefaultAsync(b => b.Name == "Honor");

        (Brand? brand, (string name, int year)[] models)[] catalog = [
            (apple, [
                ("iPhone 16 Pro Max", 2024),
                ("iPhone 16 Pro", 2024),
                ("iPhone 16", 2024),
                ("iPhone 15 Pro Max", 2023),
                ("iPhone 15", 2023),
                ("iPhone 14 Pro Max", 2022),
                ("iPhone 14", 2022),
                ("iPhone 13", 2021),
                ("iPhone 12", 2020),
                ("iPhone 11", 2019),
                ("iPhone XS", 2018),
                ("iPhone SE", 2022)
            ]),
            (samsung, [
                ("Galaxy S24 Ultra", 2024),
                ("Galaxy S24", 2024),
                ("Galaxy S23 Ultra", 2023),
                ("Galaxy S23", 2023),
                ("Galaxy Z Fold 5", 2023),
                ("Galaxy Z Flip 5", 2023),
                ("Galaxy A55 5G", 2024),
                ("Galaxy A54 5G", 2023)
            ]),
            (xiaomi, [
                ("Xiaomi 14 Ultra", 2024),
                ("Xiaomi 14", 2024),
                ("Xiaomi 13 Pro", 2023),
                ("Xiaomi 13", 2023),
                ("Redmi Note 13 Pro+", 2024),
                ("Redmi Note 13", 2024),
                ("POCO X6 Pro", 2024)
            ]),
            (oppo, [
                ("Find X7 Ultra", 2024),
                ("Find N3 Flip", 2023),
                ("Reno 12 Pro", 2024),
                ("Reno 12", 2024),
                ("Reno 11", 2023),
                ("Oppo A79 5G", 2023)
            ]),
            (vivo, [
                ("Vivo X100 Pro", 2024),
                ("Vivo V30 Pro", 2024),
                ("Vivo V30", 2024),
                ("Vivo Y100 5G", 2024)
            ]),
            (realme, [
                ("Realme GT 5 Pro", 2024),
                ("Realme 12 Pro+ 5G", 2024),
                ("Realme 12 5G", 2024),
                ("Realme C67", 2023)
            ]),
            (google, [
                ("Pixel 9 Pro XL", 2024),
                ("Pixel 9", 2024),
                ("Pixel 8 Pro", 2023),
                ("Pixel 8", 2023),
                ("Pixel 7a", 2023)
            ]),
            (honor, [
                ("Honor Magic 6 Pro", 2024),
                ("Honor 200 Pro", 2024),
                ("Honor 200", 2024),
                ("Honor 90 5G", 2023)
            ])
        ];

        foreach (var entry in catalog)
        {
            if (entry.brand == null) continue;
            foreach (var m in entry.models)
            {
                if (!await db.PhoneModels.AnyAsync(p => p.Name == m.name && p.BrandId == entry.brand.Id))
                {
                    db.PhoneModels.Add(Model(entry.brand, m.name, m.year));
                }
            }
        }
        await db.SaveChangesAsync();

        (string name, PricingType type)[] servicesList = [
            ("Thay màn hình", PricingType.FixedPrice),
            ("Thay pin", PricingType.FixedPrice),
            ("Thay camera", PricingType.FixedPrice),
            ("Sửa loa", PricingType.FixedPrice),
            ("Sửa cổng sạc", PricingType.FixedPrice),
            ("Thay vỏ", PricingType.FixedPrice),
            ("Sửa nút nguồn", PricingType.FixedPrice),
            ("Vệ sinh máy", PricingType.FixedPrice),
            ("Cài đặt phần mềm", PricingType.FixedPrice)
        ];

        foreach (var s in servicesList)
        {
            if (!await db.RepairServices.AnyAsync(r => r.Name == s.name))
            {
                db.RepairServices.Add(Service(s.name, s.type));
            }
        }
        await db.SaveChangesAsync();

        var allModels = await db.PhoneModels.Include(m => m.Brand).ToListAsync();
        var allServices = await db.RepairServices.ToListAsync();

        foreach (var model in allModels)
        {
            var brandName = model.Brand?.Name ?? "";
            var isPremium = model.Name.Contains("Ultra") || model.Name.Contains("Pro") || model.Name.Contains("Fold") || model.Name.Contains("Flip");

            decimal screenPrice = (brandName, isPremium) switch
            {
                ("Apple", true) => 5500000m,
                ("Apple", false) => 3500000m,
                ("Samsung", true) => 5200000m,
                ("Samsung", false) => 2600000m,
                ("Xiaomi", true) => 3800000m,
                ("Xiaomi", false) => 1800000m,
                ("Oppo", true) => 3500000m,
                ("Oppo", false) => 1600000m,
                ("Vivo", true) => 3400000m,
                ("Vivo", false) => 1500000m,
                ("Realme", true) => 2800000m,
                ("Realme", false) => 1400000m,
                ("Google", true) => 4200000m,
                ("Google", false) => 2500000m,
                ("Honor", true) => 3900000m,
                ("Honor", false) => 1700000m,
                _ => 2000000m
            };

            decimal batteryPrice = isPremium ? 1200000m : 750000m;
            decimal cameraPrice = isPremium ? 900000m : 550000m;
            decimal speakerPrice = 300000m;
            decimal portPrice = 350000m;
            decimal casePrice = isPremium ? 1100000m : 650000m;
            decimal powerPrice = 300000m;
            decimal cleanPrice = 200000m;
            decimal softwarePrice = 150000m;

            var priceMapping = new Dictionary<string, decimal>
            {
                ["Thay màn hình"] = screenPrice,
                ["Thay pin"] = batteryPrice,
                ["Thay camera"] = cameraPrice,
                ["Sửa loa"] = speakerPrice,
                ["Sửa cổng sạc"] = portPrice,
                ["Thay vỏ"] = casePrice,
                ["Sửa nút nguồn"] = powerPrice,
                ["Vệ sinh máy"] = cleanPrice,
                ["Cài đặt phần mềm"] = softwarePrice,
            };

            foreach (var (sName, prc) in priceMapping)
            {
                var s = allServices.FirstOrDefault(r => r.Name == sName);
                if (s != null && !await db.ServicePrices.AnyAsync(sp => sp.PhoneModelId == model.Id && sp.RepairServiceId == s.Id))
                {
                    db.ServicePrices.Add(Price(model, s, prc));
                }
            }
        }
        await db.SaveChangesAsync();
    }
}
