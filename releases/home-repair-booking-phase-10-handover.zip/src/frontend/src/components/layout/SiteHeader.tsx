import { useState } from "react"
import { NavLink } from "react-router-dom"
import { useAuth } from "../../auth/AuthContext"

export function SiteHeader() {
  const { user, logout } = useAuth()
  const [mobileOpen, setMobileOpen] = useState(false)

  const closeMenu = () => setMobileOpen(false)

  return (
    <header className="site-header">
      <div className="site-header-inner">
        <NavLink to="/" className="brand" onClick={closeMenu}>
          <span className="brand-mark" aria-hidden="true" />
          HomeRepair
        </NavLink>

        <button
          className="mobile-menu-toggle"
          type="button"
          aria-label="Mở trình đơn"
          aria-expanded={mobileOpen}
          onClick={() => setMobileOpen(!mobileOpen)}
        >
          {mobileOpen ? "✕" : "☰"}
        </button>

        <nav className={`nav ${mobileOpen ? "nav-mobile-open" : ""}`} aria-label="Điều hướng chính">
          <NavLink to="/" end className={({ isActive }) => (isActive ? "nav-link nav-link-active" : "nav-link")} onClick={closeMenu}>
            Trang chủ
          </NavLink>
          <NavLink to="/dich-vu" className={({ isActive }) => (isActive ? "nav-link nav-link-active" : "nav-link")} onClick={closeMenu}>
            Dịch vụ
          </NavLink>
          <NavLink to="/hang" className={({ isActive }) => (isActive ? "nav-link nav-link-active" : "nav-link")} onClick={closeMenu}>
            Hãng
          </NavLink>
          <NavLink to="/dong-may" className={({ isActive }) => (isActive ? "nav-link nav-link-active" : "nav-link")} onClick={closeMenu}>
            Dòng máy
          </NavLink>
          <NavLink to="/chi-nhanh" className={({ isActive }) => (isActive ? "nav-link nav-link-active" : "nav-link")} onClick={closeMenu}>
            Chi nhánh
          </NavLink>
          <NavLink to="/ho-tro" className={({ isActive }) => (isActive ? "nav-link nav-link-active" : "nav-link")} onClick={closeMenu}>
            Hỗ trợ (FAQ)
          </NavLink>
          <NavLink to="/dat-lich" className={({ isActive }) => (isActive ? "nav-link nav-link-active" : "nav-link")} onClick={closeMenu}>
            Đặt lịch
          </NavLink>

          {user ? (
            <>
              {user.role === "Admin" ? (
                <>
                  <NavLink to="/quan-tri/dashboard" className={({ isActive }) => (isActive ? "nav-link nav-link-active" : "nav-link")} onClick={closeMenu}>
                    Dashboard
                  </NavLink>
                  <NavLink to="/quan-tri/lich-hen" className={({ isActive }) => (isActive ? "nav-link nav-link-active" : "nav-link")} onClick={closeMenu}>
                    Lịch hẹn
                  </NavLink>
                  <NavLink to="/quan-tri/bao-cao" className={({ isActive }) => (isActive ? "nav-link nav-link-active" : "nav-link")} onClick={closeMenu}>
                    Báo cáo
                  </NavLink>
                  <NavLink to="/quan-tri/khach-hang" className={({ isActive }) => (isActive ? "nav-link nav-link-active" : "nav-link")} onClick={closeMenu}>
                    Khách hàng
                  </NavLink>
                  <NavLink to="/quan-tri/cua-hang" className={({ isActive }) => (isActive ? "nav-link nav-link-active" : "nav-link")} onClick={closeMenu}>
                    Cửa hàng
                  </NavLink>
                  <NavLink to="/quan-tri/danh-muc" className={({ isActive }) => (isActive ? "nav-link nav-link-active" : "nav-link")} onClick={closeMenu}>
                    Danh mục
                  </NavLink>
                  <NavLink to="/quan-tri/danh-gia" className={({ isActive }) => (isActive ? "nav-link nav-link-active" : "nav-link")} onClick={closeMenu}>
                    Đánh giá
                  </NavLink>
                </>
              ) : null}

              {user.role === "Customer" ? (
                <NavLink to="/lich-cua-toi" className={({ isActive }) => (isActive ? "nav-link nav-link-active" : "nav-link")} onClick={closeMenu}>
                  Lịch của tôi
                </NavLink>
              ) : null}

              {user.role === "Technician" ? (
                <NavLink to="/ky-thuat-vien" className={({ isActive }) => (isActive ? "nav-link nav-link-active" : "nav-link")} onClick={closeMenu}>
                  Công việc
                </NavLink>
              ) : null}

              <NavLink to="/ho-so" className={({ isActive }) => (isActive ? "nav-link nav-link-active" : "nav-link")} onClick={closeMenu}>
                {user.fullName}
              </NavLink>
              <button
                className="btn btn-quiet"
                type="button"
                onClick={() => {
                  closeMenu()
                  logout()
                }}
              >
                Đăng xuất
              </button>
            </>
          ) : (
            <>
              <NavLink to="/dang-nhap" className={({ isActive }) => (isActive ? "nav-link nav-link-active" : "nav-link")} onClick={closeMenu}>
                Đăng nhập
              </NavLink>
              <NavLink to="/dang-ky" className="btn" onClick={closeMenu}>
                Đăng ký
              </NavLink>
            </>
          )}
        </nav>
      </div>
    </header>
  )
}
