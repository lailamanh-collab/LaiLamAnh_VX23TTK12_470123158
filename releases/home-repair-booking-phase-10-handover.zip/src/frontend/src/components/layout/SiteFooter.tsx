import { Link } from "react-router-dom"

type SiteFooterProps = {
  databaseConnected: boolean | null
}

export function SiteFooter({ databaseConnected }: SiteFooterProps) {
  let statusText = "Đang kiểm tra kết nối hệ thống"
  let statusClass = ""

  if (databaseConnected === true) {
    statusText = "Cơ sở dữ liệu sẵn sàng"
    statusClass = "status-ok"
  }

  if (databaseConnected === false) {
    statusText = "Chưa kết nối cơ sở dữ liệu"
    statusClass = "status-warn"
  }

  return (
    <footer className="site-footer" style={{ marginTop: "60px", borderTop: "1px solid var(--color-line)", background: "white", padding: "48px 0 24px" }}>
      <div className="site-footer-inner" style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: "32px", marginBottom: "36px" }}>
        {/* COL 1: BRAND INFO */}
        <div>
          <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "12px" }}>
            <span className="brand-mark" style={{ width: "28px", height: "28px", borderRadius: "8px" }} aria-hidden="true" />
            <strong style={{ fontSize: "1.2rem", letterSpacing: "-0.02em" }}>HomeRepair</strong>
          </div>
          <p style={{ margin: "0 0 16px", color: "var(--color-muted)", fontSize: "0.9rem", lineHeight: 1.6 }}>
            Hệ thống đặt lịch sửa chữa nhà cửa tại cửa hàng. Giữ chỗ slot thời gian thực, bảng giá minh bạch, linh kiện chuẩn.
          </p>
          <div style={{ display: "inline-flex", alignItems: "center", gap: "8px", fontSize: "0.82rem", background: "var(--color-canvas)", padding: "4px 12px", borderRadius: "16px" }}>
            <span style={{ width: "8px", height: "8px", borderRadius: "50%", background: databaseConnected ? "#16a34a" : "#ca8a04" }} />
            <span className={statusClass}>{statusText}</span>
          </div>
        </div>

        {/* COL 2: QUICK LINKS */}
        <div>
          <strong style={{ fontSize: "0.95rem", display: "block", marginBottom: "14px", color: "var(--color-ink)" }}>
            Khám phá dịch vụ
          </strong>
          <ul style={{ listStyle: "none", padding: 0, margin: 0, display: "flex", flexDirection: "column", gap: "8px", fontSize: "0.9rem" }}>
            <li>
              <Link to="/" className="text-link" style={{ color: "var(--color-muted)" }}>Trang chủ</Link>
            </li>
            <li>
              <Link to="/dich-vu" className="text-link" style={{ color: "var(--color-muted)" }}>Bảng giá dịch vụ</Link>
            </li>
            <li>
              <Link to="/hang" className="text-link" style={{ color: "var(--color-muted)" }}>Thương hiệu hỗ trợ</Link>
            </li>
            <li>
              <Link to="/dong-may" className="text-link" style={{ color: "var(--color-muted)" }}>Danh sách dòng máy</Link>
            </li>
            <li>
              <Link to="/chi-nhanh" className="text-link" style={{ color: "var(--color-muted)" }}>Hệ thống chi nhánh</Link>
            </li>
          </ul>
        </div>

        {/* COL 3: CUSTOMER SUPPORT */}
        <div>
          <strong style={{ fontSize: "0.95rem", display: "block", marginBottom: "14px", color: "var(--color-ink)" }}>
            Hỗ trợ & Chính sách
          </strong>
          <ul style={{ listStyle: "none", padding: 0, margin: 0, display: "flex", flexDirection: "column", gap: "8px", fontSize: "0.9rem" }}>
            <li>
              <Link to="/ho-tro" className="text-link" style={{ color: "var(--color-muted)" }}>Trung tâm FAQ (42.7)</Link>
            </li>
            <li>
              <Link to="/dat-lich" className="text-link" style={{ color: "var(--color-muted)" }}>Đặt lịch trực tuyến</Link>
            </li>
            <li>
              <Link to="/ho-tro" className="text-link" style={{ color: "var(--color-muted)" }}>Chính sách bảo hành</Link>
            </li>
            <li>
              <Link to="/ho-tro" className="text-link" style={{ color: "var(--color-muted)" }}>Quy trình khảo sát sự cố</Link>
            </li>
            <li>
              <Link to="/ho-tro" className="text-link" style={{ color: "var(--color-muted)" }}>Hướng dẫn hủy lịch</Link>
            </li>
          </ul>
        </div>

        {/* COL 4: CONTACT & WORKING HOURS */}
        <div>
          <strong style={{ fontSize: "0.95rem", display: "block", marginBottom: "14px", color: "var(--color-ink)" }}>
            Liên hệ & Giờ mở cửa
          </strong>
          <p style={{ margin: "0 0 6px", fontSize: "0.9rem", color: "var(--color-muted)" }}>
            📞 Hotline: <strong style={{ color: "var(--color-accent-strong)" }}>1900 8899</strong>
          </p>
          <p style={{ margin: "0 0 6px", fontSize: "0.9rem", color: "var(--color-muted)" }}>
            📧 Email: hotro@homerepair.local
          </p>
          <p style={{ margin: "0 0 6px", fontSize: "0.9rem", color: "var(--color-muted)" }}>
            🕒 Giờ làm việc: 08:00 – 20:00
          </p>
          <span style={{ fontSize: "0.82rem", color: "var(--color-muted)" }}>
            (Phục vụ tất cả các ngày trong tuần)
          </span>
        </div>
      </div>

      {/* COPYRIGHT BOTTOM BAR */}
      <div style={{ borderTop: "1px solid var(--color-line)", paddingTop: "18px" }}>
        <div className="site-footer-inner" style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: "10px", fontSize: "0.85rem", color: "var(--color-muted)" }}>
          <span>© 2026 HomeRepair Booking System · Hệ thống quản lý sửa chữa nhà cửa</span>
          <span>Đồ án tốt nghiệp Công nghệ thông tin · ASP.NET Core & React</span>
        </div>
      </div>
    </footer>
  )
}
