import { useEffect, useState } from "react"
import { Link } from "react-router-dom"
import { getBranches, type Branch } from "../api/branches"
import { getBrands, getServices, type Brand, type RepairService } from "../api/catalog"
import { fetchPublicReviews, type ReviewItem } from "../api/reviews"

export function HomePage() {
  const [branches, setBranches] = useState<Branch[]>([])
  const [brands, setBrands] = useState<Brand[]>([])
  const [services, setServices] = useState<RepairService[]>([])
  const [reviews, setReviews] = useState<ReviewItem[]>([])

  useEffect(() => {
    let active = true
    Promise.all([
      getBranches().catch(() => []),
      getBrands().catch(() => []),
      getServices().catch(() => []),
      fetchPublicReviews(6).catch(() => []),
    ])
      .then(([bList, brList, sList, revList]) => {
        if (!active) return
        setBranches(bList.filter((b) => b.isActive))
        setBrands(brList.filter((b) => b.isActive))
        setServices(sList.filter((s) => s.isActive))
        setReviews(revList)
      })
      .catch(() => {})

    return () => {
      active = false
    }
  }, [])

  return (
    <main className="page">
      {/* HERO SECTION */}
      <section className="hero">
        <div>
          <span className="eyebrow">Chuyên biệt cho điện thoại · Minh bạch & Đúng giờ</span>
          <h1>Đặt lịch sửa điện thoại chuyên nghiệp, đúng máy, minh bạch giá.</h1>
          <p className="lede">
            Chọn chính xác hãng, dòng máy và sự cố của bạn. Nhận bảng giá tham khảo công khai, chọn chi nhánh và khung giờ còn chỗ để được kỹ thuật viên tiếp nhận xử lý ngay khi mang máy tới.
          </p>

          <div style={{ marginTop: "24px", display: "flex", gap: "12px", flexWrap: "wrap", alignItems: "center" }}>
            <Link className="btn" to="/dat-lich" style={{ padding: "12px 24px", fontSize: "1rem" }}>
              ⚡ Đặt lịch ngay (1 phút)
            </Link>
            <Link className="btn btn-quiet" to="/dich-vu" style={{ padding: "12px 20px" }}>
              🔍 Tra cứu bảng giá
            </Link>
            <Link className="btn btn-quiet" to="/chi-nhanh" style={{ padding: "12px 20px" }}>
              🏪 Xem chi nhánh
            </Link>
          </div>

          {/* BADGES */}
          <div
            style={{
              marginTop: "28px",
              display: "flex",
              gap: "10px",
              flexWrap: "wrap",
              fontSize: "0.85rem",
              color: "var(--color-muted)",
            }}
          >
            <span style={{ background: "white", padding: "6px 14px", borderRadius: "20px", border: "1px solid var(--color-line)" }}>
              ⏱️ Giữ chỗ thời gian thực, không chờ đợi
            </span>
            <span style={{ background: "white", padding: "6px 14px", borderRadius: "20px", border: "1px solid var(--color-line)" }}>
              🔍 Kỹ thuật viên kiểm tra trực tiếp
            </span>
            <span style={{ background: "white", padding: "6px 14px", borderRadius: "20px", border: "1px solid var(--color-line)" }}>
              🛡️ Bảo hành 3 – 12 tháng chu đáo
            </span>
            <span style={{ background: "white", padding: "6px 14px", borderRadius: "20px", border: "1px solid var(--color-line)" }}>
              💳 Thanh toán sau khi nghiệm thu máy
            </span>
          </div>
        </div>
      </section>

      {/* METRIC HIGHLIGHTS */}
      <section style={{ margin: "40px 0 20px" }}>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: "16px" }}>
          <div className="card" style={{ padding: "20px" }}>
            <span style={{ fontSize: "1.8rem" }}>📱</span>
            <strong style={{ display: "block", fontSize: "1.2rem", marginTop: "8px" }}>100% Điện thoại</strong>
            <p style={{ margin: "4px 0 0", color: "var(--color-muted)", fontSize: "0.88rem" }}>
              Tập trung hoàn toàn vào smartphone, linh kiện chuyên biệt, đo đạc chuẩn xác.
            </p>
          </div>

          <div className="card" style={{ padding: "20px" }}>
            <span style={{ fontSize: "1.8rem" }}>⏳</span>
            <strong style={{ display: "block", fontSize: "1.2rem", marginTop: "8px" }}>Khung giờ theo Slot</strong>
            <p style={{ margin: "4px 0 0", color: "var(--color-muted)", fontSize: "0.88rem" }}>
              Hệ thống tự động kiểm soát tải tiếp nhận, cam kết không xảy ra overbook.
            </p>
          </div>

          <div className="card" style={{ padding: "20px" }}>
            <span style={{ fontSize: "1.8rem" }}>🏷️</span>
            <strong style={{ display: "block", fontSize: "1.2rem", marginTop: "8px" }}>Báo giá minh bạch</strong>
            <p style={{ margin: "4px 0 0", color: "var(--color-muted)", fontSize: "0.88rem" }}>
              Tách bạch rõ giá cố định và giá chẩn đoán thực tế, không có phụ phí ẩn.
            </p>
          </div>

          <div className="card" style={{ padding: "20px" }}>
            <span style={{ fontSize: "1.8rem" }}>⭐</span>
            <strong style={{ display: "block", fontSize: "1.2rem", marginTop: "8px" }}>Đánh giá chân thực</strong>
            <p style={{ margin: "4px 0 0", color: "var(--color-muted)", fontSize: "0.88rem" }}>
              Chỉ khách hàng đã hoàn tất sửa máy mới có quyền gửi đánh giá dịch vụ.
            </p>
          </div>
        </div>
      </section>

      {/* 4-STEP REPAIR WORKFLOW */}
      <section className="section" id="quy-trinh">
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", flexWrap: "wrap", gap: "12px" }}>
          <div>
            <span className="eyebrow">Quy trình chuyên nghiệp</span>
            <h2>4 Bước sửa chữa tại cửa hàng</h2>
            <p className="section-intro">Quy trình khép kín, minh bạch từ lúc đặt hẹn đến khi bàn giao máy.</p>
          </div>
          <Link to="/dat-lich" className="btn btn-quiet" style={{ fontSize: "0.9rem" }}>
            Bắt đầu đặt lịch →
          </Link>
        </div>

        <div className="step-grid" style={{ gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))", marginTop: "20px" }}>
          <article className="card" style={{ position: "relative" }}>
            <span className="step-index">1</span>
            <h3 style={{ marginTop: "12px", fontSize: "1.1rem" }}>Đặt lịch trực tuyến</h3>
            <p style={{ margin: "6px 0 0", color: "var(--color-muted)", fontSize: "0.9rem", lineHeight: 1.6 }}>
              Chọn dòng máy, chọn các dịch vụ cần sửa, chi nhánh phù hợp và khung giờ còn chỗ. Nhận mã đặt lịch ngay tức thì.
            </p>
          </article>

          <article className="card" style={{ position: "relative" }}>
            <span className="step-index">2</span>
            <h3 style={{ marginTop: "12px", fontSize: "1.1rem" }}>Mang máy tới quầy</h3>
            <p style={{ margin: "6px 0 0", color: "var(--color-muted)", fontSize: "0.9rem", lineHeight: 1.6 }}>
              Nhân viên tiếp nhận đối chiếu mã lịch, kiểm tra ngoại quan máy và chuyển cho kỹ thuật viên chuyên trách.
            </p>
          </article>

          <article className="card" style={{ position: "relative" }}>
            <span className="step-index">3</span>
            <h3 style={{ marginTop: "12px", fontSize: "1.1rem" }}>Kiểm tra & Sửa chữa</h3>
            <p style={{ margin: "6px 0 0", color: "var(--color-muted)", fontSize: "0.9rem", lineHeight: 1.6 }}>
              Kỹ thuật viên chẩn đoán lỗi, thông báo giải pháp và chi phí thực tế. Sau khi khách đồng ý mới tiến hành sửa.
            </p>
          </article>

          <article className="card" style={{ position: "relative" }}>
            <span className="step-index">4</span>
            <h3 style={{ marginTop: "12px", fontSize: "1.1rem" }}>Nghiệm thu & Nhận máy</h3>
            <p style={{ margin: "6px 0 0", color: "var(--color-muted)", fontSize: "0.9rem", lineHeight: 1.6 }}>
              Bạn kiểm tra các tính năng máy, nhận phiếu bảo hành, thanh toán tại cửa hàng và đánh giá trải nghiệm dịch vụ.
            </p>
          </article>
        </div>
      </section>

      {/* POPULAR SERVICES */}
      <section className="section">
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", flexWrap: "wrap", gap: "12px" }}>
          <div>
            <span className="eyebrow">Dịch vụ sửa chữa</span>
            <h2>Các dịch vụ phổ biến</h2>
            <p className="section-intro">Giải quyết triệt để mọi sự cố từ màn hình, pin, vi mạch đến camera.</p>
          </div>
          <Link to="/dich-vu" className="btn btn-quiet" style={{ fontSize: "0.9rem" }}>
            Xem toàn bộ bảng giá →
          </Link>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))", gap: "16px", marginTop: "20px" }}>
          {services.slice(0, 6).map((s) => (
            <div key={s.id} className="card" style={{ display: "flex", flexDirection: "column", justifyContent: "space-between" }}>
              <div>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: "8px" }}>
                  <h3 style={{ margin: 0, fontSize: "1.1rem" }}>{s.name}</h3>
                  <span
                    className={`badge ${s.pricingType === "FixedPrice" ? "badge-success" : "badge-neutral"}`}
                    style={{ fontSize: "0.75rem", whiteSpace: "nowrap" }}
                  >
                    {s.pricingType === "FixedPrice" ? "Giá cố định" : "Cần kiểm tra"}
                  </span>
                </div>
                <p style={{ margin: "8px 0 0", color: "var(--color-muted)", fontSize: "0.88rem", lineHeight: 1.5 }}>
                  {s.description || "Dịch vụ thay thế và kiểm định kỹ thuật theo quy chuẩn an toàn của thiết bị."}
                </p>
              </div>
              <div style={{ marginTop: "16px", paddingTop: "12px", borderTop: "1px solid var(--color-line)", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <Link to={`/dich-vu`} className="text-link" style={{ fontSize: "0.85rem", fontWeight: 600 }}>
                  Xem giá theo dòng máy →
                </Link>
                <Link to="/dat-lich" className="btn btn-quiet" style={{ padding: "4px 10px", fontSize: "0.82rem" }}>
                  Đặt lịch
                </Link>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* SUPPORTED BRANDS */}
      <section className="section">
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", flexWrap: "wrap", gap: "12px" }}>
          <div>
            <span className="eyebrow">Dòng máy hỗ trợ</span>
            <h2>Các thương hiệu điện thoại</h2>
            <p className="section-intro">Chúng tôi tiếp nhận sửa chữa các model phổ biến trên thị trường.</p>
          </div>
          <Link to="/hang" className="btn btn-quiet" style={{ fontSize: "0.9rem" }}>
            Xem danh sách hãng →
          </Link>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: "16px", marginTop: "20px" }}>
          {brands.map((b) => (
            <Link
              key={b.id}
              to={`/dong-may?brandId=${b.id}`}
              className="card card-button"
              style={{ padding: "20px", display: "flex", alignItems: "center", gap: "14px" }}
            >
              <div
                style={{
                  width: "44px",
                  height: "44px",
                  borderRadius: "10px",
                  background: "var(--color-canvas)",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  fontSize: "1.4rem",
                  fontWeight: 800,
                  color: "var(--color-accent-strong)",
                }}
              >
                {b.name.charAt(0)}
              </div>
              <div>
                <strong style={{ fontSize: "1.05rem", display: "block" }}>{b.name}</strong>
                <span className="muted" style={{ fontSize: "0.82rem" }}>{b.modelCount} dòng máy</span>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* STORE BRANCHES */}
      <section className="section">
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", flexWrap: "wrap", gap: "12px" }}>
          <div>
            <span className="eyebrow">Hệ thống cửa hàng</span>
            <h2>Mạng lưới chi nhánh tiếp nhận</h2>
            <p className="section-intro">Không gian sửa chữa hiện đại, máy móc chuyên dụng, vị trí thuận tiện.</p>
          </div>
          <Link to="/chi-nhanh" className="btn btn-quiet" style={{ fontSize: "0.9rem" }}>
            Tất cả chi nhánh →
          </Link>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))", gap: "16px", marginTop: "20px" }}>
          {branches.map((b) => (
            <div key={b.id} className="card" style={{ display: "flex", flexDirection: "column", justifyContent: "space-between" }}>
              <div>
                <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "8px" }}>
                  <span style={{ fontSize: "1.2rem" }}>🏪</span>
                  <strong style={{ fontSize: "1.1rem" }}>{b.name}</strong>
                </div>
                <p style={{ margin: "4px 0", color: "var(--color-muted)", fontSize: "0.9rem" }}>
                  📍 {b.address}
                </p>
                <p style={{ margin: "4px 0", color: "var(--color-muted)", fontSize: "0.9rem" }}>
                  📞 {b.phone}
                </p>
                <p style={{ margin: "4px 0", color: "var(--color-muted)", fontSize: "0.85rem" }}>
                  ⏱️ Sức chứa: {b.capacityPerSlot} lượt / khung {b.slotMinutes} phút
                </p>
              </div>

              <div style={{ marginTop: "16px", paddingTop: "12px", borderTop: "1px solid var(--color-line)" }}>
                <Link to={`/dat-lich`} className="btn" style={{ width: "100%", justifyContent: "center", fontSize: "0.88rem" }}>
                  Đặt hẹn tại chi nhánh này
                </Link>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* CUSTOMER REVIEWS (42.1, 43.12) */}
      <section className="section">
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", flexWrap: "wrap", gap: "12px" }}>
          <div>
            <span className="eyebrow">Khách hàng nói gì về chúng tôi</span>
            <h2>Đánh giá thực tế từ khách hàng</h2>
            <p className="section-intro">Những phản hồi chân thực sau khi hoàn thành sửa chữa tại HomeRepair.</p>
          </div>
          <Link to="/dat-lich" className="btn btn-quiet" style={{ fontSize: "0.9rem" }}>
            Trải nghiệm ngay →
          </Link>
        </div>

        {reviews.length === 0 ? (
          <div className="card" style={{ padding: "32px", textAlign: "center", marginTop: "20px", color: "var(--color-muted)" }}>
            <p style={{ margin: 0 }}>Đang cập nhật đánh giá mới nhất từ khách hàng...</p>
          </div>
        ) : (
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))", gap: "16px", marginTop: "20px" }}>
            {reviews.map((rev) => (
              <div key={rev.id} className="card" style={{ display: "flex", flexDirection: "column", justifyContent: "space-between" }}>
                <div>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "8px" }}>
                    <div style={{ color: "#eab308", fontSize: "1.1rem" }}>
                      {"★".repeat(rev.rating)}
                      {"☆".repeat(5 - rev.rating)}
                    </div>
                    <span className="muted" style={{ fontSize: "0.78rem" }}>
                      {new Date(rev.createdAt).toLocaleDateString("vi-VN")}
                    </span>
                  </div>

                  <p style={{ margin: "8px 0", fontSize: "0.92rem", fontStyle: rev.comment ? "normal" : "italic", color: rev.comment ? "var(--color-ink)" : "var(--color-muted)" }}>
                    {rev.comment ? `"${rev.comment}"` : "Khách hàng hài lòng với chất lượng sửa chữa."}
                  </p>
                </div>

                <div style={{ marginTop: "14px", paddingTop: "10px", borderTop: "1px solid var(--color-line)", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <div>
                    <strong style={{ fontSize: "0.85rem", display: "block" }}>{rev.customerName}</strong>
                    <span className="muted" style={{ fontSize: "0.78rem" }}>{rev.phoneModelName}</span>
                  </div>
                  <span className="badge badge-neutral" style={{ fontSize: "0.72rem" }}>{rev.branchName}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* FINAL CTA BANNER */}
      <section
        className="card"
        style={{
          marginTop: "60px",
          padding: "48px 32px",
          textAlign: "center",
          background: "linear-gradient(135deg, #0c5645 0%, #0f6b56 100%)",
          color: "white",
          borderRadius: "24px",
          border: "none",
        }}
      >
        <span style={{ fontSize: "0.85rem", fontWeight: 700, letterSpacing: "0.08em", textTransform: "uppercase", color: "#a7f3d0" }}>
          Nhanh chóng · Uy tín · Minh bạch
        </span>
        <h2 style={{ fontSize: "clamp(1.6rem, 3.5vw, 2.4rem)", margin: "12px 0 16px", color: "white" }}>
          Điện thoại bạn đang gặp vấn đề? Đặt lịch ngay hôm nay!
        </h2>
        <p style={{ margin: "0 auto 28px", maxWidth: "580px", color: "#d1fae5", fontSize: "1rem", lineHeight: 1.6 }}>
          Chỉ mất 1 phút để chọn đúng máy, kiểm tra trước bảng giá và giữ chỗ khung giờ còn trống tại chi nhánh gần bạn nhất.
        </p>
        <div style={{ display: "flex", gap: "14px", justifyContent: "center", flexWrap: "wrap" }}>
          <Link
            to="/dat-lich"
            className="btn"
            style={{
              background: "white",
              color: "#0c5645",
              fontWeight: 700,
              padding: "12px 28px",
              fontSize: "1.05rem",
              boxShadow: "0 4px 14px rgba(0,0,0,0.15)",
            }}
          >
            ⚡ Đặt lịch hẹn ngay bây giờ
          </Link>
          <Link
            to="/ho-tro"
            className="btn btn-quiet"
            style={{
              background: "rgba(255,255,255,0.15)",
              color: "white",
              borderColor: "rgba(255,255,255,0.3)",
              padding: "12px 24px",
              fontSize: "1rem",
            }}
          >
            ❓ Câu hỏi thường gặp (FAQ)
          </Link>
        </div>
      </section>
    </main>
  )
}
