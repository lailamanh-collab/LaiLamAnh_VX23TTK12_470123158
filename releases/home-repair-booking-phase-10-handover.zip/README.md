# HomeFix - Dịch vụ Sửa chữa Nhà cửa Tại nhà
> **Phase 10: Public Portal & Handover (Home, Services, Support/FAQ, Readme Documentation)**


> **Hệ thống Quản lý và Đặt lịch Sửa chữa Điện thoại tại Cửa hàng**  
> Đồ án tốt nghiệp Công nghệ thông tin · Kiến trúc phân tầng ASP.NET Core 9 Web API & React 19 SPA · Microsoft SQL Server

---

## 1. Giới thiệu tổng quan

**HomeRepair Booking System** là giải pháp phần mềm chuyên sâu dành riêng cho ngành dịch vụ sửa chữa nhà cửa di động tại chuỗi cửa hàng. Hệ thống giải quyết trọn vẹn bài toán vận hành từ lúc khách hàng tìm kiếm dịch vụ, đặt lịch giữ chỗ trực tuyến, khảo sát sự cố tại quầy, quy trình kỹ thuật viên tháo lắp sửa chữa, điều phối nhân sự, đến nghiệm thu thanh toán và đánh giá chất lượng.

### Điểm đặc sắc về nghiệp vụ
- **Chuyên biệt 100% cho điện thoại**: Một lượt đặt lịch áp dụng cho đúng 1 dòng máy cụ thể (RULE 01) nhưng có thể chọn cùng lúc nhiều dịch vụ sửa chữa (RULE 02).
- **Giá dịch vụ phụ thuộc vào model máy**: Hệ thống quản lý bảng giá theo ma trận (Dòng máy × Dịch vụ) (RULE 03 & 15).
- **Quản lý khung giờ & Chống quá tải (Slot & Capacity Management)**: Khách hàng chỉ được chọn các khung giờ hệ thống cung cấp (RULE 04). Backend tự động tính toán số ca đang phục vụ và từ chối nếu khung giờ đã hết chỗ (RULE 05, 06, 07).
- **Phân quyền chặt chẽ (Role-based Security)**: Khách hàng chỉ xem lịch của chính mình (RULE 08). Kỹ thuật viên chỉ thao tác trên các ca được gán (RULE 09). Duy nhất Quản trị viên được quyền điều phối và phân công kỹ thuật viên (RULE 10).
- **Kiểm soát quy trình sửa chữa nghiêm ngặt (State Workflow)**: Lịch hẹn tuân thủ 6 trạng thái tuần tự: `Pending` -> `Confirmed` -> `Received` -> `Inspecting` -> `Repairing` -> `Completed`. Chặn mọi bước nhảy trạng thái phi logic và tuyệt đối không thể hoàn tác ca đã hoàn thành (RULE 12 & 13).
- **Hệ thống đánh giá chuẩn xác**: Khách hàng chỉ có thể đánh giá đối với các ca sửa chữa đã hoàn thành thực tế (RULE 11).

---

## 2. Công nghệ sử dụng

- **Frontend**:
  - React 19, TypeScript
  - Vite 8, Tailwind CSS v4, Vanilla CSS Design System
  - React Router DOM v7
- **Backend**:
  - ASP.NET Core 9 Web API (.NET 9)
  - Entity Framework Core 9 (Code-First Migrations)
  - Microsoft SQL Server
  - ASP.NET Core Identity & JWT Authentication (Bearer Tokens)
  - Swashbuckle Swagger UI (API Documentation)
- **Kiến trúc**:
  - Phân tầng Clean Architecture (Controllers, Services, DTOs, Domain Entities, Data/DbContext, Middleware)
  - Global Exception Handling Middleware

---

## 3. Cài đặt nhanh

Xem hướng dẫn chi tiết từng bước tại file [SETUP.md](SETUP.md).

### Bước 1: Chuẩn bị Cơ sở dữ liệu
Cấu hình chuỗi kết nối trong `src/backend/HomeRepairBooking.Api/appsettings.json`:
```json
"ConnectionStrings": {
  "DefaultConnection": "Server=localhost;Database=HomeRepairBooking;Trusted_Connection=True;TrustServerCertificate=True;MultipleActiveResultSets=True"
}
```
Chạy migration để khởi tạo database và nạp dữ liệu mẫu:
```bash
dotnet ef database update --project src/backend/HomeRepairBooking.Api
```

### Bước 2: Chạy Backend API
```bash
dotnet run --project src/backend/HomeRepairBooking.Api
```
- API Base URL: `http://localhost:5088`
- Swagger UI: `http://localhost:5088/swagger`
- Health check: `http://localhost:5088/api/health`

### Bước 3: Chạy Frontend Web App
```bash
cd src/frontend
npm install
npm run dev
```
- Web Application: `http://localhost:5173`

---

## 4. Tài khoản Demo có sẵn

| Vai trò | Email đăng nhập | Mật khẩu | Phụ trách |
| :--- | :--- | :--- | :--- |
| **Admin** | `admin@homerepair.local` | `Admin@12345` | Toàn quyền quản trị, điều phối, báo cáo |
| **Technician (Chi nhánh 1)** | `technician@homerepair.local` | `Tech@12345` | KTV Chi nhánh Quận 1 (TP.HCM) |
| **Technician (Chi nhánh 2)** | `technician2@homerepair.local` | `Tech2@12345` | KTV Chi nhánh Cầu Giấy (Hà Nội) |
| **Customer** | `customer@homerepair.local` | `Customer@12345` | Khách hàng mẫu có sẵn lịch hẹn |

---

## 5. Các phân hệ chức năng chính

### 1. Phân hệ Khách hàng (Customer Portal)
- Trang chủ công khai (42.1) hiển thị dịch vụ nổi bật, thương hiệu, chi nhánh và đánh giá thực tế.
- Tra cứu danh mục Hãng (42.2), Dòng máy (42.3), Dịch vụ & Bảng giá theo máy (42.4, 42.5).
- Mạng lưới chi nhánh & Giờ mở cửa (42.6).
- Trung tâm hỗ trợ & Giải đáp thắc mắc FAQ tương tác (42.7).
- Đăng ký tài khoản (42.8), Đăng nhập JWT (42.9), Quản lý hồ sơ cá nhân (43.1).
- Wizard Đặt lịch sửa chữa 6 bước (43.2 - 43.10) kèm kiểm tra slot thời gian thực và mã định danh duy nhất `PR-YYYYMMDD-XXXX`.
- Trang Lịch của tôi & Chi tiết lịch hẹn (43.11): Timeline 6 trạng thái trực quan, theo dõi ghi chú kỹ thuật viên và chi phí thực tế.
- Hủy lịch hẹn trước khi cửa hàng tiếp nhận (RULE 08).
- Gửi đánh giá dịch vụ 1-5 sao kèm nhận xét sau khi hoàn thành (43.12, RULE 11).

### 2. Phân hệ Kỹ thuật viên (Technician Portal)
- Bàn làm việc Kỹ thuật viên (`/ky-thuat-vien` - 44.1).
- Dashboard chỉ số cá nhân (44.2): Số ca đang sửa, ca chờ nhận, ca hoàn thành, điểm sao trung bình.
- Danh sách công việc được phân công kèm bộ lọc và tìm kiếm (44.3).
- Chi tiết ca sửa chữa (44.4) và quy trình tác nghiệp 6 bước:
  - Tiếp nhận máy (44.5)
  - Bắt đầu kiểm tra & chẩn đoán lỗi phần cứng (44.6)
  - Bắt đầu sửa chữa (44.7)
  - Cập nhật tiến độ & phương án khắc phục (44.8)
  - Nghiệm thu hoàn thành ca sửa (44.9)
- Lịch làm việc tuần và xem khung giờ trực tại chi nhánh (44.10).
- Lịch sử các ca sửa chữa đã hoàn thành (44.11).

### 3. Phân hệ Quản trị viên (Admin Portal)
- Trung tâm Chỉ huy Dashboard Admin (`/quan-tri/dashboard` - 45.2): 8 thẻ KPI thời gian thực và 6 biểu đồ trực quan (lịch hẹn theo ngày, trạng thái, top dịch vụ, top hãng, tải chi nhánh, doanh thu theo tháng).
- Điều phối & Quản lý lịch hẹn (`/quan-tri/lich-hen` - 45.10 - 45.12): Tìm kiếm tương đối, lọc đa tiêu chí, duyệt xác nhận lịch, điều phối KTV đúng chi nhánh (RULE 10), hủy lịch có lý do.
- Quản lý danh mục & Bảng giá (`/quan-tri/danh-muc` - 45.3 - 45.6): CRUD Hãng, Dòng máy, Dịch vụ, cấu hình loại giá và bảng giá chi tiết.
- Quản lý Cửa hàng & Kỹ thuật viên (`/quan-tri/cua-hang` - 45.7 - 45.9): Quản lý chi nhánh, cấu hình sức chứa mỗi slot, quản lý hồ sơ KTV và lịch trực tuần.
- Quản lý Khách hàng (`/quan-tri/khach-hang` - 45.13): Danh sách khách hàng, xem lịch sử đặt hẹn của từng khách, kích hoạt/khóa tài khoản.
- Quản lý Đánh giá (`/quan-tri/danh-gia` - 45.14): Thống kê sao trung bình, lọc theo sao/chi nhánh/KTV, duyệt ẩn/hiện hoặc xóa đánh giá.
- Hệ thống Báo cáo chuyên sâu (`/quan-tri/bao-cao` - 45.15, 45.16): Lọc theo khoảng ngày tùy biến/preset, chi nhánh, KTV, trạng thái; bảng phân tích năng suất KTV, chi nhánh, dịch vụ và thương hiệu.

---

## 6. Cấu trúc thư mục mã nguồn

```text
Home Repair System/
├── README.md                           # Giới thiệu tổng quan & hướng dẫn
├── SETUP.md                            # Hướng dẫn chi tiết cài đặt và test
├── src/
│   ├── backend/
│   │   ├── HomeRepairBooking.sln       # Solution .NET 9
│   │   └── HomeRepairBooking.Api/
│   │       ├── Controllers/            # API Endpoints (Auth, Booking, Tech, Admin, Reports...)
│   │       ├── Data/                   # ApplicationDbContext & SeedData
│   │       ├── DTOs/                   # Data Transfer Objects
│   │       ├── Entities/               # Domain Models (Booking, Review, Branch, Tech...)
│   │       ├── Enums/                  # BookingStatus, PricingType, WeekDay
│   │       ├── Middleware/             # ExceptionHandlingMiddleware
│   │       ├── Migrations/             # EF Core Migrations
│   │       ├── Services/               # Business Logic & Rules Implementation
│   │       └── Program.cs              # DI, JWT, Middleware & App Startup
│   └── frontend/
│       ├── package.json
│       ├── vite.config.ts
│       └── src/
│           ├── api/                    # Typed API client services
│           ├── auth/                   # AuthContext & token management
│           ├── components/             # Reusable UI components (Header, Footer, Modals)
│           ├── pages/                  # Page Views (Home, BookingWizard, Tech, Admin...)
│           ├── index.css               # Design system & responsive layout styles
│           └── App.tsx                 # Routing & Guards
└── releases/                           # Lưu trữ các bản phát hành theo từng Phase
```

---

## 7. Giấy phép & Thông tin liên hệ

- **Tác giả**: Đồ án tốt nghiệp Công nghệ thông tin
- **Bản quyền**: © 2026 HomeRepair System.
- **Hỗ trợ**: `hotro@homerepair.local` | Hotline: `1900 8899`
