using Microsoft.EntityFrameworkCore;

namespace PhoneRepairBooking.Api.Data;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
    {
    }
}
