import { NavLink } from "react-router-dom"

export function SiteHeader() {
  return (
    <header className="site-header">
      <div className="site-header-inner">
        <NavLink to="/" className="brand">
          <span className="brand-mark" aria-hidden="true" />
          PhoneRepair
        </NavLink>
        <nav aria-label="Điều hướng chính">
          <NavLink
            to="/"
            className={({ isActive }) => (isActive ? "nav-link nav-link-active" : "nav-link")}
          >
            Trang chủ
          </NavLink>
        </nav>
      </div>
    </header>
  )
}
