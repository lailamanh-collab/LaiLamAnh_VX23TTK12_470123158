import { useEffect, useState } from "react"
import { Route, Routes } from "react-router-dom"
import { getHealth } from "./api/health"
import { SiteFooter } from "./components/layout/SiteFooter"
import { SiteHeader } from "./components/layout/SiteHeader"
import { HomePage } from "./pages/HomePage"

export default function App() {
  const [databaseConnected, setDatabaseConnected] = useState<boolean | null>(null)

  useEffect(() => {
    let active = true

    getHealth()
      .then((health) => {
        if (active) {
          setDatabaseConnected(health.database === "connected")
        }
      })
      .catch(() => {
        if (active) {
          setDatabaseConnected(false)
        }
      })

    return () => {
      active = false
    }
  }, [])

  return (
    <>
      <SiteHeader />
      <Routes>
        <Route path="/" element={<HomePage />} />
      </Routes>
      <SiteFooter databaseConnected={databaseConnected} />
    </>
  )
}
