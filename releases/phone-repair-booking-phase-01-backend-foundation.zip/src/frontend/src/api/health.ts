export type HealthStatus = {
  status: string
  database: string
}

export async function getHealth(): Promise<HealthStatus> {
  const baseUrl = import.meta.env.VITE_API_URL.replace(/\/$/, "")
  const response = await fetch(`${baseUrl}/api/health`)

  if (!response.ok) {
    throw new Error("Không kết nối được máy chủ.")
  }

  return response.json() as Promise<HealthStatus>
}
