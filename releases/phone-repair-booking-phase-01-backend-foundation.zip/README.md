# PhoneRepairBooking

Website đặt lịch và quản lý dịch vụ sửa chữa điện thoại tại cửa hàng.

## Công nghệ

- Frontend: React, TypeScript, Vite, Tailwind CSS
- Backend: ASP.NET Core 9 Web API
- Database: Microsoft SQL Server, Entity Framework Core

## Yêu cầu môi trường

- .NET SDK 9
- Node.js 22 trở lên
- SQL Server 2019 trở lên, đăng nhập Windows trên máy local

## Cài frontend

```bash
cd src/frontend
npm install
```

Sao chép `src/frontend/.env.example` thành `src/frontend/.env.development` nếu file này chưa có. Giá trị mặc định:

```text
VITE_API_URL=http://localhost:5088
```

## Cài backend

```bash
cd src/backend
dotnet restore
```

## Database

Chuỗi kết nối mặc định trong `src/backend/PhoneRepairBooking.Api/appsettings.json`:

```text
Server=localhost;Database=PhoneRepairBooking;Trusted_Connection=True;TrustServerCertificate=True;MultipleActiveResultSets=True
```

Mẫu cùng nội dung nằm ở `appsettings.example.json`. Nếu SQL Server không dùng Windows Authentication, sửa `ConnectionStrings:DefaultConnection` trước khi chạy migration. Không ghi mật khẩu thật vào file mẫu.

Tạo database và áp migration:

```bash
dotnet ef database update --project src/backend/PhoneRepairBooking.Api
```

Lệnh này tạo database `PhoneRepairBooking` nếu tài khoản Windows có quyền tạo database.

## Chạy backend

```bash
dotnet run --project src/backend/PhoneRepairBooking.Api
```

- API: http://localhost:5088
- Swagger: http://localhost:5088/swagger
- Health: http://localhost:5088/api/health

## Chạy frontend

```bash
cd src/frontend
npm run dev
```

- Web: http://localhost:5173

## Tài khoản demo

Chưa có. Đăng nhập sẽ được bổ sung ở phase xác thực.

## Ghi chú

Footer trang chủ đọc `/api/health`. Dòng "Hệ thống sẵn sàng" nghĩa là API đã kết nối SQL Server.
