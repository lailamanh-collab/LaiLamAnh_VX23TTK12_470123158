using System.Data;
using Microsoft.EntityFrameworkCore;
using PhoneRepairBooking.Api.Data;
using PhoneRepairBooking.Api.Domain;
using PhoneRepairBooking.Api.DTOs;

namespace PhoneRepairBooking.Api.Services;

public class BookingService
{
    private readonly AppDbContext _db;

    public BookingService(AppDbContext db)
    {
        _db = db;
    }

    public async Task<List<SlotDto>> GetSlotsAsync(int branchId, DateOnly date)
    {
        var branch = await _db.Branches.AsNoTracking().Include(item => item.OpeningHours)
            .FirstOrDefaultAsync(item => item.Id == branchId && item.IsActive);
        if (branch is null)
        {
            return [];
        }

        var hours = branch.OpeningHours.FirstOrDefault(item => item.DayOfWeek == date.DayOfWeek && item.IsOpen);
        if (hours is null)
        {
            return [];
        }

        var booked = await _db.Bookings.AsNoTracking()
            .Where(item => item.BranchId == branchId && item.AppointmentDate == date && item.Status != BookingStatus.Cancelled)
            .GroupBy(item => item.SlotStart)
            .Select(group => new { Start = group.Key, Count = group.Count() })
            .ToListAsync();

        var slots = new List<SlotDto>();
        var cursor = hours.OpenTime;
        var now = DateTime.Now;
        while (cursor.AddMinutes(branch.SlotMinutes) <= hours.CloseTime)
        {
            var end = cursor.AddMinutes(branch.SlotMinutes);
            var slotMoment = date.ToDateTime(cursor);
            if (slotMoment > now)
            {
                var count = booked.FirstOrDefault(item => item.Start == cursor)?.Count ?? 0;
                slots.Add(new SlotDto(cursor.ToString("HH:mm"), end.ToString("HH:mm"), branch.CapacityPerSlot, count, count >= branch.CapacityPerSlot));
            }

            cursor = end;
        }

        return slots;
    }

    public async Task<(BookingDetailDto? Data, ApiError? Error, int Status)> CreateAsync(string customerId, CreateBookingRequest request)
    {
        if (string.IsNullOrWhiteSpace(request.ProblemDescription))
        {
            return (null, new ApiError { Message = "Nhập mô tả lỗi." }, StatusCodes.Status400BadRequest);
        }

        if (!DateOnly.TryParse(request.AppointmentDate, out var date) || !TimeOnly.TryParse(request.SlotStart, out var slotStart))
        {
            return (null, new ApiError { Message = "Ngày hoặc giờ không hợp lệ." }, StatusCodes.Status400BadRequest);
        }

        if (request.RepairServiceIds.Distinct().Count() != request.RepairServiceIds.Count || request.RepairServiceIds.Count == 0)
        {
            return (null, new ApiError { Message = "Chọn ít nhất một dịch vụ." }, StatusCodes.Status400BadRequest);
        }

        var model = await _db.PhoneModels.Include(item => item.Brand)
            .FirstOrDefaultAsync(item => item.Id == request.PhoneModelId && item.IsActive && item.Brand.IsActive);
        if (model is null)
        {
            return (null, new ApiError { Message = "Dòng máy không còn nhận sửa." }, StatusCodes.Status400BadRequest);
        }

        var prices = await _db.ServicePrices.Include(item => item.RepairService)
            .Where(item => item.PhoneModelId == model.Id && request.RepairServiceIds.Contains(item.RepairServiceId) && item.IsActive && item.RepairService.IsActive)
            .ToListAsync();
        if (prices.Count != request.RepairServiceIds.Count)
        {
            return (null, new ApiError { Message = "Có dịch vụ không áp dụng cho dòng máy này." }, StatusCodes.Status400BadRequest);
        }

        if (prices.Any(item => item.RepairService.PricingType == PricingType.FixedPrice && (item.Price is null || item.Price <= 0)))
        {
            return (null, new ApiError { Message = "Dịch vụ giá cố định chưa có đơn giá." }, StatusCodes.Status400BadRequest);
        }

        var branch = await _db.Branches.Include(item => item.OpeningHours)
            .FirstOrDefaultAsync(item => item.Id == request.BranchId && item.IsActive);
        if (branch is null)
        {
            return (null, new ApiError { Message = "Chi nhánh không nhận lịch." }, StatusCodes.Status400BadRequest);
        }

        var hours = branch.OpeningHours.FirstOrDefault(item => item.DayOfWeek == date.DayOfWeek && item.IsOpen);
        var slotEnd = slotStart.AddMinutes(branch.SlotMinutes);
        var minutesFromOpen = hours is null ? 0 : (int)Math.Round((slotStart - hours.OpenTime).TotalMinutes);
        var matchesGrid = hours is not null && slotStart >= hours.OpenTime && slotEnd <= hours.CloseTime
            && minutesFromOpen % branch.SlotMinutes == 0;
        if (!matchesGrid || date.ToDateTime(slotStart) <= DateTime.Now)
        {
            return (null, new ApiError { Message = "Khung giờ không còn khả dụng." }, StatusCodes.Status400BadRequest);
        }

        await using var transaction = await _db.Database.BeginTransactionAsync(IsolationLevel.Serializable);
        var booked = await _db.Bookings.CountAsync(item =>
            item.BranchId == branch.Id &&
            item.AppointmentDate == date &&
            item.SlotStart == slotStart &&
            item.Status != BookingStatus.Cancelled);
        if (booked >= branch.CapacityPerSlot)
        {
            return (null, new ApiError { Message = "Khung giờ đã đầy." }, StatusCodes.Status409Conflict);
        }

        var prefix = $"PRB-{date:yyyyMMdd}-";
        var sequence = await _db.Bookings.CountAsync(item => item.BookingCode.StartsWith(prefix)) + 1;
        var code = $"{prefix}{sequence:000}";
        while (await _db.Bookings.AnyAsync(item => item.BookingCode == code))
        {
            sequence++;
            code = $"{prefix}{sequence:000}";
        }
        var booking = new Booking
        {
            BookingCode = code,
            CustomerId = customerId,
            PhoneModelId = model.Id,
            PhoneModel = model,
            BranchId = branch.Id,
            Branch = branch,
            AppointmentDate = date,
            SlotStart = slotStart,
            SlotEnd = slotEnd,
            Status = BookingStatus.Pending,
            ProblemDescription = request.ProblemDescription.Trim(),
            EstimatedTotal = prices.Where(item => item.RepairService.PricingType == PricingType.FixedPrice).Sum(item => item.Price ?? 0),
            CreatedAt = DateTime.UtcNow,
            Services = prices.Select(item => new BookingServiceLine
            {
                RepairServiceId = item.RepairServiceId,
                RepairService = item.RepairService,
                ServiceName = item.RepairService.Name,
                PricingType = item.RepairService.PricingType,
                UnitPrice = item.RepairService.PricingType == PricingType.FixedPrice ? item.Price : null
            }).ToList(),
            StatusHistory =
            [
                new BookingStatusHistory
                {
                    ToStatus = BookingStatus.Pending,
                    Note = "Khách tạo lịch hẹn.",
                    ChangedByUserId = customerId,
                    ChangedAt = DateTime.UtcNow
                }
            ]
        };
        _db.Bookings.Add(booking);
        await _db.SaveChangesAsync();
        await transaction.CommitAsync();
        return (ToDetail(booking), null, StatusCodes.Status201Created);
    }

    public async Task<List<BookingSummaryDto>> GetMineAsync(string customerId, string? filter)
    {
        var query = OwnBookings().Where(item => item.CustomerId == customerId);
        query = ApplyFilter(query, filter);
        var rows = await query.OrderByDescending(item => item.CreatedAt).ToListAsync();
        return rows.Select(ToSummary).ToList();
    }

    public async Task<BookingDetailDto?> GetMineDetailAsync(string customerId, int id)
    {
        var booking = await OwnBookings().FirstOrDefaultAsync(item => item.Id == id && item.CustomerId == customerId);
        return booking is null ? null : ToDetail(booking);
    }

    public async Task<(bool Ok, ApiError? Error, int Status)> CancelMineAsync(string customerId, int id, string? reason)
    {
        var booking = await _db.Bookings.FirstOrDefaultAsync(item => item.Id == id && item.CustomerId == customerId);
        if (booking is null)
        {
            return (false, new ApiError { Message = "Không tìm thấy lịch hẹn." }, StatusCodes.Status404NotFound);
        }

        var appointment = booking.AppointmentDate.ToDateTime(booking.SlotStart);
        var allowed = booking.Status == BookingStatus.Pending || (booking.Status == BookingStatus.Confirmed && appointment > DateTime.Now);
        if (!allowed)
        {
            return (false, new ApiError { Message = "Lịch này không thể hủy." }, StatusCodes.Status400BadRequest);
        }

        var from = booking.Status;
        booking.Status = BookingStatus.Cancelled;
        booking.CancelledAt = DateTime.UtcNow;
        booking.CancelReason = string.IsNullOrWhiteSpace(reason) ? null : reason.Trim();
        _db.BookingStatusHistories.Add(new BookingStatusHistory
        {
            BookingId = booking.Id,
            FromStatus = from,
            ToStatus = BookingStatus.Cancelled,
            Note = booking.CancelReason ?? "Khách hủy lịch.",
            ChangedByUserId = customerId,
            ChangedAt = DateTime.UtcNow
        });
        await _db.SaveChangesAsync();
        return (true, null, StatusCodes.Status204NoContent);
    }

    private IQueryable<Booking> OwnBookings() => _db.Bookings.AsNoTracking()
        .Include(item => item.PhoneModel).ThenInclude(item => item.Brand)
        .Include(item => item.Branch)
        .Include(item => item.Technician)!.ThenInclude(item => item!.User)
        .Include(item => item.Services)
        .Include(item => item.StatusHistory)
        .Include(item => item.Review);

    private static IQueryable<Booking> ApplyFilter(IQueryable<Booking> query, string? filter) => filter?.ToLowerInvariant() switch
    {
        "pending" => query.Where(item => item.Status == BookingStatus.Pending),
        "inprogress" => query.Where(item => item.Status == BookingStatus.Confirmed || item.Status == BookingStatus.Received || item.Status == BookingStatus.Inspecting || item.Status == BookingStatus.Repairing),
        "completed" => query.Where(item => item.Status == BookingStatus.Completed),
        "cancelled" => query.Where(item => item.Status == BookingStatus.Cancelled),
        _ => query
    };

    private static BookingSummaryDto ToSummary(Booking booking) => new(
        booking.Id,
        booking.BookingCode,
        booking.PhoneModel.Brand.Name,
        booking.PhoneModel.Name,
        booking.Branch.Name,
        booking.AppointmentDate,
        booking.SlotStart.ToString("HH:mm"),
        booking.Status,
        booking.EstimatedTotal,
        booking.ActualCost,
        booking.Technician?.User.FullName,
        DateTime.SpecifyKind(booking.CreatedAt, DateTimeKind.Utc),
        booking.Review != null);

    private static BookingDetailDto ToDetail(Booking booking) => new(
        booking.Id,
        booking.BookingCode,
        booking.PhoneModel.Brand.Name,
        booking.PhoneModel.Name,
        booking.Branch.Name,
        booking.Branch.Address,
        booking.AppointmentDate,
        booking.SlotStart.ToString("HH:mm"),
        booking.SlotEnd.ToString("HH:mm"),
        booking.Status,
        booking.ProblemDescription,
        booking.EstimatedTotal,
        booking.ActualCost,
        booking.Technician?.User.FullName,
        booking.Diagnosis,
        booking.RepairNotes,
        booking.RepairSolution,
        DateTime.SpecifyKind(booking.CreatedAt, DateTimeKind.Utc),
        booking.Services.Select(item => new BookingLineDto(item.RepairServiceId, item.ServiceName, item.PricingType, item.UnitPrice)).ToList(),
        booking.StatusHistory.OrderBy(item => item.ChangedAt).Select(item => new BookingHistoryDto(item.FromStatus, item.ToStatus, item.Note, DateTime.SpecifyKind(item.ChangedAt, DateTimeKind.Utc))).ToList(),
        booking.Review != null ? ReviewService.ToDto(booking.Review, booking) : null);
}
