using PhoneRepairBooking.Api.Domain;

namespace PhoneRepairBooking.Api.DTOs;

public record SlotDto(string Start, string End, int Capacity, int Booked, bool IsFull);

public record BookingLineDto(int RepairServiceId, string ServiceName, PricingType PricingType, decimal? UnitPrice);

public record BookingHistoryDto(BookingStatus? FromStatus, BookingStatus ToStatus, string? Note, DateTime ChangedAt);

public record BookingSummaryDto(
    int Id,
    string BookingCode,
    string BrandName,
    string PhoneModelName,
    string BranchName,
    DateOnly AppointmentDate,
    string SlotStart,
    BookingStatus Status,
    decimal EstimatedTotal,
    decimal? ActualCost,
    string? TechnicianName,
    DateTime CreatedAt,
    bool HasReview = false);

public record BookingDetailDto(
    int Id,
    string BookingCode,
    string BrandName,
    string PhoneModelName,
    string BranchName,
    string BranchAddress,
    DateOnly AppointmentDate,
    string SlotStart,
    string SlotEnd,
    BookingStatus Status,
    string ProblemDescription,
    decimal EstimatedTotal,
    decimal? ActualCost,
    string? TechnicianName,
    string? Diagnosis,
    string? RepairNotes,
    string? RepairSolution,
    DateTime CreatedAt,
    List<BookingLineDto> Services,
    List<BookingHistoryDto> Timeline,
    ReviewDto? Review = null);

public class CreateBookingRequest
{
    public int PhoneModelId { get; set; }

    public List<int> RepairServiceIds { get; set; } = [];

    public int BranchId { get; set; }

    public string AppointmentDate { get; set; } = string.Empty;

    public string SlotStart { get; set; } = string.Empty;

    public string ProblemDescription { get; set; } = string.Empty;
}

public class CancelBookingRequest
{
    public string? Reason { get; set; }
}

public record AdminBookingDto(
    int Id,
    string BookingCode,
    string CustomerId,
    string CustomerName,
    string CustomerEmail,
    string? CustomerPhone,
    int PhoneModelId,
    string BrandName,
    string PhoneModelName,
    int BranchId,
    string BranchName,
    DateOnly AppointmentDate,
    string SlotStart,
    string SlotEnd,
    BookingStatus Status,
    string ProblemDescription,
    decimal EstimatedTotal,
    decimal? ActualCost,
    int? TechnicianId,
    string? TechnicianName,
    string? Diagnosis,
    string? RepairNotes,
    string? RepairSolution,
    DateTime CreatedAt,
    List<BookingLineDto> Services,
    List<BookingHistoryDto> Timeline);

public class AdminBookingFilterRequest
{
    public string? Search { get; set; }

    public string? Status { get; set; }

    public int? BranchId { get; set; }

    public int? TechnicianId { get; set; }

    public string? Date { get; set; }

    public string? FromDate { get; set; }

    public string? ToDate { get; set; }
}

public class AssignTechnicianRequest
{
    public int TechnicianId { get; set; }

    public string? Note { get; set; }
}

public class AdminStatusUpdateRequest
{
    public string? Note { get; set; }
}

public record CustomerSummaryDto(
    string Id,
    string FullName,
    string Email,
    string? PhoneNumber,
    bool IsActive,
    DateTime CreatedAt,
    int TotalBookings,
    int CompletedBookings);

public record CustomerDetailDto(
    string Id,
    string FullName,
    string Email,
    string? PhoneNumber,
    bool IsActive,
    DateTime CreatedAt,
    List<BookingSummaryDto> Bookings);

public record AdminSummaryDto(
    string Id,
    string FullName,
    string Email,
    string? PhoneNumber,
    bool IsActive,
    DateTime CreatedAt,
    string Role = "Admin");

public class CreateAdminRequest
{
    public string FullName { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string? PhoneNumber { get; set; }
    public string Password { get; set; } = string.Empty;
}

public record TechnicianDashboardDto(
    int TechnicianId,
    string TechnicianName,
    int BranchId,
    string BranchName,
    int JobsToday,
    int ConfirmedJobs,
    int ReceivedJobs,
    int InspectingJobs,
    int RepairingJobs,
    int CompletedJobs,
    int CompletedTodayJobs,
    int TotalActiveJobs);

public record TechnicianJobSummaryDto(
    int Id,
    string BookingCode,
    string CustomerName,
    string? CustomerPhone,
    string BrandName,
    string PhoneModelName,
    string BranchName,
    DateOnly AppointmentDate,
    string SlotStart,
    string SlotEnd,
    BookingStatus Status,
    string ProblemDescription,
    decimal EstimatedTotal,
    decimal? ActualCost,
    DateTime CreatedAt,
    DateTime? ReceivedAt,
    DateTime? InspectionStartedAt,
    DateTime? RepairStartedAt,
    DateTime? CompletedAt);

public record TechnicianJobDetailDto(
    int Id,
    string BookingCode,
    string CustomerId,
    string CustomerName,
    string CustomerEmail,
    string? CustomerPhone,
    int PhoneModelId,
    string BrandName,
    string PhoneModelName,
    int BranchId,
    string BranchName,
    string BranchAddress,
    DateOnly AppointmentDate,
    string SlotStart,
    string SlotEnd,
    BookingStatus Status,
    string ProblemDescription,
    decimal EstimatedTotal,
    decimal? ActualCost,
    string? Diagnosis,
    string? RepairNotes,
    string? RepairSolution,
    DateTime CreatedAt,
    DateTime? ReceivedAt,
    DateTime? InspectionStartedAt,
    DateTime? RepairStartedAt,
    DateTime? CompletedAt,
    List<BookingLineDto> Services,
    List<BookingHistoryDto> Timeline);

public class TechnicianJobFilterRequest
{
    public string? Status { get; set; }
    public string? Search { get; set; }
}

public class TechnicianReceiveRequest
{
    public string? ReceiveNote { get; set; }
}

public class TechnicianInspectRequest
{
    public string? Diagnosis { get; set; }
    public string? RepairNotes { get; set; }
    public decimal? ActualCost { get; set; }
}

public class TechnicianStartRepairRequest
{
    public string? RepairSolution { get; set; }
    public string? RepairNotes { get; set; }
    public decimal? ActualCost { get; set; }
}

public class TechnicianUpdateRepairRequest
{
    public string? Diagnosis { get; set; }
    public string? RepairSolution { get; set; }
    public string? RepairNotes { get; set; }
    public decimal? ActualCost { get; set; }
    public string? ProgressNote { get; set; }
}

public class TechnicianCompleteRepairRequest
{
    public string? RepairResult { get; set; }
    public string? RepairNotes { get; set; }
    public decimal? ActualCost { get; set; }
}

