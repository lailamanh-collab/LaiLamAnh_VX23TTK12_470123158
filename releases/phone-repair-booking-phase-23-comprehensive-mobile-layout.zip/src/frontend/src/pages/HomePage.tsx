import { useEffect, useMemo, useState } from "react"
import { Link, useNavigate } from "react-router-dom"
import {
  branchQuan1,
  branchQuan7,
  branchThuDuc,
  workshopBg,
  heroPhones,
  bookingAdvisor,
  BRAND_LOGOS,
  SERVICE_ICONS,
} from "../assets"
import { getBrands, getServices, type Brand, type RepairService } from "../api/catalog"
import { getBranches, type Branch } from "../api/branches"
import { fetchPublicReviews, type ReviewItem } from "../api/reviews"
import { useAuth } from "../auth/AuthContext"

interface StoreBranchPreview {
  id: number
  name: string
  address: string
  hours: string
  phone: string
  image: string
}

const FALLBACK_BRANCHES: StoreBranchPreview[] = [
  { id: 1, name: "PhoneRepair Quận 1", address: "123 Nguyễn Huệ, Quận 1, TP.HCM", hours: "08:00 - 20:00", phone: "028 1234 5678", image: branchQuan1 },
  { id: 2, name: "PhoneRepair Quận 7", address: "456 Nguyễn Thị Thập, Quận 7", hours: "08:00 - 20:00", phone: "028 2345 6789", image: branchQuan7 },
  { id: 3, name: "PhoneRepair Thủ Đức", address: "789 Võ Văn Ngân, Thủ Đức", hours: "08:00 - 20:00", phone: "028 3456 7890", image: branchThuDuc },
]

const SERVICE_ICON_KEY_MAP: { keywords: string[]; key: string }[] = [
  { keywords: ["màn hình", "screen", "kính"], key: "screen" },
  { keywords: ["pin", "battery"], key: "battery" },
  { keywords: ["camera", "cam"], key: "camera" },
  { keywords: ["loa", "speaker", "mic"], key: "speaker" },
  { keywords: ["cổng sạc", "sạc", "port", "charge"], key: "port" },
  { keywords: ["vỏ", "lưng", "case", "backglass"], key: "case" },
  { keywords: ["nút nguồn", "power"], key: "power" },
  { keywords: ["vệ sinh", "clean"], key: "clean" },
  { keywords: ["phần mềm", "software", "cài đặt"], key: "software" },
  { keywords: ["nước", "water"], key: "water" },
  { keywords: ["main", "nguồn", "motherboard"], key: "motherboard" },
]

const SERVICE_BG_MAP: { key: string; bg: string; color: string }[] = [
  { key: "screen", bg: "#eff6ff", color: "#2563eb" },
  { key: "battery", bg: "#f0fdf4", color: "#16a34a" },
  { key: "camera", bg: "#faf5ff", color: "#9333ea" },
  { key: "port", bg: "#f0f9ff", color: "#0284c7" },
  { key: "speaker", bg: "#fdf4ff", color: "#c026d3" },
  { key: "case", bg: "#fff7ed", color: "#ea580c" },
  { key: "power", bg: "#f0fdf4", color: "#15803d" },
  { key: "clean", bg: "#ecfeff", color: "#0891b2" },
  { key: "software", bg: "#fefce8", color: "#ca8a04" },
  { key: "water", bg: "#f0f9ff", color: "#0284c7" },
  { key: "motherboard", bg: "#f8fafc", color: "#475569" },
]

function resolveServiceIconKey(serviceName: string): string {
  const lower = serviceName.toLowerCase()
  for (const entry of SERVICE_ICON_KEY_MAP) {
    if (entry.keywords.some((k) => lower.includes(k))) return entry.key
  }
  return "clean"
}

function resolveServiceStyle(serviceKey: string) {
  return SERVICE_BG_MAP.find((s) => s.key === serviceKey) ?? { bg: "#f1f5f9", color: "#475569" }
}

const BRAND_ICON_KEY_MAP: Record<string, string> = {
  apple: "Apple", samsung: "Samsung", xiaomi: "Xiaomi", oppo: "Oppo",
  vivo: "Vivo", realme: "Realme", google: "Google", honor: "Honor",
}

function resolveBrandKey(brandName: string): string {
  const lower = brandName.toLowerCase()
  for (const [key, val] of Object.entries(BRAND_ICON_KEY_MAP)) {
    if (lower.includes(key)) return val
  }
  return brandName
}

export function HomePage() {
  const navigate = useNavigate()
  const { user } = useAuth()
  const [heroSearch, setHeroSearch] = useState("")

  const [services, setServices] = useState<RepairService[]>([])
  const [brands, setBrands] = useState<Brand[]>([])
  const [branches, setBranches] = useState<Branch[]>([])
  const [reviews, setReviews] = useState<ReviewItem[]>([])
  const [servicesLoading, setServicesLoading] = useState(true)
  const [brandsLoading, setBrandsLoading] = useState(true)
  const [branchesLoading, setBranchesLoading] = useState(true)
  const [reviewsLoading, setReviewsLoading] = useState(true)

  useEffect(() => {
    getServices()
      .then((data) => {
        // Only show actual phone repair services (exclude non-service symptoms like Máy không lên nguồn, Máy bị vào nước, Vệ sinh thiết bị)
        const actualServices = data.filter((s) => {
          if (!s.isActive) return false
          const lower = s.name.toLowerCase()
          if (lower.includes("vào nước") || lower.includes("không lên nguồn") || lower.includes("thiết bị")) return false
          return true
        })
        setServices(actualServices.slice(0, 9))
      })
      .catch(() => { })
      .finally(() => setServicesLoading(false))
    getBrands().then((data) => setBrands(data.filter((b) => b.isActive).slice(0, 8))).catch(() => { }).finally(() => setBrandsLoading(false))
    getBranches().then((data) => setBranches(data.filter((b) => b.isActive).slice(0, 3))).catch(() => { }).finally(() => setBranchesLoading(false))
    fetchPublicReviews(3).then(setReviews).catch(() => { }).finally(() => setReviewsLoading(false))
  }, [])

  const handleHeroSearch = (e: React.FormEvent) => {
    e.preventDefault()
    navigate(heroSearch.trim() ? `/services?q=${encodeURIComponent(heroSearch.trim())}` : "/services")
  }

  const displayedBranches: StoreBranchPreview[] =
    !branchesLoading && branches.length > 0
      ? branches.map((b, i) => ({
        id: b.id, name: b.name, address: b.address,
        hours: (() => { const oh = b.openingHours?.find((h) => h.dayOfWeek === new Date().toLocaleDateString("en-US", { weekday: "long" })); return oh && oh.isOpen ? `${oh.openTime} - ${oh.closeTime}` : "08:00 - 20:00" })(),
        phone: b.phone,
        image: [branchQuan1, branchQuan7, branchThuDuc][i] ?? branchQuan1,
      }))
      : FALLBACK_BRANCHES

  const FALLBACK_SERVICES = [
    { id: 1, name: "Thay màn hình", key: "screen" },
    { id: 2, name: "Thay pin", key: "battery" },
    { id: 3, name: "Thay camera", key: "camera" },
    { id: 4, name: "Sửa cổng sạc", key: "port" },
    { id: 5, name: "Sửa loa", key: "speaker" },
    { id: 6, name: "Thay vỏ", key: "case" },
    { id: 7, name: "Sửa nút nguồn", key: "power" },
    { id: 8, name: "Vệ sinh máy", key: "clean" },
    { id: 9, name: "Cài đặt phần mềm", key: "software" },
  ]

  const FALLBACK_BRANDS = [
    { name: "Apple", sub: "iPhone" }, { name: "Samsung", sub: "Galaxy" }, { name: "Xiaomi", sub: "" },
    { name: "Oppo", sub: "" }, { name: "Vivo", sub: "" }, { name: "Realme", sub: "" },
    { name: "Google", sub: "Pixel" }, { name: "Honor", sub: "" },
  ]

  const FALLBACK_REVIEWS = [
    { name: "Nguyễn Minh Tuấn", timeAgo: "2 tuần trước", comment: "Sửa nhanh, nhân viên rất nhiệt tình. Máy hoạt động tốt, giá hợp lý.", rating: 5 },
    { name: "Trần Thị Lan", timeAgo: "1 tháng trước", comment: "Đặt lịch online rất tiện, không phải chờ đợi. Dịch vụ chuyên nghiệp.", rating: 5 },
    { name: "Lê Hoàng Nam", timeAgo: "3 tuần trước", comment: "Thay pin iPhone nhanh chóng, bảo hành rõ ràng. Sẽ quay lại.", rating: 5 },
  ]

  // Gracefully blend real reviews with fallback reviews to always display a full 3-card grid without empty spaces
  const displayedReviews = useMemo(() => {
    if (reviewsLoading) return []
    if (reviews.length >= 3) return reviews.slice(0, 3)
    const needed = 3 - reviews.length
    const fallbacks = FALLBACK_REVIEWS.slice(0, needed).map((r, i) => ({
      id: `fallback-${i}`,
      customerName: r.name,
      rating: r.rating,
      comment: r.comment,
      timeAgo: r.timeAgo,
      createdAt: "",
    }))
    return [...reviews, ...fallbacks]
  }, [reviews, reviewsLoading])

  const reviewsLink = user?.role === "Admin" ? "/admin/reviews" : user?.role === "Customer" ? "/my-bookings" : "/support"

  return (
    <main className="home-page-container">
      {/* HERO SECTION */}
      <section className="home-hero-section" style={{ background: `linear-gradient(90deg, rgba(15,23,42,0.94) 0%, rgba(15,23,42,0.85) 44%, rgba(15,23,42,0.35) 75%, rgba(15,23,42,0.15) 100%), url('\''${workshopBg}'\'') center/cover no-repeat` }}>
        <div>
          <h1 className="home-hero-title">Sửa điện thoại nhanh chóng,<br />uy tín, chuyên nghiệp</h1>
          <p className="home-hero-subtitle">Đặt lịch trước – Không chờ đợi – Lấy máy đúng hẹn</p>
          <form onSubmit={handleHeroSearch} className="home-hero-search-box">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#94a3b8" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" style={{ marginRight: "10px", flexShrink: 0 }}>
              <circle cx="11" cy="11" r="8" /><line x1="21" y1="21" x2="16.65" y2="16.65" />
            </svg>
            <input type="text" className="home-hero-search-input" placeholder="Tìm kiếm dịch vụ, thiết bị hoặc chi nhánh..." value={heroSearch} onChange={(e) => setHeroSearch(e.target.value)} />
            <button type="submit" className="home-hero-search-btn">Tìm kiếm</button>
          </form>
          <div className="home-quality-badges-row">
            {[
              { icon: <><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" /><path d="m9 12 2 2 4-4" /></>, label: "Linh kiện chính hãng", sub: "Chất lượng đảm bảo" },
              { icon: <><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2" /><circle cx="12" cy="7" r="4" /></>, label: "Kỹ thuật viên chuyên nghiệp", sub: "Nhiều năm kinh nghiệm" },
              { icon: <><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" /><path d="m9 12 2 2 4-4" /></>, label: "Bảo hành rõ ràng", sub: "An tâm sau sửa chữa" },
              { icon: <><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z" /><circle cx="12" cy="10" r="3" /></>, label: "Hệ thống chi nhánh", sub: "Thuận tiện, dễ tìm" },
            ].map((badge, i) => (
              <div key={i} className="home-quality-badge-item">
                <div style={{ width: "34px", height: "34px", borderRadius: "50%", background: "#ffffff", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, boxShadow: "0 2px 8px rgba(0,0,0,0.15)" }}>
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#2563eb" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">{badge.icon}</svg>
                </div>
                <div>
                  <strong style={{ display: "block", fontSize: "0.85rem", color: "#ffffff", fontWeight: 700 }}>{badge.label}</strong>
                  <span style={{ fontSize: "0.75rem", color: "#cbd5e1" }}>{badge.sub}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
        <div className="home-hero-visual-col">
          <div style={{ position: "relative", width: "100%", maxWidth: "470px" }}>
            <img
              src={heroPhones}
              alt="Dịch vụ sửa chữa điện thoại PhoneRepair"
              style={{
                width: "100%",
                height: "auto",
                display: "block",
                borderRadius: "16px",
                filter: "drop-shadow(0 20px 40px rgba(0,0,0,0.45))",
              }}
            />
            {/* Nút đặt lịch tương tác thật */}
            <Link
              to="/booking"
              className="home-floating-hero-btn"
              title="Đặt lịch ngay chỉ với vài bước"
            >
              <div style={{ display: "flex", flexDirection: "column", textAlign: "left" }}>
                <span style={{ fontSize: "0.95rem", fontWeight: 800, lineHeight: 1.2, color: "#ffffff", letterSpacing: "-0.01em" }}>
                  Đặt lịch ngay
                </span>
                <span style={{ fontSize: "0.74rem", color: "rgba(255, 255, 255, 0.9)", fontWeight: 500 }}>
                  chỉ với vài bước
                </span>
              </div>
              <div className="hero-btn-arrow">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#ffffff" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M5 12h14" />
                  <path d="m12 5 7 7-7 7" />
                </svg>
              </div>
            </Link>
          </div>
        </div>
      </section>

      {/* DUAL CARDS: DỊCH VỤ & HÃNG */}
      <section className="home-dual-cards-row">
        <div className="home-section-card">
          <div className="home-section-card-header">
            <h2 className="home-section-card-title">Dịch vụ sửa chữa phổ biến</h2>
            <Link to="/services" className="home-section-card-link">Xem tất cả →</Link>
          </div>
          <div className="home-popular-services-grid">
            {(servicesLoading ? [] : services.length > 0 ? services.map((svc) => { const k = resolveServiceIconKey(svc.name); return { id: svc.id, name: svc.name, key: k, pricingLabel: svc.pricingType === "FixedPrice" ? "Giá cố định" : "Cần kiểm tra" } }) : FALLBACK_SERVICES.map((s) => ({ ...s, pricingLabel: "Giá cố định" }))).map((s) => {
              const style = resolveServiceStyle(s.key)
              return (
                <div key={s.id} className="home-popular-service-item" style={{ cursor: "pointer" }} onClick={() => navigate(`/booking?service=${encodeURIComponent(s.name)}`)} title={`Đặt lịch ${s.name}`}>
                  <div className="home-popular-service-icon" style={{ background: style.bg, color: style.color }}>
                    {SERVICE_ICONS[s.key] ? <img src={SERVICE_ICONS[s.key]} alt={s.name} style={{ width: "20px", height: "20px" }} /> : <span style={{ fontSize: "1.1rem" }}>🔧</span>}
                  </div>
                  <strong style={{ fontSize: "0.85rem", color: "#0f172a", marginBottom: "4px" }}>{s.name}</strong>
                  <span style={{ fontSize: "0.72rem", color: "#64748b" }}>{"pricingLabel" in s ? s.pricingLabel : "Giá cố định"}</span>
                </div>
              )
            })}
          </div>
        </div>

        <div className="home-section-card">
          <div className="home-section-card-header">
            <h2 className="home-section-card-title">Các hãng điện thoại phổ biến</h2>
            <Link to="/brands" className="home-section-card-link">Xem tất cả →</Link>
          </div>
          <div className="home-popular-brands-grid">
            {(brandsLoading ? [] : brands.length > 0 ? brands.map((b) => ({ id: b.id, name: b.name, sub: b.modelCount > 0 ? `${b.modelCount} model` : "", logoKey: resolveBrandKey(b.name) })) : FALLBACK_BRANDS.map((b, i) => ({ id: i, name: b.name, sub: b.sub, logoKey: b.name }))).map((b) => (
              <div key={b.id ?? b.name} className="home-popular-brand-item" style={{ cursor: "pointer" }} onClick={() => navigate(`/booking?brand=${encodeURIComponent(b.name)}`)} title={`Đặt lịch sửa ${b.name}`}>
                <div className="home-popular-brand-icon">
                  {BRAND_LOGOS[b.logoKey ?? b.name] ? (
                    <img
                      src={BRAND_LOGOS[b.logoKey ?? b.name]}
                      alt={b.name}
                      style={{
                        maxHeight: "22px",
                        maxWidth: "34px",
                        width: "auto",
                        height: "auto",
                        objectFit: "contain",
                        display: "block",
                      }}
                    />
                  ) : (
                    <span style={{ fontSize: "1.2rem" }}>📱</span>
                  )}
                </div>
                <strong style={{ fontSize: "0.85rem", color: "#0f172a", marginBottom: "4px", display: "block", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", width: "100%", textAlign: "center" }}>
                  {b.name}
                </strong>
                <span style={{ fontSize: "0.72rem", color: "#64748b", display: "block", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", width: "100%", textAlign: "center" }}>
                  {b.sub || "\u00A0"}
                </span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* PROCESS CARD */}
      <section className="home-process-card">
        <h2 style={{ fontSize: "1.35rem", fontWeight: 800, color: "#0f172a", margin: "0 0 28px" }}>Quy trình sửa chữa tại PhoneRepair</h2>
        <div className="home-process-split">
          <div className="home-process-steps-row">
            {[
              { icon: "📅", num: 1, label: "Đặt lịch", desc: "Chọn dịch vụ, chi nhánh, ngày giờ phù hợp" },
              { icon: "📋", num: 2, label: "Tiếp nhận", desc: "Kiểm tra tình trạng máy" },
              { icon: "🔧", num: 3, label: "Sửa chữa", desc: "Kỹ thuật viên thực hiện" },
              { icon: "🛡️", num: 4, label: "Kiểm tra & bàn giao", desc: "Kiểm tra chức năng, nhận máy và bảo hành" },
            ].map((step, i, arr) => (
              <>
                <div key={step.num} className="home-process-step-col">
                  <div className="home-process-icon-circle">{step.icon}<span className="home-process-badge-number">{step.num}</span></div>
                  <strong style={{ fontSize: "0.95rem", color: "#0f172a", marginBottom: "4px" }}>{step.label}</strong>
                  <span style={{ fontSize: "0.78rem", color: "#64748b", lineHeight: 1.4 }}>{step.desc}</span>
                </div>
                {i < arr.length - 1 && <span key={`arrow-${i}`} className="home-process-arrow">›</span>}
              </>
            ))}
          </div>
          <div className="home-booking-feature-box">
            <div className="home-booking-phone-badge">
              <div style={{ width: "38px", height: "62px", borderRadius: "9px", background: "#2563eb", display: "flex", alignItems: "center", justifyContent: "center" }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#ffffff" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12" /></svg>
              </div>
            </div>
            <div className="home-booking-text-col">
              <strong style={{ fontSize: "1.08rem", color: "#0f172a", display: "block", fontWeight: 800 }}>Đặt lịch trực tuyến</strong>
              <span style={{ fontSize: "0.82rem", color: "#64748b", fontWeight: 600 }}>Nhanh chóng, tiện lợi</span>
              <ul style={{ listStyle: "none", padding: 0, margin: "10px 0 14px", display: "flex", flexDirection: "column", gap: "6px", fontSize: "0.8rem", color: "#334155" }}>
                {["Chọn chi nhánh gần bạn", "Chọn dịch vụ và thời gian", "Không cần chờ đợi", "Nhận xác nhận ngay lập tức"].map((item) => (
                  <li key={item} style={{ display: "flex", alignItems: "center", gap: "7px" }}>
                    <span style={{ width: "16px", height: "16px", borderRadius: "50%", background: "#16a34a", color: "#ffffff", display: "inline-flex", alignItems: "center", justifyContent: "center", fontSize: "0.65rem", fontWeight: 800, flexShrink: 0 }}>✓</span>
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
              <Link to="/booking" className="btn home-booking-cta-btn" style={{ background: "#2563eb", color: "#ffffff", padding: "9px 22px", borderRadius: "8px", fontSize: "0.85rem", fontWeight: 700, display: "inline-block", boxShadow: "0 4px 12px rgba(37,99,235,0.3)" }}>Đặt lịch ngay →</Link>
            </div>
            <div className="home-booking-advisor-col">
              <img src={bookingAdvisor} alt="Chuyên viên hỗ trợ PhoneRepair" style={{ width: "100%", height: "auto", display: "block", objectFit: "contain" }} />
            </div>
          </div>
        </div>
      </section>

      {/* DUAL BOTTOM CARDS: CHI NHÁNH & REVIEWS */}
      <section className="home-branches-reviews-row">
        <div className="home-section-card">
          <div className="home-section-card-header">
            <h2 className="home-section-card-title">Chi nhánh của chúng tôi</h2>
            <Link to="/branches" className="home-section-card-link">Xem tất cả →</Link>
          </div>
          <div className="home-branch-triplet-grid">
            {displayedBranches.map((b) => (
              <Link key={b.id} to="/branches" className="home-branch-mini-card">
                <img src={b.image} alt={b.name} className="home-branch-mini-img" />
                <div className="home-branch-mini-body">
                  <strong style={{ fontSize: "0.92rem", color: "#0f172a", marginBottom: "2px" }}>{b.name}</strong>
                  <div style={{ fontSize: "0.76rem", color: "#64748b" }}>📍 {b.address}</div>
                  <div style={{ fontSize: "0.76rem", color: "#64748b" }}>🕒 {b.hours}</div>
                  <div style={{ fontSize: "0.76rem", color: "#64748b" }}>📞 {b.phone}</div>
                </div>
              </Link>
            ))}
          </div>
        </div>

        <div className="home-section-card">
          <div className="home-section-card-header">
            <h2 className="home-section-card-title">Khách hàng nói gì về chúng tôi</h2>
            <Link to={reviewsLink} className="home-section-card-link">Xem tất cả →</Link>
          </div>
          <div className="home-reviews-triplet-grid">
            {reviewsLoading ? Array.from({ length: 3 }).map((_, i) => (
              <div key={i} className="home-review-mini-card" style={{ opacity: 0.4 }}>
                <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "8px" }}>
                  <div style={{ width: "36px", height: "36px", borderRadius: "50%", background: "#e2e8f0", flexShrink: 0 }} />
                  <div style={{ flex: 1 }}><div style={{ height: "12px", background: "#e2e8f0", borderRadius: "4px", marginBottom: "4px" }} /><div style={{ height: "10px", background: "#e2e8f0", borderRadius: "4px", width: "60%" }} /></div>
                </div>
                <div style={{ height: "40px", background: "#e2e8f0", borderRadius: "4px" }} />
              </div>
            )) : displayedReviews.map((r, i) => (
              <div key={r.id ?? i} className="home-review-mini-card">
                <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "8px" }}>
                  <div style={{ width: "36px", height: "36px", borderRadius: "50%", background: "#2563eb", color: "#fff", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 700, fontSize: "0.9rem", flexShrink: 0 }}>
                    {r.customerName?.charAt(0)?.toUpperCase() ?? "K"}
                  </div>
                  <div>
                    <strong style={{ display: "block", fontSize: "0.85rem", color: "#0f172a" }}>{r.customerName}</strong>
                    <span style={{ fontSize: "0.72rem", color: "#94a3b8" }}>
                      {r.createdAt ? new Date(r.createdAt).toLocaleDateString("vi-VN") : ("timeAgo" in r ? (r as any).timeAgo : "")}
                    </span>
                  </div>
                </div>
                <div style={{ color: "#eab308", fontSize: "0.85rem", marginBottom: "8px" }}>
                  {"★".repeat(Math.max(1, Math.min(5, r.rating)))}{"☆".repeat(Math.max(0, 5 - Math.max(1, Math.min(5, r.rating))))}
                </div>
                <p style={{ margin: 0, fontSize: "0.8rem", color: "#475569", lineHeight: 1.5 }}>"{r.comment}"</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </main>
  )
}
