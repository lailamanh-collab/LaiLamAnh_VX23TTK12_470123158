import { useState } from "react"
import { Link } from "react-router-dom"
import { useAuth } from "../auth/AuthContext"

interface FaqItem {
  id: string
  category: "booking" | "pricing" | "workflow" | "warranty" | "security" | "policy"
  question: string
  answer: string
  badge?: string
}

const FAQ_LIST: FaqItem[] = [
  {
    id: "b1",
    category: "booking",
    question: "Tôi có cần thanh toán tiền trước khi đặt lịch không?",
    badge: "Phổ biến",
    answer:
      "Không. Hệ thống đặt lịch trực tuyến của PhoneRepair hoàn toàn miễn phí 100% và không yêu cầu đặt cọc trước. Lịch hẹn giúp giữ khung giờ riêng với kỹ thuật viên để bạn đến là được tiếp nhận ngay không phải chờ đợi. Bạn chỉ thanh toán tại cửa hàng sau khi kỹ thuật viên hoàn thành sửa chữa và bạn đã nghiệm thu máy ưng ý.",
  },
  {
    id: "b2",
    category: "booking",
    question: "Một lịch hẹn tôi có thể sửa nhiều dịch vụ hoặc nhiều máy cùng lúc không?",
    badge: "Quy tắc đặt lịch",
    answer:
      "Mỗi lượt đặt lịch áp dụng cho đúng 1 thiết bị (1 dòng máy cụ thể). Tuy nhiên, trên thiết bị đó bạn có thể chọn đồng thời nhiều dịch vụ sửa chữa khác nhau (ví dụ: vừa thay pin vừa ép kính màn hình). Nếu bạn có từ 2 máy trở lên, vui lòng tạo riêng từng lịch hẹn để kỹ thuật viên bố trí đủ thời gian thao tác chu đáo nhất.",
  },
  {
    id: "b3",
    category: "booking",
    question: "Tôi có thể chọn đích danh kỹ thuật viên sửa cho mình không?",
    answer:
      "Khi đặt lịch, bạn chọn chi nhánh và khung giờ mong muốn. Nhằm đảm bảo chuyên môn hóa và tiến độ tốt nhất, Quản trị viên chi nhánh sẽ điều phối kỹ thuật viên có chuyên môn sâu nhất về dòng máy của bạn ngay khi tiếp nhận. Thông tin tên, tay nghề và đánh giá sao của kỹ thuật viên sẽ hiển thị minh bạch trên lịch hẹn của bạn.",
  },
  {
    id: "p1",
    category: "pricing",
    question: "Sự khác biệt giữa 'Giá cố định' (Fixed Price) và 'Cần kiểm tra trước' (Inspection Required)?",
    badge: "Minh bạch giá",
    answer:
      "Với các lỗi tiêu chuẩn như thay pin, thay màn hình, ép kính... hệ thống áp dụng bảng giá cố định theo từng dòng máy cụ thể. Với các ca lỗi phức tạp như mất nguồn, vô nước, chập bo mạch (IC main)... kỹ thuật viên cần mở máy đo đạc phần cứng trước, sau đó chẩn đoán và báo giá thực tế chính xác cho bạn duyệt trước khi tiến hành sửa chữa.",
  },
  {
    id: "p2",
    category: "pricing",
    question: "Giá hiển thị trên hệ thống đã bao gồm công thợ và bảo hành chưa?",
    answer:
      "Tất cả mức giá hiển thị trên website và ứng dụng đã bao gồm trọn gói: linh kiện chính hãng, công lắp ráp kiểm tra và gói bảo hành tiêu chuẩn từ 3 - 12 tháng. PhoneRepair cam kết 100% không phát sinh bất kỳ phụ phí ẩn nào mà chưa được khách hàng đồng ý.",
  },
  {
    id: "p3",
    category: "pricing",
    question: "Nếu sau khi kiểm tra máy tôi không đồng ý sửa thì có mất phí không?",
    badge: "Miễn phí 100%",
    answer:
      "Hoàn toàn MIỄN PHÍ. Dịch vụ tư vấn, đo đạc và chẩn đoán lỗi tại PhoneRepair là miễn phí 100%. Nếu sau khi kỹ thuật viên báo phương án và giá mà bạn chưa muốn sửa lúc này, bạn hoàn toàn có thể nhận lại máy nguyên vẹn mà không phải thanh toán bất kỳ khoản phí nào.",
  },
  {
    id: "w1",
    category: "workflow",
    question: "Thời gian cho một ca sửa chữa thường mất bao lâu? Có lấy máy ngay được không?",
    badge: "Lấy ngay",
    answer:
      "Hầu hết các dịch vụ phổ biến như thay màn hình, thay pin, sửa chân sạc, thay camera đều hoàn thành trong vòng 30 - 60 phút. Bạn có thể ngồi tại phòng chờ máy lạnh, quan sát trực tiếp kỹ thuật viên sửa chữa và nhận máy ngay trong ngày.",
  },
  {
    id: "w2",
    category: "workflow",
    question: "Tôi có được trực tiếp xem kỹ thuật viên thao tác trên máy không?",
    answer:
      "Có! 100% quy trình sửa chữa tại PhoneRepair được thực hiện công khai tại quầy kỹ thuật mở. Trước khi tháo máy, bạn sẽ được hướng dẫn ký tên lên toàn bộ linh kiện quan trọng (màn hình, bo mạch, pin, camera). Bạn hoàn toàn yên tâm không lo lắng vấn đề tráo đổi đồ.",
  },
  {
    id: "w3",
    category: "workflow",
    question: "Nếu tôi đến muộn hơn khung giờ đã đặt hẹn thì có được tiếp nhận không?",
    answer:
      "Chúng tôi khuyến khích bạn đến đúng trong khung giờ đã chọn để được phục vụ ngay lập tức. Nếu bạn đến muộn quá 15 phút, cửa hàng vẫn tiếp đón chu đáo nhưng có thể cần xếp ca của bạn xen kẽ giữa các khung giờ còn trống tiếp theo của chi nhánh.",
  },
  {
    id: "wa1",
    category: "warranty",
    question: "Chính sách bảo hành sau khi sửa chữa như thế nào?",
    badge: "Bảo hành 3-12T",
    answer:
      "Thời hạn bảo hành dao động từ 3 tháng đến 12 tháng tùy loại linh kiện. Thông tin bảo hành được lưu trữ điện tử đồng bộ theo Số điện thoại và Mã lịch hẹn trên toàn hệ thống. Nếu linh kiện gặp lỗi từ nhà sản xuất trong thời gian bảo hành, bạn sẽ được 1 đổi 1 linh kiện mới hoàn toàn miễn phí tại bất kỳ chi nhánh nào.",
  },
  {
    id: "wa2",
    category: "warranty",
    question: "Nguồn gốc và chất lượng linh kiện thay thế tại PhoneRepair?",
    answer:
      "PhoneRepair cam kết chỉ sử dụng linh kiện đạt tiêu chuẩn kiểm định cao cấp nhất: linh kiện chính hãng bóc máy hoặc linh kiện thương hiệu cao cấp đạt chứng nhận ISO. Toàn bộ linh kiện đều có tem bảo hành niêm phong rõ ràng.",
  },
  {
    id: "s1",
    category: "security",
    question: "Dữ liệu cá nhân (hình ảnh, tin nhắn, tài khoản) trên máy có an toàn không?",
    badge: "Bảo mật",
    answer:
      "Chúng tôi cam kết bảo mật tuyệt đối thông tin khách hàng. Kỹ thuật viên không yêu cầu bạn cung cấp mật khẩu mở khóa màn hình trừ khi thật sự cần test chức năng (và luôn có sự đồng ý của bạn). Bạn có thể tự mình test máy sau khi thợ lắp xong.",
  },
  {
    id: "po1",
    category: "policy",
    question: "Tôi có thể hủy lịch hẹn đã đặt không? Có bị phạt phí gì không?",
    answer:
      "Bạn hoàn toàn có thể hủy hoặc đổi lịch hẹn bất kỳ lúc nào trước giờ hẹn. Chỉ cần truy cập mục 'Tài khoản của tôi > Lịch hẹn của tôi' và bấm 'Hủy lịch hẹn' kèm lý do. Việc hủy lịch là hoàn toàn miễn phí và không ảnh hưởng đến các lần đặt lịch sau.",
  },
  {
    id: "po2",
    category: "policy",
    question: "Làm thế nào để tôi đánh giá dịch vụ hoặc phản ánh nếu chưa hài lòng?",
    answer:
      "Sau khi ca sửa hoàn tất, bạn có thể vào tab 'Đánh giá dịch vụ' trong trang cá nhân để chấm điểm từ 1 đến 5 sao và gửi phản hồi. Ngoài ra, bạn có thể gọi thẳng đến Hotline giải quyết khiếu nại 1900 8899 (bấm phím 2) để quản lý cấp cao hỗ trợ trực tiếp.",
  },
]

const CATEGORIES = [
  { id: "all", label: "Tất cả câu hỏi", icon: "💡" },
  { id: "booking", label: "Đặt lịch & Tiếp nhận", icon: "🗓️" },
  { id: "pricing", label: "Bảng giá & Chi phí", icon: "💰" },
  { id: "workflow", label: "Thời gian & Quy trình", icon: "⏱️" },
  { id: "warranty", label: "Chính sách Bảo hành", icon: "🛡️" },
  { id: "security", label: "Bảo mật dữ liệu", icon: "🔒" },
  { id: "policy", label: "Hủy lịch & Khiếu nại", icon: "📋" },
]

export function SupportPage() {
  const { user } = useAuth()
  const [activeCategory, setActiveCategory] = useState<string>("all")
  const [searchQuery, setSearchQuery] = useState<string>("")
  const [openItems, setOpenItems] = useState<Record<string, boolean>>({
    b1: true,
    p1: true,
    w1: true,
  })

  // Quick ticket form states
  const [ticketName, setTicketName] = useState(user?.fullName || "")
  const [ticketPhone, setTicketPhone] = useState(user?.phoneNumber || "")
  const [ticketType, setTicketType] = useState("Tư vấn báo giá sửa chữa")
  const [ticketMessage, setTicketMessage] = useState("")
  const [ticketSent, setTicketSent] = useState(false)
  const [ticketSending, setTicketSending] = useState(false)

  const toggleItem = (id: string) => {
    setOpenItems((prev) => ({ ...prev, [id]: !prev[id] }))
  }

  const toggleAll = (expand: boolean) => {
    const newState: Record<string, boolean> = {}
    FAQ_LIST.forEach((item) => {
      newState[item.id] = expand
    })
    setOpenItems(newState)
  }

  const filteredFaqs = FAQ_LIST.filter((item) => {
    const matchCategory = activeCategory === "all" || item.category === activeCategory
    const matchSearch =
      !searchQuery.trim() ||
      item.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.answer.toLowerCase().includes(searchQuery.toLowerCase())
    return matchCategory && matchSearch
  })

  const handleSubmitTicket = (e: React.FormEvent) => {
    e.preventDefault()
    if (!ticketPhone.trim() || !ticketMessage.trim()) return

    setTicketSending(true)
    setTimeout(() => {
      setTicketSending(false)
      setTicketSent(true)
      setTicketMessage("")
    }, 800)
  }

  return (
    <main style={{ background: "#f8fafc", minHeight: "100vh", padding: "24px 20px 80px" }}>
      <div style={{ maxWidth: "1280px", margin: "0 auto" }}>
        {/* TOP BREADCRUMB */}
        <div style={{ display: "flex", alignItems: "center", gap: "8px", fontSize: "0.85rem", color: "#64748b", marginBottom: "20px" }}>
          <Link to="/" style={{ color: "#64748b", textDecoration: "none" }}>
            Trang chủ
          </Link>
          <span>/</span>
          <span style={{ color: "#0f172a", fontWeight: 700 }}>Trung tâm Hỗ trợ & FAQ</span>
        </div>

        {/* ================= 1. HERO BANNER WITH SEARCH ================= */}
        <section
          style={{
            background: "linear-gradient(135deg, #0b1329 0%, #172554 45%, #1e40af 100%)",
            borderRadius: "24px",
            padding: "44px 36px",
            color: "#ffffff",
            marginBottom: "36px",
            boxShadow: "0 10px 30px rgba(15,23,42,0.18)",
            position: "relative",
            overflow: "hidden",
          }}
        >
          {/* BACKGROUND GLOW ACCENT */}
          <div
            style={{
              position: "absolute",
              top: "-60px",
              right: "-60px",
              width: "280px",
              height: "280px",
              background: "radial-gradient(circle, rgba(59,130,246,0.35) 0%, rgba(0,0,0,0) 70%)",
              borderRadius: "50%",
              pointerEvents: "none",
            }}
          />

          <div style={{ maxWidth: "780px", margin: "0 auto", textAlign: "center", position: "relative", zIndex: 2 }}>
            <span
              style={{
                display: "inline-flex",
                alignItems: "center",
                gap: "6px",
                background: "rgba(255,255,255,0.15)",
                border: "1px solid rgba(255,255,255,0.25)",
                padding: "4px 14px",
                borderRadius: "999px",
                fontSize: "0.78rem",
                fontWeight: 700,
                letterSpacing: "0.5px",
                marginBottom: "16px",
                backdropFilter: "blur(6px)",
              }}
            >
              <span>🎧</span>
              <span>TRUNG TÂM TRỢ GIÚP 24/7</span>
            </span>

            <h1 style={{ fontSize: "2.3rem", fontWeight: 900, margin: "0 0 14px", letterSpacing: "-0.02em", lineHeight: 1.25 }}>
              Chúng tôi có thể giúp gì cho bạn?
            </h1>
            <p style={{ fontSize: "1rem", color: "#cbd5e1", margin: "0 auto 28px", lineHeight: 1.6, maxWidth: "640px" }}>
              Tìm câu trả lời nhanh chóng về chi phí, quy trình tiếp nhận, chính sách bảo hành và cam kết chất lượng tại PhoneRepair.
            </p>

            {/* SEARCH INPUT BAR */}
            <div
              style={{
                position: "relative",
                maxWidth: "640px",
                margin: "0 auto 18px",
                background: "#ffffff",
                borderRadius: "16px",
                boxShadow: "0 8px 25px rgba(0,0,0,0.25)",
                display: "flex",
                alignItems: "center",
                padding: "6px 8px 6px 18px",
              }}
            >
              <span style={{ fontSize: "1.2rem", color: "#94a3b8", marginRight: "10px" }}>🔍</span>
              <input
                type="text"
                placeholder="Nhập câu hỏi hoặc từ khóa: giá thay pin, bảo hành, hủy lịch, thời gian..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                style={{
                  flex: 1,
                  border: "none",
                  outline: "none",
                  fontSize: "0.95rem",
                  color: "#0f172a",
                  padding: "8px 0",
                }}
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery("")}
                  style={{ background: "none", border: "none", color: "#94a3b8", cursor: "pointer", fontSize: "1rem", padding: "0 10px" }}
                >
                  ✕
                </button>
              )}
            </div>

            {/* POPULAR KEYWORD TAGS */}
            <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: "8px", flexWrap: "wrap", fontSize: "0.78rem" }}>
              <span style={{ color: "#94a3b8" }}>Tìm kiếm phổ biến:</span>
              {[
                "Thay pin lấy ngay",
                "Giá thay màn hình",
                "Chính sách bảo hành",
                "Hủy lịch hẹn",
                "Ký tên linh kiện",
              ].map((tag) => (
                <button
                  key={tag}
                  type="button"
                  onClick={() => setSearchQuery(tag)}
                  style={{
                    background: "rgba(255,255,255,0.12)",
                    border: "1px solid rgba(255,255,255,0.2)",
                    color: "#ffffff",
                    borderRadius: "999px",
                    padding: "3px 12px",
                    fontSize: "0.76rem",
                    cursor: "pointer",
                    transition: "all 0.15s ease",
                  }}
                >
                  {tag}
                </button>
              ))}
            </div>
          </div>
        </section>

        {/* ================= 2. 4 QUICK CONTACT CHANNELS ================= */}
        <section style={{ marginBottom: "40px" }}>
          <div className="support-quick-contact-grid">
            {/* CHANNEL 1 */}
            <div
              style={{
                background: "#ffffff",
                border: "1px solid #e2e8f0",
                borderRadius: "18px",
                padding: "22px 20px",
                boxShadow: "0 2px 10px rgba(15,23,42,0.02)",
                display: "flex",
                flexDirection: "column",
                justifyContent: "space-between",
              }}
            >
              <div>
                <div style={{ width: "44px", height: "44px", borderRadius: "12px", background: "#eff6ff", color: "#2563eb", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "1.4rem", marginBottom: "12px" }}>
                  📞
                </div>
                <strong style={{ fontSize: "1rem", color: "#0f172a", display: "block", marginBottom: "4px" }}>
                  Tổng đài CSKH miễn phí
                </strong>
                <p style={{ fontSize: "0.8rem", color: "#64748b", margin: "0 0 12px", lineHeight: 1.45 }}>
                  Tư vấn kỹ thuật và đặt lịch nhanh 08:00 - 21:00 hàng ngày.
                </p>
                <div style={{ fontSize: "1.25rem", fontWeight: 900, color: "#1d4ed8", letterSpacing: "0.5px", marginBottom: "14px" }}>
                  1900 8899
                </div>
              </div>
              <a
                href="tel:19008899"
                style={{
                  display: "block",
                  textAlign: "center",
                  background: "#eff6ff",
                  color: "#2563eb",
                  border: "1px solid #bfdbfe",
                  padding: "8px 14px",
                  borderRadius: "10px",
                  fontSize: "0.82rem",
                  fontWeight: 700,
                  textDecoration: "none",
                }}
              >
                Gọi ngay ↗
              </a>
            </div>

            {/* CHANNEL 2 */}
            <div
              style={{
                background: "#ffffff",
                border: "1px solid #e2e8f0",
                borderRadius: "18px",
                padding: "22px 20px",
                boxShadow: "0 2px 10px rgba(15,23,42,0.02)",
                display: "flex",
                flexDirection: "column",
                justifyContent: "space-between",
              }}
            >
              <div>
                <div style={{ width: "44px", height: "44px", borderRadius: "12px", background: "#f0fdf4", color: "#16a34a", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "1.4rem", marginBottom: "12px" }}>
                  💬
                </div>
                <strong style={{ fontSize: "1rem", color: "#0f172a", display: "block", marginBottom: "4px" }}>
                  Chat Zalo / Hotline Kỹ thuật
                </strong>
                <p style={{ fontSize: "0.8rem", color: "#64748b", margin: "0 0 12px", lineHeight: 1.45 }}>
                  Gửi ảnh tình trạng máy để kỹ thuật viên chẩn đoán và báo giá.
                </p>
                <div style={{ fontSize: "1.1rem", fontWeight: 800, color: "#16a34a", marginBottom: "14px" }}>
                  0901 234 567
                </div>
              </div>
              <a
                href="https://zalo.me"
                target="_blank"
                rel="noreferrer"
                style={{
                  display: "block",
                  textAlign: "center",
                  background: "#f0fdf4",
                  color: "#16a34a",
                  border: "1px solid #bbf7d0",
                  padding: "8px 14px",
                  borderRadius: "10px",
                  fontSize: "0.82rem",
                  fontWeight: 700,
                  textDecoration: "none",
                }}
              >
                Nhắn Zalo ngay ↗
              </a>
            </div>

            {/* CHANNEL 3 */}
            <div
              style={{
                background: "#ffffff",
                border: "1px solid #e2e8f0",
                borderRadius: "18px",
                padding: "22px 20px",
                boxShadow: "0 2px 10px rgba(15,23,42,0.02)",
                display: "flex",
                flexDirection: "column",
                justifyContent: "space-between",
              }}
            >
              <div>
                <div style={{ width: "44px", height: "44px", borderRadius: "12px", background: "#faf5ff", color: "#9333ea", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "1.4rem", marginBottom: "12px" }}>
                  📧
                </div>
                <strong style={{ fontSize: "1rem", color: "#0f172a", display: "block", marginBottom: "4px" }}>
                  Hòm thư hỗ trợ chính thức
                </strong>
                <p style={{ fontSize: "0.8rem", color: "#64748b", margin: "0 0 12px", lineHeight: 1.45 }}>
                  Tiếp nhận phản ánh, xuất hóa đơn VAT và góp ý dịch vụ.
                </p>
                <div style={{ fontSize: "0.88rem", fontWeight: 700, color: "#9333ea", marginBottom: "14px", wordBreak: "break-all" }}>
                  hotro@phonerepair.vn
                </div>
              </div>
              <a
                href="mailto:hotro@phonerepair.vn"
                style={{
                  display: "block",
                  textAlign: "center",
                  background: "#faf5ff",
                  color: "#9333ea",
                  border: "1px solid #e9d5ff",
                  padding: "8px 14px",
                  borderRadius: "10px",
                  fontSize: "0.82rem",
                  fontWeight: 700,
                  textDecoration: "none",
                }}
              >
                Gửi email ↗
              </a>
            </div>

            {/* CHANNEL 4 */}
            <div
              style={{
                background: "#ffffff",
                border: "1px solid #e2e8f0",
                borderRadius: "18px",
                padding: "22px 20px",
                boxShadow: "0 2px 10px rgba(15,23,42,0.02)",
                display: "flex",
                flexDirection: "column",
                justifyContent: "space-between",
              }}
            >
              <div>
                <div style={{ width: "44px", height: "44px", borderRadius: "12px", background: "#ecfeff", color: "#0891b2", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "1.4rem", marginBottom: "12px" }}>
                  📍
                </div>
                <strong style={{ fontSize: "1rem", color: "#0f172a", display: "block", marginBottom: "4px" }}>
                  Hệ thống 6 chi nhánh
                </strong>
                <p style={{ fontSize: "0.8rem", color: "#64748b", margin: "0 0 12px", lineHeight: 1.45 }}>
                  Phục vụ tại Hà Nội & TP. Hồ Chí Minh. Giờ mở cửa: 08:00 - 20:30.
                </p>
                <div style={{ fontSize: "0.88rem", fontWeight: 700, color: "#0891b2", marginBottom: "14px" }}>
                  Đến trực tiếp sửa ngay
                </div>
              </div>
              <Link
                to="/branches"
                style={{
                  display: "block",
                  textAlign: "center",
                  background: "#ecfeff",
                  color: "#0891b2",
                  border: "1px solid #bae6fd",
                  padding: "8px 14px",
                  borderRadius: "10px",
                  fontSize: "0.82rem",
                  fontWeight: 700,
                  textDecoration: "none",
                }}
              >
                Xem chi nhánh & bản đồ →
              </Link>
            </div>
          </div>
        </section>

        {/* ================= 3. FAQ ACCORDION WITH CATEGORIES ================= */}
        <section style={{ marginBottom: "48px" }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "18px" }}>
            <div>
              <h2 style={{ fontSize: "1.4rem", fontWeight: 800, color: "#0f172a", margin: "0 0 4px" }}>
                Câu hỏi thường gặp (FAQ)
              </h2>
              <p style={{ fontSize: "0.85rem", color: "#64748b", margin: 0 }}>
                {filteredFaqs.length} câu trả lời được chuyên gia kỹ thuật PhoneRepair biên soạn chi tiết.
              </p>
            </div>

            <div style={{ display: "flex", gap: "8px" }}>
              <button
                type="button"
                onClick={() => toggleAll(true)}
                style={{ background: "#ffffff", border: "1px solid #cbd5e1", borderRadius: "8px", padding: "6px 12px", fontSize: "0.78rem", fontWeight: 600, color: "#475569", cursor: "pointer" }}
              >
                Mở tất cả
              </button>
              <button
                type="button"
                onClick={() => toggleAll(false)}
                style={{ background: "#ffffff", border: "1px solid #cbd5e1", borderRadius: "8px", padding: "6px 12px", fontSize: "0.78rem", fontWeight: 600, color: "#475569", cursor: "pointer" }}
              >
                Thu gọn
              </button>
            </div>
          </div>

          {/* CATEGORY SELECTOR PILLS */}
          <div style={{ display: "flex", gap: "8px", flexWrap: "wrap", marginBottom: "22px" }}>
            {CATEGORIES.map((cat) => {
              const isActive = activeCategory === cat.id
              const count =
                cat.id === "all"
                  ? FAQ_LIST.length
                  : FAQ_LIST.filter((f) => f.category === cat.id).length
              return (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => {
                    setActiveCategory(cat.id)
                    setSearchQuery("")
                  }}
                  style={{
                    display: "inline-flex",
                    alignItems: "center",
                    gap: "6px",
                    padding: "8px 16px",
                    borderRadius: "999px",
                    fontSize: "0.82rem",
                    fontWeight: isActive ? 700 : 500,
                    border: isActive ? "1.5px solid #2563eb" : "1px solid #e2e8f0",
                    background: isActive ? "#2563eb" : "#ffffff",
                    color: isActive ? "#ffffff" : "#475569",
                    cursor: "pointer",
                    boxShadow: isActive ? "0 2px 8px rgba(37,99,235,0.25)" : "none",
                    transition: "all 0.15s ease",
                  }}
                >
                  <span>{cat.icon}</span>
                  <span>{cat.label}</span>
                  <span
                    style={{
                      fontSize: "0.7rem",
                      background: isActive ? "rgba(255,255,255,0.25)" : "#f1f5f9",
                      color: isActive ? "#ffffff" : "#64748b",
                      padding: "1px 6px",
                      borderRadius: "999px",
                      marginLeft: "2px",
                    }}
                  >
                    {count}
                  </span>
                </button>
              )
            })}
          </div>

          {/* ACCORDION ITEMS LIST */}
          <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
            {filteredFaqs.length === 0 ? (
              <div style={{ background: "#ffffff", border: "1px solid #e2e8f0", borderRadius: "16px", padding: "48px 20px", textAlign: "center" }}>
                <span style={{ fontSize: "2.5rem", display: "block", marginBottom: "8px" }}>🔍</span>
                <strong style={{ fontSize: "1rem", color: "#0f172a", display: "block", marginBottom: "4px" }}>
                  Không tìm thấy câu hỏi phù hợp với "{searchQuery}"
                </strong>
                <p style={{ fontSize: "0.85rem", color: "#64748b", margin: "0 0 16px" }}>
                  Hãy thử tìm kiếm với các từ khóa ngắn gọn hơn hoặc gửi yêu cầu bên dưới để chúng tôi giải đáp.
                </p>
                <button
                  type="button"
                  onClick={() => {
                    setSearchQuery("")
                    setActiveCategory("all")
                  }}
                  style={{
                    background: "#2563eb",
                    color: "#ffffff",
                    border: "none",
                    padding: "8px 18px",
                    borderRadius: "8px",
                    fontSize: "0.82rem",
                    fontWeight: 700,
                    cursor: "pointer",
                  }}
                >
                  Xóa bộ lọc tìm kiếm
                </button>
              </div>
            ) : (
              filteredFaqs.map((faq) => {
                const isOpen = !!openItems[faq.id]
                return (
                  <div
                    key={faq.id}
                    style={{
                      background: "#ffffff",
                      border: isOpen ? "1.5px solid #2563eb" : "1px solid #e2e8f0",
                      borderRadius: "14px",
                      overflow: "hidden",
                      boxShadow: isOpen ? "0 4px 14px rgba(37,99,235,0.06)" : "0 2px 6px rgba(15,23,42,0.015)",
                      transition: "all 0.18s ease",
                    }}
                  >
                    <button
                      type="button"
                      onClick={() => toggleItem(faq.id)}
                      style={{
                        width: "100%",
                        padding: "18px 22px",
                        background: "none",
                        border: "none",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "space-between",
                        textAlign: "left",
                        cursor: "pointer",
                        gap: "16px",
                      }}
                    >
                      <div style={{ display: "flex", alignItems: "center", gap: "12px", flex: 1 }}>
                        <span style={{ fontSize: "1.1rem" }}>
                          {faq.category === "booking"
                            ? "🗓️"
                            : faq.category === "pricing"
                            ? "💰"
                            : faq.category === "workflow"
                            ? "⏱️"
                            : faq.category === "warranty"
                            ? "🛡️"
                            : faq.category === "security"
                            ? "🔒"
                            : "📋"}
                        </span>
                        <span style={{ fontSize: "0.98rem", fontWeight: 700, color: isOpen ? "#1e40af" : "#0f172a", lineHeight: 1.4 }}>
                          {faq.question}
                        </span>
                        {faq.badge && (
                          <span
                            style={{
                              fontSize: "0.68rem",
                              background: "#eff6ff",
                              color: "#2563eb",
                              padding: "2px 8px",
                              borderRadius: "999px",
                              fontWeight: 700,
                              whiteSpace: "nowrap",
                            }}
                          >
                            {faq.badge}
                          </span>
                        )}
                      </div>

                      <div
                        style={{
                          width: "28px",
                          height: "28px",
                          borderRadius: "50%",
                          background: isOpen ? "#eff6ff" : "#f8fafc",
                          color: isOpen ? "#2563eb" : "#64748b",
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                          fontSize: "1.1rem",
                          fontWeight: 700,
                          flexShrink: 0,
                          transition: "all 0.18s ease",
                        }}
                      >
                        {isOpen ? "−" : "+"}
                      </div>
                    </button>

                    {isOpen && (
                      <div
                        style={{
                          padding: "0 22px 20px 52px",
                          borderTop: "1px dashed #f1f5f9",
                          marginTop: "2px",
                          fontSize: "0.9rem",
                          color: "#475569",
                          lineHeight: 1.7,
                        }}
                      >
                        <p style={{ margin: "14px 0 0" }}>{faq.answer}</p>
                      </div>
                    )}
                  </div>
                )
              })
            )}
          </div>
        </section>

        {/* ================= 4. QUICK SUPPORT TICKET FORM ================= */}
        <section
          style={{
            background: "#ffffff",
            border: "1px solid #e2e8f0",
            borderRadius: "20px",
            padding: "clamp(18px, 4vw, 36px)",
            marginBottom: "48px",
            boxShadow: "0 4px 18px rgba(15,23,42,0.03)",
          }}
        >
          <div className="support-ticket-split">
            {/* LEFT: INFO & COMMITMENTS */}
            <div>
              <span style={{ fontSize: "0.8rem", color: "#2563eb", fontWeight: 800, textTransform: "uppercase", letterSpacing: "0.5px" }}>
                Liên hệ trực tiếp
              </span>
              <h3 style={{ fontSize: "1.45rem", fontWeight: 800, color: "#0f172a", margin: "6px 0 12px" }}>
                Gửi câu hỏi cho chuyên viên kỹ thuật
              </h3>
              <p style={{ fontSize: "0.88rem", color: "#64748b", lineHeight: 1.6, margin: "0 0 24px" }}>
                Nếu câu hỏi của bạn chưa có trong danh mục FAQ hoặc bạn cần báo giá chính xác cho tình trạng máy, hãy gửi tin nhắn. Đội ngũ kỹ thuật viên sẽ gọi lại tư vấn miễn phí cho bạn trong vòng 15 phút.
              </p>

              <div style={{ display: "flex", flexDirection: "column", gap: "14px" }}>
                <div style={{ display: "flex", alignItems: "flex-start", gap: "10px" }}>
                  <span style={{ color: "#16a34a", fontSize: "1.1rem" }}>✓</span>
                  <div style={{ fontSize: "0.82rem", color: "#334155" }}>
                    <strong>Kiểm tra máy miễn phí 100%:</strong> Không sửa không mất bất kỳ khoản phí nào.
                  </div>
                </div>

                <div style={{ display: "flex", alignItems: "flex-start", gap: "10px" }}>
                  <span style={{ color: "#16a34a", fontSize: "1.1rem" }}>✓</span>
                  <div style={{ fontSize: "0.82rem", color: "#334155" }}>
                    <strong>Báo giá minh bạch trước khi làm:</strong> Khách duyệt giá mới tiến hành tháo lắp.
                  </div>
                </div>

                <div style={{ display: "flex", alignItems: "flex-start", gap: "10px" }}>
                  <span style={{ color: "#16a34a", fontSize: "1.1rem" }}>✓</span>
                  <div style={{ fontSize: "0.82rem", color: "#334155" }}>
                    <strong>Ký tên lên toàn bộ linh kiện:</strong> Trực tiếp ngồi xem thợ sửa tại quầy mở.
                  </div>
                </div>

                <div style={{ display: "flex", alignItems: "flex-start", gap: "10px" }}>
                  <span style={{ color: "#16a34a", fontSize: "1.1rem" }}>✓</span>
                  <div style={{ fontSize: "0.82rem", color: "#334155" }}>
                    <strong>Bảo mật thông tin:</strong> Không động vào dữ liệu cá nhân trên máy của bạn.
                  </div>
                </div>
              </div>
            </div>

            {/* RIGHT: TICKET FORM */}
            <div style={{ background: "#f8fafc", border: "1px solid #e2e8f0", borderRadius: "16px", padding: "26px" }}>
              {ticketSent ? (
                <div style={{ textAlign: "center", padding: "30px 10px" }}>
                  <span style={{ fontSize: "3rem", display: "block", marginBottom: "12px" }}>🎉</span>
                  <strong style={{ fontSize: "1.15rem", color: "#0f172a", display: "block", marginBottom: "6px" }}>
                    Yêu cầu đã được gửi thành công!
                  </strong>
                  <p style={{ fontSize: "0.85rem", color: "#64748b", margin: "0 0 20px" }}>
                    Chuyên viên kỹ thuật PhoneRepair sẽ liên hệ qua số điện thoại <strong>{ticketPhone}</strong> trong vòng 15 phút.
                  </p>
                  <button
                    type="button"
                    onClick={() => setTicketSent(false)}
                    style={{
                      background: "#2563eb",
                      color: "#ffffff",
                      border: "none",
                      padding: "8px 18px",
                      borderRadius: "8px",
                      fontSize: "0.82rem",
                      fontWeight: 700,
                      cursor: "pointer",
                    }}
                  >
                    Gửi yêu cầu khác
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmitTicket} style={{ display: "flex", flexDirection: "column", gap: "14px" }}>
                  <div className="form-two-col">
                    <div>
                      <label style={{ display: "block", fontSize: "0.8rem", fontWeight: 700, color: "#0f172a", marginBottom: "4px" }}>
                        Họ và tên
                      </label>
                      <input
                        type="text"
                        placeholder="Nguyễn Văn A"
                        value={ticketName}
                        onChange={(e) => setTicketName(e.target.value)}
                        style={{ width: "100%", padding: "9px 12px", borderRadius: "8px", border: "1px solid #cbd5e1", fontSize: "0.85rem" }}
                      />
                    </div>
                    <div>
                      <label style={{ display: "block", fontSize: "0.8rem", fontWeight: 700, color: "#0f172a", marginBottom: "4px" }}>
                        Số điện thoại liên hệ <span style={{ color: "#ef4444" }}>*</span>
                      </label>
                      <input
                        type="tel"
                        placeholder="090 123 4567"
                        required
                        value={ticketPhone}
                        onChange={(e) => setTicketPhone(e.target.value)}
                        style={{ width: "100%", padding: "9px 12px", borderRadius: "8px", border: "1px solid #cbd5e1", fontSize: "0.85rem" }}
                      />
                    </div>
                  </div>

                  <div>
                    <label style={{ display: "block", fontSize: "0.8rem", fontWeight: 700, color: "#0f172a", marginBottom: "4px" }}>
                      Chủ đề cần hỗ trợ
                    </label>
                    <select
                      value={ticketType}
                      onChange={(e) => setTicketType(e.target.value)}
                      style={{ width: "100%", padding: "9px 12px", borderRadius: "8px", border: "1px solid #cbd5e1", fontSize: "0.85rem" }}
                    >
                      <option value="Tư vấn báo giá sửa chữa">Tư vấn báo giá sửa chữa linh kiện</option>
                      <option value="Hỏi tiến độ ca sửa máy">Tra cứu tiến độ lịch hẹn / ca sửa máy</option>
                      <option value="Hỗ trợ bảo hành">Hỗ trợ chính sách bảo hành</option>
                      <option value="Khiếu nại / Phản ánh">Khiếu nại dịch vụ & thái độ phục vụ</option>
                      <option value="Khác">Chủ đề khác</option>
                    </select>
                  </div>

                  <div>
                    <label style={{ display: "block", fontSize: "0.8rem", fontWeight: 700, color: "#0f172a", marginBottom: "4px" }}>
                      Nội dung thắc mắc hoặc mô tả lỗi máy <span style={{ color: "#ef4444" }}>*</span>
                    </label>
                    <textarea
                      rows={3}
                      required
                      placeholder="Ví dụ: Máy iPhone 15 Pro bị sọc xanh màn hình, cần hỏi giá thay và thời gian có linh kiện..."
                      value={ticketMessage}
                      onChange={(e) => setTicketMessage(e.target.value)}
                      style={{ width: "100%", padding: "10px 12px", borderRadius: "8px", border: "1px solid #cbd5e1", fontSize: "0.85rem", resize: "vertical" }}
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={ticketSending}
                    style={{
                      background: "#2563eb",
                      color: "#ffffff",
                      border: "none",
                      padding: "11px 18px",
                      borderRadius: "10px",
                      fontSize: "0.88rem",
                      fontWeight: 700,
                      cursor: ticketSending ? "wait" : "pointer",
                      boxShadow: "0 2px 8px rgba(37,99,235,0.25)",
                    }}
                  >
                    {ticketSending ? "Đang gửi yêu cầu..." : "Gửi yêu cầu hỗ trợ ngay"}
                  </button>
                </form>
              )}
            </div>
          </div>
        </section>

        {/* ================= 5. TRUST HIGHLIGHTS ================= */}
        <section style={{ marginBottom: "48px" }}>
          <div style={{ textAlign: "center", marginBottom: "26px" }}>
            <span style={{ fontSize: "0.8rem", color: "#2563eb", fontWeight: 800, textTransform: "uppercase", letterSpacing: "0.5px" }}>
              Cam kết dịch vụ vàng
            </span>
            <h2 style={{ fontSize: "1.45rem", fontWeight: 800, color: "#0f172a", margin: "6px 0 0" }}>
              4 Lý do an tâm tuyệt đối khi sửa máy tại PhoneRepair
            </h2>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: "18px" }}>
            <div style={{ background: "#ffffff", border: "1px solid #e2e8f0", borderRadius: "16px", padding: "24px 20px", textAlign: "center" }}>
              <div style={{ width: "48px", height: "48px", borderRadius: "50%", background: "#eff6ff", color: "#2563eb", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "1.5rem", margin: "0 auto 12px" }}>
                🛡️
              </div>
              <strong style={{ fontSize: "0.95rem", color: "#0f172a", display: "block", marginBottom: "6px" }}>
                Linh kiện chính hãng 100%
              </strong>
              <p style={{ fontSize: "0.78rem", color: "#64748b", margin: 0, lineHeight: 1.5 }}>
                Đạt chuẩn kiểm định quốc tế, tem mác niêm phong xuất xứ rõ ràng.
              </p>
            </div>

            <div style={{ background: "#ffffff", border: "1px solid #e2e8f0", borderRadius: "16px", padding: "24px 20px", textAlign: "center" }}>
              <div style={{ width: "48px", height: "48px", borderRadius: "50%", background: "#f0fdf4", color: "#16a34a", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "1.5rem", margin: "0 auto 12px" }}>
                ⏱️
              </div>
              <strong style={{ fontSize: "0.95rem", color: "#0f172a", display: "block", marginBottom: "6px" }}>
                Lấy ngay trong 30 - 60 phút
              </strong>
              <p style={{ fontSize: "0.78rem", color: "#64748b", margin: 0, lineHeight: 1.5 }}>
                Tiết kiệm thời gian, khách hàng trực tiếp ngồi xem thợ tháo lắp máy.
              </p>
            </div>

            <div style={{ background: "#ffffff", border: "1px solid #e2e8f0", borderRadius: "16px", padding: "24px 20px", textAlign: "center" }}>
              <div style={{ width: "48px", height: "48px", borderRadius: "50%", background: "#faf5ff", color: "#9333ea", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "1.5rem", margin: "0 auto 12px" }}>
                👨‍🔧
              </div>
              <strong style={{ fontSize: "0.95rem", color: "#0f172a", display: "block", marginBottom: "6px" }}>
                Kỹ thuật viên chuyên nghiệp
              </strong>
              <p style={{ fontSize: "0.78rem", color: "#64748b", margin: 0, lineHeight: 1.5 }}>
                Kinh nghiệm hơn 5 năm, xử lý thành công hàng ngàn ca lỗi bo mạch phức tạp.
              </p>
            </div>

            <div style={{ background: "#ffffff", border: "1px solid #e2e8f0", borderRadius: "16px", padding: "24px 20px", textAlign: "center" }}>
              <div style={{ width: "48px", height: "48px", borderRadius: "50%", background: "#ecfeff", color: "#0891b2", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "1.5rem", margin: "0 auto 12px" }}>
                🔄
              </div>
              <strong style={{ fontSize: "0.95rem", color: "#0f172a", display: "block", marginBottom: "6px" }}>
                Bảo hành 1 đổi 1 chu đáo
              </strong>
              <p style={{ fontSize: "0.78rem", color: "#64748b", margin: 0, lineHeight: 1.5 }}>
                Thời hạn bảo hành từ 3 - 12 tháng, kích hoạt bảo hành điện tử toàn quốc.
              </p>
            </div>
          </div>
        </section>

        {/* ================= 6. BOTTOM CTA BANNER ================= */}
        <section
          style={{
            background: "linear-gradient(135deg, #1e3a8a 0%, #2563eb 100%)",
            borderRadius: "22px",
            padding: "44px 32px",
            textAlign: "center",
            color: "#ffffff",
            boxShadow: "0 8px 25px rgba(37,99,235,0.25)",
          }}
        >
          <h2 style={{ fontSize: "1.8rem", fontWeight: 900, margin: "0 0 10px", letterSpacing: "-0.01em" }}>
            Bạn đã sẵn sàng khắc phục lỗi thiết bị hôm nay?
          </h2>
          <p style={{ fontSize: "0.95rem", opacity: 0.92, margin: "0 auto 24px", maxWidth: "600px", lineHeight: 1.6 }}>
            Đặt lịch hẹn trực tuyến chỉ mất 1 phút để chọn trước khung giờ mong muốn, giữ chỗ kỹ thuật viên tại chi nhánh gần bạn nhất!
          </p>
          <div style={{ display: "flex", gap: "14px", justifyContent: "center", flexWrap: "wrap" }}>
            <Link
              to="/booking"
              style={{
                background: "#ffffff",
                color: "#2563eb",
                padding: "12px 28px",
                borderRadius: "12px",
                fontSize: "0.9rem",
                fontWeight: 800,
                textDecoration: "none",
                boxShadow: "0 4px 12px rgba(0,0,0,0.12)",
              }}
            >
              Đặt lịch sửa chữa ngay ↗
            </Link>
            <Link
              to="/pricing"
              style={{
                background: "rgba(255,255,255,0.15)",
                color: "#ffffff",
                border: "1.5px solid rgba(255,255,255,0.4)",
                padding: "12px 28px",
                borderRadius: "12px",
                fontSize: "0.9rem",
                fontWeight: 700,
                textDecoration: "none",
                backdropFilter: "blur(4px)",
              }}
            >
              Tra cứu bảng giá dịch vụ
            </Link>
          </div>
        </section>
      </div>
    </main>
  )
}
