import { useEffect, useMemo, useState } from "react"
import { Link } from "react-router-dom"
import {
  adminBrands,
  adminModels,
  adminPrices,
  adminServices,
  formatPrice,
  saveBrand,
  saveModel,
  savePrice,
  saveService,
  type Brand,
  type PhoneModel,
  type PricingType,
  type RepairService,
  type ServicePrice,
} from "../api/catalog"
import { ApiError } from "../api/client"
import { useAuth } from "../auth/AuthContext"
import { BRAND_LOGOS } from "../assets"
import { useIsMobile } from "../utils/useMediaQuery"

export function AdminCatalogPage() {
  const isMobile = useIsMobile(960)
  const { token } = useAuth()

  // Data states
  const [brands, setBrands] = useState<Brand[]>([])
  const [models, setModels] = useState<PhoneModel[]>([])
  const [services, setServices] = useState<RepairService[]>([])
  const [prices, setPrices] = useState<ServicePrice[]>([])
  const [loading, setLoading] = useState(false)
  const [actionLoading, setActionLoading] = useState(false)

  // Feedback messages
  const [successMsg, setSuccessMsg] = useState("")
  const [errorMsg, setErrorMsg] = useState("")

  // Active tab: brands, models, services, prices
  const [activeTab, setActiveTab] = useState<"brands" | "models" | "services" | "prices">("brands")

  // Form states
  const [brandName, setBrandName] = useState("")
  const [modelName, setModelName] = useState("")
  const [modelBrandId, setModelBrandId] = useState("")
  const [modelYear, setModelYear] = useState("")
  const [serviceName, setServiceName] = useState("")
  const [pricingType, setPricingType] = useState<PricingType>("FixedPrice")
  const [priceModelId, setPriceModelId] = useState("")
  const [priceServiceId, setPriceServiceId] = useState("")
  const [amount, setAmount] = useState("")

  // Search & Filter states
  const [brandSearch, setBrandSearch] = useState("")
  const [modelSearch, setModelSearch] = useState("")
  const [modelFilterBrand, setModelFilterBrand] = useState("")
  const [serviceSearch, setServiceSearch] = useState("")
  const [priceSearch, setPriceSearch] = useState("")
  const [priceFilterBrand, setPriceFilterBrand] = useState("")
  const [priceFilterService, setPriceFilterService] = useState("")

  async function reload() {
    if (!token) return
    setLoading(true)
    try {
      const [brandRows, modelRows, serviceRows, priceRows] = await Promise.all([
        adminBrands(token),
        adminModels(token),
        adminServices(token),
        adminPrices(token),
      ])
      setBrands(brandRows)
      setModels(modelRows)
      setServices(serviceRows)
      setPrices(priceRows)
    } catch {
      setErrorMsg("Không thể tải danh mục dữ liệu.")
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    void reload()
  }, [token])

  async function run(action: () => Promise<unknown>, successText = "Đã lưu thành công.") {
    setErrorMsg("")
    setSuccessMsg("")
    setActionLoading(true)
    try {
      await action()
      await reload()
      setSuccessMsg(successText)
    } catch (error) {
      setErrorMsg(error instanceof ApiError ? error.message : "Thao tác không thành công.")
    } finally {
      setActionLoading(false)
    }
  }

  // Filtered lists
  const filteredBrands = useMemo(() => {
    return brands.filter((b) => b.name.toLowerCase().includes(brandSearch.trim().toLowerCase()))
  }, [brands, brandSearch])

  const filteredModels = useMemo(() => {
    return models.filter((m) => {
      const matchesSearch =
        m.name.toLowerCase().includes(modelSearch.trim().toLowerCase()) ||
        (m.brandName && m.brandName.toLowerCase().includes(modelSearch.trim().toLowerCase()))
      const matchesBrand = modelFilterBrand ? String(m.brandId) === modelFilterBrand : true
      return matchesSearch && matchesBrand
    })
  }, [models, modelSearch, modelFilterBrand])

  const filteredServices = useMemo(() => {
    return services.filter((s) => s.name.toLowerCase().includes(serviceSearch.trim().toLowerCase()))
  }, [services, serviceSearch])

  const filteredPrices = useMemo(() => {
    return prices.filter((p) => {
      const matchesSearch =
        (p.brandName && p.brandName.toLowerCase().includes(priceSearch.trim().toLowerCase())) ||
        (p.phoneModelName && p.phoneModelName.toLowerCase().includes(priceSearch.trim().toLowerCase())) ||
        (p.repairServiceName && p.repairServiceName.toLowerCase().includes(priceSearch.trim().toLowerCase()))
      const matchesBrand = priceFilterBrand
        ? p.brandName?.toLowerCase() === priceFilterBrand.toLowerCase()
        : true
      const matchesService = priceFilterService
        ? String(p.repairServiceId) === priceFilterService
        : true
      return matchesSearch && matchesBrand && matchesService
    })
  }, [prices, priceSearch, priceFilterBrand, priceFilterService])

  return (
    <main className="page" style={{ maxWidth: "1360px", margin: "0 auto", padding: isMobile ? "16px 12px 60px" : "24px 20px 80px" }}>
      {/* BACK TO ADMIN PORTAL */}
      <div style={{ marginBottom: "16px" }}>
        <Link className="text-link" to="/admin">
          ← Quay lại Trung tâm Quản trị
        </Link>
      </div>

      {/* HERO BANNER */}
      <section className="hero" style={{ paddingBottom: "24px", marginBottom: "20px" }}>
        <div>
          <span className="eyebrow">Quản trị & Danh mục</span>
          <h1 style={{ fontSize: isMobile ? "1.6rem" : "2.2rem", margin: "4px 0 8px" }}>
            Quản lý Danh mục Sửa chữa & Bảng giá
          </h1>
          <p className="lede" style={{ fontSize: isMobile ? "0.9rem" : "1.05rem", margin: 0 }}>
            Quản lý các thương hiệu điện thoại, model thiết bị, dịch vụ sửa chữa và thiết lập bảng giá theo từng máy.
          </p>
        </div>
      </section>

      {/* FEEDBACK ALERTS */}
      {loading ? <p style={{ margin: "14px 0", color: "#64748b", textAlign: "center" }}>Đang đồng bộ dữ liệu danh mục...</p> : null}
      {errorMsg ? <p className="form-error" style={{ margin: "14px 0" }}>{errorMsg}</p> : null}
      {successMsg ? <p className="form-success" style={{ margin: "14px 0" }}>{successMsg}</p> : null}

      {/* 4 STATS OVERVIEW CARDS */}
      <div
        style={{
          display: "grid",
          gridTemplateColumns: isMobile ? "repeat(2, 1fr)" : "repeat(4, 1fr)",
          gap: isMobile ? "10px" : "16px",
          marginBottom: "24px",
        }}
      >
        <div
          onClick={() => setActiveTab("brands")}
          style={{
            background: activeTab === "brands" ? "#eff6ff" : "#ffffff",
            border: activeTab === "brands" ? "2px solid #2563eb" : "1px solid #e2e8f0",
            borderRadius: "14px",
            padding: "16px",
            cursor: "pointer",
            transition: "all 0.15s ease",
            boxShadow: "0 2px 8px rgba(15,23,42,0.03)",
          }}
        >
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
            <span style={{ fontSize: "0.8rem", fontWeight: 700, color: "#64748b" }}>THƯƠNG HIỆU</span>
            <span style={{ fontSize: "1.2rem" }}>📱</span>
          </div>
          <div style={{ fontSize: "1.7rem", fontWeight: 800, color: "#0f172a", margin: "4px 0 2px" }}>
            {brands.length}
          </div>
          <span style={{ fontSize: "0.76rem", color: "#2563eb", fontWeight: 600 }}>Tất cả hãng máy</span>
        </div>

        <div
          onClick={() => setActiveTab("models")}
          style={{
            background: activeTab === "models" ? "#eff6ff" : "#ffffff",
            border: activeTab === "models" ? "2px solid #2563eb" : "1px solid #e2e8f0",
            borderRadius: "14px",
            padding: "16px",
            cursor: "pointer",
            transition: "all 0.15s ease",
            boxShadow: "0 2px 8px rgba(15,23,42,0.03)",
          }}
        >
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
            <span style={{ fontSize: "0.8rem", fontWeight: 700, color: "#64748b" }}>DÒNG MÁY</span>
            <span style={{ fontSize: "1.2rem" }}>📲</span>
          </div>
          <div style={{ fontSize: "1.7rem", fontWeight: 800, color: "#0f172a", margin: "4px 0 2px" }}>
            {models.length}
          </div>
          <span style={{ fontSize: "0.76rem", color: "#2563eb", fontWeight: 600 }}>Model thiết bị</span>
        </div>

        <div
          onClick={() => setActiveTab("services")}
          style={{
            background: activeTab === "services" ? "#eff6ff" : "#ffffff",
            border: activeTab === "services" ? "2px solid #2563eb" : "1px solid #e2e8f0",
            borderRadius: "14px",
            padding: "16px",
            cursor: "pointer",
            transition: "all 0.15s ease",
            boxShadow: "0 2px 8px rgba(15,23,42,0.03)",
          }}
        >
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
            <span style={{ fontSize: "0.8rem", fontWeight: 700, color: "#64748b" }}>DỊCH VỤ SỬA</span>
            <span style={{ fontSize: "1.2rem" }}>🔧</span>
          </div>
          <div style={{ fontSize: "1.7rem", fontWeight: 800, color: "#0f172a", margin: "4px 0 2px" }}>
            {services.length}
          </div>
          <span style={{ fontSize: "0.76rem", color: "#2563eb", fontWeight: 600 }}>Gói dịch vụ</span>
        </div>

        <div
          onClick={() => setActiveTab("prices")}
          style={{
            background: activeTab === "prices" ? "#eff6ff" : "#ffffff",
            border: activeTab === "prices" ? "2px solid #2563eb" : "1px solid #e2e8f0",
            borderRadius: "14px",
            padding: "16px",
            cursor: "pointer",
            transition: "all 0.15s ease",
            boxShadow: "0 2px 8px rgba(15,23,42,0.03)",
          }}
        >
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
            <span style={{ fontSize: "0.8rem", fontWeight: 700, color: "#64748b" }}>ĐƠN GIÁ ĐÃ CẤU HÌNH</span>
            <span style={{ fontSize: "1.2rem" }}>💰</span>
          </div>
          <div style={{ fontSize: "1.7rem", fontWeight: 800, color: "#0f172a", margin: "4px 0 2px" }}>
            {prices.length}
          </div>
          <span style={{ fontSize: "0.76rem", color: "#2563eb", fontWeight: 600 }}>Giá theo từng máy</span>
        </div>
      </div>

      {/* SEGMENTED TAB NAVIGATION */}
      <div
        style={{
          display: "flex",
          gap: "8px",
          background: "#ffffff",
          padding: "6px",
          borderRadius: "14px",
          border: "1px solid #e2e8f0",
          marginBottom: "24px",
          overflowX: "auto",
        }}
      >
        <button
          type="button"
          onClick={() => setActiveTab("brands")}
          style={{
            flex: isMobile ? "initial" : 1,
            padding: "10px 16px",
            borderRadius: "10px",
            border: "none",
            background: activeTab === "brands" ? "#2563eb" : "transparent",
            color: activeTab === "brands" ? "#ffffff" : "#475569",
            fontWeight: 700,
            fontSize: "0.88rem",
            cursor: "pointer",
            display: "inline-flex",
            alignItems: "center",
            justifyContent: "center",
            gap: "8px",
            whiteSpace: "nowrap",
            transition: "all 0.15s ease",
          }}
        >
          <span>📱</span>
          <span>Thương hiệu ({brands.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab("models")}
          style={{
            flex: isMobile ? "initial" : 1,
            padding: "10px 16px",
            borderRadius: "10px",
            border: "none",
            background: activeTab === "models" ? "#2563eb" : "transparent",
            color: activeTab === "models" ? "#ffffff" : "#475569",
            fontWeight: 700,
            fontSize: "0.88rem",
            cursor: "pointer",
            display: "inline-flex",
            alignItems: "center",
            justifyContent: "center",
            gap: "8px",
            whiteSpace: "nowrap",
            transition: "all 0.15s ease",
          }}
        >
          <span>📲</span>
          <span>Dòng máy ({models.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab("services")}
          style={{
            flex: isMobile ? "initial" : 1,
            padding: "10px 16px",
            borderRadius: "10px",
            border: "none",
            background: activeTab === "services" ? "#2563eb" : "transparent",
            color: activeTab === "services" ? "#ffffff" : "#475569",
            fontWeight: 700,
            fontSize: "0.88rem",
            cursor: "pointer",
            display: "inline-flex",
            alignItems: "center",
            justifyContent: "center",
            gap: "8px",
            whiteSpace: "nowrap",
            transition: "all 0.15s ease",
          }}
        >
          <span>🔧</span>
          <span>Dịch vụ ({services.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab("prices")}
          style={{
            flex: isMobile ? "initial" : 1,
            padding: "10px 16px",
            borderRadius: "10px",
            border: "none",
            background: activeTab === "prices" ? "#2563eb" : "transparent",
            color: activeTab === "prices" ? "#ffffff" : "#475569",
            fontWeight: 700,
            fontSize: "0.88rem",
            cursor: "pointer",
            display: "inline-flex",
            alignItems: "center",
            justifyContent: "center",
            gap: "8px",
            whiteSpace: "nowrap",
            transition: "all 0.15s ease",
          }}
        >
          <span>💰</span>
          <span>Bảng giá ({prices.length})</span>
        </button>
      </div>

      {/* ================= TAB 1: BRANDS ================= */}
      {activeTab === "brands" && (
        <div style={{ display: "grid", gridTemplateColumns: isMobile ? "1fr" : "360px 1fr", gap: "20px", alignItems: "flex-start" }}>
          {/* FORM: THÊM HÃNG */}
          <section className="card" style={{ padding: "20px" }}>
            <h2 style={{ fontSize: "1.1rem", fontWeight: 800, margin: "0 0 4px", color: "#0f172a" }}>
              + Thêm thương hiệu mới
            </h2>
            <p style={{ fontSize: "0.82rem", color: "#64748b", margin: "0 0 16px" }}>
              Thêm hãng điện thoại mới vào danh mục hệ thống.
            </p>

            <form
              onSubmit={(e) => {
                e.preventDefault()
                if (!token || !brandName.trim()) return
                void run(() => saveBrand(token, { name: brandName.trim(), description: "", isActive: true }), `Đã thêm hãng ${brandName}.`)
                setBrandName("")
              }}
              style={{ display: "flex", flexDirection: "column", gap: "12px" }}
            >
              <label style={{ display: "block" }}>
                <span style={{ display: "block", fontSize: "0.82rem", fontWeight: 700, marginBottom: "4px" }}>Tên thương hiệu *</span>
                <input
                  className="input"
                  style={{ width: "100%", boxSizing: "border-box" }}
                  value={brandName}
                  onChange={(e) => setBrandName(e.target.value)}
                  placeholder="VD: Apple, Samsung, Xiaomi..."
                  required
                />
              </label>

              <button className="btn" type="submit" disabled={actionLoading || !brandName.trim()} style={{ width: "100%", marginTop: "4px" }}>
                {actionLoading ? "Đang lưu..." : "Lưu thương hiệu"}
              </button>
            </form>
          </section>

          {/* LIST: DANH SÁCH HÃNG */}
          <section className="card" style={{ padding: "20px" }}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: "10px", marginBottom: "16px" }}>
              <div>
                <h2 style={{ fontSize: "1.1rem", fontWeight: 800, margin: 0, color: "#0f172a" }}>
                  Danh sách thương hiệu ({filteredBrands.length})
                </h2>
                <span style={{ fontSize: "0.78rem", color: "#64748b" }}>Bấm Bật/Tắt để ẩn hoặc hiện hãng trên trang chủ & đặt lịch</span>
              </div>

              <input
                type="search"
                className="input"
                placeholder="Tìm hãng..."
                value={brandSearch}
                onChange={(e) => setBrandSearch(e.target.value)}
                style={{ width: isMobile ? "100%" : "220px", height: "36px", fontSize: "0.84rem" }}
              />
            </div>

            <div style={{ display: "flex", flexDirection: "column", gap: "8px", maxHeight: "560px", overflowY: "auto" }}>
              {filteredBrands.map((b) => {
                const isWordmark = ["Samsung", "Oppo", "Vivo", "Honor", "Realme"].includes(b.name)
                return (
                  <div
                    key={b.id}
                    style={{
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "space-between",
                      padding: "12px 14px",
                      borderRadius: "10px",
                      border: "1px solid #e2e8f0",
                      background: b.isActive ? "#ffffff" : "#f8fafc",
                      transition: "all 0.15s ease",
                    }}
                  >
                    <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
                      <div
                        style={{
                          width: "36px",
                          height: "36px",
                          borderRadius: "8px",
                          background: "#f1f5f9",
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                          flexShrink: 0,
                        }}
                      >
                        {BRAND_LOGOS[b.name] ? (
                          <img
                            src={BRAND_LOGOS[b.name]}
                            alt={b.name}
                            style={
                              isWordmark
                                ? { height: "14px", maxWidth: "28px", objectFit: "contain" }
                                : { width: "18px", height: "18px", objectFit: "contain" }
                            }
                          />
                        ) : (
                          <span>📱</span>
                        )}
                      </div>

                      <div>
                        <strong style={{ fontSize: "0.92rem", color: b.isActive ? "#0f172a" : "#94a3b8" }}>
                          {b.name}
                        </strong>
                        <div style={{ fontSize: "0.76rem" }}>
                          {b.isActive ? (
                            <span style={{ color: "#16a34a", fontWeight: 600 }}>● Đang kích hoạt</span>
                          ) : (
                            <span style={{ color: "#94a3b8" }}>○ Đã tạm ẩn</span>
                          )}
                        </div>
                      </div>
                    </div>

                    <button
                      type="button"
                      disabled={actionLoading}
                      onClick={() => {
                        if (!token) return
                        void run(
                          () => saveBrand(token, { name: b.name, description: b.description ?? "", isActive: !b.isActive }, b.id),
                          `Đã ${b.isActive ? "tắt" : "bật"} hãng ${b.name}.`
                        )
                      }}
                      style={{
                        padding: "6px 14px",
                        borderRadius: "8px",
                        border: b.isActive ? "1px solid #cbd5e1" : "1px solid #86efac",
                        background: b.isActive ? "#ffffff" : "#f0fdf4",
                        color: b.isActive ? "#475569" : "#16a34a",
                        fontSize: "0.82rem",
                        fontWeight: 700,
                        cursor: "pointer",
                      }}
                    >
                      {b.isActive ? "Tạm ẩn" : "Kích hoạt"}
                    </button>
                  </div>
                )
              })}
              {filteredBrands.length === 0 && (
                <p style={{ textAlign: "center", color: "#94a3b8", padding: "24px 0" }}>Không tìm thấy thương hiệu nào.</p>
              )}
            </div>
          </section>
        </div>
      )}

      {/* ================= TAB 2: MODELS ================= */}
      {activeTab === "models" && (
        <div style={{ display: "grid", gridTemplateColumns: isMobile ? "1fr" : "360px 1fr", gap: "20px", alignItems: "flex-start" }}>
          {/* FORM: THÊM DÒNG MÁY */}
          <section className="card" style={{ padding: "20px" }}>
            <h2 style={{ fontSize: "1.1rem", fontWeight: 800, margin: "0 0 4px", color: "#0f172a" }}>
              + Thêm dòng máy mới
            </h2>
            <p style={{ fontSize: "0.82rem", color: "#64748b", margin: "0 0 16px" }}>
              Khai báo model điện thoại thuộc thương hiệu tương ứng.
            </p>

            <form
              onSubmit={(e) => {
                e.preventDefault()
                if (!token || !modelBrandId || !modelName.trim()) return
                const y = modelYear ? Number(modelYear) : null
                void run(
                  () => saveModel(token, { brandId: Number(modelBrandId), name: modelName.trim(), imageUrl: "", description: "", releaseYear: y, isActive: true }),
                  `Đã thêm dòng máy ${modelName}.`
                )
                setModelName("")
                setModelYear("")
              }}
              style={{ display: "flex", flexDirection: "column", gap: "12px" }}
            >
              <label style={{ display: "block" }}>
                <span style={{ display: "block", fontSize: "0.82rem", fontWeight: 700, marginBottom: "4px" }}>Thuộc hãng máy *</span>
                <select
                  className="input"
                  style={{ width: "100%", boxSizing: "border-box" }}
                  value={modelBrandId}
                  onChange={(e) => setModelBrandId(e.target.value)}
                  required
                >
                  <option value="">-- Chọn thương hiệu --</option>
                  {brands.map((b) => (
                    <option key={b.id} value={b.id}>{b.name}</option>
                  ))}
                </select>
              </label>

              <label style={{ display: "block" }}>
                <span style={{ display: "block", fontSize: "0.82rem", fontWeight: 700, marginBottom: "4px" }}>Tên model thiết bị *</span>
                <input
                  className="input"
                  style={{ width: "100%", boxSizing: "border-box" }}
                  value={modelName}
                  onChange={(e) => setModelName(e.target.value)}
                  placeholder="VD: iPhone 16 Pro Max, Galaxy S24..."
                  required
                />
              </label>

              <label style={{ display: "block" }}>
                <span style={{ display: "block", fontSize: "0.82rem", fontWeight: 700, marginBottom: "4px" }}>Năm ra mắt (Tùy chọn)</span>
                <input
                  className="input"
                  type="number"
                  style={{ width: "100%", boxSizing: "border-box" }}
                  value={modelYear}
                  onChange={(e) => setModelYear(e.target.value)}
                  placeholder="VD: 2024"
                />
              </label>

              <button className="btn" type="submit" disabled={actionLoading || !modelBrandId || !modelName.trim()} style={{ width: "100%", marginTop: "4px" }}>
                {actionLoading ? "Đang lưu..." : "Lưu dòng máy"}
              </button>
            </form>
          </section>

          {/* LIST: DANH SÁCH DÒNG MÁY */}
          <section className="card" style={{ padding: "20px" }}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: "10px", marginBottom: "16px" }}>
              <div>
                <h2 style={{ fontSize: "1.1rem", fontWeight: 800, margin: 0, color: "#0f172a" }}>
                  Danh sách model máy ({filteredModels.length})
                </h2>
                <span style={{ fontSize: "0.78rem", color: "#64748b" }}>Hiển thị trong bước chọn thiết bị khi khách đặt lịch</span>
              </div>

              <div style={{ display: "flex", gap: "8px", width: isMobile ? "100%" : "auto" }}>
                <select
                  className="input"
                  value={modelFilterBrand}
                  onChange={(e) => setModelFilterBrand(e.target.value)}
                  style={{ height: "36px", fontSize: "0.82rem", flex: isMobile ? 1 : "initial" }}
                >
                  <option value="">Tất cả hãng</option>
                  {brands.map((b) => (
                    <option key={b.id} value={b.id}>{b.name}</option>
                  ))}
                </select>

                <input
                  type="search"
                  className="input"
                  placeholder="Tìm model..."
                  value={modelSearch}
                  onChange={(e) => setModelSearch(e.target.value)}
                  style={{ width: isMobile ? "50%" : "200px", height: "36px", fontSize: "0.84rem" }}
                />
              </div>
            </div>

            <div style={{ display: "grid", gridTemplateColumns: isMobile ? "1fr" : "repeat(2, 1fr)", gap: "10px", maxHeight: "560px", overflowY: "auto", paddingRight: "4px" }}>
              {filteredModels.map((m) => (
                <div
                  key={m.id}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                    padding: "12px 14px",
                    borderRadius: "10px",
                    border: "1px solid #e2e8f0",
                    background: "#ffffff",
                    boxShadow: "0 1px 3px rgba(15,23,42,0.02)",
                  }}
                >
                  <div>
                    <div style={{ display: "flex", alignItems: "center", gap: "6px", marginBottom: "2px" }}>
                      <span
                        style={{
                          fontSize: "0.72rem",
                          fontWeight: 700,
                          background: "#eff6ff",
                          color: "#2563eb",
                          padding: "1px 6px",
                          borderRadius: "4px",
                        }}
                      >
                        {m.brandName}
                      </span>
                      {m.releaseYear && (
                        <span style={{ fontSize: "0.72rem", color: "#94a3b8" }}>({m.releaseYear})</span>
                      )}
                    </div>
                    <strong style={{ fontSize: "0.92rem", color: "#0f172a" }}>{m.name}</strong>
                  </div>

                  <span style={{ fontSize: "0.76rem", color: "#16a34a", fontWeight: 600 }}>
                    ✓ Sẵn sàng
                  </span>
                </div>
              ))}
              {filteredModels.length === 0 && (
                <div style={{ gridColumn: "1 / -1", textAlign: "center", color: "#94a3b8", padding: "24px 0" }}>
                  Không tìm thấy dòng máy nào khớp bộ lọc.
                </div>
              )}
            </div>
          </section>
        </div>
      )}

      {/* ================= TAB 3: SERVICES ================= */}
      {activeTab === "services" && (
        <div style={{ display: "grid", gridTemplateColumns: isMobile ? "1fr" : "360px 1fr", gap: "20px", alignItems: "flex-start" }}>
          {/* FORM: THÊM DỊCH VỤ */}
          <section className="card" style={{ padding: "20px" }}>
            <h2 style={{ fontSize: "1.1rem", fontWeight: 800, margin: "0 0 4px", color: "#0f172a" }}>
              + Thêm dịch vụ sửa chữa
            </h2>
            <p style={{ fontSize: "0.82rem", color: "#64748b", margin: "0 0 16px" }}>
              Tạo danh mục sửa chữa mới (thay màn, thay pin, sửa camera...).
            </p>

            <form
              onSubmit={(e) => {
                e.preventDefault()
                if (!token || !serviceName.trim()) return
                void run(
                  () => saveService(token, { name: serviceName.trim(), description: "", pricingType, isActive: true }),
                  `Đã thêm dịch vụ ${serviceName}.`
                )
                setServiceName("")
              }}
              style={{ display: "flex", flexDirection: "column", gap: "12px" }}
            >
              <label style={{ display: "block" }}>
                <span style={{ display: "block", fontSize: "0.82rem", fontWeight: 700, marginBottom: "4px" }}>Tên dịch vụ *</span>
                <input
                  className="input"
                  style={{ width: "100%", boxSizing: "border-box" }}
                  value={serviceName}
                  onChange={(e) => setServiceName(e.target.value)}
                  placeholder="VD: Thay màn hình, Thay pin, Sửa FaceID..."
                  required
                />
              </label>

              <label style={{ display: "block" }}>
                <span style={{ display: "block", fontSize: "0.82rem", fontWeight: 700, marginBottom: "4px" }}>Cơ chế tính giá *</span>
                <select
                  className="input"
                  style={{ width: "100%", boxSizing: "border-box" }}
                  value={pricingType}
                  onChange={(e) => setPricingType(e.target.value as PricingType)}
                >
                  <option value="FixedPrice">Giá cố định (theo model máy)</option>
                  <option value="InspectionRequired">Cần kỹ thuật viên kiểm tra trực tiếp</option>
                </select>
              </label>

              <button className="btn" type="submit" disabled={actionLoading || !serviceName.trim()} style={{ width: "100%", marginTop: "4px" }}>
                {actionLoading ? "Đang lưu..." : "Lưu dịch vụ"}
              </button>
            </form>
          </section>

          {/* LIST: DANH SÁCH DỊCH VỤ */}
          <section className="card" style={{ padding: "20px" }}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: "10px", marginBottom: "16px" }}>
              <div>
                <h2 style={{ fontSize: "1.1rem", fontWeight: 800, margin: 0, color: "#0f172a" }}>
                  Danh sách dịch vụ sửa chữa ({filteredServices.length})
                </h2>
                <span style={{ fontSize: "0.78rem", color: "#64748b" }}>Các gói dịch vụ xuất hiện trên trang chủ, bảng giá & quy trình đặt lịch</span>
              </div>

              <input
                type="search"
                className="input"
                placeholder="Tìm dịch vụ..."
                value={serviceSearch}
                onChange={(e) => setServiceSearch(e.target.value)}
                style={{ width: isMobile ? "100%" : "220px", height: "36px", fontSize: "0.84rem" }}
              />
            </div>

            <div style={{ display: "flex", flexDirection: "column", gap: "8px", maxHeight: "560px", overflowY: "auto" }}>
              {filteredServices.map((s) => (
                <div
                  key={s.id}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                    padding: "12px 14px",
                    borderRadius: "10px",
                    border: "1px solid #e2e8f0",
                    background: "#ffffff",
                  }}
                >
                  <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
                    <div style={{ width: "36px", height: "36px", borderRadius: "8px", background: "#f0fdf4", color: "#16a34a", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "1.1rem" }}>
                      🔧
                    </div>
                    <div>
                      <strong style={{ fontSize: "0.92rem", color: "#0f172a" }}>{s.name}</strong>
                      <div style={{ fontSize: "0.76rem", color: "#64748b" }}>
                        {s.pricingType === "InspectionRequired" ? "🔍 Cần kiểm tra chẩn đoán" : "🏷️ Có đơn giá cụ thể theo máy"}
                      </div>
                    </div>
                  </div>

                  <span
                    style={{
                      fontSize: "0.75rem",
                      fontWeight: 700,
                      background: s.pricingType === "InspectionRequired" ? "#fef3c7" : "#eff6ff",
                      color: s.pricingType === "InspectionRequired" ? "#b45309" : "#2563eb",
                      padding: "4px 10px",
                      borderRadius: "6px",
                    }}
                  >
                    {s.pricingType === "InspectionRequired" ? "Ktra báo giá" : "Định giá theo model"}
                  </span>
                </div>
              ))}
              {filteredServices.length === 0 && (
                <p style={{ textAlign: "center", color: "#94a3b8", padding: "24px 0" }}>Không tìm thấy dịch vụ nào.</p>
              )}
            </div>
          </section>
        </div>
      )}

      {/* ================= TAB 4: PRICES ================= */}
      {activeTab === "prices" && (
        <div style={{ display: "grid", gridTemplateColumns: isMobile ? "1fr" : "360px 1fr", gap: "20px", alignItems: "flex-start" }}>
          {/* FORM: CẤU HÌNH ĐƠN GIÁ */}
          <section className="card" style={{ padding: "20px" }}>
            <h2 style={{ fontSize: "1.1rem", fontWeight: 800, margin: "0 0 4px", color: "#0f172a" }}>
              + Cấu hình giá theo máy
            </h2>
            <p style={{ fontSize: "0.82rem", color: "#64748b", margin: "0 0 16px" }}>
              Thiết lập đơn giá cho từng dòng máy và loại dịch vụ cụ thể.
            </p>

            <form
              onSubmit={(e) => {
                e.preventDefault()
                if (!token || !priceModelId || !priceServiceId) return
                const svc = services.find((item) => item.id === Number(priceServiceId))
                const priceVal = svc?.pricingType === "InspectionRequired" ? null : Number(amount)
                void run(
                  () => savePrice(token, {
                    phoneModelId: Number(priceModelId),
                    repairServiceId: Number(priceServiceId),
                    price: priceVal,
                    isActive: true,
                  }),
                  "Đã lưu đơn giá cho dòng máy thành công."
                )
                setAmount("")
              }}
              style={{ display: "flex", flexDirection: "column", gap: "12px" }}
            >
              <label style={{ display: "block" }}>
                <span style={{ display: "block", fontSize: "0.82rem", fontWeight: 700, marginBottom: "4px" }}>Dòng máy *</span>
                <select
                  className="input"
                  style={{ width: "100%", boxSizing: "border-box" }}
                  value={priceModelId}
                  onChange={(e) => setPriceModelId(e.target.value)}
                  required
                >
                  <option value="">-- Chọn model thiết bị --</option>
                  {models.map((m) => (
                    <option key={m.id} value={m.id}>{m.brandName} {m.name}</option>
                  ))}
                </select>
              </label>

              <label style={{ display: "block" }}>
                <span style={{ display: "block", fontSize: "0.82rem", fontWeight: 700, marginBottom: "4px" }}>Dịch vụ sửa chữa *</span>
                <select
                  className="input"
                  style={{ width: "100%", boxSizing: "border-box" }}
                  value={priceServiceId}
                  onChange={(e) => setPriceServiceId(e.target.value)}
                  required
                >
                  <option value="">-- Chọn dịch vụ --</option>
                  {services.map((s) => (
                    <option key={s.id} value={s.id}>{s.name} ({s.pricingType === "InspectionRequired" ? "Ktra báo sau" : "Giá cố định"})</option>
                  ))}
                </select>
              </label>

              <label style={{ display: "block" }}>
                <span style={{ display: "block", fontSize: "0.82rem", fontWeight: 700, marginBottom: "4px" }}>Đơn giá (VNĐ)</span>
                <input
                  className="input"
                  type="number"
                  style={{ width: "100%", boxSizing: "border-box" }}
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="VD: 1500000"
                />
              </label>

              <button className="btn" type="submit" disabled={actionLoading || !priceModelId || !priceServiceId} style={{ width: "100%", marginTop: "4px" }}>
                {actionLoading ? "Đang lưu..." : "Lưu đơn giá"}
              </button>
            </form>
          </section>

          {/* TABLE: BẢNG GIÁ CHI TIẾT */}
          <section className="card" style={{ padding: "20px" }}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: "10px", marginBottom: "16px" }}>
              <div>
                <h2 style={{ fontSize: "1.1rem", fontWeight: 800, margin: 0, color: "#0f172a" }}>
                  Bảng giá theo từng máy ({filteredPrices.length})
                </h2>
                <span style={{ fontSize: "0.78rem", color: "#64748b" }}>
                  Tự động áp dụng khi khách hàng đặt lịch hoặc tra cứu bảng giá
                </span>
              </div>

              {/* FILTER CONTROLS */}
              <div style={{ display: "flex", gap: "8px", flexWrap: "wrap", width: isMobile ? "100%" : "auto" }}>
                <select
                  className="input"
                  value={priceFilterBrand}
                  onChange={(e) => setPriceFilterBrand(e.target.value)}
                  style={{ height: "36px", fontSize: "0.82rem", flex: isMobile ? 1 : "initial" }}
                >
                  <option value="">Tất cả hãng</option>
                  {brands.map((b) => (
                    <option key={b.id} value={b.name}>{b.name}</option>
                  ))}
                </select>

                <select
                  className="input"
                  value={priceFilterService}
                  onChange={(e) => setPriceFilterService(e.target.value)}
                  style={{ height: "36px", fontSize: "0.82rem", flex: isMobile ? 1 : "initial" }}
                >
                  <option value="">Tất cả dịch vụ</option>
                  {services.map((s) => (
                    <option key={s.id} value={s.id}>{s.name}</option>
                  ))}
                </select>

                <input
                  type="search"
                  className="input"
                  placeholder="Tìm kiếm..."
                  value={priceSearch}
                  onChange={(e) => setPriceSearch(e.target.value)}
                  style={{ width: isMobile ? "100%" : "180px", height: "36px", fontSize: "0.84rem" }}
                />
              </div>
            </div>

            {/* SCROLLABLE TABLE/LIST CONTAINER */}
            <div style={{ maxHeight: "560px", overflowY: "auto", border: "1px solid #e2e8f0", borderRadius: "12px" }}>
              {isMobile ? (
                <div style={{ display: "flex", flexDirection: "column", gap: "8px", padding: "10px" }}>
                  {filteredPrices.map((p) => (
                    <div
                      key={p.id}
                      style={{
                        background: "#ffffff",
                        border: "1px solid #f1f5f9",
                        borderRadius: "10px",
                        padding: "12px",
                        boxShadow: "0 1px 3px rgba(0,0,0,0.02)",
                      }}
                    >
                      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: "4px" }}>
                        <div>
                          <span style={{ fontSize: "0.7rem", color: "#2563eb", fontWeight: 700, background: "#eff6ff", padding: "1px 6px", borderRadius: "4px", marginRight: "6px" }}>
                            {p.brandName}
                          </span>
                          <strong style={{ fontSize: "0.9rem", color: "#0f172a" }}>{p.phoneModelName}</strong>
                        </div>
                        <span style={{ fontSize: "0.95rem", fontWeight: 800, color: "#16a34a" }}>
                          {formatPrice(p.pricingType, p.price)}
                        </span>
                      </div>
                      <div style={{ fontSize: "0.82rem", color: "#64748b" }}>
                        🔧 {p.repairServiceName}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <table style={{ width: "100%", borderCollapse: "collapse", textAlign: "left", fontSize: "0.88rem" }}>
                  <thead>
                    <tr style={{ background: "#f8fafc", borderBottom: "1px solid #e2e8f0", color: "#64748b" }}>
                      <th style={{ padding: "10px 14px" }}>Hãng & Dòng máy</th>
                      <th style={{ padding: "10px 14px" }}>Dịch vụ sửa chữa</th>
                      <th style={{ padding: "10px 14px" }}>Loại định giá</th>
                      <th style={{ padding: "10px 14px", textAlign: "right" }}>Đơn giá (VNĐ)</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredPrices.map((p) => (
                      <tr key={p.id} style={{ borderBottom: "1px solid #f1f5f9" }}>
                        <td style={{ padding: "10px 14px" }}>
                          <span style={{ fontSize: "0.74rem", color: "#2563eb", fontWeight: 700, background: "#eff6ff", padding: "1px 6px", borderRadius: "4px", marginRight: "6px" }}>
                            {p.brandName}
                          </span>
                          <strong>{p.phoneModelName}</strong>
                        </td>
                        <td style={{ padding: "10px 14px" }}>{p.repairServiceName}</td>
                        <td style={{ padding: "10px 14px" }}>
                          <span style={{ fontSize: "0.75rem", color: p.pricingType === "InspectionRequired" ? "#b45309" : "#475569" }}>
                            {p.pricingType === "InspectionRequired" ? "Ktra trực tiếp" : "Giá cố định"}
                          </span>
                        </td>
                        <td style={{ padding: "10px 14px", textAlign: "right", fontWeight: 700, color: "#16a34a" }}>
                          {formatPrice(p.pricingType, p.price)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}

              {filteredPrices.length === 0 && (
                <p style={{ textAlign: "center", color: "#94a3b8", padding: "32px 0" }}>
                  Không tìm thấy đơn giá nào khớp với tiêu chí tìm kiếm.
                </p>
              )}
            </div>
          </section>
        </div>
      )}
    </main>
  )
}
