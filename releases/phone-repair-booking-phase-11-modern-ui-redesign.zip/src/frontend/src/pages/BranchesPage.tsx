import { useEffect, useState } from "react"
import { useNavigate } from "react-router-dom"
import { getBranches, type Branch } from "../api/branches"

interface BranchItem extends Branch {
  distance: string
  image: string
  district: string
  rating: number
  hasParking: boolean
  featuredServices: string[]
  mapCoordinates: { x: number; y: number } // percentages for interactive map
}

const FALLBACK_BRANCHES: BranchItem[] = [
  {
    id: 1,
    name: "PhoneRepair Quận 1",
    address: "123 Nguyễn Huệ, Quận 1, TP.HCM",
    phone: "028 1234 5678",
    capacityPerSlot: 4,
    slotMinutes: 30,
    isActive: true,
    openingHours: [],
    distance: "2.1 km",
    image: "https://images.unsplash.com/photo-1550009158-9ebf69173e03?auto=format&fit=crop&w=400&q=80",
    district: "Quận 1",
    rating: 4.9,
    hasParking: true,
    featuredServices: ["Thay màn hình", "Thay pin", "Sửa camera", "Sửa loa", "Vệ sinh máy"],
    mapCoordinates: { x: 50, y: 50 },
  },
  {
    id: 2,
    name: "PhoneRepair Quận 3",
    address: "456 Võ Thị Sáu, Quận 3, TP.HCM",
    phone: "028 2345 6789",
    capacityPerSlot: 4,
    slotMinutes: 30,
    isActive: true,
    openingHours: [],
    distance: "3.5 km",
    image: "https://images.unsplash.com/photo-1581092921461-eab62e97a780?auto=format&fit=crop&w=400&q=80",
    district: "Quận 3",
    rating: 4.8,
    hasParking: true,
    featuredServices: ["Thay màn hình", "Thay pin", "Sửa sạc", "Sửa Face ID"],
    mapCoordinates: { x: 38, y: 48 },
  },
  {
    id: 3,
    name: "PhoneRepair Quận 7",
    address: "789 Nguyễn Văn Linh, Quận 7, TP.HCM",
    phone: "028 3456 7890",
    capacityPerSlot: 4,
    slotMinutes: 30,
    isActive: true,
    openingHours: [],
    distance: "5.3 km",
    image: "https://images.unsplash.com/photo-1517430816045-df4b7de81d39?auto=format&fit=crop&w=400&q=80",
    district: "Quận 7",
    rating: 4.9,
    hasParking: true,
    featuredServices: ["Thay màn hình", "Thay pin", "Sửa loa", "Vệ sinh máy"],
    mapCoordinates: { x: 70, y: 68 },
  },
  {
    id: 4,
    name: "PhoneRepair Thủ Đức",
    address: "789 Võ Văn Ngân, TP. Thủ Đức, TP.HCM",
    phone: "028 3456 7890",
    capacityPerSlot: 4,
    slotMinutes: 30,
    isActive: true,
    openingHours: [],
    distance: "7.8 km",
    image: "https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=400&q=80",
    district: "TP. Thủ Đức",
    rating: 4.8,
    hasParking: true,
    featuredServices: ["Thay màn hình", "Thay pin", "Sửa camera", "Sửa micro"],
    mapCoordinates: { x: 72, y: 32 },
  },
  {
    id: 5,
    name: "PhoneRepair Tân Bình",
    address: "321 Cộng Hòa, Quận Tân Bình, TP.HCM",
    phone: "028 6789 1234",
    capacityPerSlot: 4,
    slotMinutes: 30,
    isActive: true,
    openingHours: [],
    distance: "6.2 km",
    image: "https://images.unsplash.com/photo-1512496015851-a90fb38ba796?auto=format&fit=crop&w=400&q=80",
    district: "Tân Bình",
    rating: 4.7,
    hasParking: true,
    featuredServices: ["Thay màn hình", "Thay pin", "Vệ sinh máy"],
    mapCoordinates: { x: 25, y: 42 },
  },
  {
    id: 6,
    name: "PhoneRepair Gò Vấp",
    address: "654 Quang Trung, Quận Gò Vấp, TP.HCM",
    phone: "028 6789 5678",
    capacityPerSlot: 4,
    slotMinutes: 30,
    isActive: true,
    openingHours: [],
    distance: "8.1 km",
    image: "https://images.unsplash.com/photo-1519389950473-47ba0277781c?auto=format&fit=crop&w=400&q=80",
    district: "Gò Vấp",
    rating: 4.8,
    hasParking: true,
    featuredServices: ["Thay màn hình", "Thay pin", "Sửa loa", "Sửa sạc"],
    mapCoordinates: { x: 32, y: 28 },
  },
]

export function BranchesPage() {
  const navigate = useNavigate()
  const [branches, setBranches] = useState<BranchItem[]>(FALLBACK_BRANCHES)
  const [selectedBranchId, setSelectedBranchId] = useState<number>(1)
  const [searchKeyword, setSearchKeyword] = useState("")
  const [selectedCity, setSelectedCity] = useState("TP. Hồ Chí Minh")
  const [selectedService, setSelectedService] = useState("all")
  const [mapMode, setMapMode] = useState<"map" | "satellite">("map")
  const [zoomLevel, setZoomLevel] = useState(1)

  useEffect(() => {
    getBranches()
      .then((serverBranches) => {
        if (serverBranches && serverBranches.length > 0) {
          const enriched: BranchItem[] = serverBranches.map((b, index) => {
            const fallback = FALLBACK_BRANCHES.find((f) => f.id === b.id) || FALLBACK_BRANCHES[index % FALLBACK_BRANCHES.length]
            return {
              ...b,
              distance: fallback?.distance || `${(index + 1) * 2}.1 km`,
              image: fallback?.image || FALLBACK_BRANCHES[0].image,
              district: fallback?.district || "TP.HCM",
              rating: fallback?.rating || 4.9,
              hasParking: fallback?.hasParking ?? true,
              featuredServices: fallback?.featuredServices || ["Thay màn hình", "Thay pin", "Sửa loa"],
              mapCoordinates: fallback?.mapCoordinates || { x: 30 + (index % 4) * 15, y: 30 + (index % 3) * 15 },
            }
          })
          setBranches(enriched)
          if (enriched[0]) setSelectedBranchId(enriched[0].id)
        }
      })
      .catch(() => {
        // use fallback rich branch data
      })
  }, [])

  const filteredBranches = branches.filter((b) => {
    const matchKeyword =
      b.name.toLowerCase().includes(searchKeyword.toLowerCase()) ||
      b.address.toLowerCase().includes(searchKeyword.toLowerCase()) ||
      b.district.toLowerCase().includes(searchKeyword.toLowerCase())
    return matchKeyword
  })

  const selectedBranch = branches.find((b) => b.id === selectedBranchId) || branches[0] || FALLBACK_BRANCHES[0]

  const handleSelectBranch = (branchId: number) => {
    setSelectedBranchId(branchId)
  }

  const handleBookAtBranch = (branchId: number) => {
    navigate(`/booking?branchId=${branchId}`)
  }

  return (
    <main style={{ background: "#f8fafc", minHeight: "100vh", paddingBottom: "40px" }}>
      {/* 1. HERO HEADER (IMAGE 3) */}
      <section className="branches-hero">
        <h1>Hệ thống chi nhánh PhoneRepair</h1>
        <p>Tìm chi nhánh gần bạn nhất tại TP. Hồ Chí Minh để được hỗ trợ nhanh chóng, chuyên nghiệp</p>

        <div className="branches-feature-badges">
          <div className="branch-feature-badge">
            <span style={{ color: "#2563eb", fontSize: "1.1rem" }}>📍</span>
            <div>
              <strong>Nhiều chi nhánh</strong>
              <span style={{ color: "#64748b", marginLeft: "4px" }}>thuận tiện di chuyển</span>
            </div>
          </div>

          <div className="branch-feature-badge">
            <span style={{ color: "#0284c7", fontSize: "1.1rem" }}>🕒</span>
            <div>
              <strong>Giờ mở cửa linh hoạt</strong>
              <span style={{ color: "#64748b", marginLeft: "4px" }}>8:00 - 20:00 hàng ngày</span>
            </div>
          </div>

          <div className="branch-feature-badge">
            <span style={{ color: "#16a34a", fontSize: "1.1rem" }}>🛡️</span>
            <div>
              <strong>Kỹ thuật viên chuyên nghiệp</strong>
              <span style={{ color: "#64748b", marginLeft: "4px" }}>Tại tất cả chi nhánh</span>
            </div>
          </div>

          <div className="branch-feature-badge">
            <span style={{ color: "#eab308", fontSize: "1.1rem" }}>⭐</span>
            <div>
              <strong>Dịch vụ đồng nhất</strong>
              <span style={{ color: "#64748b", marginLeft: "4px" }}>Chất lượng toàn hệ thống</span>
            </div>
          </div>
        </div>
      </section>

      {/* 2. SEARCH & FILTER TOOLBAR (IMAGE 3) */}
      <div style={{ padding: "0 20px" }}>
        <div className="branch-search-toolbar">
          <div style={{ position: "relative", flex: 2, display: "flex", alignItems: "center" }}>
            <span style={{ position: "absolute", left: "12px", color: "#94a3b8" }}>🔍</span>
            <input
              type="text"
              className="branch-search-input"
              placeholder="Tìm kiếm chi nhánh, quận, địa chỉ..."
              value={searchKeyword}
              onChange={(e) => setSearchKeyword(e.target.value)}
            />
          </div>

          <select
            className="branch-select-pill"
            value={selectedCity}
            onChange={(e) => setSelectedCity(e.target.value)}
          >
            <option value="TP. Hồ Chí Minh">📍 TP. Hồ Chí Minh</option>
            <option value="Hà Nội">📍 Hà Nội</option>
            <option value="Đà Nẵng">📍 Đà Nẵng</option>
          </select>

          <select
            className="branch-select-pill"
            value={selectedService}
            onChange={(e) => setSelectedService(e.target.value)}
          >
            <option value="all">⚙️ Tất cả dịch vụ</option>
            <option value="screen">Thay màn hình</option>
            <option value="battery">Thay pin</option>
            <option value="camera">Sửa camera</option>
            <option value="clean">Vệ sinh máy</option>
          </select>

          <button
            type="button"
            className="btn"
            style={{
              padding: "0 28px",
              height: "44px",
              borderRadius: "12px",
              background: "#2563eb",
              fontWeight: 700,
              flexShrink: 0,
            }}
          >
            Tìm chi nhánh
          </button>
        </div>
      </div>

      {/* 3. SPLIT VIEW: BRANCH LIST (LEFT) & INTERACTIVE MAP (RIGHT) (IMAGE 3) */}
      <div style={{ padding: "0 20px" }}>
        <div className="branches-split-view">
          {/* LEFT LIST COLUMN */}
          <div>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "14px" }}>
              <strong style={{ fontSize: "1.05rem", color: "#0f172a" }}>
                Danh sách chi nhánh tại TP. Hồ Chí Minh ({filteredBranches.length} chi nhánh)
              </strong>
              <span style={{ fontSize: "0.84rem", color: "#64748b" }}>Sắp xếp: <strong>Gần nhất ⌄</strong></span>
            </div>

            <div className="branches-list-col">
              {filteredBranches.map((b) => {
                const isSelected = b.id === selectedBranchId
                return (
                  <article
                    key={b.id}
                    className={`branch-row-card ${isSelected ? "active" : ""}`}
                    onClick={() => handleSelectBranch(b.id)}
                  >
                    <img src={b.image} alt={b.name} className="branch-thumb" />

                    <div className="branch-row-info">
                      <div>
                        <div className="branch-row-top">
                          <h2 className="branch-row-title">{b.name}</h2>
                          <span className="branch-distance-chip">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                              <polygon points="3 11 22 2 13 21 11 13 3 11" />
                            </svg>
                            {b.distance}
                          </span>
                        </div>

                        <div className="branch-row-meta">
                          <div style={{ display: "flex", alignItems: "center", gap: "6px" }}>
                            <span>📍</span>
                            <span>{b.address}</span>
                          </div>
                          <div style={{ display: "flex", alignItems: "center", gap: "6px", marginTop: "2px" }}>
                            <span>🕒</span>
                            <span>08:00 - 20:00 (T2 - CN)</span>
                          </div>
                          <div style={{ display: "flex", alignItems: "center", gap: "6px", marginTop: "2px" }}>
                            <span>📞</span>
                            <span>{b.phone}</span>
                          </div>
                        </div>
                      </div>

                      <div className="branch-row-actions">
                        <button
                          type="button"
                          className="branch-btn-view"
                          onClick={(e) => {
                            e.stopPropagation()
                            handleSelectBranch(b.id)
                          }}
                        >
                          Xem chi tiết
                        </button>
                        <button
                          type="button"
                          className="branch-btn-select"
                          onClick={(e) => {
                            e.stopPropagation()
                            handleBookAtBranch(b.id)
                          }}
                        >
                          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                            <polygon points="3 11 22 2 13 21 11 13 3 11" />
                          </svg>
                          Chọn chi nhánh
                        </button>
                      </div>
                    </div>
                  </article>
                )
              })}
            </div>
          </div>

          {/* RIGHT MAP COLUMN WITH STYLED PINS & FLOATING CARD */}
          <div className="branches-map-container">
            {/* MAP TABS */}
            <div className="map-control-tabs">
              <button
                type="button"
                className={`map-control-btn ${mapMode === "map" ? "active" : ""}`}
                onClick={() => setMapMode("map")}
              >
                Bản đồ
              </button>
              <button
                type="button"
                className={`map-control-btn ${mapMode === "satellite" ? "active" : ""}`}
                onClick={() => setMapMode("satellite")}
              >
                Vệ tinh
              </button>
            </div>

            {/* ZOOM CONTROLS */}
            <div className="map-zoom-controls">
              <button
                type="button"
                className="map-zoom-btn"
                onClick={() => setZoomLevel((z) => Math.min(z + 0.15, 1.45))}
                title="Phóng to"
              >
                +
              </button>
              <div style={{ height: "1px", background: "#e2e8f0" }} />
              <button
                type="button"
                className="map-zoom-btn"
                onClick={() => setZoomLevel((z) => Math.max(z - 0.15, 0.85))}
                title="Thu nhỏ"
              >
                −
              </button>
              <div style={{ height: "1px", background: "#e2e8f0" }} />
              <button
                type="button"
                className="map-zoom-btn"
                onClick={() => setZoomLevel(1)}
                title="Định vị của bạn"
                style={{ fontSize: "0.95rem" }}
              >
                🎯
              </button>
            </div>

            {/* VECTOR MAP SVG BACKGROUND (TP.HCM RIVER & ROADS SCHEME) */}
            <div
              style={{
                position: "absolute",
                inset: 0,
                transform: `scale(${zoomLevel})`,
                transformOrigin: "center center",
                transition: "transform 0.25s ease",
                background: mapMode === "map" ? "#e9f2f9" : "#1a2c3a",
              }}
            >
              <svg width="100%" height="100%" viewBox="0 0 800 800" preserveAspectRatio="none">
                {/* RIVER PATH */}
                <path
                  d="M 50,200 Q 150,150 250,220 T 450,280 T 600,200 T 780,260 T 680,450 T 600,600 T 520,780"
                  fill="none"
                  stroke="#99d2f2"
                  strokeWidth="42"
                  strokeLinecap="round"
                />
                <path
                  d="M 250,220 Q 300,320 280,480 T 400,600"
                  fill="none"
                  stroke="#b3def7"
                  strokeWidth="24"
                />

                {/* MAIN ARTERY ROADS */}
                <line x1="0" y1="180" x2="800" y2="400" stroke="#ffffff" strokeWidth="6" />
                <line x1="200" y1="0" x2="350" y2="800" stroke="#ffffff" strokeWidth="8" />
                <line x1="0" y1="520" x2="800" y2="480" stroke="#ffffff" strokeWidth="10" />
                <line x1="480" y1="0" x2="520" y2="800" stroke="#ffffff" strokeWidth="7" />
                <line x1="100" y1="700" x2="700" y2="200" stroke="#ffffff" strokeWidth="5" />

                {/* DISTRICT LABELS */}
                <text x="360" y="550" fill="#64748b" fontSize="18" fontWeight="bold" letterSpacing="1">
                  TP. Hồ Chí Minh
                </text>
                <text x="590" y="340" fill="#94a3b8" fontSize="13">Bình Thạnh</text>
                <text x="700" y="390" fill="#94a3b8" fontSize="13">TP. Thủ Đức</text>
                <text x="620" y="620" fill="#94a3b8" fontSize="13">PHÚ MỸ HƯNG</text>
                <text x="520" y="430" fill="#94a3b8" fontSize="13">Quận 1</text>
                <text x="440" y="470" fill="#94a3b8" fontSize="13">Quận 3</text>
                <text x="210" y="330" fill="#94a3b8" fontSize="13">✈️ Sân bay Tân Sơn Nhất</text>
              </svg>

              {/* MAP PINS */}
              {branches.map((b) => {
                const isSelected = b.id === selectedBranchId
                return (
                  <div
                    key={b.id}
                    onClick={() => handleSelectBranch(b.id)}
                    style={{
                      position: "absolute",
                      left: `${b.mapCoordinates.x}%`,
                      top: `${b.mapCoordinates.y}%`,
                      transform: "translate(-50%, -100%)",
                      cursor: "pointer",
                      zIndex: isSelected ? 15 : 12,
                      display: "flex",
                      alignItems: "center",
                      gap: "6px",
                      transition: "all 0.2s ease",
                    }}
                  >
                    <div
                      style={{
                        background: isSelected ? "#ef4444" : "#2563eb",
                        color: "#ffffff",
                        padding: "6px 12px",
                        borderRadius: "20px",
                        fontSize: "0.82rem",
                        fontWeight: 700,
                        boxShadow: "0 6px 16px rgba(0,0,0,0.25)",
                        display: "flex",
                        alignItems: "center",
                        gap: "6px",
                        border: "2px solid #ffffff",
                        transform: isSelected ? "scale(1.15)" : "scale(1)",
                      }}
                    >
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="white">
                        <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z" />
                      </svg>
                      <span>{b.district}</span>
                    </div>
                  </div>
                )
              })}
            </div>

            {/* FLOATING SELECTED BRANCH CARD AT BOTTOM (IMAGE 3) */}
            {selectedBranch && (
              <div className="map-selected-preview-card">
                <div style={{ display: "grid", gridTemplateColumns: "140px 1fr", gap: "20px", alignItems: "center" }}>
                  <img
                    src={selectedBranch.image}
                    alt={selectedBranch.name}
                    style={{ width: "140px", height: "110px", borderRadius: "14px", objectFit: "cover" }}
                  />

                  <div>
                    <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "6px" }}>
                      <h3 style={{ fontSize: "1.25rem", fontWeight: 800, margin: 0, color: "#0f172a" }}>
                        {selectedBranch.name}
                      </h3>
                      <span
                        style={{
                          background: "#eff6ff",
                          color: "#2563eb",
                          fontSize: "0.78rem",
                          fontWeight: 700,
                          padding: "3px 10px",
                          borderRadius: "999px",
                          border: "1px solid #bfdbfe",
                          display: "inline-flex",
                          alignItems: "center",
                          gap: "4px",
                        }}
                      >
                        📍 Chi nhánh gần bạn
                      </span>
                    </div>

                    <div style={{ display: "flex", flexWrap: "wrap", gap: "16px", fontSize: "0.84rem", color: "#64748b", marginBottom: "10px" }}>
                      <div>📍 {selectedBranch.address}</div>
                      <div>🚀 Cách bạn {selectedBranch.distance}</div>
                      <div>🕒 08:00 - 20:00 (Thứ 2 - Chủ nhật)</div>
                      <div>📞 {selectedBranch.phone}</div>
                      <div>🚗 Có chỗ đỗ xe</div>
                    </div>

                    <div style={{ display: "flex", alignItems: "center", gap: "8px", flexWrap: "wrap", marginBottom: "12px" }}>
                      <span style={{ fontSize: "0.78rem", fontWeight: 700, color: "#475569" }}>
                        Dịch vụ nổi bật tại chi nhánh này:
                      </span>
                      {selectedBranch.featuredServices.map((svc) => (
                        <span
                          key={svc}
                          style={{
                            fontSize: "0.76rem",
                            background: "#f1f5f9",
                            padding: "3px 10px",
                            borderRadius: "6px",
                            color: "#334155",
                            fontWeight: 600,
                          }}
                        >
                          {svc}
                        </span>
                      ))}
                    </div>

                    <div style={{ display: "flex", gap: "12px" }}>
                      <button
                        type="button"
                        style={{
                          padding: "8px 18px",
                          borderRadius: "10px",
                          border: "1px solid #cbd5e1",
                          background: "#ffffff",
                          fontSize: "0.85rem",
                          fontWeight: 600,
                          cursor: "pointer",
                        }}
                        onClick={() => handleSelectBranch(selectedBranch.id)}
                      >
                        🔍 Xem chi tiết chi nhánh
                      </button>
                      <button
                        type="button"
                        className="btn"
                        style={{
                          padding: "8px 24px",
                          borderRadius: "10px",
                          background: "#2563eb",
                          fontSize: "0.85rem",
                          fontWeight: 700,
                          boxShadow: "0 4px 12px rgba(37,99,235,0.3)",
                        }}
                        onClick={() => handleBookAtBranch(selectedBranch.id)}
                      >
                        📅 Chọn chi nhánh này
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </main>
  )
}
