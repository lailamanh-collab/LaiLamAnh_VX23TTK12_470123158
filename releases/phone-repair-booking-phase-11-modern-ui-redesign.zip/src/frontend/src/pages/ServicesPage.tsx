import { useEffect, useState } from "react"
import { Link } from "react-router-dom"
import { getServices } from "../api/catalog"

interface ServiceCardData {
  id: number
  key: string
  name: string
  category: string
  description: string
  image: string
  badges: string[]
  fromPrice: number
  pricingType: "FixedPrice" | "InspectionRequired"
}

const FEATURED_SERVICES: ServiceCardData[] = [
  {
    id: 1,
    key: "screen",
    name: "Thay màn hình",
    category: "screen",
    description: "Thay màn hình chính hãng, hiển thị sắc nét, cảm ứng mượt mà.",
    image: "https://images.unsplash.com/photo-1592750475338-74b7b21085ab?auto=format&fit=crop&w=300&q=80",
    badges: ["Chính hãng", "Bảo hành dài hạn"],
    fromPrice: 1500000,
    pricingType: "FixedPrice",
  },
  {
    id: 2,
    key: "battery",
    name: "Thay pin",
    category: "battery",
    description: "Thay pin dung lượng chuẩn, ổn định và an toàn.",
    image: "https://images.unsplash.com/photo-1609081219090-a6d81d3085bf?auto=format&fit=crop&w=300&q=80",
    badges: ["Chính hãng", "Bảo hành 6 tháng"],
    fromPrice: 500000,
    pricingType: "FixedPrice",
  },
  {
    id: 3,
    key: "port",
    name: "Sửa cổng sạc",
    category: "battery",
    description: "Khắc phục lỗi sạc, sạc không vào, lỏng cổng sạc.",
    image: "https://images.unsplash.com/photo-1583863788434-e58a36330cf0?auto=format&fit=crop&w=300&q=80",
    badges: ["Kiểm tra miễn phí", "Bảo hành 3 tháng"],
    fromPrice: 400000,
    pricingType: "FixedPrice",
  },
  {
    id: 4,
    key: "camera",
    name: "Sửa camera",
    category: "camera",
    description: "Sửa lỗi camera mờ, không lấy nét, không hoạt động.",
    image: "https://images.unsplash.com/photo-1512499617640-c74ae3a79d37?auto=format&fit=crop&w=300&q=80",
    badges: ["Kiểm tra miễn phí", "Bảo hành 3 tháng"],
    fromPrice: 300000,
    pricingType: "FixedPrice",
  },
  {
    id: 5,
    key: "speaker",
    name: "Sửa loa",
    category: "camera",
    description: "Sửa loa trong, loa ngoài bị rè, mất tiếng, âm thanh nhỏ.",
    image: "https://images.unsplash.com/photo-1545454675-3531b543be5d?auto=format&fit=crop&w=300&q=80",
    badges: ["Kiểm tra miễn phí", "Bảo hành 3 tháng"],
    fromPrice: 250000,
    pricingType: "FixedPrice",
  },
  {
    id: 6,
    key: "clean",
    name: "Vệ sinh máy",
    category: "maintenance",
    description: "Vệ sinh tổng thể, loại bỏ bụi bẩn, tăng hiệu suất hoạt động.",
    image: "https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=300&q=80",
    badges: ["Làm sạch chuyên sâu", "An toàn thiết bị"],
    fromPrice: 150000,
    pricingType: "FixedPrice",
  },
  {
    id: 7,
    key: "faceid",
    name: "Sửa Face ID",
    category: "sensor",
    description: "Sửa lỗi Face ID, không nhận diện, nhận diện chậm.",
    image: "https://images.unsplash.com/photo-1563206767-5b18f218e8de?auto=format&fit=crop&w=300&q=80",
    badges: ["Kiểm tra miễn phí", "Bảo hành 3 tháng"],
    fromPrice: 600000,
    pricingType: "InspectionRequired",
  },
  {
    id: 8,
    key: "mic",
    name: "Sửa micro",
    category: "camera",
    description: "Sửa lỗi micro, không thu âm, âm thanh nhỏ, bị rè.",
    image: "https://images.unsplash.com/photo-1590602847861-f357a9332bbc?auto=format&fit=crop&w=300&q=80",
    badges: ["Kiểm tra miễn phí", "Bảo hành 3 tháng"],
    fromPrice: 250000,
    pricingType: "FixedPrice",
  },
]

const CATEGORIES = [
  { id: "all", label: "Tất cả dịch vụ", icon: "✓" },
  { id: "screen", label: "Màn hình", icon: "📱" },
  { id: "battery", label: "Pin - Sạc", icon: "🔋" },
  { id: "camera", label: "Camera - Âm thanh", icon: "📷" },
  { id: "maintenance", label: "Vệ sinh - Bảo dưỡng", icon: "🛠️" },
  { id: "sensor", label: "Face ID - Cảm biến", icon: "🔍" },
  { id: "other", label: "Khác", icon: "⚙️" },
]

const BRAND_CHECKBOXES = [
  { id: "apple", label: "Apple (iPhone)" },
  { id: "samsung", label: "Samsung (Galaxy)" },
  { id: "xiaomi", label: "Xiaomi" },
  { id: "oppo", label: "Oppo" },
  { id: "vivo", label: "Vivo" },
  { id: "realme", label: "Realme" },
  { id: "google", label: "Google (Pixel)" },
  { id: "honor", label: "Honor" },
]

export function ServicesPage() {
  const [services, setServices] = useState<ServiceCardData[]>(FEATURED_SERVICES)
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedBrands, setSelectedBrands] = useState<string[]>(["apple"])
  const [maxPrice, setMaxPrice] = useState(10000000)
  const [sortBy, setSortBy] = useState("popular")

  useEffect(() => {
    getServices()
      .then((serverServices) => {
        if (serverServices && serverServices.length > 0) {
          // Merge with rich visual mockups
          const merged = FEATURED_SERVICES.map((feat) => {
            const found = serverServices.find((s) => s.name.toLowerCase() === feat.name.toLowerCase())
            return found ? { ...feat, id: found.id } : feat
          })
          setServices(merged)
        }
      })
      .catch(() => {
        // use default rich list
      })
  }, [])

  const toggleBrand = (brandId: string) => {
    setSelectedBrands((prev) =>
      prev.includes(brandId) ? prev.filter((b) => b !== brandId) : [...prev, brandId]
    )
  }

  const resetFilters = () => {
    setSelectedCategory("all")
    setSearchQuery("")
    setSelectedBrands(["apple"])
    setMaxPrice(10000000)
  }

  const filteredServices = services.filter((svc) => {
    if (selectedCategory !== "all" && svc.category !== selectedCategory) return false
    if (searchQuery.trim() && !svc.name.toLowerCase().includes(searchQuery.toLowerCase())) return false
    if (svc.fromPrice > maxPrice) return false
    return true
  })

  const formatVnd = (price: number) => {
    return new Intl.NumberFormat("vi-VN", { style: "currency", currency: "VND", maximumFractionDigits: 0 }).format(price)
  }

  return (
    <main style={{ background: "#f8fafc", minHeight: "100vh" }}>
      {/* 1. DARK WORKSHOP HERO BANNER (IMAGE 5) */}
      <section className="services-catalog-hero">
        <div className="services-catalog-hero-inner">
          <div style={{ maxWidth: "700px" }}>
            <h1 style={{ fontSize: "2.35rem", fontWeight: 800, margin: "0 0 10px", letterSpacing: "-0.03em" }}>
              Dịch vụ sửa chữa điện thoại
            </h1>
            <p style={{ fontSize: "1.05rem", color: "#cbd5e1", margin: 0, lineHeight: 1.5 }}>
              Sửa chữa nhanh chóng, minh bạch, chính hãng – Lấy máy đúng hẹn
            </p>

            {/* SEARCH INPUT */}
            <div className="services-hero-search-box">
              <span style={{ color: "#94a3b8", marginRight: "10px", fontSize: "1.1rem" }}>🔍</span>
              <input
                type="text"
                className="services-hero-search-input"
                placeholder="Tìm kiếm dịch vụ (ví dụ: thay màn hình, thay pin, sửa loa...)"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <button
                type="button"
                className="btn"
                style={{
                  height: "40px",
                  padding: "0 24px",
                  borderRadius: "999px",
                  background: "#2563eb",
                  fontWeight: 700,
                  fontSize: "0.9rem",
                }}
              >
                Tìm kiếm
              </button>
            </div>

            {/* 4 HIGHLIGHT BADGES ROW */}
            <div className="services-hero-badges-row">
              <div className="services-hero-badge-item">
                <div className="services-hero-badge-icon">🛡️</div>
                <div>
                  <strong style={{ display: "block", fontSize: "0.85rem", color: "white" }}>Linh kiện chính hãng</strong>
                  <span style={{ fontSize: "0.75rem", color: "#94a3b8" }}>Chất lượng đảm bảo</span>
                </div>
              </div>

              <div className="services-hero-badge-item">
                <div className="services-hero-badge-icon">⏱️</div>
                <div>
                  <strong style={{ display: "block", fontSize: "0.85rem", color: "white" }}>Sửa nhanh lấy liền</strong>
                  <span style={{ fontSize: "0.75rem", color: "#94a3b8" }}>Tiết kiệm thời gian</span>
                </div>
              </div>

              <div className="services-hero-badge-item">
                <div className="services-hero-badge-icon">👨‍🔧</div>
                <div>
                  <strong style={{ display: "block", fontSize: "0.85rem", color: "white" }}>Kỹ thuật viên chuyên nghiệp</strong>
                  <span style={{ fontSize: "0.75rem", color: "#94a3b8" }}>Nhiều năm kinh nghiệm</span>
                </div>
              </div>

              <div className="services-hero-badge-item">
                <div className="services-hero-badge-icon">📍</div>
                <div>
                  <strong style={{ display: "block", fontSize: "0.85rem", color: "white" }}>Hệ thống chi nhánh</strong>
                  <span style={{ fontSize: "0.75rem", color: "#94a3b8" }}>Phủ khắp TP.HCM và các tỉnh</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 2. CATALOG CONTENT WITH FILTER SIDEBAR & 8 CARDS GRID (IMAGE 5) */}
      <div className="services-catalog-layout">
        {/* LEFT FILTER SIDEBAR */}
        <aside className="services-filter-sidebar">
          <div className="services-filter-title">
            <strong style={{ fontSize: "1rem", color: "#0f172a" }}>⚙️ Bộ lọc dịch vụ</strong>
            <button
              type="button"
              onClick={resetFilters}
              style={{ background: "none", border: "none", color: "#2563eb", fontSize: "0.82rem", fontWeight: 600, cursor: "pointer" }}
            >
              Xóa tất cả
            </button>
          </div>

          {/* DANH MỤC DỊCH VỤ */}
          <div className="services-filter-section">
            <div className="services-filter-section-title">
              <span>Danh mục dịch vụ</span>
              <span>⌄</span>
            </div>
            {CATEGORIES.map((cat) => (
              <div
                key={cat.id}
                className={`services-category-pill ${selectedCategory === cat.id ? "active" : ""}`}
                onClick={() => setSelectedCategory(cat.id)}
              >
                <span style={{ width: "18px", textAlign: "center" }}>{cat.icon}</span>
                <span>{cat.label}</span>
              </div>
            ))}
          </div>

          {/* HÃNG ĐIỆN THOẠI */}
          <div className="services-filter-section">
            <div className="services-filter-section-title">
              <span>Hãng điện thoại</span>
              <span>⌄</span>
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
              {BRAND_CHECKBOXES.map((b) => (
                <label key={b.id} style={{ display: "flex", alignItems: "center", gap: "10px", fontSize: "0.85rem", color: "#334155", cursor: "pointer" }}>
                  <input
                    type="checkbox"
                    checked={selectedBrands.includes(b.id)}
                    onChange={() => toggleBrand(b.id)}
                    style={{ width: "16px", height: "16px", accentColor: "#2563eb" }}
                  />
                  <span>{b.label}</span>
                </label>
              ))}
            </div>
          </div>

          {/* KHOẢNG GIÁ */}
          <div className="services-filter-section" style={{ marginBottom: 0 }}>
            <div className="services-filter-section-title">
              <span>Khoảng giá</span>
            </div>
            <input
              type="range"
              min="150000"
              max="10000000"
              step="100000"
              value={maxPrice}
              onChange={(e) => setMaxPrice(Number(e.target.value))}
              style={{ width: "100%", accentColor: "#2563eb" }}
            />
            <div style={{ display: "flex", justifyContent: "space-between", fontSize: "0.8rem", color: "#64748b", marginTop: "6px" }}>
              <span>0đ</span>
              <strong style={{ color: "#2563eb" }}>{formatVnd(maxPrice)}</strong>
              <span>10.000.000đ+</span>
            </div>
          </div>
        </aside>

        {/* RIGHT GRID CONTENT */}
        <div>
          {/* HEADER ROW */}
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "20px" }}>
            <strong style={{ fontSize: "1.1rem", color: "#0f172a" }}>
              Tổng {filteredServices.length} dịch vụ
            </strong>

            <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
              <span style={{ fontSize: "0.88rem", color: "#64748b" }}>Sắp xếp theo:</span>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                style={{
                  padding: "6px 14px",
                  borderRadius: "10px",
                  border: "1px solid #cbd5e1",
                  background: "#ffffff",
                  fontSize: "0.88rem",
                  color: "#1e293b",
                  fontWeight: 600,
                }}
              >
                <option value="popular">Phổ biến nhất</option>
                <option value="price-asc">Giá tăng dần</option>
                <option value="price-desc">Giá giảm dần</option>
              </select>
            </div>
          </div>

          {/* 8 SERVICE CARDS */}
          <div className="services-card-grid">
            {filteredServices.map((svc) => (
              <article key={svc.id} className="service-item-card">
                <div className="service-item-img-wrap">
                  <img src={svc.image} alt={svc.name} className="service-item-img" />
                </div>

                <h3 className="service-item-title">{svc.name}</h3>
                <p className="service-item-desc">{svc.description}</p>

                <div className="service-item-badges">
                  {svc.badges.map((b) => (
                    <span key={b} className="service-item-badge">
                      {b}
                    </span>
                  ))}
                </div>

                <div className="service-item-price-row">
                  <span className="service-item-price-label">Giá từ</span>
                  <span className="service-item-price-val">{formatVnd(svc.fromPrice)}</span>

                  <div className="service-item-actions">
                    <Link to={`/pricing?service=${svc.key}`} className="service-btn-outline">
                      Xem chi tiết
                    </Link>
                    <Link to={`/booking?serviceId=${svc.id}`} className="service-btn-fill">
                      Đặt lịch
                    </Link>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </div>
    </main>
  )
}
