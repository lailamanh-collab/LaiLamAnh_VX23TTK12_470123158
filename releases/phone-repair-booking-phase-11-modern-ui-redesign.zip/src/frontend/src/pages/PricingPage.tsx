import { useState } from "react"
import { Link, useNavigate } from "react-router-dom"

interface PricingRow {
  modelName: string
  modelId?: number
  screenType: string
  badgeLabel: string
  price: number
  warranty: string
  duration: string
}

const DEFAULT_SERIES_PRICES: Record<string, PricingRow[]> = {
  "iPhone 16 Series": [
    { modelName: "iPhone 16 Pro Max", screenType: "Màn hình chính hãng", badgeLabel: "Apple", price: 7500000, warranty: "12 tháng", duration: "60 - 90 phút" },
    { modelName: "iPhone 16 Pro", screenType: "Màn hình chính hãng", badgeLabel: "Apple", price: 6500000, warranty: "12 tháng", duration: "60 - 90 phút" },
    { modelName: "iPhone 16 Plus", screenType: "Màn hình chính hãng", badgeLabel: "Apple", price: 5500000, warranty: "12 tháng", duration: "45 - 60 phút" },
    { modelName: "iPhone 16", screenType: "Màn hình chính hãng", badgeLabel: "Apple", price: 4500000, warranty: "12 tháng", duration: "45 - 60 phút" },
    { modelName: "iPhone 16e", screenType: "Màn hình linh kiện cao cấp", badgeLabel: "LK cao cấp", price: 3500000, warranty: "6 tháng", duration: "45 - 60 phút" },
  ],
  "iPhone 15 Series": [
    { modelName: "iPhone 15 Pro Max", screenType: "Màn hình chính hãng", badgeLabel: "Apple", price: 6800000, warranty: "12 tháng", duration: "60 - 90 phút" },
    { modelName: "iPhone 15 Pro", screenType: "Màn hình chính hãng", badgeLabel: "Apple", price: 5800000, warranty: "12 tháng", duration: "60 - 90 phút" },
    { modelName: "iPhone 15 Plus", screenType: "Màn hình chính hãng", badgeLabel: "Apple", price: 4800000, warranty: "12 tháng", duration: "45 - 60 phút" },
    { modelName: "iPhone 15", screenType: "Màn hình chính hãng", badgeLabel: "Apple", price: 3900000, warranty: "12 tháng", duration: "45 - 60 phút" },
  ],
  "iPhone 14 Series": [
    { modelName: "iPhone 14 Pro Max", screenType: "Màn hình chính hãng", badgeLabel: "Apple", price: 5900000, warranty: "12 tháng", duration: "60 - 90 phút" },
    { modelName: "iPhone 14 Pro", screenType: "Màn hình chính hãng", badgeLabel: "Apple", price: 5100000, warranty: "12 tháng", duration: "60 - 90 phút" },
    { modelName: "iPhone 14 Plus", screenType: "Màn hình chính hãng", badgeLabel: "Apple", price: 4100000, warranty: "12 tháng", duration: "45 - 60 phút" },
    { modelName: "iPhone 14", screenType: "Màn hình chính hãng", badgeLabel: "Apple", price: 3400000, warranty: "12 tháng", duration: "45 - 60 phút" },
  ],
  "iPhone 13 Series": [
    { modelName: "iPhone 13 Pro Max", screenType: "Màn hình chính hãng", badgeLabel: "Apple", price: 4900000, warranty: "12 tháng", duration: "60 - 90 phút" },
    { modelName: "iPhone 13 Pro", screenType: "Màn hình chính hãng", badgeLabel: "Apple", price: 4200000, warranty: "12 tháng", duration: "60 - 90 phút" },
    { modelName: "iPhone 13", screenType: "Màn hình chính hãng", badgeLabel: "Apple", price: 2900000, warranty: "12 tháng", duration: "45 - 60 phút" },
    { modelName: "iPhone 13 Mini", screenType: "Màn hình chính hãng", badgeLabel: "Apple", price: 2600000, warranty: "12 tháng", duration: "45 - 60 phút" },
  ],
  "iPhone 12 Series": [
    { modelName: "iPhone 12 Pro Max", screenType: "Màn hình chính hãng", badgeLabel: "Apple", price: 3800000, warranty: "12 tháng", duration: "60 - 90 phút" },
    { modelName: "iPhone 12 Pro", screenType: "Màn hình chính hãng", badgeLabel: "Apple", price: 3200000, warranty: "12 tháng", duration: "60 - 90 phút" },
    { modelName: "iPhone 12", screenType: "Màn hình chính hãng", badgeLabel: "Apple", price: 2400000, warranty: "12 tháng", duration: "45 - 60 phút" },
  ],
  "iPhone 11 Series": [
    { modelName: "iPhone 11 Pro Max", screenType: "Màn hình chính hãng", badgeLabel: "Apple", price: 2800000, warranty: "12 tháng", duration: "45 - 60 phút" },
    { modelName: "iPhone 11 Pro", screenType: "Màn hình chính hãng", badgeLabel: "Apple", price: 2300000, warranty: "12 tháng", duration: "45 - 60 phút" },
    { modelName: "iPhone 11", screenType: "Màn hình chính hãng", badgeLabel: "Apple", price: 1650000, warranty: "12 tháng", duration: "45 - 60 phút" },
  ],
  "iPhone X Series": [
    { modelName: "iPhone XS Max", screenType: "Màn hình chính hãng", badgeLabel: "Apple", price: 1950000, warranty: "12 tháng", duration: "45 - 60 phút" },
    { modelName: "iPhone XS", screenType: "Màn hình chính hãng", badgeLabel: "Apple", price: 1600000, warranty: "12 tháng", duration: "45 - 60 phút" },
    { modelName: "iPhone XR", screenType: "Màn hình chính hãng", badgeLabel: "Apple", price: 1400000, warranty: "12 tháng", duration: "45 - 60 phút" },
    { modelName: "iPhone X", screenType: "Màn hình chính hãng", badgeLabel: "Apple", price: 1500000, warranty: "12 tháng", duration: "45 - 60 phút" },
  ],
  "iPhone 8 Series": [
    { modelName: "iPhone 8 Plus", screenType: "Màn hình chính hãng", badgeLabel: "Apple", price: 950000, warranty: "12 tháng", duration: "30 - 45 phút" },
    { modelName: "iPhone 8", screenType: "Màn hình chính hãng", badgeLabel: "Apple", price: 750000, warranty: "12 tháng", duration: "30 - 45 phút" },
  ],
}

const BRANDS = ["Apple", "Samsung", "Xiaomi", "OPPO", "vivo", "Realme", "Google", "Honor"]

export function PricingPage() {
  const navigate = useNavigate()

  const [selectedBrand, setSelectedBrand] = useState("Apple")
  const [selectedSeries, setSelectedSeries] = useState("iPhone 16 Series")
  const [searchModel, setSearchModel] = useState("")
  const [selectedImageIdx, setSelectedImageIdx] = useState(0)

  const galleryImages = [
    "https://images.unsplash.com/photo-1592750475338-74b7b21085ab?auto=format&fit=crop&w=800&q=80",
    "https://images.unsplash.com/photo-1581092921461-eab62e97a780?auto=format&fit=crop&w=400&q=80",
    "https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=400&q=80",
    "https://images.unsplash.com/photo-1550009158-9ebf69173e03?auto=format&fit=crop&w=400&q=80",
  ]

  const currentRows = DEFAULT_SERIES_PRICES[selectedSeries] || DEFAULT_SERIES_PRICES["iPhone 16 Series"]

  const filteredRows = currentRows.filter((r) =>
    r.modelName.toLowerCase().includes(searchModel.toLowerCase())
  )

  const formatVnd = (price: number) => {
    return new Intl.NumberFormat("vi-VN", { style: "currency", currency: "VND", maximumFractionDigits: 0 }).format(price)
  }

  const handleBookModel = (modelName: string) => {
    navigate(`/booking?modelName=${encodeURIComponent(modelName)}&serviceName=Thay màn hình`)
  }

  return (
    <main className="pricing-page-container">
      {/* 1. BREADCRUMBS (IMAGE 4) */}
      <nav className="pricing-breadcrumb">
        <Link to="/" style={{ color: "#64748b" }}>Trang chủ</Link>
        <span>›</span>
        <Link to="/services" style={{ color: "#64748b" }}>Dịch vụ sửa chữa</Link>
        <span>›</span>
        <strong style={{ color: "#0f172a" }}>Thay màn hình</strong>
      </nav>

      {/* 2. TOP HERO CARD (IMAGE 4) */}
      <section className="pricing-hero-card">
        {/* GALLERY COLUMN */}
        <div className="pricing-gallery-col">
          <div style={{ position: "relative" }}>
            <img
              src={galleryImages[selectedImageIdx]}
              alt="Thay màn hình điện thoại"
              className="pricing-main-image"
            />
            <div
              style={{
                position: "absolute",
                inset: 0,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                pointerEvents: "none",
              }}
            >
              <div
                style={{
                  width: "48px",
                  height: "48px",
                  borderRadius: "50%",
                  background: "rgba(255, 255, 255, 0.85)",
                  backdropFilter: "blur(6px)",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  boxShadow: "0 4px 16px rgba(0,0,0,0.2)",
                  color: "#2563eb",
                  fontSize: "1.2rem",
                  paddingLeft: "3px",
                }}
              >
                ▶
              </div>
            </div>
          </div>

          <div className="pricing-thumbs-row">
            {galleryImages.slice(0, 3).map((img, i) => (
              <img
                key={i}
                src={img}
                alt={`Thumbnail ${i}`}
                className={`pricing-thumb-item ${selectedImageIdx === i ? "active" : ""}`}
                onClick={() => setSelectedImageIdx(i)}
              />
            ))}
            <div
              className="pricing-thumb-item"
              style={{
                background: "#f1f5f9",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                fontSize: "0.82rem",
                color: "#475569",
                fontWeight: 600,
              }}
              onClick={() => setSelectedImageIdx(3)}
            >
              +3 ảnh
            </div>
          </div>
        </div>

        {/* CENTER INFO COLUMN */}
        <div className="pricing-info-col">
          <h1>Thay màn hình điện thoại</h1>
          <p>
            Thay màn hình chính hãng, linh kiện chất lượng cao cho tất cả các dòng điện thoại. Kỹ thuật viên giàu kinh nghiệm, quy trình minh bạch, lấy ngay chỉ với vài bước.
          </p>

          <div className="pricing-chips-grid">
            <div className="pricing-chip-item">
              <span style={{ fontSize: "1.2rem", color: "#2563eb" }}>🛡️</span>
              <div>
                <strong style={{ display: "block", fontSize: "0.85rem", color: "#0f172a" }}>Linh kiện chính hãng</strong>
                <span style={{ fontSize: "0.75rem", color: "#64748b" }}>Cam kết chất lượng</span>
              </div>
            </div>

            <div className="pricing-chip-item">
              <span style={{ fontSize: "1.2rem", color: "#0284c7" }}>⚡</span>
              <div>
                <strong style={{ display: "block", fontSize: "0.85rem", color: "#0f172a" }}>Lấy ngay 30 - 60 phút</strong>
                <span style={{ fontSize: "0.75rem", color: "#64748b" }}>Không giữ máy lâu</span>
              </div>
            </div>

            <div className="pricing-chip-item">
              <span style={{ fontSize: "1.2rem", color: "#7c3aed" }}>💎</span>
              <div>
                <strong style={{ display: "block", fontSize: "0.85rem", color: "#0f172a" }}>Kỹ thuật viên chuyên nghiệp</strong>
                <span style={{ fontSize: "0.75rem", color: "#64748b" }}>Tay nghề cao</span>
              </div>
            </div>

            <div className="pricing-chip-item">
              <span style={{ fontSize: "1.2rem", color: "#16a34a" }}>🛡️</span>
              <div>
                <strong style={{ display: "block", fontSize: "0.85rem", color: "#0f172a" }}>Bảo hành 3 - 12 tháng</strong>
                <span style={{ fontSize: "0.75rem", color: "#64748b" }}>Hỗ trợ tận tâm</span>
              </div>
            </div>
          </div>
        </div>

        {/* RIGHT CTA CARD */}
        <div className="pricing-cta-card">
          <div>
            <span style={{ fontSize: "0.88rem", color: "#64748b" }}>Giá dịch vụ từ</span>
            <div style={{ fontSize: "2rem", fontWeight: 900, color: "#2563eb", letterSpacing: "-0.02em" }}>
              1.500.000đ
            </div>

            <div className="pricing-cta-price-badge">
              <span>✓</span>
              <span>Chính hãng - Bảo hành đến 12 tháng</span>
            </div>
          </div>

          <div style={{ margin: "24px 0" }}>
            <Link
              to="/booking?serviceName=Thay màn hình"
              className="btn"
              style={{
                width: "100%",
                padding: "14px 18px",
                background: "#2563eb",
                borderRadius: "14px",
                fontWeight: 700,
                fontSize: "0.95rem",
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                textAlign: "center",
                boxShadow: "0 6px 20px rgba(37,99,235,0.3)",
              }}
            >
              <span style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                <span>📅</span>
                <span>Đặt lịch sửa chữa</span>
              </span>
              <span style={{ fontSize: "0.76rem", fontWeight: 400, opacity: 0.9, marginTop: "2px" }}>
                Chọn chi nhánh, thời gian phù hợp
              </span>
            </Link>
          </div>

          <div style={{ display: "flex", flexDirection: "column", gap: "8px", fontSize: "0.82rem", color: "#64748b" }}>
            <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
              <span>📞</span>
              <span>Tư vấn miễn phí: <strong style={{ color: "#0f172a" }}>1900 1234</strong></span>
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
              <span>🚚</span>
              <span>Kiểm tra máy: <strong style={{ color: "#16a34a" }}>Miễn phí</strong></span>
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
              <span>🛡️</span>
              <span>Cam kết giá: <strong style={{ color: "#0f172a" }}>Minh bạch</strong></span>
            </div>
          </div>
        </div>
      </section>

      {/* 3. PRICE MATRIX SECTION (IMAGE 4) */}
      <section className="pricing-matrix-section">
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: "16px" }}>
          <div>
            <h2 style={{ fontSize: "1.45rem", fontWeight: 800, margin: "0 0 6px", color: "#0f172a" }}>
              Bảng giá thay màn hình theo dòng máy
            </h2>
            <p style={{ fontSize: "0.88rem", color: "#64748b", margin: 0 }}>
              Chọn thương hiệu và model điện thoại để xem chi tiết giá và thông tin linh kiện
            </p>
          </div>

          <div style={{ position: "relative", minWidth: "280px" }}>
            <span style={{ position: "absolute", left: "12px", top: "10px", color: "#94a3b8" }}>🔍</span>
            <input
              type="text"
              placeholder="Tìm kiếm model (ví dụ: iPhone 15)..."
              value={searchModel}
              onChange={(e) => setSearchModel(e.target.value)}
              style={{
                width: "100%",
                height: "40px",
                padding: "0 14px 0 38px",
                border: "1px solid #cbd5e1",
                borderRadius: "10px",
                fontSize: "0.88rem",
              }}
            />
          </div>
        </div>

        {/* BRAND TABS */}
        <div className="pricing-brands-bar">
          {BRANDS.map((brand) => (
            <button
              key={brand}
              type="button"
              className={`pricing-brand-pill ${selectedBrand === brand ? "active" : ""}`}
              onClick={() => setSelectedBrand(brand)}
            >
              {brand === "Apple" ? "🍎 Apple" : brand}
            </button>
          ))}
        </div>

        {/* 2-COLUMN SUB-LAYOUT: SERIES SIDEBAR + MATRIX TABLE */}
        <div className="pricing-matrix-split">
          {/* SERIES SIDEBAR */}
          <div className="pricing-series-sidebar">
            <span style={{ fontSize: "0.82rem", fontWeight: 700, color: "#64748b", display: "block", marginBottom: "12px", textTransform: "uppercase" }}>
              Dòng máy iPhone
            </span>

            {Object.keys(DEFAULT_SERIES_PRICES).map((series) => (
              <div
                key={series}
                className={`pricing-series-item ${selectedSeries === series ? "active" : ""}`}
                onClick={() => setSelectedSeries(series)}
              >
                <span>{series}</span>
                <span style={{ fontSize: "0.8rem", color: selectedSeries === series ? "#2563eb" : "#94a3b8" }}>›</span>
              </div>
            ))}
          </div>

          {/* PRICING TABLE */}
          <div>
            <h3 style={{ fontSize: "1.1rem", fontWeight: 700, margin: "0 0 16px", color: "#0f172a" }}>
              Bảng giá thay màn hình {selectedSeries}
            </h3>

            <div style={{ overflowX: "auto" }}>
              <table className="pricing-table">
                <thead>
                  <tr>
                    <th>Model</th>
                    <th>Loại màn hình</th>
                    <th>Giá dịch vụ</th>
                    <th>Bảo hành</th>
                    <th>Thời gian</th>
                    <th style={{ textAlign: "right" }}>Đặt lịch</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredRows.map((row, idx) => (
                    <tr key={idx}>
                      <td style={{ fontWeight: 700, color: "#0f172a" }}>{row.modelName}</td>
                      <td>
                        <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                          <span>{row.screenType}</span>
                          <span
                            style={{
                              fontSize: "0.72rem",
                              fontWeight: 700,
                              background: row.badgeLabel === "Apple" ? "#eff6ff" : "#f0fdf4",
                              color: row.badgeLabel === "Apple" ? "#2563eb" : "#16a34a",
                              border: `1px solid ${row.badgeLabel === "Apple" ? "#bfdbfe" : "#bbf7d0"}`,
                              padding: "2px 8px",
                              borderRadius: "6px",
                            }}
                          >
                            {row.badgeLabel}
                          </span>
                        </div>
                      </td>
                      <td style={{ fontWeight: 800, color: "#2563eb", fontSize: "0.98rem" }}>
                        {formatVnd(row.price)}
                      </td>
                      <td>{row.warranty}</td>
                      <td>{row.duration}</td>
                      <td style={{ textAlign: "right" }}>
                        <button
                          type="button"
                          className="btn"
                          style={{
                            padding: "6px 14px",
                            fontSize: "0.82rem",
                            borderRadius: "8px",
                            background: "#eff6ff",
                            color: "#2563eb",
                            border: "1px solid #bfdbfe",
                          }}
                          onClick={() => handleBookModel(row.modelName)}
                        >
                          Đặt lịch
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </section>

      {/* 4. BOTTOM 3 CARDS: PROCESS, WARRANTY, COMMITMENTS (IMAGE 4) */}
      <section className="pricing-bottom-cards">
        {/* CARD 1: QUY TRÌNH THAY MÀN HÌNH */}
        <div className="pricing-bottom-card">
          <h3 style={{ fontSize: "1.1rem", fontWeight: 800, color: "#0f172a", margin: "0 0 20px" }}>
            Quy trình thay màn hình
          </h3>

          <div style={{ display: "flex", flexDirection: "column", gap: "18px" }}>
            <div style={{ display: "flex", gap: "14px", alignItems: "flex-start" }}>
              <div className="pricing-step-num">1</div>
              <div>
                <strong style={{ display: "block", fontSize: "0.9rem", color: "#0f172a", marginBottom: "2px" }}>
                  Kiểm tra máy
                </strong>
                <span style={{ fontSize: "0.82rem", color: "#64748b" }}>
                  Kỹ thuật viên kiểm tra tình trạng, tư vấn giải pháp
                </span>
              </div>
            </div>

            <div style={{ display: "flex", gap: "14px", alignItems: "flex-start" }}>
              <div className="pricing-step-num">2</div>
              <div>
                <strong style={{ display: "block", fontSize: "0.9rem", color: "#0f172a", marginBottom: "2px" }}>
                  Báo giá & xác nhận
                </strong>
                <span style={{ fontSize: "0.82rem", color: "#64748b" }}>
                  Báo giá chi tiết, khách hàng xác nhận dịch vụ
                </span>
              </div>
            </div>

            <div style={{ display: "flex", gap: "14px", alignItems: "flex-start" }}>
              <div className="pricing-step-num">3</div>
              <div>
                <strong style={{ display: "block", fontSize: "0.9rem", color: "#0f172a", marginBottom: "2px" }}>
                  Tiến hành thay
                </strong>
                <span style={{ fontSize: "0.82rem", color: "#64748b" }}>
                  Thay màn hình bởi kỹ thuật viên chuyên nghiệp
                </span>
              </div>
            </div>

            <div style={{ display: "flex", gap: "14px", alignItems: "flex-start" }}>
              <div className="pricing-step-num">4</div>
              <div>
                <strong style={{ display: "block", fontSize: "0.9rem", color: "#0f172a", marginBottom: "2px" }}>
                  Kiểm tra & bàn giao
                </strong>
                <span style={{ fontSize: "0.82rem", color: "#64748b" }}>
                  Kiểm tra chất lượng, vệ sinh máy và bàn giao
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* CARD 2: CHÍNH SÁCH BẢO HÀNH */}
        <div className="pricing-bottom-card">
          <h3 style={{ fontSize: "1.1rem", fontWeight: 800, color: "#0f172a", margin: "0 0 20px", display: "flex", alignItems: "center", gap: "8px" }}>
            <span style={{ color: "#2563eb" }}>🛡️</span> Chính sách bảo hành
          </h3>

          <ul style={{ listStyle: "none", padding: 0, margin: "0 0 24px", display: "flex", flexDirection: "column", gap: "12px", fontSize: "0.85rem", color: "#334155" }}>
            <li style={{ display: "flex", gap: "10px", alignItems: "flex-start" }}>
              <span style={{ color: "#16a34a", fontWeight: "bold" }}>✓</span>
              <span>Bảo hành từ 3 - 12 tháng tùy loại linh kiện</span>
            </li>
            <li style={{ display: "flex", gap: "10px", alignItems: "flex-start" }}>
              <span style={{ color: "#16a34a", fontWeight: "bold" }}>✓</span>
              <span>1 đổi 1 nếu có lỗi từ nhà sản xuất</span>
            </li>
            <li style={{ display: "flex", gap: "10px", alignItems: "flex-start" }}>
              <span style={{ color: "#16a34a", fontWeight: "bold" }}>✓</span>
              <span>Hỗ trợ kỹ thuật miễn phí trong thời gian bảo hành</span>
            </li>
            <li style={{ display: "flex", gap: "10px", alignItems: "flex-start" }}>
              <span style={{ color: "#16a34a", fontWeight: "bold" }}>✓</span>
              <span>Không bảo hành với lỗi do rơi vỡ, vào nước</span>
            </li>
            <li style={{ display: "flex", gap: "10px", alignItems: "flex-start" }}>
              <span style={{ color: "#16a34a", fontWeight: "bold" }}>✓</span>
              <span>Bảo hành minh bạch, tra cứu dễ dàng</span>
            </li>
          </ul>

          <Link to="/support" style={{ fontSize: "0.85rem", color: "#2563eb", fontWeight: 700, display: "inline-flex", alignItems: "center", gap: "6px" }}>
            📄 Xem chi tiết chính sách bảo hành →
          </Link>
        </div>

        {/* CARD 3: CAM KẾT DỊCH VỤ */}
        <div className="pricing-bottom-card">
          <h3 style={{ fontSize: "1.1rem", fontWeight: 800, color: "#0f172a", margin: "0 0 20px", display: "flex", alignItems: "center", gap: "8px" }}>
            <span style={{ color: "#2563eb" }}>💎</span> Cam kết dịch vụ
          </h3>

          <ul style={{ listStyle: "none", padding: 0, margin: 0, display: "flex", flexDirection: "column", gap: "12px", fontSize: "0.85rem", color: "#334155" }}>
            <li style={{ display: "flex", gap: "10px", alignItems: "flex-start" }}>
              <span style={{ color: "#2563eb" }}>💎</span>
              <span>Linh kiện chính hãng, nguồn gốc rõ ràng</span>
            </li>
            <li style={{ display: "flex", gap: "10px", alignItems: "flex-start" }}>
              <span style={{ color: "#2563eb" }}>💎</span>
              <span>Giá cả minh bạch, không phát sinh chi phí</span>
            </li>
            <li style={{ display: "flex", gap: "10px", alignItems: "flex-start" }}>
              <span style={{ color: "#2563eb" }}>💎</span>
              <span>Kỹ thuật viên giàu kinh nghiệm, tay nghề cao</span>
            </li>
            <li style={{ display: "flex", gap: "10px", alignItems: "flex-start" }}>
              <span style={{ color: "#2563eb" }}>💎</span>
              <span>Lấy ngay trong ngày, tiết kiệm thời gian</span>
            </li>
            <li style={{ display: "flex", gap: "10px", alignItems: "flex-start" }}>
              <span style={{ color: "#2563eb" }}>💎</span>
              <span>Vệ sinh máy miễn phí sau khi sửa</span>
            </li>
            <li style={{ display: "flex", gap: "10px", alignItems: "flex-start" }}>
              <span style={{ color: "#2563eb" }}>💎</span>
              <span>Hỗ trợ tư vấn, chăm sóc khách hàng tận tâm</span>
            </li>
          </ul>
        </div>
      </section>
    </main>
  )
}
