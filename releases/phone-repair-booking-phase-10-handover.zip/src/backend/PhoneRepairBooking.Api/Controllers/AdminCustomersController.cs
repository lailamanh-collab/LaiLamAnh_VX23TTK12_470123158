using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PhoneRepairBooking.Api.Domain;
using PhoneRepairBooking.Api.DTOs;
using PhoneRepairBooking.Api.Services;

namespace PhoneRepairBooking.Api.Controllers;

[ApiController]
[Authorize(Roles = AppRoles.Admin)]
[Route("api/admin/customers")]
public class AdminCustomersController : ControllerBase
{
    private readonly AdminBookingService _adminBookings;

    public AdminCustomersController(AdminBookingService adminBookings)
    {
        _adminBookings = adminBookings;
    }

    [HttpGet]
    public async Task<ActionResult<List<CustomerSummaryDto>>> Get([FromQuery] string? search)
    {
        return Ok(await _adminBookings.GetCustomersAsync(search));
    }

    [HttpGet("{id}")]
    public async Task<ActionResult<CustomerDetailDto>> GetDetail(string id)
    {
        var detail = await _adminBookings.GetCustomerDetailAsync(id);
        return detail is null ? NotFound(new ApiError { Message = "Không tìm thấy khách hàng." }) : Ok(detail);
    }

    [HttpPost("{id}/toggle-status")]
    public async Task<IActionResult> ToggleStatus(string id)
    {
        var (ok, error, status) = await _adminBookings.ToggleCustomerStatusAsync(id);
        return ok ? NoContent() : StatusCode(status, error);
    }
}
