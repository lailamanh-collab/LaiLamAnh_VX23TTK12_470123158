using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using PhoneRepairBooking.Api.Data;
using PhoneRepairBooking.Api.Domain;
using PhoneRepairBooking.Api.DTOs;

namespace PhoneRepairBooking.Api.Services;

public class ReportService
{
    private readonly AppDbContext _db;
    private readonly UserManager<ApplicationUser> _users;

    public ReportService(AppDbContext db, UserManager<ApplicationUser> users)
    {
        _db = db;
        _users = users;
    }

    public async Task<AdminDashboardDto> GetDashboardAsync()
    {
        var today = DateOnly.FromDateTime(DateTime.UtcNow);

        // 1. STATISTIC CARDS (45.2)
        var bookingsToday = await _db.Bookings.CountAsync(b => b.AppointmentDate == today && b.Status != BookingStatus.Cancelled);
        var pendingBookings = await _db.Bookings.CountAsync(b => b.Status == BookingStatus.Pending);
        var confirmedBookings = await _db.Bookings.CountAsync(b => b.Status == BookingStatus.Confirmed);
        var repairingBookings = await _db.Bookings.CountAsync(b => b.Status == BookingStatus.Repairing);
        var completedToday = await _db.Bookings.CountAsync(b => b.Status == BookingStatus.Completed && b.CompletedAt.HasValue && DateOnly.FromDateTime(b.CompletedAt.Value) == today);
        var completedAllTime = await _db.Bookings.CountAsync(b => b.Status == BookingStatus.Completed);
        var totalRepairValue = await _db.Bookings.Where(b => b.Status == BookingStatus.Completed).SumAsync(b => b.ActualCost ?? b.EstimatedTotal);

        var customers = await _users.GetUsersInRoleAsync(AppRoles.Customer);
        var totalCustomers = customers.Count;
        var totalTechnicians = await _db.Technicians.CountAsync(t => t.IsActive);

        var stats = new StatCardsDto(
            bookingsToday,
            pendingBookings,
            confirmedBookings,
            repairingBookings,
            completedToday,
            totalCustomers,
            totalTechnicians,
            totalRepairValue,
            completedAllTime);

        // 2. CHART: BOOKINGS BY DATE (Past 7 days)
        var dateList = new List<ChartDateItem>();
        for (int i = 6; i >= 0; i--)
        {
            var d = today.AddDays(-i);
            var dateStr = d.ToString("yyyy-MM-dd");
            var dayBookings = await _db.Bookings.Where(b => b.AppointmentDate == d && b.Status != BookingStatus.Cancelled).ToListAsync();
            var count = dayBookings.Count;
            var rev = dayBookings.Where(b => b.Status == BookingStatus.Completed).Sum(b => b.ActualCost ?? b.EstimatedTotal);
            dateList.Add(new ChartDateItem(dateStr, count, rev));
        }

        // 3. CHART: BOOKINGS BY STATUS
        var statusLabels = new Dictionary<BookingStatus, string>
        {
            { BookingStatus.Pending, "Chờ xác nhận" },
            { BookingStatus.Confirmed, "Đã xác nhận" },
            { BookingStatus.Received, "Đã nhận máy" },
            { BookingStatus.Inspecting, "Đang kiểm tra" },
            { BookingStatus.Repairing, "Đang sửa chữa" },
            { BookingStatus.Completed, "Đã hoàn thành" },
            { BookingStatus.Cancelled, "Đã hủy" }
        };

        var statusGroups = await _db.Bookings
            .GroupBy(b => b.Status)
            .Select(g => new { Status = g.Key, Count = g.Count() })
            .ToListAsync();

        var statusList = Enum.GetValues<BookingStatus>().Select(s =>
        {
            var matched = statusGroups.FirstOrDefault(g => g.Status == s);
            return new ChartStatusItem(s.ToString(), statusLabels[s], matched?.Count ?? 0);
        }).ToList();

        // 4. CHART: POPULAR SERVICES
        var serviceRaw = await _db.BookingServiceLines
            .Select(s => new { s.ServiceName, s.UnitPrice })
            .ToListAsync();

        var popularServices = serviceRaw
            .GroupBy(s => s.ServiceName)
            .Select(g => new ChartServiceItem(g.Key, g.Count(), g.Sum(x => x.UnitPrice ?? 0)))
            .OrderByDescending(s => s.Count)
            .Take(6)
            .ToList();

        // 5. CHART: REPAIRED BRANDS
        var brandsRaw = await _db.Bookings
            .Where(b => b.Status != BookingStatus.Cancelled)
            .Select(b => new
            {
                BrandName = b.PhoneModel.Brand.Name,
                b.Status,
                Revenue = b.ActualCost ?? b.EstimatedTotal
            })
            .ToListAsync();

        var brands = brandsRaw
            .GroupBy(b => b.BrandName)
            .Select(g => new ChartBrandItem(g.Key, g.Count(), g.Where(b => b.Status == BookingStatus.Completed).Sum(b => b.Revenue)))
            .OrderByDescending(b => b.Count)
            .ToList();

        // 6. CHART: REPAIRED MODELS
        var modelsRaw = await _db.Bookings
            .Where(b => b.Status != BookingStatus.Cancelled)
            .Select(b => new
            {
                ModelName = b.PhoneModel.Name,
                BrandName = b.PhoneModel.Brand.Name
            })
            .ToListAsync();

        var models = modelsRaw
            .GroupBy(b => new { b.ModelName, b.BrandName })
            .Select(g => new ChartModelItem(g.Key.ModelName, g.Key.BrandName, g.Count()))
            .OrderByDescending(m => m.Count)
            .Take(6)
            .ToList();

        // 7. CHART: BOOKINGS BY BRANCH
        var branchesRaw = await _db.Bookings
            .Where(b => b.Status != BookingStatus.Cancelled)
            .Select(b => new
            {
                BranchName = b.Branch.Name,
                b.Status,
                Revenue = b.ActualCost ?? b.EstimatedTotal
            })
            .ToListAsync();

        var branches = branchesRaw
            .GroupBy(b => b.BranchName)
            .Select(g => new ChartBranchItem(g.Key, g.Count(), g.Where(b => b.Status == BookingStatus.Completed).Sum(b => b.Revenue)))
            .OrderByDescending(b => b.Count)
            .ToList();

        // 8. CHART: REVENUE BY MONTH (Past 6 months)
        var monthsList = new List<ChartMonthItem>();
        var nowUtc = DateTime.UtcNow;
        for (int i = 5; i >= 0; i--)
        {
            var mDate = nowUtc.AddMonths(-i);
            var year = mDate.Year;
            var month = mDate.Month;
            var label = $"{month:00}/{year}";

            var mBookings = await _db.Bookings
                .Where(b => b.CreatedAt.Year == year && b.CreatedAt.Month == month)
                .ToListAsync();

            var count = mBookings.Count;
            var rev = mBookings.Where(b => b.Status == BookingStatus.Completed).Sum(b => b.ActualCost ?? b.EstimatedTotal);
            monthsList.Add(new ChartMonthItem(label, rev, count));
        }

        return new AdminDashboardDto(
            stats,
            dateList,
            statusList,
            popularServices,
            brands,
            models,
            branches,
            monthsList);
    }

    public async Task<ReportResultDto> GetReportDataAsync(ReportFilterRequest filter)
    {
        var query = _db.Bookings
            .AsNoTracking()
            .Include(b => b.Customer)
            .Include(b => b.PhoneModel).ThenInclude(m => m.Brand)
            .Include(b => b.Branch)
            .Include(b => b.Technician).ThenInclude(t => t!.User)
            .Include(b => b.Services)
            .Include(b => b.Review)
            .AsQueryable();

        if (!string.IsNullOrWhiteSpace(filter.FromDate) && DateOnly.TryParse(filter.FromDate, out var fromDate))
        {
            query = query.Where(b => b.AppointmentDate >= fromDate);
        }

        if (!string.IsNullOrWhiteSpace(filter.ToDate) && DateOnly.TryParse(filter.ToDate, out var toDate))
        {
            query = query.Where(b => b.AppointmentDate <= toDate);
        }

        if (filter.BranchId.HasValue)
        {
            query = query.Where(b => b.BranchId == filter.BranchId.Value);
        }

        if (filter.TechnicianId.HasValue)
        {
            query = query.Where(b => b.TechnicianId == filter.TechnicianId.Value);
        }

        if (filter.RepairServiceId.HasValue)
        {
            query = query.Where(b => b.Services.Any(s => s.RepairServiceId == filter.RepairServiceId.Value));
        }

        if (filter.BrandId.HasValue)
        {
            query = query.Where(b => b.PhoneModel.BrandId == filter.BrandId.Value);
        }

        if (filter.PhoneModelId.HasValue)
        {
            query = query.Where(b => b.PhoneModelId == filter.PhoneModelId.Value);
        }

        if (!string.IsNullOrWhiteSpace(filter.Status) && Enum.TryParse<BookingStatus>(filter.Status, true, out var parsedStatus))
        {
            query = query.Where(b => b.Status == parsedStatus);
        }

        var list = await query.ToListAsync();

        // Summary KPI
        var total = list.Count;
        var completed = list.Count(b => b.Status == BookingStatus.Completed);
        var cancelled = list.Count(b => b.Status == BookingStatus.Cancelled);
        var revenue = list.Where(b => b.Status == BookingStatus.Completed).Sum(b => b.ActualCost ?? b.EstimatedTotal);
        var avgValue = completed > 0 ? Math.Round(revenue / completed, 0) : 0;
        var summary = new ReportSummaryDto(total, completed, cancelled, revenue, avgValue);

        // Technician Performance
        var techPerf = list
            .Where(b => b.Technician != null)
            .GroupBy(b => new { b.TechnicianId, TechName = b.Technician!.User.FullName, BranchName = b.Branch.Name })
            .Select(g =>
            {
                var assigned = g.Count();
                var done = g.Count(b => b.Status == BookingStatus.Completed);
                var techRev = g.Where(b => b.Status == BookingStatus.Completed).Sum(b => b.ActualCost ?? b.EstimatedTotal);
                var reviews = g.Where(b => b.Review != null).Select(b => b.Review!).ToList();
                var rating = reviews.Count > 0 ? Math.Round(reviews.Average(r => r.Rating), 1) : 5.0;
                return new TechnicianPerformanceItem(g.Key.TechnicianId!.Value, g.Key.TechName, g.Key.BranchName, assigned, done, techRev, rating, reviews.Count);
            })
            .OrderByDescending(t => t.CompletedJobs)
            .ToList();

        // Branch Performance
        var branchPerf = list
            .GroupBy(b => new { b.BranchId, b.Branch.Name })
            .Select(g =>
            {
                var bTotal = g.Count();
                var bDone = g.Count(b => b.Status == BookingStatus.Completed);
                var bRev = g.Where(b => b.Status == BookingStatus.Completed).Sum(b => b.ActualCost ?? b.EstimatedTotal);
                return new BranchPerformanceItem(g.Key.BranchId, g.Key.Name, bTotal, bDone, bRev);
            })
            .OrderByDescending(b => b.Revenue)
            .ToList();

        // Service Performance
        var servicePerf = list
            .SelectMany(b => b.Services.Select(s => new { s.RepairServiceId, s.ServiceName, s.UnitPrice, IsDone = b.Status == BookingStatus.Completed }))
            .GroupBy(s => new { s.RepairServiceId, s.ServiceName })
            .Select(g => new ServicePerformanceItem(
                g.Key.RepairServiceId,
                g.Key.ServiceName,
                g.Count(),
                g.Where(s => s.IsDone).Sum(s => s.UnitPrice ?? 0)))
            .OrderByDescending(s => s.Count)
            .ToList();

        // Brand Performance
        var brandPerf = list
            .GroupBy(b => b.PhoneModel.Brand.Name)
            .Select(g => new BrandPerformanceItem(
                g.Key,
                g.Count(),
                g.Where(b => b.Status == BookingStatus.Completed).Sum(b => b.ActualCost ?? b.EstimatedTotal)))
            .OrderByDescending(b => b.Count)
            .ToList();

        return new ReportResultDto(summary, techPerf, branchPerf, servicePerf, brandPerf);
    }
}
