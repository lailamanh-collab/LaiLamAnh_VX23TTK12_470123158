using Microsoft.EntityFrameworkCore;
using PhoneRepairBooking.Api.Data;
using PhoneRepairBooking.Api.Domain;
using PhoneRepairBooking.Api.DTOs;

namespace PhoneRepairBooking.Api.Services;

public class TechnicianJobService
{
    private readonly AppDbContext _db;

    public TechnicianJobService(AppDbContext db)
    {
        _db = db;
    }

    private async Task<Technician?> GetTechnicianByUserIdAsync(string userId)
    {
        return await _db.Technicians
            .Include(t => t.Branch)
            .Include(t => t.User)
            .FirstOrDefaultAsync(t => t.UserId == userId && t.IsActive);
    }

    public async Task<(bool Ok, ApiError? Error, int Status, TechnicianDashboardDto? Data)> GetDashboardAsync(string userId)
    {
        var tech = await GetTechnicianByUserIdAsync(userId);
        if (tech is null)
        {
            return (false, new ApiError { Message = "Không tìm thấy hồ sơ kỹ thuật viên hợp lệ của tài khoản này." }, 403, null);
        }

        var today = DateOnly.FromDateTime(DateTime.UtcNow);
        var myJobs = _db.Bookings.Where(b => b.TechnicianId == tech.Id);

        var jobsToday = await myJobs.CountAsync(b => b.AppointmentDate == today && b.Status != BookingStatus.Cancelled);
        var confirmedJobs = await myJobs.CountAsync(b => b.Status == BookingStatus.Confirmed);
        var receivedJobs = await myJobs.CountAsync(b => b.Status == BookingStatus.Received);
        var inspectingJobs = await myJobs.CountAsync(b => b.Status == BookingStatus.Inspecting);
        var repairingJobs = await myJobs.CountAsync(b => b.Status == BookingStatus.Repairing);
        var completedJobs = await myJobs.CountAsync(b => b.Status == BookingStatus.Completed);
        var completedTodayJobs = await myJobs.CountAsync(b => b.Status == BookingStatus.Completed && b.CompletedAt.HasValue && DateOnly.FromDateTime(b.CompletedAt.Value) == today);
        var totalActive = confirmedJobs + receivedJobs + inspectingJobs + repairingJobs;

        var data = new TechnicianDashboardDto(
            tech.Id,
            tech.User.FullName,
            tech.BranchId,
            tech.Branch.Name,
            jobsToday,
            confirmedJobs,
            receivedJobs,
            inspectingJobs,
            repairingJobs,
            completedJobs,
            completedTodayJobs,
            totalActive);

        return (true, null, 200, data);
    }

    public async Task<(bool Ok, ApiError? Error, int Status, List<TechnicianJobSummaryDto>? Data)> GetJobsAsync(string userId, TechnicianJobFilterRequest filter)
    {
        var tech = await GetTechnicianByUserIdAsync(userId);
        if (tech is null)
        {
            return (false, new ApiError { Message = "Không tìm thấy hồ sơ kỹ thuật viên hợp lệ của tài khoản này." }, 403, null);
        }

        var query = _db.Bookings
            .AsNoTracking()
            .Include(b => b.Customer)
            .Include(b => b.PhoneModel).ThenInclude(m => m.Brand)
            .Include(b => b.Branch)
            .Where(b => b.TechnicianId == tech.Id);

        var statusKey = filter.Status?.Trim();
        var isCompletedTab = false;

        if (!string.IsNullOrWhiteSpace(statusKey))
        {
            if (statusKey.Equals("Today", StringComparison.OrdinalIgnoreCase))
            {
                var today = DateOnly.FromDateTime(DateTime.UtcNow);
                query = query.Where(b => b.AppointmentDate == today && b.Status != BookingStatus.Cancelled);
            }
            else if (statusKey.Equals("Confirmed", StringComparison.OrdinalIgnoreCase) || statusKey.Equals("NeedReceive", StringComparison.OrdinalIgnoreCase))
            {
                query = query.Where(b => b.Status == BookingStatus.Confirmed);
            }
            else if (statusKey.Equals("Received", StringComparison.OrdinalIgnoreCase))
            {
                query = query.Where(b => b.Status == BookingStatus.Received);
            }
            else if (statusKey.Equals("Inspecting", StringComparison.OrdinalIgnoreCase))
            {
                query = query.Where(b => b.Status == BookingStatus.Inspecting);
            }
            else if (statusKey.Equals("Repairing", StringComparison.OrdinalIgnoreCase))
            {
                query = query.Where(b => b.Status == BookingStatus.Repairing);
            }
            else if (statusKey.Equals("Completed", StringComparison.OrdinalIgnoreCase))
            {
                isCompletedTab = true;
                query = query.Where(b => b.Status == BookingStatus.Completed);
            }
            else if (statusKey.Equals("Active", StringComparison.OrdinalIgnoreCase) || statusKey.Equals("InProgress", StringComparison.OrdinalIgnoreCase))
            {
                query = query.Where(b => b.Status == BookingStatus.Confirmed || b.Status == BookingStatus.Received || b.Status == BookingStatus.Inspecting || b.Status == BookingStatus.Repairing);
            }
        }

        if (!string.IsNullOrWhiteSpace(filter.Search))
        {
            var q = filter.Search.Trim().ToLower();
            query = query.Where(b =>
                b.BookingCode.ToLower().Contains(q) ||
                b.Customer.FullName.ToLower().Contains(q) ||
                (b.Customer.PhoneNumber != null && b.Customer.PhoneNumber.ToLower().Contains(q)) ||
                b.PhoneModel.Name.ToLower().Contains(q) ||
                b.PhoneModel.Brand.Name.ToLower().Contains(q));
        }

        IOrderedQueryable<Booking> ordered;
        if (isCompletedTab)
        {
            ordered = query.OrderByDescending(b => b.CompletedAt ?? b.CreatedAt);
        }
        else
        {
            ordered = query.OrderBy(b => b.Status == BookingStatus.Completed ? 1 : 0)
                .ThenBy(b => b.AppointmentDate)
                .ThenBy(b => b.SlotStart);
        }

        var rows = await ordered.ToListAsync();
        var list = rows.Select(ToSummaryDto).ToList();
        return (true, null, 200, list);
    }

    public async Task<(bool Ok, ApiError? Error, int Status, TechnicianJobDetailDto? Data)> GetJobDetailAsync(string userId, int id)
    {
        var tech = await GetTechnicianByUserIdAsync(userId);
        if (tech is null)
        {
            return (false, new ApiError { Message = "Không tìm thấy hồ sơ kỹ thuật viên hợp lệ của tài khoản này." }, 403, null);
        }

        var booking = await DetailQuery().FirstOrDefaultAsync(b => b.Id == id);
        if (booking is null)
        {
            return (false, new ApiError { Message = "Không tìm thấy thông tin ca sửa chữa này." }, 404, null);
        }

        // RULE 09: Technician only operates on assigned jobs
        if (booking.TechnicianId != tech.Id)
        {
            return (false, new ApiError { Message = "Bạn chỉ có thể xem và xử lý các ca sửa chữa được phân công cho mình." }, 403, null);
        }

        return (true, null, 200, ToDetailDto(booking));
    }

    public async Task<(bool Ok, ApiError? Error, int Status, TechnicianJobDetailDto? Data)> ReceiveJobAsync(string userId, int id, TechnicianReceiveRequest request)
    {
        var tech = await GetTechnicianByUserIdAsync(userId);
        if (tech is null)
        {
            return (false, new ApiError { Message = "Không tìm thấy hồ sơ kỹ thuật viên hợp lệ của tài khoản này." }, 403, null);
        }

        var booking = await DetailQuery().FirstOrDefaultAsync(b => b.Id == id);
        if (booking is null)
        {
            return (false, new ApiError { Message = "Không tìm thấy ca sửa chữa này." }, 404, null);
        }

        // RULE 09
        if (booking.TechnicianId != tech.Id)
        {
            return (false, new ApiError { Message = "Bạn không có quyền tiếp nhận ca sửa chữa của kỹ thuật viên khác." }, 403, null);
        }

        // RULE 12: Transition logic
        if (booking.Status != BookingStatus.Confirmed)
        {
            return (false, new ApiError { Message = $"Chỉ có thể tiếp nhận thiết bị từ lịch hẹn đã xác nhận (Confirmed). Trạng thái hiện tại: {booking.Status}." }, 400, null);
        }

        var now = DateTime.UtcNow;
        var prevStatus = booking.Status;
        booking.Status = BookingStatus.Received;
        booking.ReceivedAt = now;

        var note = !string.IsNullOrWhiteSpace(request.ReceiveNote)
            ? request.ReceiveNote.Trim()
            : "Kỹ thuật viên đã tiếp nhận máy từ khách hàng tại cửa hàng.";

        booking.StatusHistory.Add(new BookingStatusHistory
        {
            BookingId = booking.Id,
            FromStatus = prevStatus,
            ToStatus = BookingStatus.Received,
            ChangedAt = now,
            ChangedByUserId = userId,
            Note = note
        });

        await _db.SaveChangesAsync();
        return (true, null, 200, ToDetailDto(booking));
    }

    public async Task<(bool Ok, ApiError? Error, int Status, TechnicianJobDetailDto? Data)> StartInspectionAsync(string userId, int id, TechnicianInspectRequest request)
    {
        var tech = await GetTechnicianByUserIdAsync(userId);
        if (tech is null)
        {
            return (false, new ApiError { Message = "Không tìm thấy hồ sơ kỹ thuật viên hợp lệ của tài khoản này." }, 403, null);
        }

        var booking = await DetailQuery().FirstOrDefaultAsync(b => b.Id == id);
        if (booking is null)
        {
            return (false, new ApiError { Message = "Không tìm thấy ca sửa chữa này." }, 404, null);
        }

        // RULE 09
        if (booking.TechnicianId != tech.Id)
        {
            return (false, new ApiError { Message = "Bạn không có quyền thao tác trên ca sửa chữa của kỹ thuật viên khác." }, 403, null);
        }

        // RULE 12
        if (booking.Status != BookingStatus.Received)
        {
            return (false, new ApiError { Message = $"Chỉ có thể bắt đầu kiểm tra sau khi máy đã được tiếp nhận (Received). Trạng thái hiện tại: {booking.Status}." }, 400, null);
        }

        var now = DateTime.UtcNow;
        var prevStatus = booking.Status;
        booking.Status = BookingStatus.Inspecting;
        booking.InspectionStartedAt = now;

        if (!string.IsNullOrWhiteSpace(request.Diagnosis))
        {
            booking.Diagnosis = request.Diagnosis.Trim();
        }

        if (!string.IsNullOrWhiteSpace(request.RepairNotes))
        {
            booking.RepairNotes = request.RepairNotes.Trim();
        }

        if (request.ActualCost.HasValue)
        {
            booking.ActualCost = Math.Round(request.ActualCost.Value, 0);
        }

        var note = !string.IsNullOrWhiteSpace(request.Diagnosis)
            ? $"Bắt đầu kiểm tra: {request.Diagnosis.Trim()}"
            : "Kỹ thuật viên bắt đầu kiểm tra tổng quát tình trạng thiết bị.";

        booking.StatusHistory.Add(new BookingStatusHistory
        {
            BookingId = booking.Id,
            FromStatus = prevStatus,
            ToStatus = BookingStatus.Inspecting,
            ChangedAt = now,
            ChangedByUserId = userId,
            Note = note
        });

        await _db.SaveChangesAsync();
        return (true, null, 200, ToDetailDto(booking));
    }

    public async Task<(bool Ok, ApiError? Error, int Status, TechnicianJobDetailDto? Data)> StartRepairAsync(string userId, int id, TechnicianStartRepairRequest request)
    {
        var tech = await GetTechnicianByUserIdAsync(userId);
        if (tech is null)
        {
            return (false, new ApiError { Message = "Không tìm thấy hồ sơ kỹ thuật viên hợp lệ của tài khoản này." }, 403, null);
        }

        var booking = await DetailQuery().FirstOrDefaultAsync(b => b.Id == id);
        if (booking is null)
        {
            return (false, new ApiError { Message = "Không tìm thấy ca sửa chữa này." }, 404, null);
        }

        // RULE 09
        if (booking.TechnicianId != tech.Id)
        {
            return (false, new ApiError { Message = "Bạn không có quyền thao tác trên ca sửa chữa của kỹ thuật viên khác." }, 403, null);
        }

        // RULE 12
        if (booking.Status != BookingStatus.Inspecting)
        {
            return (false, new ApiError { Message = $"Chỉ có thể bắt đầu sửa chữa khi máy đang trong trạng thái kiểm tra (Inspecting). Trạng thái hiện tại: {booking.Status}." }, 400, null);
        }

        var now = DateTime.UtcNow;
        var prevStatus = booking.Status;
        booking.Status = BookingStatus.Repairing;
        booking.RepairStartedAt = now;

        if (!string.IsNullOrWhiteSpace(request.RepairSolution))
        {
            booking.RepairSolution = request.RepairSolution.Trim();
        }

        if (!string.IsNullOrWhiteSpace(request.RepairNotes))
        {
            booking.RepairNotes = request.RepairNotes.Trim();
        }

        if (request.ActualCost.HasValue)
        {
            booking.ActualCost = Math.Round(request.ActualCost.Value, 0);
        }

        var note = !string.IsNullOrWhiteSpace(request.RepairSolution)
            ? $"Bắt đầu sửa chữa: {request.RepairSolution.Trim()}"
            : "Bắt đầu tiến hành thao tác kỹ thuật / thay thế linh kiện.";

        booking.StatusHistory.Add(new BookingStatusHistory
        {
            BookingId = booking.Id,
            FromStatus = prevStatus,
            ToStatus = BookingStatus.Repairing,
            ChangedAt = now,
            ChangedByUserId = userId,
            Note = note
        });

        await _db.SaveChangesAsync();
        return (true, null, 200, ToDetailDto(booking));
    }

    public async Task<(bool Ok, ApiError? Error, int Status, TechnicianJobDetailDto? Data)> UpdateRepairInfoAsync(string userId, int id, TechnicianUpdateRepairRequest request)
    {
        var tech = await GetTechnicianByUserIdAsync(userId);
        if (tech is null)
        {
            return (false, new ApiError { Message = "Không tìm thấy hồ sơ kỹ thuật viên hợp lệ của tài khoản này." }, 403, null);
        }

        var booking = await DetailQuery().FirstOrDefaultAsync(b => b.Id == id);
        if (booking is null)
        {
            return (false, new ApiError { Message = "Không tìm thấy ca sửa chữa này." }, 404, null);
        }

        // RULE 09
        if (booking.TechnicianId != tech.Id)
        {
            return (false, new ApiError { Message = "Bạn không có quyền thao tác trên ca sửa chữa của kỹ thuật viên khác." }, 403, null);
        }

        // Only allow updating during inspecting or repairing
        if (booking.Status != BookingStatus.Inspecting && booking.Status != BookingStatus.Repairing)
        {
            return (false, new ApiError { Message = "Chỉ có thể cập nhật thông tin kỹ thuật khi máy đang được kiểm tra hoặc đang sửa chữa." }, 400, null);
        }

        if (request.Diagnosis != null)
        {
            booking.Diagnosis = string.IsNullOrWhiteSpace(request.Diagnosis) ? null : request.Diagnosis.Trim();
        }

        if (request.RepairSolution != null)
        {
            booking.RepairSolution = string.IsNullOrWhiteSpace(request.RepairSolution) ? null : request.RepairSolution.Trim();
        }

        if (request.RepairNotes != null)
        {
            booking.RepairNotes = string.IsNullOrWhiteSpace(request.RepairNotes) ? null : request.RepairNotes.Trim();
        }

        if (request.ActualCost.HasValue)
        {
            booking.ActualCost = Math.Round(request.ActualCost.Value, 0);
        }

        if (!string.IsNullOrWhiteSpace(request.ProgressNote))
        {
            booking.StatusHistory.Add(new BookingStatusHistory
            {
                BookingId = booking.Id,
                FromStatus = booking.Status,
                ToStatus = booking.Status,
                ChangedAt = DateTime.UtcNow,
                ChangedByUserId = userId,
                Note = $"Cập nhật tiến độ: {request.ProgressNote.Trim()}"
            });
        }

        await _db.SaveChangesAsync();
        return (true, null, 200, ToDetailDto(booking));
    }

    public async Task<(bool Ok, ApiError? Error, int Status, TechnicianJobDetailDto? Data)> CompleteRepairAsync(string userId, int id, TechnicianCompleteRepairRequest request)
    {
        var tech = await GetTechnicianByUserIdAsync(userId);
        if (tech is null)
        {
            return (false, new ApiError { Message = "Không tìm thấy hồ sơ kỹ thuật viên hợp lệ của tài khoản này." }, 403, null);
        }

        var booking = await DetailQuery().FirstOrDefaultAsync(b => b.Id == id);
        if (booking is null)
        {
            return (false, new ApiError { Message = "Không tìm thấy ca sửa chữa này." }, 404, null);
        }

        // RULE 09
        if (booking.TechnicianId != tech.Id)
        {
            return (false, new ApiError { Message = "Bạn không có quyền thao tác trên ca sửa chữa của kỹ thuật viên khác." }, 403, null);
        }

        // RULE 12, RULE 13
        if (booking.Status != BookingStatus.Repairing)
        {
            return (false, new ApiError { Message = $"Chỉ có thể hoàn thành từ trạng thái đang sửa (Repairing). Trạng thái hiện tại: {booking.Status}." }, 400, null);
        }

        var now = DateTime.UtcNow;
        var prevStatus = booking.Status;
        booking.Status = BookingStatus.Completed;
        booking.CompletedAt = now;

        if (!string.IsNullOrWhiteSpace(request.RepairResult))
        {
            var res = request.RepairResult.Trim();
            booking.RepairSolution = !string.IsNullOrWhiteSpace(booking.RepairSolution)
                ? $"{booking.RepairSolution} (Kết quả: {res})"
                : res;
        }

        if (!string.IsNullOrWhiteSpace(request.RepairNotes))
        {
            booking.RepairNotes = request.RepairNotes.Trim();
        }

        if (request.ActualCost.HasValue)
        {
            booking.ActualCost = Math.Round(request.ActualCost.Value, 0);
        }
        else if (!booking.ActualCost.HasValue && booking.EstimatedTotal > 0)
        {
            // Default to estimated total if no custom actual cost was set
            booking.ActualCost = booking.EstimatedTotal;
        }

        var note = !string.IsNullOrWhiteSpace(request.RepairResult)
            ? $"Hoàn thành sửa chữa: {request.RepairResult.Trim()}"
            : "Kỹ thuật viên đã hoàn thành sửa chữa máy và kiểm tra lại toàn diện chức năng.";

        booking.StatusHistory.Add(new BookingStatusHistory
        {
            BookingId = booking.Id,
            FromStatus = prevStatus,
            ToStatus = BookingStatus.Completed,
            ChangedAt = now,
            ChangedByUserId = userId,
            Note = note
        });

        await _db.SaveChangesAsync();
        return (true, null, 200, ToDetailDto(booking));
    }

    private IQueryable<Booking> DetailQuery()
    {
        return _db.Bookings
            .Include(b => b.Customer)
            .Include(b => b.PhoneModel).ThenInclude(m => m.Brand)
            .Include(b => b.Branch)
            .Include(b => b.Services)
            .Include(b => b.StatusHistory);
    }

    private static TechnicianJobSummaryDto ToSummaryDto(Booking b)
    {
        return new TechnicianJobSummaryDto(
            b.Id,
            b.BookingCode,
            b.Customer.FullName,
            b.Customer.PhoneNumber,
            b.PhoneModel.Brand.Name,
            b.PhoneModel.Name,
            b.Branch.Name,
            b.AppointmentDate,
            b.SlotStart.ToString("HH:mm"),
            b.SlotEnd.ToString("HH:mm"),
            b.Status,
            b.ProblemDescription,
            b.EstimatedTotal,
            b.ActualCost,
            b.CreatedAt,
            b.ReceivedAt,
            b.InspectionStartedAt,
            b.RepairStartedAt,
            b.CompletedAt);
    }

    private static TechnicianJobDetailDto ToDetailDto(Booking b)
    {
        return new TechnicianJobDetailDto(
            b.Id,
            b.BookingCode,
            b.CustomerId,
            b.Customer.FullName,
            b.Customer.Email ?? string.Empty,
            b.Customer.PhoneNumber,
            b.PhoneModelId,
            b.PhoneModel.Brand.Name,
            b.PhoneModel.Name,
            b.BranchId,
            b.Branch.Name,
            b.Branch.Address,
            b.AppointmentDate,
            b.SlotStart.ToString("HH:mm"),
            b.SlotEnd.ToString("HH:mm"),
            b.Status,
            b.ProblemDescription,
            b.EstimatedTotal,
            b.ActualCost,
            b.Diagnosis,
            b.RepairNotes,
            b.RepairSolution,
            b.CreatedAt,
            b.ReceivedAt,
            b.InspectionStartedAt,
            b.RepairStartedAt,
            b.CompletedAt,
            b.Services.Select(s => new BookingLineDto(s.RepairServiceId, s.ServiceName, s.PricingType, s.UnitPrice)).ToList(),
            b.StatusHistory.OrderBy(h => h.ChangedAt).Select(h => new BookingHistoryDto(h.FromStatus, h.ToStatus, h.Note, h.ChangedAt)).ToList());
    }
}
