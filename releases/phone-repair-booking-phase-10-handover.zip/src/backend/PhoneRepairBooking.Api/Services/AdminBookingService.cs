using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using PhoneRepairBooking.Api.Data;
using PhoneRepairBooking.Api.Domain;
using PhoneRepairBooking.Api.DTOs;

namespace PhoneRepairBooking.Api.Services;

public class AdminBookingService
{
    private readonly AppDbContext _db;
    private readonly UserManager<ApplicationUser> _users;

    public AdminBookingService(AppDbContext db, UserManager<ApplicationUser> users)
    {
        _db = db;
        _users = users;
    }

    public async Task<List<AdminBookingDto>> GetBookingsAsync(AdminBookingFilterRequest request)
    {
        var query = AdminQuery();

        if (!string.IsNullOrWhiteSpace(request.Search))
        {
            var q = request.Search.Trim().ToLower();
            query = query.Where(item =>
                item.BookingCode.ToLower().Contains(q) ||
                item.Customer.FullName.ToLower().Contains(q) ||
                (item.Customer.PhoneNumber != null && item.Customer.PhoneNumber.ToLower().Contains(q)) ||
                (item.Customer.Email != null && item.Customer.Email.ToLower().Contains(q)) ||
                item.PhoneModel.Name.ToLower().Contains(q) ||
                item.PhoneModel.Brand.Name.ToLower().Contains(q) ||
                item.Branch.Name.ToLower().Contains(q) ||
                (item.Technician != null && item.Technician.User.FullName.ToLower().Contains(q)) ||
                item.Services.Any(s => s.ServiceName.ToLower().Contains(q)));
        }

        if (!string.IsNullOrWhiteSpace(request.Status) && Enum.TryParse<BookingStatus>(request.Status, true, out var parsedStatus))
        {
            query = query.Where(item => item.Status == parsedStatus);
        }

        if (request.BranchId.HasValue)
        {
            query = query.Where(item => item.BranchId == request.BranchId.Value);
        }

        if (request.TechnicianId.HasValue)
        {
            query = query.Where(item => item.TechnicianId == request.TechnicianId.Value);
        }

        if (!string.IsNullOrWhiteSpace(request.Date) && DateOnly.TryParse(request.Date, out var date))
        {
            query = query.Where(item => item.AppointmentDate == date);
        }

        if (!string.IsNullOrWhiteSpace(request.FromDate) && DateOnly.TryParse(request.FromDate, out var fromDate))
        {
            query = query.Where(item => item.AppointmentDate >= fromDate);
        }

        if (!string.IsNullOrWhiteSpace(request.ToDate) && DateOnly.TryParse(request.ToDate, out var toDate))
        {
            query = query.Where(item => item.AppointmentDate <= toDate);
        }

        var rows = await query.OrderByDescending(item => item.CreatedAt).ToListAsync();
        return rows.Select(ToAdminDto).ToList();
    }

    public async Task<AdminBookingDto?> GetBookingDetailAsync(int id)
    {
        var booking = await AdminQuery().FirstOrDefaultAsync(item => item.Id == id);
        return booking is null ? null : ToAdminDto(booking);
    }

    public async Task<(bool Ok, ApiError? Error, int Status)> ConfirmBookingAsync(int id, string adminUserId, string? note)
    {
        var booking = await _db.Bookings
            .Include(item => item.StatusHistory)
            .FirstOrDefaultAsync(item => item.Id == id);

        if (booking is null)
        {
            return (false, new ApiError { Message = "Không tìm thấy lịch hẹn." }, StatusCodes.Status404NotFound);
        }

        if (booking.Status != BookingStatus.Pending)
        {
            return (false, new ApiError { Message = $"Không thể xác nhận lịch đang ở trạng thái {booking.Status}." }, StatusCodes.Status400BadRequest);
        }

        var from = booking.Status;
        booking.Status = BookingStatus.Confirmed;
        _db.BookingStatusHistories.Add(new BookingStatusHistory
        {
            BookingId = booking.Id,
            FromStatus = from,
            ToStatus = BookingStatus.Confirmed,
            Note = string.IsNullOrWhiteSpace(note) ? "Admin xác nhận lịch hẹn." : note.Trim(),
            ChangedByUserId = adminUserId,
            ChangedAt = DateTime.UtcNow
        });

        await _db.SaveChangesAsync();
        return (true, null, StatusCodes.Status200OK);
    }

    public async Task<(bool Ok, ApiError? Error, int Status)> AssignTechnicianAsync(int id, int technicianId, string adminUserId, string? note)
    {
        var booking = await _db.Bookings
            .Include(item => item.StatusHistory)
            .FirstOrDefaultAsync(item => item.Id == id);

        if (booking is null)
        {
            return (false, new ApiError { Message = "Không tìm thấy lịch hẹn." }, StatusCodes.Status404NotFound);
        }

        if (booking.Status == BookingStatus.Completed || booking.Status == BookingStatus.Cancelled)
        {
            return (false, new ApiError { Message = "Không thể phân công kỹ thuật viên cho lịch đã hoàn thành hoặc đã hủy." }, StatusCodes.Status400BadRequest);
        }

        var technician = await _db.Technicians
            .Include(item => item.User)
            .FirstOrDefaultAsync(item => item.Id == technicianId && item.IsActive);

        if (technician is null)
        {
            return (false, new ApiError { Message = "Kỹ thuật viên không tồn tại hoặc đã bị vô hiệu hóa." }, StatusCodes.Status400BadRequest);
        }

        if (technician.BranchId != booking.BranchId)
        {
            return (false, new ApiError { Message = "Kỹ thuật viên không thuộc chi nhánh của lịch hẹn này." }, StatusCodes.Status400BadRequest);
        }

        var isReassign = booking.TechnicianId.HasValue && booking.TechnicianId.Value != technicianId;
        booking.TechnicianId = technicianId;

        var defaultNote = isReassign
            ? $"Admin đổi phân công sang kỹ thuật viên {technician.User.FullName}."
            : $"Admin phân công kỹ thuật viên {technician.User.FullName}.";

        _db.BookingStatusHistories.Add(new BookingStatusHistory
        {
            BookingId = booking.Id,
            FromStatus = booking.Status,
            ToStatus = booking.Status,
            Note = string.IsNullOrWhiteSpace(note) ? defaultNote : note.Trim(),
            ChangedByUserId = adminUserId,
            ChangedAt = DateTime.UtcNow
        });

        await _db.SaveChangesAsync();
        return (true, null, StatusCodes.Status200OK);
    }

    public async Task<(bool Ok, ApiError? Error, int Status)> CancelBookingAsync(int id, string adminUserId, string? reason)
    {
        var booking = await _db.Bookings
            .Include(item => item.StatusHistory)
            .FirstOrDefaultAsync(item => item.Id == id);

        if (booking is null)
        {
            return (false, new ApiError { Message = "Không tìm thấy lịch hẹn." }, StatusCodes.Status404NotFound);
        }

        if (booking.Status == BookingStatus.Completed || booking.Status == BookingStatus.Cancelled)
        {
            return (false, new ApiError { Message = "Lịch đã hoàn thành hoặc đã hủy trước đó." }, StatusCodes.Status400BadRequest);
        }

        var from = booking.Status;
        booking.Status = BookingStatus.Cancelled;
        booking.CancelledAt = DateTime.UtcNow;
        booking.CancelReason = string.IsNullOrWhiteSpace(reason) ? "Admin hủy lịch hẹn." : reason.Trim();

        _db.BookingStatusHistories.Add(new BookingStatusHistory
        {
            BookingId = booking.Id,
            FromStatus = from,
            ToStatus = BookingStatus.Cancelled,
            Note = booking.CancelReason,
            ChangedByUserId = adminUserId,
            ChangedAt = DateTime.UtcNow
        });

        await _db.SaveChangesAsync();
        return (true, null, StatusCodes.Status200OK);
    }

    public async Task<List<CustomerSummaryDto>> GetCustomersAsync(string? search)
    {
        var customerUsers = await _users.GetUsersInRoleAsync(AppRoles.Customer);
        var customerIds = customerUsers.Select(u => u.Id).ToList();

        var bookingsPerCustomer = await _db.Bookings
            .Where(b => customerIds.Contains(b.CustomerId))
            .GroupBy(b => b.CustomerId)
            .Select(g => new
            {
                CustomerId = g.Key,
                Total = g.Count(),
                Completed = g.Count(item => item.Status == BookingStatus.Completed)
            })
            .ToDictionaryAsync(item => item.CustomerId, item => (item.Total, item.Completed));

        var result = customerUsers.Select(u =>
        {
            var stats = bookingsPerCustomer.TryGetValue(u.Id, out var val) ? val : (0, 0);
            return new CustomerSummaryDto(
                u.Id,
                u.FullName,
                u.Email ?? "",
                u.PhoneNumber,
                u.IsActive,
                u.CreatedAt,
                stats.Item1,
                stats.Item2
            );
        });

        if (!string.IsNullOrWhiteSpace(search))
        {
            var q = search.Trim().ToLower();
            result = result.Where(u =>
                u.FullName.ToLower().Contains(q) ||
                u.Email.ToLower().Contains(q) ||
                (u.PhoneNumber != null && u.PhoneNumber.Contains(q)));
        }

        return result.OrderByDescending(u => u.CreatedAt).ToList();
    }

    public async Task<CustomerDetailDto?> GetCustomerDetailAsync(string customerId)
    {
        var user = await _users.FindByIdAsync(customerId);
        if (user is null || !await _users.IsInRoleAsync(user, AppRoles.Customer))
        {
            return null;
        }

        var bookings = await _db.Bookings.AsNoTracking()
            .Include(item => item.PhoneModel).ThenInclude(item => item.Brand)
            .Include(item => item.Branch)
            .Include(item => item.Technician)!.ThenInclude(item => item!.User)
            .Where(item => item.CustomerId == customerId)
            .OrderByDescending(item => item.CreatedAt)
            .ToListAsync();

        var summaries = bookings.Select(b => new BookingSummaryDto(
            b.Id,
            b.BookingCode,
            b.PhoneModel.Brand.Name,
            b.PhoneModel.Name,
            b.Branch.Name,
            b.AppointmentDate,
            b.SlotStart.ToString("HH:mm"),
            b.Status,
            b.EstimatedTotal,
            b.ActualCost,
            b.Technician?.User.FullName
        )).ToList();

        return new CustomerDetailDto(
            user.Id,
            user.FullName,
            user.Email ?? "",
            user.PhoneNumber,
            user.IsActive,
            user.CreatedAt,
            summaries
        );
    }

    public async Task<(bool Ok, ApiError? Error, int Status)> ToggleCustomerStatusAsync(string customerId)
    {
        var user = await _users.FindByIdAsync(customerId);
        if (user is null || !await _users.IsInRoleAsync(user, AppRoles.Customer))
        {
            return (false, new ApiError { Message = "Không tìm thấy khách hàng." }, StatusCodes.Status404NotFound);
        }

        user.IsActive = !user.IsActive;
        await _users.UpdateAsync(user);
        return (true, null, StatusCodes.Status200OK);
    }

    private IQueryable<Booking> AdminQuery() => _db.Bookings.AsNoTracking()
        .Include(item => item.Customer)
        .Include(item => item.PhoneModel).ThenInclude(item => item.Brand)
        .Include(item => item.Branch)
        .Include(item => item.Technician)!.ThenInclude(item => item!.User)
        .Include(item => item.Services)
        .Include(item => item.StatusHistory);

    private static AdminBookingDto ToAdminDto(Booking booking) => new(
        booking.Id,
        booking.BookingCode,
        booking.CustomerId,
        booking.Customer.FullName,
        booking.Customer.Email ?? "",
        booking.Customer.PhoneNumber,
        booking.PhoneModelId,
        booking.PhoneModel.Brand.Name,
        booking.PhoneModel.Name,
        booking.BranchId,
        booking.Branch.Name,
        booking.AppointmentDate,
        booking.SlotStart.ToString("HH:mm"),
        booking.SlotEnd.ToString("HH:mm"),
        booking.Status,
        booking.ProblemDescription,
        booking.EstimatedTotal,
        booking.ActualCost,
        booking.TechnicianId,
        booking.Technician?.User.FullName,
        booking.Diagnosis,
        booking.RepairNotes,
        booking.RepairSolution,
        booking.CreatedAt,
        booking.Services.Select(s => new BookingLineDto(s.RepairServiceId, s.ServiceName, s.PricingType, s.UnitPrice)).ToList(),
        booking.StatusHistory.OrderBy(h => h.ChangedAt).Select(h => new BookingHistoryDto(h.FromStatus, h.ToStatus, h.Note, h.ChangedAt)).ToList()
    );
}
