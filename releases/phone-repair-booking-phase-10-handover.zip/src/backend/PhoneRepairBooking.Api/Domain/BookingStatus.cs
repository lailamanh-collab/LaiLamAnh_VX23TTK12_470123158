namespace PhoneRepairBooking.Api.Domain;

public enum BookingStatus
{
    Pending,
    Confirmed,
    Received,
    Inspecting,
    Repairing,
    Completed,
    Cancelled
}
