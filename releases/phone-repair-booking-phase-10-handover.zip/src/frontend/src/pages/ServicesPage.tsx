import { useEffect, useState } from "react"
import { Link } from "react-router-dom"
import { formatPrice, getBrands, pricingLabel, searchCatalog, type Brand, type CatalogSearchItem } from "../api/catalog"

export function ServicesPage() {
  const [query, setQuery] = useState("pin iphone")
  const [brandId, setBrandId] = useState("")
  const [pricingType, setPricingType] = useState("")
  const [brands, setBrands] = useState<Brand[]>([])
  const [items, setItems] = useState<CatalogSearchItem[]>([])
  const [message, setMessage] = useState("")

  useEffect(() => {
    getBrands().then(setBrands).catch(() => setMessage("Không tải được danh sách hãng."))
  }, [])

  useEffect(() => {
    searchCatalog(query, brandId ? Number(brandId) : undefined, pricingType || undefined)
      .then((result) => {
        setItems(result)
        setMessage(result.length === 0 ? "Không có dịch vụ phù hợp." : "")
      })
      .catch(() => setMessage("Không tìm được dịch vụ."))
  }, [query, brandId, pricingType])

  return (
    <main className="page">
      <section className="section-head">
        <h1>Dịch vụ sửa chữa</h1>
          <p className="section-intro">Giá phụ thuộc dòng máy. Dịch vụ cần kiểm tra chưa có giá chốt.</p>
          <Link className="btn" to="/dat-lich">Đặt lịch</Link>
      </section>
      <form className="toolbar" onSubmit={(event) => event.preventDefault()}>
        <label className="field">
          <span>Tìm kiếm</span>
          <input className="input" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Ví dụ: pin iphone" />
        </label>
        <label className="field">
          <span>Hãng</span>
          <select className="input" value={brandId} onChange={(event) => setBrandId(event.target.value)}>
            <option value="">Tất cả</option>
            {brands.map((brand) => <option key={brand.id} value={brand.id}>{brand.name}</option>)}
          </select>
        </label>
        <label className="field">
          <span>Kiểu giá</span>
          <select className="input" value={pricingType} onChange={(event) => setPricingType(event.target.value)}>
            <option value="">Tất cả</option>
            <option value="FixedPrice">Giá cố định</option>
            <option value="InspectionRequired">Cần kiểm tra</option>
          </select>
        </label>
      </form>
      {message ? <p className="section-intro">{message}</p> : null}
      <div className="result-list">
        {items.map((item) => (
          <article className="card" key={`${item.phoneModelId}-${item.repairServiceId}`}>
            <h2>{item.repairServiceName}</h2>
            <p>{item.brandName} {item.phoneModelName}</p>
            <p>{pricingLabel(item.pricingType)}</p>
            <strong>{formatPrice(item.pricingType, item.price)}</strong>
          </article>
        ))}
      </div>
    </main>
  )
}
