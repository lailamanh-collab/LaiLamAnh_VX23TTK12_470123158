import { useEffect, useMemo, useState } from "react"
import { Link } from "react-router-dom"
import { formatPrice, getBrands, getModels, getPrices, type Brand, type PhoneModel, type ServicePrice } from "../api/catalog"
import { getBranches, type Branch } from "../api/branches"
import { createBooking, getSlots, type BookingDetail, type Slot } from "../api/bookings"
import { ApiError } from "../api/client"
import { useAuth } from "../auth/AuthContext"

const steps = [
  "1. Chọn hãng",
  "2. Dòng máy",
  "3. Dịch vụ",
  "4. Chi nhánh",
  "5. Ngày & Giờ",
  "6. Xác nhận",
]

export function BookingWizardPage() {
  const { token, user } = useAuth()

  const [step, setStep] = useState(0)
  const [brands, setBrands] = useState<Brand[]>([])
  const [models, setModels] = useState<PhoneModel[]>([])
  const [prices, setPrices] = useState<ServicePrice[]>([])
  const [branches, setBranches] = useState<Branch[]>([])
  const [slots, setSlots] = useState<Slot[]>([])

  const [brandId, setBrandId] = useState<number | null>(null)
  const [modelId, setModelId] = useState<number | null>(null)
  const [modelSearch, setModelSearch] = useState("")
  const [serviceIds, setServiceIds] = useState<number[]>([])
  const [branchId, setBranchId] = useState<number | null>(null)
  const [date, setDate] = useState("")
  const [slot, setSlot] = useState("")
  const [problem, setProblem] = useState("")

  const [message, setMessage] = useState("")
  const [saving, setSaving] = useState(false)
  const [slotsLoading, setSlotsLoading] = useState(false)
  const [createdBooking, setCreatedBooking] = useState<BookingDetail | null>(null)
  const [copiedCode, setCopiedCode] = useState(false)

  // Load initial public catalog data
  useEffect(() => {
    getBrands().then(setBrands).catch(() => setMessage("Không tải được danh sách hãng."))
    getBranches().then(setBranches).catch(() => setMessage("Không tải được danh sách chi nhánh."))
  }, [])

  // Load models when brand changes
  useEffect(() => {
    if (!brandId) return
    getModels(brandId)
      .then(setModels)
      .catch(() => setModels([]))
  }, [brandId])

  // Load prices for selected model
  useEffect(() => {
    if (!modelId) return
    getPrices(modelId)
      .then(setPrices)
      .catch(() => setPrices([]))
  }, [modelId])

  // Load slots when branch and date are selected
  useEffect(() => {
    if (!branchId || !date) return
    setSlotsLoading(true)
    getSlots(branchId, date)
      .then((data) => {
        setSlots(data)
        if (slot && !data.some((s) => s.start === slot && !s.isFull)) {
          setSlot("")
        }
      })
      .catch(() => setSlots([]))
      .finally(() => setSlotsLoading(false))
  }, [branchId, date])

  const selectedBrand = brands.find((b) => b.id === brandId)
  const selectedModel = models.find((m) => m.id === modelId)
  const selectedBranch = branches.find((b) => b.id === branchId)
  const selectedPrices = prices.filter((item) => serviceIds.includes(item.repairServiceId))

  const estimatedTotal = selectedPrices.reduce(
    (sum, item) => sum + (item.pricingType === "FixedPrice" ? item.price ?? 0 : 0),
    0
  )
  const hasInspectionRequired = selectedPrices.some((item) => item.pricingType === "InspectionRequired")

  const minDate = useMemo(() => new Date().toISOString().slice(0, 10), [])

  const filteredModels = useMemo(() => {
    if (!modelSearch.trim()) return models
    const q = modelSearch.toLowerCase()
    return models.filter((m) => m.name.toLowerCase().includes(q))
  }, [models, modelSearch])

  function toggleService(id: number) {
    setServiceIds((current) =>
      current.includes(id) ? current.filter((item) => item !== id) : [...current, id]
    )
  }

  function handleCopyCode(code: string) {
    navigator.clipboard?.writeText(code).then(() => {
      setCopiedCode(true)
      setTimeout(() => setCopiedCode(false), 2500)
    })
  }

  async function handleConfirmBooking() {
    if (!token || !modelId || !branchId || !date || !slot) {
      setMessage("Vui lòng hoàn thành đầy đủ thông tin đặt lịch.")
      return
    }

    if (!problem.trim()) {
      setMessage("Vui lòng nhập mô tả lỗi của thiết bị.")
      return
    }

    setSaving(true)
    setMessage("")
    try {
      const created = await createBooking(token, {
        phoneModelId: modelId,
        repairServiceIds: serviceIds,
        branchId,
        appointmentDate: date,
        slotStart: slot,
        problemDescription: problem.trim(),
      })
      setCreatedBooking(created)
      setStep(6) // Success screen (Step 7)
    } catch (error) {
      if (error instanceof ApiError && error.status === 409) {
        setMessage("Khung giờ vừa chọn đã đầy. Vui lòng chọn một khung giờ khác.")
        if (branchId && date) {
          getSlots(branchId, date).then(setSlots).catch(() => undefined)
        }
        setStep(4)
      } else {
        setMessage(error instanceof ApiError ? error.message : "Không tạo được lịch hẹn.")
      }
    } finally {
      setSaving(false)
    }
  }

  return (
    <main className="page">
      <section className="section-head">
        <h1>Đặt lịch sửa chữa</h1>
        <p className="section-intro">
          Quy trình 6 bước đơn giản, báo giá rõ ràng, giữ chỗ trước tại cửa hàng.
        </p>
      </section>

      {/* Stepper Navigation (Only shown before success) */}
      {step < 6 ? (
        <nav className="stepper-nav" aria-label="Tiến trình đặt lịch">
          {steps.map((label, index) => {
            let className = "stepper-step"
            if (index === step) className += " stepper-step-active"
            else if (index < step) className += " stepper-step-done"
            return (
              <span key={label} className={className}>
                {index < step ? "✓ " : ""}
                {label}
              </span>
            )
          })}
        </nav>
      ) : null}

      {message ? <p className="form-error" role="alert">{message}</p> : null}

      {/* STEP 0: SELECT BRAND */}
      {step === 0 ? (
        <div>
          <h2>Bước 1: Chọn hãng điện thoại của bạn</h2>
          <p className="section-intro">Chọn thương hiệu thiết bị bạn cần sửa chữa:</p>
          <div className="result-list">
            {brands.map((brand) => (
              <button
                key={brand.id}
                type="button"
                className="card card-button"
                onClick={() => {
                  setBrandId(brand.id)
                  setModelId(null)
                  setServiceIds([])
                  setModelSearch("")
                  setStep(1)
                }}
              >
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <strong style={{ fontSize: "1.2rem" }}>{brand.name}</strong>
                  <span className="badge badge-confirmed">Chọn →</span>
                </div>
              </button>
            ))}
          </div>
        </div>
      ) : null}

      {/* STEP 1: SELECT PHONE MODEL */}
      {step === 1 ? (
        <div>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: "12px" }}>
            <h2>Bước 2: Chọn dòng máy {selectedBrand?.name}</h2>
            <button className="btn btn-quiet" type="button" onClick={() => setStep(0)}>
              ← Đổi hãng khác
            </button>
          </div>
          <p className="section-intro">Chọn chính xác dòng máy để hệ thống áp dụng đúng bảng giá linh kiện:</p>
          <div className="toolbar-single" style={{ marginBottom: "16px" }}>
            <input
              className="input"
              type="search"
              placeholder={`Tìm nhanh dòng máy ${selectedBrand?.name}...`}
              value={modelSearch}
              onChange={(e) => setModelSearch(e.target.value)}
            />
          </div>
          <div className="result-list">
            {filteredModels.length === 0 ? (
              <p>Không tìm thấy dòng máy phù hợp.</p>
            ) : (
              filteredModels.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  className="card card-button"
                  onClick={() => {
                    setModelId(item.id)
                    setServiceIds([])
                    setStep(2)
                  }}
                >
                  <div style={{ display: "flex", gap: "12px", alignItems: "center" }}>
                    {item.imageUrl ? (
                      <img className="model-image" src={item.imageUrl} alt={item.name} loading="lazy" />
                    ) : (
                      <div
                        style={{
                          width: "48px",
                          height: "48px",
                          borderRadius: "10px",
                          background: "#e2e8f0",
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                          fontWeight: 700,
                          color: "#475569",
                        }}
                      >
                        📱
                      </div>
                    )}
                    <div>
                      <strong style={{ fontSize: "1.1rem" }}>{item.name}</strong>
                      {item.releaseYear ? <p className="muted" style={{ margin: "2px 0 0" }}>Năm: {item.releaseYear}</p> : null}
                    </div>
                  </div>
                </button>
              ))
            )}
          </div>
        </div>
      ) : null}

      {/* STEP 2: SELECT REPAIR SERVICES */}
      {step === 2 ? (
        <div>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: "12px" }}>
            <div>
              <h2>Bước 3: Chọn dịch vụ cần sửa</h2>
              <p className="section-intro">
                Dòng máy: <strong>{selectedBrand?.name} {selectedModel?.name}</strong>. Bạn có thể chọn 1 hoặc nhiều dịch vụ cùng lúc.
              </p>
            </div>
            <button className="btn btn-quiet" type="button" onClick={() => setStep(1)}>
              ← Đổi máy
            </button>
          </div>

          <div className="result-list">
            {prices.length === 0 ? (
              <p>Hiện tại chưa có dịch vụ nào cho dòng máy này.</p>
            ) : (
              prices.map((item) => {
                const isSelected = serviceIds.includes(item.repairServiceId)
                return (
                  <button
                    key={item.id}
                    type="button"
                    className={isSelected ? "card card-button card-selected" : "card card-button"}
                    onClick={() => toggleService(item.repairServiceId)}
                    style={{ position: "relative" }}
                  >
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", width: "100%" }}>
                      <strong style={{ fontSize: "1.05rem" }}>{item.repairServiceName}</strong>
                      <span className={isSelected ? "badge badge-completed" : "badge"}>
                        {isSelected ? "✓ Đã chọn" : "+ Chọn"}
                      </span>
                    </div>
                    <div style={{ marginTop: "12px", display: "flex", justifyContent: "space-between", alignItems: "center", width: "100%" }}>
                      <span className={item.pricingType === "FixedPrice" ? "badge badge-fixed" : "badge badge-inspection"}>
                        {item.pricingType === "FixedPrice" ? "Giá cố định" : "Cần kiểm tra trước"}
                      </span>
                      <strong style={{ color: "var(--color-accent-strong)" }}>
                        {formatPrice(item.pricingType, item.price)}
                      </strong>
                    </div>
                  </button>
                )
              })
            )}
          </div>

          {/* Sticky Summary Bar */}
          <div className="card" style={{ marginTop: "24px", background: "#f8fafc", borderColor: "#cbd5e1" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: "12px" }}>
              <div>
                <strong>Đã chọn: {serviceIds.length} dịch vụ</strong>
                <p style={{ margin: "4px 0 0", color: "var(--color-muted)" }}>
                  Tạm tính: <strong style={{ color: "var(--color-accent-strong)", fontSize: "1.15rem" }}>{new Intl.NumberFormat("vi-VN").format(estimatedTotal)} đ</strong>
                  {hasInspectionRequired ? " (chưa gồm các dịch vụ cần kiểm tra)" : ""}
                </p>
              </div>
              <button
                className="btn"
                type="button"
                disabled={serviceIds.length === 0}
                onClick={() => setStep(3)}
              >
                Tiếp tục chọn chi nhánh →
              </button>
            </div>
          </div>
        </div>
      ) : null}

      {/* STEP 3: SELECT BRANCH */}
      {step === 3 ? (
        <div>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: "12px" }}>
            <h2>Bước 4: Chọn chi nhánh tiếp nhận</h2>
            <button className="btn btn-quiet" type="button" onClick={() => setStep(2)}>
              ← Quay lại
            </button>
          </div>
          <p className="section-intro">Chọn cửa hàng gần bạn nhất để mang máy tới sửa chữa:</p>
          <div className="result-list">
            {branches.map((item) => (
              <button
                key={item.id}
                type="button"
                className={branchId === item.id ? "card card-button card-selected" : "card card-button"}
                onClick={() => {
                  setBranchId(item.id)
                  setSlot("")
                  setStep(4)
                }}
              >
                <strong style={{ fontSize: "1.15rem" }}>{item.name}</strong>
                <p style={{ margin: "6px 0", color: "var(--color-muted)" }}>📍 {item.address}</p>
                <p style={{ margin: "0", color: "var(--color-muted)" }}>📞 {item.phone}</p>
                <div style={{ marginTop: "12px" }}>
                  <span className="badge badge-received">Sức chứa: {item.capacityPerSlot} máy/khung giờ</span>
                </div>
              </button>
            ))}
          </div>
        </div>
      ) : null}

      {/* STEP 4: SELECT DATE & TIME SLOT */}
      {step === 4 ? (
        <div>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: "12px" }}>
            <div>
              <h2>Bước 5: Chọn ngày và khung giờ hẹn</h2>
              <p className="section-intro">
                Chi nhánh: <strong>{selectedBranch?.name}</strong> (📍 {selectedBranch?.address})
              </p>
            </div>
            <button className="btn btn-quiet" type="button" onClick={() => setStep(3)}>
              ← Đổi chi nhánh
            </button>
          </div>

          <div className="card" style={{ marginTop: "16px" }}>
            <label className="field" style={{ maxWidth: "320px" }}>
              <span>Ngày hẹn mang máy tới</span>
              <input
                className="input"
                type="date"
                min={minDate}
                value={date}
                onChange={(e) => {
                  setDate(e.target.value)
                  setSlot("")
                }}
              />
            </label>

            <div style={{ marginTop: "24px" }}>
              <strong>Khung giờ khả dụng:</strong>
              {!date ? (
                <p className="muted" style={{ marginTop: "8px" }}>Vui lòng chọn ngày ở trên để xem các khung giờ.</p>
              ) : slotsLoading ? (
                <p className="muted" style={{ marginTop: "8px" }}>Đang kiểm tra lịch trống...</p>
              ) : slots.length === 0 ? (
                <p className="muted" style={{ marginTop: "8px" }}>Không có khung giờ khả dụng cho ngày này (cửa hàng đóng cửa hoặc đã hết giờ làm việc).</p>
              ) : (
                <div className="slot-grid" style={{ marginTop: "12px" }}>
                  {slots.map((item) => (
                    <button
                      key={item.start}
                      type="button"
                      className={slot === item.start ? "slot slot-selected" : "slot"}
                      disabled={item.isFull}
                      onClick={() => setSlot(item.start)}
                      style={{ display: "flex", flexDirection: "column", gap: "2px", alignItems: "center", minWidth: "110px" }}
                    >
                      <span style={{ fontWeight: 700 }}>{item.start} – {item.end}</span>
                      <span style={{ fontSize: "0.75rem", color: item.isFull ? "var(--color-danger)" : "var(--color-ok)" }}>
                        {item.isFull ? "Đã kín chỗ" : `Còn ${item.capacity - item.booked} chỗ`}
                      </span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {slot ? (
              <div style={{ marginTop: "20px", display: "flex", justifyContent: "flex-end" }}>
                <button className="btn" type="button" onClick={() => setStep(5)}>
                  Tiếp tục xác nhận thông tin →
                </button>
              </div>
            ) : null}
          </div>
        </div>
      ) : null}

      {/* STEP 5: REVIEW & CONFIRM */}
      {step === 5 ? (
        <section className="card" style={{ maxWidth: "760px", margin: "0 auto" }}>
          <h2>Bước 6: Xem lại và xác nhận lịch hẹn</h2>
          <p className="section-intro">Vui lòng kiểm tra lại thông tin trước khi hoàn tất đặt lịch:</p>

          <div style={{ display: "grid", gap: "16px", margin: "20px 0" }}>
            <div style={{ padding: "14px", background: "#f8fafc", borderRadius: "12px", border: "1px solid var(--color-line)" }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <strong>📱 Thiết bị sửa chữa</strong>
                <button className="btn btn-quiet" type="button" onClick={() => setStep(1)} style={{ padding: "2px 8px", fontSize: "0.85rem" }}>Đổi</button>
              </div>
              <p style={{ margin: "4px 0 0", fontSize: "1.05rem", color: "var(--color-ink)" }}>
                {selectedModel?.brandName} {selectedModel?.name}
              </p>
            </div>

            <div style={{ padding: "14px", background: "#f8fafc", borderRadius: "12px", border: "1px solid var(--color-line)" }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <strong>📍 Chi nhánh & Thời gian hẹn</strong>
                <button className="btn btn-quiet" type="button" onClick={() => setStep(4)} style={{ padding: "2px 8px", fontSize: "0.85rem" }}>Đổi</button>
              </div>
              <p style={{ margin: "4px 0 0", color: "var(--color-ink)" }}>
                <strong>{selectedBranch?.name}</strong> ({selectedBranch?.address})
              </p>
              <p style={{ margin: "4px 0 0", color: "var(--color-muted)" }}>
                Ngày hẹn: <strong>{date}</strong> · Khung giờ: <strong>{slot}</strong>
              </p>
            </div>

            <div style={{ padding: "14px", background: "#f8fafc", borderRadius: "12px", border: "1px solid var(--color-line)" }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <strong>🛠️ Dịch vụ đã chọn ({selectedPrices.length})</strong>
                <button className="btn btn-quiet" type="button" onClick={() => setStep(2)} style={{ padding: "2px 8px", fontSize: "0.85rem" }}>Đổi</button>
              </div>
              <ul className="plain-list" style={{ marginTop: "10px" }}>
                {selectedPrices.map((item) => (
                  <li key={item.id} style={{ display: "flex", justifyContent: "space-between", padding: "4px 0" }}>
                    <span>{item.repairServiceName}</span>
                    <strong>{formatPrice(item.pricingType, item.price)}</strong>
                  </li>
                ))}
              </ul>
              <div style={{ borderTop: "1px solid #e2e8f0", marginTop: "12px", paddingTop: "10px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <strong>Tổng chi phí tạm tính:</strong>
                <strong style={{ fontSize: "1.2rem", color: "var(--color-accent-strong)" }}>
                  {new Intl.NumberFormat("vi-VN").format(estimatedTotal)} đ
                </strong>
              </div>
              {hasInspectionRequired ? (
                <p style={{ margin: "8px 0 0", fontSize: "0.85rem", color: "#854d0e" }}>
                  * Các dịch vụ cần kiểm tra sẽ được kỹ thuật viên báo chi phí chính xác sau khi tiếp nhận và mở máy kiểm tra.
                </p>
              ) : null}
            </div>

            <label className="field">
              <span>Mô tả chi tiết tình trạng lỗi của máy *</span>
              <textarea
                className="input text-area"
                placeholder="Ví dụ: Máy bị vỡ kính sau va chạm, cảm ứng vẫn dùng được bình thường; pin sụt nhanh..."
                value={problem}
                onChange={(e) => setProblem(e.target.value)}
              />
            </label>
          </div>

          <div style={{ marginTop: "24px", display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: "12px" }}>
            <button className="btn btn-quiet" type="button" onClick={() => setStep(4)}>
              ← Quay lại chọn giờ
            </button>

            {user && token ? (
              <button
                className="btn"
                type="button"
                disabled={saving || problem.trim().length === 0}
                onClick={() => void handleConfirmBooking()}
              >
                {saving ? "Đang xử lý đặt lịch..." : "Xác nhận đặt lịch ngay ✓"}
              </button>
            ) : (
              <div style={{ textAlign: "right" }}>
                <p style={{ margin: "0 0 8px", color: "var(--color-muted)", fontSize: "0.9rem" }}>
                  Bạn cần đăng nhập để lưu lịch hẹn vào tài khoản cá nhân.
                </p>
                <Link className="btn" to="/dang-nhap">
                  Đăng nhập để xác nhận đặt lịch
                </Link>
              </div>
            )}
          </div>
        </section>
      ) : null}

      {/* STEP 6: BOOKING SUCCESS (Feature 43.6) */}
      {step === 6 && createdBooking ? (
        <section className="success-card">
          <div className="success-icon">✓</div>
          <h1 style={{ fontSize: "1.8rem", margin: "0 0 8px" }}>Đặt lịch sửa chữa thành công!</h1>
          <p className="muted" style={{ margin: 0 }}>
            Hệ thống đã ghi nhận lịch hẹn của bạn. Thông tin chi tiết như sau:
          </p>

          <div className="code-display">
            <span>{createdBooking.bookingCode}</span>
            <button
              className="btn btn-quiet"
              type="button"
              onClick={() => handleCopyCode(createdBooking.bookingCode)}
              style={{ padding: "4px 10px", fontSize: "0.8rem" }}
            >
              {copiedCode ? "Đã chép ✓" : "Sao chép"}
            </button>
          </div>

          <div style={{ textAlign: "left", background: "#f8fafc", padding: "16px 20px", borderRadius: "12px", border: "1px solid var(--color-line)", margin: "16px 0" }}>
            <p style={{ margin: "4px 0" }}>
              📱 <strong>Thiết bị:</strong> {createdBooking.brandName} {createdBooking.phoneModelName}
            </p>
            <p style={{ margin: "4px 0" }}>
              🛠️ <strong>Dịch vụ:</strong> {createdBooking.services.map((s) => s.serviceName).join(", ")}
            </p>
            <p style={{ margin: "4px 0" }}>
              📍 <strong>Chi nhánh:</strong> {createdBooking.branchName} ({createdBooking.branchAddress})
            </p>
            <p style={{ margin: "4px 0" }}>
              ⏰ <strong>Thời gian hẹn:</strong> Ngày {createdBooking.appointmentDate} lúc {createdBooking.slotStart} – {createdBooking.slotEnd}
            </p>
            <p style={{ margin: "4px 0" }}>
              💵 <strong>Tạm tính:</strong> {new Intl.NumberFormat("vi-VN").format(createdBooking.estimatedTotal)} đ
            </p>
          </div>

          <div className="next-steps-box">
            <h3>📌 Các bước tiếp theo:</h3>
            <ol>
              <li>Lưu lại mã đặt lịch <strong>{createdBooking.bookingCode}</strong> hoặc kiểm tra trong mục <strong>Lịch của tôi</strong>.</li>
              <li>Mang điện thoại đến chi nhánh đúng ngày hẹn và khung giờ đã đăng ký.</li>
              <li>Đọc mã đặt lịch hoặc số điện thoại cho nhân viên tiếp tân để bàn giao máy cho kỹ thuật viên.</li>
            </ol>
          </div>

          <div style={{ display: "flex", justifyContent: "center", gap: "12px", flexWrap: "wrap", marginTop: "24px" }}>
            <Link className="btn" to={`/lich-cua-toi/${createdBooking.id}`}>
              Xem chi tiết & Theo dõi tiến trình →
            </Link>
            <button
              className="btn btn-quiet"
              type="button"
              onClick={() => {
                setStep(0)
                setBrandId(null)
                setModelId(null)
                setServiceIds([])
                setBranchId(null)
                setDate("")
                setSlot("")
                setProblem("")
                setCreatedBooking(null)
              }}
            >
              Đặt thêm lịch mới
            </button>
            <Link className="btn btn-quiet" to="/">
              Về trang chủ
            </Link>
          </div>
        </section>
      ) : null}
    </main>
  )
}
