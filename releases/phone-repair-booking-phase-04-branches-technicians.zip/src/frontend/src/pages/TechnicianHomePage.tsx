import { useEffect, useState } from "react"
import { dayLabel, dayOrder, myTechnicianProfile, type ScheduleDay } from "../api/branches"
import { useAuth } from "../auth/AuthContext"

export function TechnicianHomePage() {
  const { token } = useAuth()
  const [branchName, setBranchName] = useState("")
  const [schedules, setSchedules] = useState<ScheduleDay[]>([])
  const [message, setMessage] = useState("")

  useEffect(() => {
    if (!token) return
    myTechnicianProfile(token)
      .then((profile) => {
        setBranchName(profile.branchName)
        setSchedules(profile.schedules)
      })
      .catch(() => setMessage("Không tải được lịch làm việc."))
  }, [token])

  return (
    <main className="page">
      <section className="hero">
        <div>
          <p className="eyebrow">Khu vực kỹ thuật viên</p>
          <h1>{branchName || "Lịch làm việc"}</h1>
          <p className="lede">Chỉ xem lịch của tài khoản đang đăng nhập.</p>
        </div>
      </section>
      {message ? <p className="form-error">{message}</p> : null}
      <ul className="plain-list card">
        {dayOrder.map((day) => {
          const row = schedules.find((item) => item.dayOfWeek === day)
          return (
            <li key={day}>
              {dayLabel[day]}: {row?.isWorking ? `${row.startTime} – ${row.endTime}` : "Nghỉ"}
            </li>
          )
        })}
      </ul>
    </main>
  )
}
