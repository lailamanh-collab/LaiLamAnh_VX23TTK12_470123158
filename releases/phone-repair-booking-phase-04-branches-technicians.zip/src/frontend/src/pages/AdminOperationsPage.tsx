import { useEffect, useState } from "react"
import {
  adminBranches,
  adminTechnicians,
  createTechnician,
  dayLabel,
  dayOrder,
  defaultHours,
  saveBranch,
  saveSchedule,
  updateTechnician,
  type Branch,
  type OpeningHour,
  type Technician,
} from "../api/branches"
import { ApiError } from "../api/client"
import { useAuth } from "../auth/AuthContext"

export function AdminOperationsPage() {
  const { token } = useAuth()
  const [branches, setBranches] = useState<Branch[]>([])
  const [technicians, setTechnicians] = useState<Technician[]>([])
  const [message, setMessage] = useState("")
  const [name, setName] = useState("")
  const [address, setAddress] = useState("")
  const [phone, setPhone] = useState("")
  const [capacity, setCapacity] = useState("4")
  const [techName, setTechName] = useState("")
  const [techEmail, setTechEmail] = useState("")
  const [techPhone, setTechPhone] = useState("")
  const [techPassword, setTechPassword] = useState("")
  const [techBranchId, setTechBranchId] = useState("")
  const [selectedTech, setSelectedTech] = useState<Technician | null>(null)

  async function reload() {
    if (!token) return
    const [branchRows, techRows] = await Promise.all([adminBranches(token), adminTechnicians(token)])
    setBranches(branchRows)
    setTechnicians(techRows)
  }

  useEffect(() => {
    reload().catch(() => setMessage("Không tải được dữ liệu cửa hàng."))
  }, [token])

  async function run(action: () => Promise<unknown>) {
    setMessage("")
    try {
      await action()
      await reload()
      setMessage("Đã lưu.")
    } catch (error) {
      setMessage(error instanceof ApiError ? error.message : "Không lưu được.")
    }
  }

  return (
    <main className="page">
      <section className="section-head">
        <h1>Cửa hàng và kỹ thuật viên</h1>
      </section>
      {message ? <p className="form-success">{message}</p> : null}
      <div className="admin-grid">
        <form className="card form" onSubmit={(event) => {
          event.preventDefault()
          if (!token) return
          const hours: OpeningHour[] = defaultHours()
          void run(async () => {
            await saveBranch(token, {
              name, address, phone, capacityPerSlot: Number(capacity), slotMinutes: 30, isActive: true, openingHours: hours,
            })
            setName("")
            setAddress("")
            setPhone("")
          })
        }}>
          <h2>Thêm chi nhánh</h2>
          <input className="input" value={name} onChange={(event) => setName(event.target.value)} placeholder="Tên chi nhánh" />
          <input className="input" value={address} onChange={(event) => setAddress(event.target.value)} placeholder="Địa chỉ" />
          <input className="input" value={phone} onChange={(event) => setPhone(event.target.value)} placeholder="Điện thoại" />
          <input className="input" value={capacity} onChange={(event) => setCapacity(event.target.value)} placeholder="Sức chứa mỗi slot" />
          <button className="btn" type="submit">Lưu chi nhánh</button>
          <ul className="plain-list">
            {branches.map((branch) => (
              <li key={branch.id}>
                {branch.name} · {branch.capacityPerSlot} chỗ/slot
                <button className="btn btn-quiet" type="button" onClick={() => {
                  if (!token) return
                  void run(() => saveBranch(token, { ...branch, isActive: !branch.isActive }, branch.id))
                }}>{branch.isActive ? "Tắt" : "Bật"}</button>
              </li>
            ))}
          </ul>
        </form>

        <form className="card form" onSubmit={(event) => {
          event.preventDefault()
          if (!token) return
          void run(async () => {
            await createTechnician(token, {
              fullName: techName,
              email: techEmail,
              phoneNumber: techPhone,
              password: techPassword,
              branchId: Number(techBranchId),
              isActive: true,
            })
            setTechName("")
            setTechEmail("")
            setTechPhone("")
            setTechPassword("")
          })
        }}>
          <h2>Thêm kỹ thuật viên</h2>
          <input className="input" value={techName} onChange={(event) => setTechName(event.target.value)} placeholder="Họ tên" />
          <input className="input" value={techEmail} onChange={(event) => setTechEmail(event.target.value)} placeholder="Email" />
          <input className="input" value={techPhone} onChange={(event) => setTechPhone(event.target.value)} placeholder="Điện thoại" />
          <input className="input" type="password" value={techPassword} onChange={(event) => setTechPassword(event.target.value)} placeholder="Mật khẩu" />
          <select className="input" value={techBranchId} onChange={(event) => setTechBranchId(event.target.value)}>
            <option value="">Chọn chi nhánh</option>
            {branches.filter((branch) => branch.isActive).map((branch) => <option key={branch.id} value={branch.id}>{branch.name}</option>)}
          </select>
          <button className="btn" type="submit">Tạo tài khoản</button>
          <ul className="plain-list">
            {technicians.map((tech) => (
              <li key={tech.id}>
                {tech.fullName} · {tech.branchName}
                <button className="btn btn-quiet" type="button" onClick={() => setSelectedTech(tech)}>Lịch</button>
                <button className="btn btn-quiet" type="button" onClick={() => {
                  if (!token) return
                  void run(() => updateTechnician(token, tech.id, {
                    fullName: tech.fullName,
                    phoneNumber: tech.phoneNumber ?? "",
                    branchId: tech.branchId,
                    isActive: !tech.isActive,
                  }))
                }}>{tech.isActive ? "Tắt" : "Bật"}</button>
              </li>
            ))}
          </ul>
        </form>
      </div>
      {selectedTech ? (
        <form className="card form" onSubmit={(event) => {
          event.preventDefault()
          if (!token) return
          void run(() => saveSchedule(token, selectedTech.id, selectedTech.schedules))
        }}>
          <h2>Lịch của {selectedTech.fullName}</h2>
          {dayOrder.map((day) => {
            const row = selectedTech.schedules.find((item) => item.dayOfWeek === day) ?? {
              dayOfWeek: day,
              isWorking: false,
              startTime: "08:00",
              endTime: "17:00",
            }
            const update = (partial: Partial<typeof row>) => {
              setSelectedTech({
                ...selectedTech,
                schedules: dayOrder.map((item) => {
                  const current = selectedTech.schedules.find((schedule) => schedule.dayOfWeek === item) ?? {
                    dayOfWeek: item,
                    isWorking: false,
                    startTime: "08:00",
                    endTime: "17:00",
                  }
                  return item === day ? { ...current, ...partial } : current
                }),
              })
            }
            return (
              <div className="schedule-row" key={day}>
                <label className="check-line">
                  <input type="checkbox" checked={row.isWorking} onChange={(event) => update({ isWorking: event.target.checked })} />
                  {dayLabel[day]}
                </label>
                <input className="input" type="time" value={row.startTime} onChange={(event) => update({ startTime: event.target.value })} />
                <input className="input" type="time" value={row.endTime} onChange={(event) => update({ endTime: event.target.value })} />
              </div>
            )
          })}
          <button className="btn" type="submit">Lưu lịch</button>
        </form>
      ) : null}
    </main>
  )
}
