import { useEffect, useState } from "react"
import { dayLabel, dayOrder, getBranches, type Branch } from "../api/branches"

export function BranchesPage() {
  const [branches, setBranches] = useState<Branch[]>([])
  const [message, setMessage] = useState("")

  useEffect(() => {
    getBranches().then(setBranches).catch(() => setMessage("Không tải được chi nhánh."))
  }, [])

  return (
    <main className="page">
      <section className="section-head">
        <h1>Chi nhánh</h1>
        <p className="section-intro">Mang máy tới chi nhánh đã chọn theo khung giờ còn chỗ.</p>
      </section>
      {message ? <p className="form-error">{message}</p> : null}
      <div className="result-list">
        {branches.map((branch) => (
          <article className="card" key={branch.id}>
            <h2>{branch.name}</h2>
            <p>{branch.address}</p>
            <p>{branch.phone}</p>
            <p>Mỗi khung {branch.slotMinutes} phút nhận tối đa {branch.capacityPerSlot} máy.</p>
            <ul className="plain-list">
              {dayOrder.map((day) => {
                const hour = branch.openingHours.find((item) => item.dayOfWeek === day)
                return (
                  <li key={day}>
                    {dayLabel[day]}: {hour?.isOpen ? `${hour.openTime} – ${hour.closeTime}` : "Đóng cửa"}
                  </li>
                )
              })}
            </ul>
          </article>
        ))}
      </div>
    </main>
  )
}
