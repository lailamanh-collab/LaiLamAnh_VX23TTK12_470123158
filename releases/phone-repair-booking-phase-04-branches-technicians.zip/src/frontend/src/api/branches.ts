import { api } from "./client"

export type WeekDay = "Sunday" | "Monday" | "Tuesday" | "Wednesday" | "Thursday" | "Friday" | "Saturday"

export type OpeningHour = {
  dayOfWeek: WeekDay
  isOpen: boolean
  openTime: string
  closeTime: string
}

export type Branch = {
  id: number
  name: string
  address: string
  phone: string
  capacityPerSlot: number
  slotMinutes: number
  isActive: boolean
  openingHours: OpeningHour[]
}

export type ScheduleDay = {
  dayOfWeek: WeekDay
  isWorking: boolean
  startTime: string
  endTime: string
}

export type Technician = {
  id: number
  fullName: string
  email: string
  phoneNumber: string | null
  branchId: number
  branchName: string
  isActive: boolean
  schedules: ScheduleDay[]
}

export const dayOrder: WeekDay[] = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]

export const dayLabel: Record<WeekDay, string> = {
  Monday: "Thứ hai",
  Tuesday: "Thứ ba",
  Wednesday: "Thứ tư",
  Thursday: "Thứ năm",
  Friday: "Thứ sáu",
  Saturday: "Thứ bảy",
  Sunday: "Chủ nhật",
}

export const defaultHours = (): OpeningHour[] => dayOrder.map((day) => ({
  dayOfWeek: day,
  isOpen: day !== "Sunday",
  openTime: "08:00",
  closeTime: "17:30",
}))

export const getBranches = () => api<Branch[]>("/api/branches")
export const adminBranches = (token: string) => api<Branch[]>("/api/admin/branches", {}, token)
export const adminTechnicians = (token: string) => api<Technician[]>("/api/admin/technicians", {}, token)
export const myTechnicianProfile = (token: string) => api<Technician>("/api/technician/me", {}, token)

export function saveBranch(token: string, body: object, id?: number) {
  return api<Branch>(`/api/admin/branches${id ? `/${id}` : ""}`, {
    method: id ? "PUT" : "POST",
    body: JSON.stringify(body),
  }, token)
}

export function createTechnician(token: string, body: object) {
  return api<Technician>("/api/admin/technicians", { method: "POST", body: JSON.stringify(body) }, token)
}

export function updateTechnician(token: string, id: number, body: object) {
  return api<Technician>(`/api/admin/technicians/${id}`, { method: "PUT", body: JSON.stringify(body) }, token)
}

export function saveSchedule(token: string, id: number, schedules: ScheduleDay[]) {
  return api<Technician>(`/api/admin/technicians/${id}/schedule`, {
    method: "PUT",
    body: JSON.stringify({ schedules }),
  }, token)
}
