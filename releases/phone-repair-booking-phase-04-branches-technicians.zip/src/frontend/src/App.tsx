import { Route, Routes } from "react-router-dom"
import { useEffect, useState } from "react"
import { getHealth } from "./api/health"
import { AuthProvider } from "./auth/AuthContext"
import { RequireAuth } from "./components/auth/RequireAuth"
import { SiteFooter } from "./components/layout/SiteFooter"
import { SiteHeader } from "./components/layout/SiteHeader"
import { AdminCatalogPage } from "./pages/AdminCatalogPage"
import { AdminOperationsPage } from "./pages/AdminOperationsPage"
import { BrandsPage } from "./pages/BrandsPage"
import { BranchesPage } from "./pages/BranchesPage"
import { HomePage } from "./pages/HomePage"
import { LoginPage } from "./pages/LoginPage"
import { ModelsPage } from "./pages/ModelsPage"
import { ProfilePage } from "./pages/ProfilePage"
import { RegisterPage } from "./pages/RegisterPage"
import { RoleHomePage } from "./pages/RoleHomePage"
import { ServicesPage } from "./pages/ServicesPage"
import { TechnicianHomePage } from "./pages/TechnicianHomePage"

function Shell() {
  const [databaseConnected, setDatabaseConnected] = useState<boolean | null>(null)

  useEffect(() => {
    let active = true
    getHealth()
      .then((health) => {
        if (active) {
          setDatabaseConnected(health.database === "connected")
        }
      })
      .catch(() => {
        if (active) {
          setDatabaseConnected(false)
        }
      })

    return () => {
      active = false
    }
  }, [])

  return (
    <>
      <SiteHeader />
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/dich-vu" element={<ServicesPage />} />
        <Route path="/hang" element={<BrandsPage />} />
        <Route path="/dong-may" element={<ModelsPage />} />
        <Route path="/chi-nhanh" element={<BranchesPage />} />
        <Route path="/dang-nhap" element={<LoginPage />} />
        <Route path="/dang-ky" element={<RegisterPage />} />
        <Route path="/ho-so" element={<RequireAuth><ProfilePage /></RequireAuth>} />
        <Route
          path="/quan-tri/danh-muc"
          element={<RequireAuth role="Admin"><AdminCatalogPage /></RequireAuth>}
        />
        <Route
          path="/quan-tri/cua-hang"
          element={<RequireAuth role="Admin"><AdminOperationsPage /></RequireAuth>}
        />
        <Route
          path="/quan-tri"
          element={
            <RequireAuth role="Admin">
              <RoleHomePage
                title="Khu vực quản trị"
                description="Quản lý hãng, dòng máy, dịch vụ và giá sửa chữa trong mục Danh mục."
              />
            </RequireAuth>
          }
        />
        <Route
          path="/ky-thuat-vien"
          element={
            <RequireAuth role="Technician">
              <TechnicianHomePage />
            </RequireAuth>
          }
        />
      </Routes>
      <SiteFooter databaseConnected={databaseConnected} />
    </>
  )
}

export default function App() {
  return (
    <AuthProvider>
      <Shell />
    </AuthProvider>
  )
}
