namespace PhoneRepairBooking.Api.Domain;

public class BranchOpeningHour
{
    public int Id { get; set; }

    public int BranchId { get; set; }

    public Branch Branch { get; set; } = null!;

    public DayOfWeek DayOfWeek { get; set; }

    public bool IsOpen { get; set; }

    public TimeOnly OpenTime { get; set; }

    public TimeOnly CloseTime { get; set; }
}
