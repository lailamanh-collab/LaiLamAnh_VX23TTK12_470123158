namespace PhoneRepairBooking.Api.DTOs;

public record OpeningHourDto(DayOfWeek DayOfWeek, bool IsOpen, string OpenTime, string CloseTime);

public record BranchDto(
    int Id,
    string Name,
    string Address,
    string Phone,
    int CapacityPerSlot,
    int SlotMinutes,
    bool IsActive,
    List<OpeningHourDto> OpeningHours);

public class BranchRequest
{
    public string Name { get; set; } = string.Empty;

    public string Address { get; set; } = string.Empty;

    public string Phone { get; set; } = string.Empty;

    public int CapacityPerSlot { get; set; } = 4;

    public int SlotMinutes { get; set; } = 30;

    public bool IsActive { get; set; } = true;

    public List<OpeningHourDto> OpeningHours { get; set; } = [];
}

public record ScheduleDto(DayOfWeek DayOfWeek, bool IsWorking, string StartTime, string EndTime);

public record TechnicianDto(
    int Id,
    string FullName,
    string Email,
    string? PhoneNumber,
    int BranchId,
    string BranchName,
    bool IsActive,
    List<ScheduleDto> Schedules);

public class CreateTechnicianRequest
{
    public string FullName { get; set; } = string.Empty;

    public string Email { get; set; } = string.Empty;

    public string PhoneNumber { get; set; } = string.Empty;

    public string Password { get; set; } = string.Empty;

    public int BranchId { get; set; }

    public bool IsActive { get; set; } = true;
}

public class UpdateTechnicianRequest
{
    public string FullName { get; set; } = string.Empty;

    public string PhoneNumber { get; set; } = string.Empty;

    public int BranchId { get; set; }

    public bool IsActive { get; set; } = true;
}

public class ScheduleRequest
{
    public List<ScheduleDto> Schedules { get; set; } = [];
}
