using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using PhoneRepairBooking.Api.Domain;
using PhoneRepairBooking.Api.Services;

namespace PhoneRepairBooking.Api.Data;

public static class DbSeeder
{
    public static async Task SeedAsync(IServiceProvider services)
    {
        var roles = services.GetRequiredService<RoleManager<IdentityRole>>();
        var users = services.GetRequiredService<UserManager<ApplicationUser>>();

        foreach (var role in AppRoles.All)
        {
            if (!await roles.RoleExistsAsync(role))
            {
                await roles.CreateAsync(new IdentityRole(role));
            }
        }

        await EnsureUserAsync(users, "admin@phonerepair.local", "Quản trị viên", "0901000001", "Admin@12345", AppRoles.Admin);
        await EnsureUserAsync(users, "technician@phonerepair.local", "Kỹ thuật viên demo", "0901000002", "Tech@12345", AppRoles.Technician);
        await EnsureUserAsync(users, "customer@phonerepair.local", "Khách hàng demo", "0901000003", "Customer@12345", AppRoles.Customer);
        await SeedCatalogAsync(services.GetRequiredService<AppDbContext>());
        await SeedOperationsAsync(services);
    }

    private static async Task SeedOperationsAsync(IServiceProvider services)
    {
        var db = services.GetRequiredService<AppDbContext>();
        var users = services.GetRequiredService<UserManager<ApplicationUser>>();
        if (await db.Branches.AnyAsync())
        {
            return;
        }

        var district1 = NewBranch("PhoneRepair Quận 1", "12 Nguyễn Huệ, Quận 1, TP.HCM", "02811110001");
        var district7 = NewBranch("PhoneRepair Quận 7", "45 Nguyễn Văn Linh, Quận 7, TP.HCM", "02811110007");
        var thuDuc = NewBranch("PhoneRepair Thủ Đức", "89 Võ Văn Ngân, TP. Thủ Đức", "02811110008");
        db.Branches.AddRange(district1, district7, thuDuc);
        await db.SaveChangesAsync();

        await EnsureUserAsync(users, "technician2@phonerepair.local", "Kỹ thuật viên Quận 7", "0901000004", "Tech2@12345", AppRoles.Technician);
        var first = await users.FindByEmailAsync("technician@phonerepair.local");
        var second = await users.FindByEmailAsync("technician2@phonerepair.local");
        if (first is not null)
        {
            db.Technicians.Add(NewTechnician(first.Id, district1.Id));
        }

        if (second is not null)
        {
            db.Technicians.Add(NewTechnician(second.Id, district7.Id));
        }

        await db.SaveChangesAsync();
    }

    private static Branch NewBranch(string name, string address, string phone)
    {
        var branch = new Branch
        {
            Name = name,
            Address = address,
            Phone = phone,
            CapacityPerSlot = 4,
            SlotMinutes = 30,
            IsActive = true,
            CreatedAt = DateTime.UtcNow
        };
        foreach (var hour in BranchService.DefaultHours())
        {
            branch.OpeningHours.Add(new BranchOpeningHour
            {
                DayOfWeek = hour.DayOfWeek,
                IsOpen = hour.IsOpen,
                OpenTime = TimeOnly.Parse(hour.OpenTime),
                CloseTime = TimeOnly.Parse(hour.CloseTime)
            });
        }

        return branch;
    }

    private static Technician NewTechnician(string userId, int branchId)
    {
        var technician = new Technician
        {
            UserId = userId,
            BranchId = branchId,
            IsActive = true,
            CreatedAt = DateTime.UtcNow
        };
        foreach (DayOfWeek day in Enum.GetValues<DayOfWeek>())
        {
            technician.Schedules.Add(new TechnicianSchedule
            {
                DayOfWeek = day,
                IsWorking = day != DayOfWeek.Sunday,
                StartTime = new TimeOnly(8, 0),
                EndTime = new TimeOnly(17, 0)
            });
        }

        return technician;
    }

    private static async Task SeedCatalogAsync(AppDbContext db)
    {
        if (await db.Brands.AnyAsync())
        {
            return;
        }

        var apple = Brand("Apple");
        var samsung = Brand("Samsung");
        var xiaomi = Brand("Xiaomi");
        var oppo = Brand("Oppo");
        db.Brands.AddRange(apple, samsung, xiaomi, oppo);

        var iphone13 = Model(apple, "iPhone 13", 2021);
        var iphone15 = Model(apple, "iPhone 15", 2023);
        var galaxyS24 = Model(samsung, "Galaxy S24", 2024);
        var redmiNote13 = Model(xiaomi, "Redmi Note 13", 2024);
        db.PhoneModels.AddRange(iphone13, iphone15, galaxyS24, redmiNote13);

        var screen = Service("Thay màn hình", PricingType.FixedPrice);
        var battery = Service("Thay pin", PricingType.FixedPrice);
        var speaker = Service("Sửa loa", PricingType.FixedPrice);
        var clean = Service("Vệ sinh thiết bị", PricingType.FixedPrice);
        var noPower = Service("Máy không lên nguồn", PricingType.InspectionRequired);
        var water = Service("Máy bị vào nước", PricingType.InspectionRequired);
        db.RepairServices.AddRange(screen, battery, speaker, clean, noPower, water);

        db.ServicePrices.AddRange(
            Price(iphone13, screen, 2000000),
            Price(iphone15, screen, 3500000),
            Price(galaxyS24, screen, 3000000),
            Price(redmiNote13, screen, 1200000),
            Price(iphone13, battery, 900000),
            Price(iphone15, battery, 1500000),
            Price(galaxyS24, battery, 1100000),
            Price(redmiNote13, battery, 450000),
            Price(iphone15, speaker, 700000),
            Price(iphone15, clean, 300000),
            Price(iphone13, noPower, null),
            Price(iphone15, noPower, null),
            Price(galaxyS24, water, null));

        await db.SaveChangesAsync();
    }

    private static Brand Brand(string name) => new()
    {
        Name = name,
        Slug = Slugger.Make(name),
        IsActive = true,
        CreatedAt = DateTime.UtcNow
    };

    private static PhoneModel Model(Brand brand, string name, int year) => new()
    {
        Brand = brand,
        Name = name,
        Slug = Slugger.Make($"{brand.Name}-{name}"),
        ReleaseYear = year,
        IsActive = true,
        CreatedAt = DateTime.UtcNow
    };

    private static RepairService Service(string name, PricingType pricingType) => new()
    {
        Name = name,
        Slug = Slugger.Make(name),
        PricingType = pricingType,
        IsActive = true,
        CreatedAt = DateTime.UtcNow
    };

    private static ServicePrice Price(PhoneModel model, RepairService service, decimal? amount) => new()
    {
        PhoneModel = model,
        RepairService = service,
        Price = amount,
        IsActive = true
    };

    private static async Task EnsureUserAsync(
        UserManager<ApplicationUser> users,
        string email,
        string fullName,
        string phone,
        string password,
        string role)
    {
        var user = await users.FindByEmailAsync(email);
        if (user is null)
        {
            user = new ApplicationUser
            {
                UserName = email,
                Email = email,
                FullName = fullName,
                PhoneNumber = phone,
                EmailConfirmed = true,
                IsActive = true,
                CreatedAt = DateTime.UtcNow
            };
            var created = await users.CreateAsync(user, password);
            if (!created.Succeeded)
            {
                throw new InvalidOperationException($"Cannot seed {email}.");
            }
        }

        if (!await users.IsInRoleAsync(user, role))
        {
            await users.AddToRoleAsync(user, role);
        }
    }
}
