import { useEffect, useMemo, useState } from "react"
import { Link, useSearchParams } from "react-router-dom"
import { getBrands, getModels, getPrices, type Brand, type PhoneModel, type ServicePrice } from "../api/catalog"
import { getBranches, type Branch } from "../api/branches"
import { createBooking, getSlots, type BookingDetail, type Slot } from "../api/bookings"
import { ApiError } from "../api/client"
import { useAuth } from "../auth/AuthContext"
import { BookingSuccessPage } from "./BookingSuccessPage"

interface MockupModel {
  name: string
  year: number
  image: string
}

const MOCKUP_IPHONE_MODELS: MockupModel[] = [
  { name: "iPhone 16", year: 2024, image: "https://images.unsplash.com/photo-1592750475338-74b7b21085ab?auto=format&fit=crop&w=260&q=80" },
  { name: "iPhone 15", year: 2023, image: "https://images.unsplash.com/photo-1695048133142-1a20484d2569?auto=format&fit=crop&w=260&q=80" },
  { name: "iPhone 14", year: 2022, image: "https://images.unsplash.com/photo-1663499482523-1c0c1bae4ce1?auto=format&fit=crop&w=260&q=80" },
  { name: "iPhone 13", year: 2021, image: "https://images.unsplash.com/photo-1632661674596-df8be070a5c5?auto=format&fit=crop&w=260&q=80" },
  { name: "iPhone 12", year: 2020, image: "https://images.unsplash.com/photo-1605236453806-6ff36851218e?auto=format&fit=crop&w=260&q=80" },
  { name: "iPhone 11", year: 2019, image: "https://images.unsplash.com/photo-1574944985070-8f3ebc6b79d2?auto=format&fit=crop&w=260&q=80" },
  { name: "iPhone XS", year: 2018, image: "https://images.unsplash.com/photo-1510557880182-3d4d3cba35a5?auto=format&fit=crop&w=260&q=80" },
  { name: "iPhone XR", year: 2018, image: "https://images.unsplash.com/photo-1530319067432-f2a729c03db5?auto=format&fit=crop&w=260&q=80" },
  { name: "iPhone X", year: 2017, image: "https://images.unsplash.com/photo-1519389950473-47ba0277781c?auto=format&fit=crop&w=260&q=80" },
  { name: "iPhone 8", year: 2017, image: "https://images.unsplash.com/photo-1523206489230-c012c64b2b48?auto=format&fit=crop&w=260&q=80" },
  { name: "iPhone 8 Plus", year: 2017, image: "https://images.unsplash.com/photo-1565849904461-04a58ad377e0?auto=format&fit=crop&w=260&q=80" },
  { name: "iPhone SE", year: 2022, image: "https://images.unsplash.com/photo-1589492477829-5e65395b66cc?auto=format&fit=crop&w=260&q=80" },
]

interface ServiceTemplate {
  key: string
  name: string
  desc: string
  price: number
  icon: string
  iconBg: string
  isPopular?: boolean
}

const SERVICE_TEMPLATES: ServiceTemplate[] = [
  { key: "screen", name: "Thay màn hình", desc: "Màn hình chính hãng, hiển thị sắc nét, cảm ứng mượt mà", price: 3500000, icon: "📱", iconBg: "#eff6ff", isPopular: true },
  { key: "battery", name: "Thay pin", desc: "Pin chính hãng, dung lượng chuẩn, bảo hành dài hạn", price: 1500000, icon: "🔋", iconBg: "#ecfdf5", isPopular: true },
  { key: "camera", name: "Thay camera", desc: "Camera chính hãng, chụp ảnh sắc nét, lấy nét nhanh", price: 800000, icon: "📷", iconBg: "#eff6ff" },
  { key: "speaker", name: "Sửa loa", desc: "Khôi phục âm thanh rõ ràng, không rè, không nhỏ", price: 300000, icon: "🔊", iconBg: "#f5f3ff" },
  { key: "port", name: "Sửa cổng sạc", desc: "Sạc ổn định, tiếp xúc tốt, không lỏng lẻo", price: 400000, icon: "🔌", iconBg: "#eff6ff" },
  { key: "case", name: "Thay vỏ", desc: "Vỏ chính hãng, khôi phục ngoại hình như mới", price: 1200000, icon: "📱", iconBg: "#f5f3ff" },
  { key: "power", name: "Sửa nút nguồn", desc: "Khắc phục lỗi nút nguồn, nhạy và bền bỉ", price: 350000, icon: "⏻", iconBg: "#eff6ff" },
  { key: "clean", name: "Vệ sinh máy", desc: "Vệ sinh tổng thể, tản nhiệt tốt hơn, tăng hiệu năng", price: 200000, icon: "🪄", iconBg: "#eff6ff" },
  { key: "software", name: "Cài đặt phần mềm", desc: "Cài đặt iOS, khôi phục dữ liệu, kiểm tra phần mềm", price: 150000, icon: "⚙️", iconBg: "#eff6ff" },
]

const BRAND_TABS = [
  { name: "Apple", logo: "apple" },
  { name: "Samsung", logo: "samsung" },
  { name: "Xiaomi", logo: "xiaomi" },
  { name: "Oppo", logo: "oppo" },
  { name: "Vivo", logo: "vivo" },
  { name: "Realme", logo: "realme" },
  { name: "Google", logo: "google" },
  { name: "Honor", logo: "honor" },
]

interface BranchMeta {
  id: number
  name: string
  address: string
  distance: string
  hours: string
  phone: string
  tags: { text: string; bg: string; color: string }[]
  image: string
  mapX: number // percentage for svg map
  mapY: number
}

const MOCKUP_BRANCHES: BranchMeta[] = [
  {
    id: 1,
    name: "PhoneRepair Quận 1",
    address: "123 Nguyễn Huệ, Quận 1, TP.HCM",
    distance: "2.1 km",
    hours: "08:00 - 20:00",
    phone: "028 1234 5678",
    tags: [
      { text: "Gần bạn", bg: "#dcfce7", color: "#16a34a" },
      { text: "Đông khách", bg: "#ffedd5", color: "#ea580c" },
    ],
    image: "https://images.unsplash.com/photo-1577705998148-6da4f3963bc8?auto=format&fit=crop&w=320&q=80",
    mapX: 42,
    mapY: 48,
  },
  {
    id: 2,
    name: "PhoneRepair Quận 7",
    address: "456 Nguyễn Thị Thập, Quận 7, TP.HCM",
    distance: "5.3 km",
    hours: "08:00 - 20:00",
    phone: "028 2345 6789",
    tags: [
      { text: "Bãi đỗ xe", bg: "#e0f2fe", color: "#0284c7" },
      { text: "Thoáng hơn", bg: "#dcfce7", color: "#16a34a" },
    ],
    image: "https://images.unsplash.com/photo-1555529771-835f59fc5efe?auto=format&fit=crop&w=320&q=80",
    mapX: 58,
    mapY: 76,
  },
  {
    id: 3,
    name: "PhoneRepair Thủ Đức",
    address: "789 Võ Văn Ngân, Thủ Đức, TP.HCM",
    distance: "8.7 km",
    hours: "08:00 - 20:00",
    phone: "028 3456 7890",
    tags: [
      { text: "Rộng rãi", bg: "#e0f2fe", color: "#0284c7" },
      { text: "Ít chờ đợi", bg: "#dcfce7", color: "#16a34a" },
    ],
    image: "https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&w=320&q=80",
    mapX: 72,
    mapY: 28,
  },
]

// 18 standard time slots matching mockup screenshot
const TIME_SLOTS_PRESET = [
  { start: "08:00", end: "08:30", isFull: false },
  { start: "08:30", end: "09:00", isFull: false },
  { start: "09:00", end: "09:30", isFull: false },
  { start: "09:30", end: "10:00", isFull: false },
  { start: "10:00", end: "10:30", isFull: false },
  { start: "10:30", end: "11:00", isFull: false },
  { start: "11:00", end: "11:30", isFull: false },
  { start: "11:30", end: "12:00", isFull: false },
  { start: "13:00", end: "13:30", isFull: false },
  { start: "13:30", end: "14:00", isFull: false },
  { start: "14:00", end: "14:30", isFull: false },
  { start: "14:30", end: "15:00", isFull: false },
  { start: "15:00", end: "15:30", isFull: false },
  { start: "15:30", end: "16:00", isFull: false },
  { start: "16:00", end: "16:30", isFull: true },
  { start: "16:30", end: "17:00", isFull: true },
  { start: "17:00", end: "17:30", isFull: false },
  { start: "17:30", end: "18:00", isFull: true },
]

function formatVietnameseDate(isoDate: string) {
  if (!isoDate) return ""
  const [y, m, d] = isoDate.split("-").map(Number)
  const dt = new Date(y, m - 1, d)
  const days = ["Chủ Nhật", "Thứ Hai", "Thứ Ba", "Thứ Tư", "Thứ Năm", "Thứ Sáu", "Thứ Bảy"]
  const dayName = days[dt.getDay()]
  return `${dayName}, ${d} tháng ${m}, ${y}`
}

export function BookingWizardPage() {
  const { token, user } = useAuth()
  const [searchParams] = useSearchParams()
  const initialBranchParam = searchParams.get("branchId")

  // Wizard state:
  // 0 = Bước 1: Chọn máy & dịch vụ
  // 1 = Bước 2: Chọn chi nhánh + Ngày & giờ (khớp mockup ảnh 2)
  // 2 = Bước 3: Thông tin khách hàng & mô tả
  // 3 = Bước 4: Xác nhận đặt lịch
  // 4 = Bước 5: Thành công (mã đặt lịch)
  const [activeStep, setActiveStep] = useState(0)

  // Data from backend
  const [brands, setBrands] = useState<Brand[]>([])
  const [models, setModels] = useState<PhoneModel[]>([])
  const [prices, setPrices] = useState<ServicePrice[]>([])
  const [branches, setBranches] = useState<Branch[]>([])
  const [slots, setSlots] = useState<Slot[]>([])

  // User selections
  const [selectedBrandName, setSelectedBrandName] = useState("Apple")
  const [selectedModelName, setSelectedModelName] = useState("iPhone 16")
  const [modelSearch, setModelSearch] = useState("")
  const [selectedStorage, setSelectedStorage] = useState("128GB")
  const [selectedColor, setSelectedColor] = useState("Đen")
  const [selectedCondition, setSelectedCondition] = useState("Bật nguồn, ngoại hình tốt")

  // Selected services (default to "Thay màn hình" matching mockup 2)
  const [selectedServiceNames, setSelectedServiceNames] = useState<string[]>(["Thay màn hình"])
  const [selectedBranchId, setSelectedBranchId] = useState<number>(initialBranchParam ? Number(initialBranchParam) : 1)

  // Calendar & Slot selection: default to "2024-10-15" and "08:30" matching mockup screenshot
  const [appointmentDate, setAppointmentDate] = useState("2024-10-15")
  const [calendarMonth, setCalendarMonth] = useState(9) // 0-indexed: 9 = October
  const [calendarYear, setCalendarYear] = useState(2024)
  const [selectedSlot, setSelectedSlot] = useState("08:30")

  // Customer info & description
  const [customerName, setCustomerName] = useState(user?.fullName || "Nguyễn Văn A")
  const [customerPhone, setCustomerPhone] = useState(user?.phoneNumber || "0901234567")
  const [problemDescription, setProblemDescription] = useState("Màn hình bị nứt kính và cảm ứng hơi đơ góc trên bên phải.")

  const [saving, setSaving] = useState(false)
  const [errorMessage, setErrorMessage] = useState("")
  const [createdBooking, setCreatedBooking] = useState<BookingDetail | null>(null)

  // Fetch catalog brands & branches
  useEffect(() => {
    getBrands().then(setBrands).catch(() => {})
    getBranches()
      .then((brList) => {
        setBranches(brList)
        if (!selectedBranchId && brList.length > 0) {
          setSelectedBranchId(brList[0].id)
        }
      })
      .catch(() => {})
  }, [selectedBranchId])

  // Fetch models for brand
  useEffect(() => {
    const brand = brands.find((b) => b.name.toLowerCase() === selectedBrandName.toLowerCase())
    if (brand) {
      getModels(brand.id)
        .then(setModels)
        .catch(() => setModels([]))
    }
  }, [brands, selectedBrandName])

  // Fetch prices for selected model
  const activeModel = models.find((m) => m.name.toLowerCase() === selectedModelName.toLowerCase())
  useEffect(() => {
    if (activeModel) {
      getPrices(activeModel.id)
        .then(setPrices)
        .catch(() => setPrices([]))
    }
  }, [activeModel])

  // Fetch time slots when branch and date change
  useEffect(() => {
    if (selectedBranchId && appointmentDate) {
      getSlots(selectedBranchId, appointmentDate)
        .then((s) => {
          setSlots(s)
        })
        .catch(() => setSlots([]))
    }
  }, [selectedBranchId, appointmentDate])

  // Calculate pricing
  const totalAmount = useMemo(() => {
    return selectedServiceNames.reduce((sum, sName) => {
      const template = SERVICE_TEMPLATES.find((t) => t.name === sName)
      const serverPrice = prices.find((p) => p.repairServiceName.toLowerCase() === sName.toLowerCase() && p.price)
      return sum + (serverPrice?.price ?? template?.price ?? 0)
    }, 0)
  }, [selectedServiceNames, prices])

  // Merge backend slots with preset slots
  const effectiveSlots = useMemo(() => {
    if (!slots || slots.length === 0) return TIME_SLOTS_PRESET
    return TIME_SLOTS_PRESET.map((p) => {
      const match = slots.find((s) => s.start === p.start)
      return match ? { ...p, isFull: match.isFull } : p
    })
  }, [slots])

  const effectiveBranches = useMemo(() => {
    if (branches.length === 0) return MOCKUP_BRANCHES
    return MOCKUP_BRANCHES.map((mb) => {
      const match = branches.find((b) => b.id === mb.id)
      return match ? { ...mb, name: match.name, address: match.address, phone: match.phone } : mb
    })
  }, [branches])

  const toggleService = (sName: string) => {
    setSelectedServiceNames((prev) =>
      prev.includes(sName) ? prev.filter((n) => n !== sName) : [...prev, sName]
    )
  }

  const removeService = (sName: string) => {
    setSelectedServiceNames((prev) => prev.filter((n) => n !== sName))
  }

  const handleNextStep = () => {
    setErrorMessage("")
    if (activeStep === 0) {
      if (selectedServiceNames.length === 0) {
        setErrorMessage("Vui lòng chọn ít nhất một dịch vụ sửa chữa.")
        return
      }
      setActiveStep(1)
    } else if (activeStep === 1) {
      if (!selectedBranchId) {
        setErrorMessage("Vui lòng chọn một chi nhánh.")
        return
      }
      if (!appointmentDate || !selectedSlot) {
        setErrorMessage("Vui lòng chọn ngày và giờ hẹn.")
        return
      }
      setActiveStep(2) // Move to Thông tin
    } else if (activeStep === 2) {
      if (!customerName.trim() || !customerPhone.trim()) {
        setErrorMessage("Vui lòng nhập họ tên và số điện thoại liên hệ.")
        return
      }
      if (!problemDescription.trim()) {
        setErrorMessage("Vui lòng nhập mô tả tình trạng máy.")
        return
      }
      setActiveStep(3) // Move to Xác nhận
    } else if (activeStep === 3) {
      handleSubmitBooking()
    }
  }

  const handlePrevStep = () => {
    setErrorMessage("")
    if (activeStep > 0) setActiveStep((prev) => prev - 1)
  }

  const handleSubmitBooking = async () => {
    if (!token) {
      setErrorMessage("Vui lòng đăng nhập để hoàn tất đặt lịch.")
      return
    }

    const modelToBook = models.find((m) => m.name.toLowerCase() === selectedModelName.toLowerCase()) || models[0]
    if (!modelToBook || !selectedBranchId || !appointmentDate || !selectedSlot) {
      setErrorMessage("Thông tin đặt lịch chưa đầy đủ.")
      return
    }

    const serviceIdsToBook = prices
      .filter((p) => selectedServiceNames.some((sn) => sn.toLowerCase() === p.repairServiceName.toLowerCase()))
      .map((p) => p.repairServiceId)

    setSaving(true)
    setErrorMessage("")
    try {
      const created = await createBooking(token, {
        phoneModelId: modelToBook.id,
        repairServiceIds: serviceIdsToBook.length > 0 ? serviceIdsToBook : [1],
        branchId: selectedBranchId,
        appointmentDate,
        slotStart: selectedSlot,
        problemDescription: problemDescription.trim(),
      })
      setCreatedBooking(created)
      setActiveStep(4)
    } catch (err) {
      if (err instanceof ApiError) {
        setErrorMessage(err.message)
      } else {
        setErrorMessage("Không thể tạo lịch hẹn. Vui lòng thử lại.")
      }
    } finally {
      setSaving(false)
    }
  }

  const formatVnd = (price: number) => {
    return price.toLocaleString("vi-VN") + "đ"
  }

  const activeBranch = effectiveBranches.find((b) => b.id === selectedBranchId) || effectiveBranches[0]
  const activeSlotObj = effectiveSlots.find((s) => s.start === selectedSlot) || effectiveSlots[1]

  // Calendar days generation for current calendarMonth & calendarYear
  const calendarDays = useMemo(() => {
    const daysInMonth = new Date(calendarYear, calendarMonth + 1, 0).getDate()
    const firstDayOfWeek = new Date(calendarYear, calendarMonth, 1).getDay() // 0 = Sun, 1 = Mon
    // Convert to Mon=0..Sun=6
    const offset = (firstDayOfWeek + 6) % 7

    const days: { day: number; isCurrentMonth: boolean; dateStr: string }[] = []

    // Previous month filler
    const prevMonthDays = new Date(calendarYear, calendarMonth, 0).getDate()
    for (let i = offset - 1; i >= 0; i--) {
      const d = prevMonthDays - i
      days.push({ day: d, isCurrentMonth: false, dateStr: "" })
    }

    // Current month days
    for (let d = 1; d <= daysInMonth; d++) {
      const monthStr = String(calendarMonth + 1).padStart(2, "0")
      const dayStr = String(d).padStart(2, "0")
      days.push({
        day: d,
        isCurrentMonth: true,
        dateStr: `${calendarYear}-${monthStr}-${dayStr}`,
      })
    }

    return days
  }, [calendarMonth, calendarYear])

  if (activeStep === 4 && createdBooking) {
    return (
      <BookingSuccessPage
        initialData={{
          booking: createdBooking,
          customerName,
          customerPhone,
          customerEmail: user?.email || "nguyenvana@gmail.com",
          modelName: selectedModelName,
          brandName: selectedBrandName,
          storage: selectedStorage,
          color: selectedColor,
          condition: selectedCondition,
          imei: "355012345678901",
          branchName: activeBranch.name,
          branchAddress: activeBranch.address,
          branchPhone: activeBranch.phone,
          appointmentDate: formatVietnameseDate(appointmentDate),
          slotTime: `${activeSlotObj.start} - ${activeSlotObj.end}`,
          services: selectedServiceNames.map((sn) => {
            const tmpl = SERVICE_TEMPLATES.find((t) => t.name === sn)
            const sPrice = prices.find((p) => p.repairServiceName.toLowerCase() === sn.toLowerCase() && p.price)
            return {
              name: sn,
              price: sPrice?.price ?? tmpl?.price ?? 0,
              desc: tmpl?.desc,
              icon: tmpl?.icon,
              iconBg: tmpl?.iconBg,
            }
          }),
          totalAmount,
        }}
      />
    )
  }

  return (
    <main style={{ background: "#f8fafc", minHeight: "100vh", padding: "24px 20px 60px" }}>
      <div style={{ maxWidth: "1340px", margin: "0 auto" }}>
        {/* TOP BREADCRUMB & PAGE TITLE */}
        <div style={{ marginBottom: "20px" }}>
          <Link
            to="/"
            style={{
              display: "inline-flex",
              alignItems: "center",
              gap: "6px",
              fontSize: "0.85rem",
              color: "#64748b",
              textDecoration: "none",
              marginBottom: "12px",
              fontWeight: 500,
            }}
          >
            <span>←</span>
            <span>Quay lại trang chủ</span>
          </Link>

          <h1 style={{ fontSize: "1.75rem", fontWeight: 800, color: "#0f172a", margin: "0 0 24px", letterSpacing: "-0.02em" }}>
            Đặt lịch sửa chữa
          </h1>

          {/* STEPPER PROGRESS BAR (5 STEPS MATCHING SCREENSHOT) */}
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", maxWidth: "860px", position: "relative" }}>
            {[
              { num: 1, label: "Chọn máy" },
              { num: 2, label: "Chọn chi nhánh" },
              { num: 3, label: "Ngày & giờ" },
              { num: 4, label: "Thông tin" },
              { num: 5, label: "Xác nhận" },
            ].map((st, i) => {
              // In step 1 (activeStep=0), circle 1 is active (blue).
              // In step 2 (activeStep=1, which contains both Branch & Date/Time):
              // Circle 1 has checkmark, Circle 2 is active (blue).
              const isDone = activeStep > 0 && i === 0
              const isCurrent = (activeStep === 0 && i === 0) || (activeStep === 1 && i === 1) || (activeStep === 2 && i === 3) || (activeStep === 3 && i === 4)

              return (
                <div key={st.num} style={{ display: "flex", flexDirection: "column", alignItems: "center", position: "relative", zIndex: 2 }}>
                  <div
                    onClick={() => {
                      if (i === 0 && activeStep > 0) setActiveStep(0)
                      if (i === 1 && activeStep > 1) setActiveStep(1)
                    }}
                    style={{
                      width: "32px",
                      height: "32px",
                      borderRadius: "50%",
                      background: isDone || isCurrent ? "#2563eb" : "#ffffff",
                      border: isDone || isCurrent ? "2px solid #2563eb" : "2px solid #cbd5e1",
                      color: isDone || isCurrent ? "#ffffff" : "#64748b",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      fontSize: "0.85rem",
                      fontWeight: 800,
                      cursor: (i === 0 && activeStep > 0) || (i === 1 && activeStep > 1) ? "pointer" : "default",
                      boxShadow: isCurrent ? "0 4px 12px rgba(37,99,235,0.3)" : "none",
                      transition: "all 0.2s ease",
                    }}
                  >
                    {isDone ? "✓" : st.num}
                  </div>
                  <span
                    style={{
                      fontSize: "0.82rem",
                      fontWeight: isCurrent ? 800 : 600,
                      color: isCurrent ? "#0f172a" : "#64748b",
                      marginTop: "6px",
                      whiteSpace: "nowrap",
                    }}
                  >
                    {st.label}
                  </span>
                </div>
              )
            })}

            {/* CONNECTING STEP LINE */}
            <div
              style={{
                position: "absolute",
                top: "16px",
                left: "40px",
                right: "40px",
                height: "2px",
                background: "#e2e8f0",
                zIndex: 1,
              }}
            >
              <div
                style={{
                  height: "100%",
                  width: activeStep >= 1 ? "25%" : "0%",
                  background: "#2563eb",
                  transition: "width 0.3s ease",
                }}
              />
            </div>
          </div>
        </div>

        {errorMessage && (
          <div style={{ background: "#fef2f2", border: "1px solid #fecaca", color: "#dc2626", borderRadius: "10px", padding: "12px 16px", marginBottom: "20px", fontSize: "0.88rem" }}>
            {errorMessage}
          </div>
        )}

        {/* MAIN 2-COLUMN LAYOUT: WIZARD BODY (LEFT) & STICKY SUMMARY (RIGHT) */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 360px", gap: "28px", alignItems: "flex-start" }}>
          {/* LEFT COLUMN */}
          <div style={{ background: "#ffffff", border: "1px solid #e2e8f0", borderRadius: "20px", padding: "26px", boxShadow: "0 2px 10px rgba(15,23,42,0.03)" }}>
            {/* ================= STEP 0: CHỌN MÁY & DỊCH VỤ ================= */}
            {activeStep === 0 && (
              <div>
                {/* 1. CHỌN HÃNG VÀ DÒNG MÁY */}
                <div style={{ marginBottom: "28px" }}>
                  <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "4px" }}>
                    <div style={{ width: "24px", height: "24px", borderRadius: "50%", background: "#2563eb", color: "#ffffff", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "0.8rem", fontWeight: 800 }}>
                      1
                    </div>
                    <h2 style={{ fontSize: "1.05rem", fontWeight: 800, color: "#0f172a", margin: 0 }}>
                      Chọn hãng và dòng máy
                    </h2>
                  </div>
                  <p style={{ fontSize: "0.82rem", color: "#64748b", margin: "0 0 16px 34px" }}>
                    Chọn thương hiệu điện thoại và model thiết bị của bạn
                  </p>

                  {/* 8 BRAND PILL BUTTONS */}
                  <div style={{ display: "flex", gap: "10px", overflowX: "auto", paddingBottom: "6px", marginBottom: "22px" }}>
                    {BRAND_TABS.map((b) => {
                      const isActive = selectedBrandName === b.name
                      return (
                        <button
                          key={b.name}
                          type="button"
                          onClick={() => setSelectedBrandName(b.name)}
                          style={{
                            padding: "8px 18px",
                            borderRadius: "10px",
                            border: isActive ? "1.5px solid #2563eb" : "1px solid #e2e8f0",
                            background: isActive ? "#eff6ff" : "#ffffff",
                            color: isActive ? "#2563eb" : "#334155",
                            fontWeight: isActive ? 700 : 500,
                            fontSize: "0.86rem",
                            cursor: "pointer",
                            display: "flex",
                            alignItems: "center",
                            gap: "8px",
                            whiteSpace: "nowrap",
                            transition: "all 0.15s ease",
                          }}
                        >
                          {b.logo === "apple" && (
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
                              <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.81-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M15.97 6.37c.63-.76 1.05-1.82.93-2.87-.9.04-2 .6-2.65 1.36-.58.67-.99 1.76-.85 2.78 1 .08 2.05-.51 2.57-1.27z" />
                            </svg>
                          )}
                          {b.logo === "samsung" && <span style={{ fontWeight: 800, fontSize: "0.76rem", color: "#1428a0" }}>SAMSUNG</span>}
                          {b.logo === "xiaomi" && <span style={{ background: "#ff6700", color: "white", padding: "1px 3px", borderRadius: "3px", fontSize: "0.6rem", fontWeight: 800 }}>mi</span>}
                          {b.logo === "oppo" && <span style={{ fontWeight: 800, fontSize: "0.76rem", color: "#008853" }}>Oppo</span>}
                          {b.logo === "vivo" && <span style={{ fontWeight: 800, fontSize: "0.76rem", color: "#415fff" }}>Vivo</span>}
                          {b.logo === "realme" && <span style={{ background: "#ffc915", color: "#000", padding: "1px 4px", borderRadius: "3px", fontSize: "0.62rem", fontWeight: 900 }}>R</span>}
                          {b.logo === "google" && <span style={{ fontWeight: 800, fontSize: "0.76rem", color: "#4285F4" }}>Google</span>}
                          {b.logo === "honor" && <span style={{ fontWeight: 800, fontSize: "0.76rem" }}>Honor</span>}
                          <span>{b.name}</span>
                        </button>
                      )
                    })}
                  </div>

                  {/* CHỌN DÒNG MÁY HEADER & SEARCH */}
                  <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "16px" }}>
                    <span style={{ fontSize: "0.95rem", fontWeight: 800, color: "#0f172a" }}>
                      Chọn dòng máy {selectedBrandName}
                    </span>

                    <div style={{ position: "relative", width: "230px" }}>
                      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#94a3b8" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" style={{ position: "absolute", left: "10px", top: "10px" }}>
                        <circle cx="11" cy="11" r="8" />
                        <line x1="21" y1="21" x2="16.65" y2="16.65" />
                      </svg>
                      <input
                        type="text"
                        placeholder={`Tìm kiếm model ${selectedBrandName}...`}
                        value={modelSearch}
                        onChange={(e) => setModelSearch(e.target.value)}
                        style={{
                          width: "100%",
                          height: "34px",
                          padding: "0 10px 0 32px",
                          borderRadius: "8px",
                          border: "1px solid #cbd5e1",
                          fontSize: "0.82rem",
                          background: "#f8fafc",
                          outline: "none",
                        }}
                      />
                    </div>
                  </div>

                  {/* 12 PHONE MODEL CARDS */}
                  <div style={{ display: "grid", gridTemplateColumns: "repeat(6, 1fr)", gap: "12px" }}>
                    {MOCKUP_IPHONE_MODELS.filter((m) => m.name.toLowerCase().includes(modelSearch.toLowerCase())).map((m) => {
                      const isSelected = selectedModelName.toLowerCase() === m.name.toLowerCase()
                      return (
                        <div
                          key={m.name}
                          onClick={() => setSelectedModelName(m.name)}
                          style={{
                            background: isSelected ? "#eff6ff" : "#ffffff",
                            border: isSelected ? "1.5px solid #2563eb" : "1px solid #e2e8f0",
                            borderRadius: "12px",
                            padding: "12px 8px 10px",
                            display: "flex",
                            flexDirection: "column",
                            alignItems: "center",
                            cursor: "pointer",
                            position: "relative",
                            transition: "all 0.15s ease",
                            boxShadow: isSelected ? "0 4px 12px rgba(37,99,235,0.12)" : "none",
                          }}
                        >
                          {/* CHECKBOX INDICATOR TOP-LEFT */}
                          <div
                            style={{
                              position: "absolute",
                              top: "6px",
                              left: "6px",
                              width: "18px",
                              height: "18px",
                              borderRadius: "4px",
                              border: isSelected ? "none" : "1.5px solid #cbd5e1",
                              background: isSelected ? "#2563eb" : "#ffffff",
                              display: "flex",
                              alignItems: "center",
                              justifyContent: "center",
                              color: "#ffffff",
                              fontSize: "0.72rem",
                              fontWeight: 800,
                            }}
                          >
                            {isSelected ? "✓" : ""}
                          </div>

                          {/* SMARTPHONE IMAGE */}
                          <img
                            src={m.image}
                            alt={m.name}
                            style={{
                              width: "58px",
                              height: "76px",
                              objectFit: "contain",
                              marginBottom: "8px",
                              filter: "drop-shadow(0 4px 6px rgba(0,0,0,0.06))",
                            }}
                          />

                          <strong style={{ fontSize: "0.84rem", color: "#0f172a", textAlign: "center", display: "block" }}>
                            {m.name}
                          </strong>
                          <span style={{ fontSize: "0.72rem", color: "#94a3b8", textAlign: "center" }}>
                            ({m.year})
                          </span>
                        </div>
                      )
                    })}
                  </div>
                </div>

                {/* 2. CHỌN DỊCH VỤ SỬA CHỮA */}
                <div>
                  <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "4px" }}>
                    <div style={{ width: "24px", height: "24px", borderRadius: "50%", background: "#2563eb", color: "#ffffff", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "0.8rem", fontWeight: 800 }}>
                      2
                    </div>
                    <h2 style={{ fontSize: "1.05rem", fontWeight: 800, color: "#0f172a", margin: 0 }}>
                      Chọn dịch vụ sửa chữa
                    </h2>
                  </div>
                  <p style={{ fontSize: "0.82rem", color: "#64748b", margin: "0 0 18px 34px" }}>
                    Chọn một hoặc nhiều dịch vụ cần sửa chữa cho {selectedModelName}. Bạn có thể chọn nhiều dịch vụ cùng lúc.
                  </p>

                  {/* 9 REPAIR SERVICE CARDS */}
                  <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "14px" }}>
                    {SERVICE_TEMPLATES.map((svc) => {
                      const isChecked = selectedServiceNames.includes(svc.name)
                      return (
                        <div
                          key={svc.key}
                          onClick={() => toggleService(svc.name)}
                          style={{
                            background: isChecked ? "#eff6ff" : "#ffffff",
                            border: isChecked ? "1.5px solid #2563eb" : "1px solid #e2e8f0",
                            borderRadius: "14px",
                            padding: "14px",
                            display: "flex",
                            flexDirection: "column",
                            justifyContent: "space-between",
                            cursor: "pointer",
                            position: "relative",
                            transition: "all 0.15s ease",
                            minHeight: "115px",
                          }}
                        >
                          <div style={{ display: "flex", alignItems: "flex-start", gap: "10px" }}>
                            <div
                              style={{
                                width: "18px",
                                height: "18px",
                                borderRadius: "4px",
                                border: isChecked ? "none" : "1.5px solid #cbd5e1",
                                background: isChecked ? "#2563eb" : "#ffffff",
                                display: "flex",
                                alignItems: "center",
                                justifyContent: "center",
                                color: "#ffffff",
                                fontSize: "0.72rem",
                                fontWeight: 800,
                                flexShrink: 0,
                                marginTop: "2px",
                              }}
                            >
                              {isChecked ? "✓" : ""}
                            </div>

                            <div
                              style={{
                                width: "36px",
                                height: "36px",
                                borderRadius: "8px",
                                background: svc.iconBg,
                                display: "flex",
                                alignItems: "center",
                                justifyContent: "center",
                                fontSize: "1.2rem",
                                flexShrink: 0,
                              }}
                            >
                              {svc.icon}
                            </div>

                            <div style={{ flex: 1 }}>
                              <h3 style={{ fontSize: "0.92rem", fontWeight: 800, color: "#0f172a", margin: "0 0 4px" }}>
                                {svc.name}
                              </h3>
                              <p style={{ fontSize: "0.75rem", color: "#64748b", margin: 0, lineHeight: 1.35 }}>
                                {svc.desc}
                              </p>
                            </div>
                          </div>

                          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginTop: "12px", paddingLeft: "28px" }}>
                            <strong style={{ fontSize: "0.95rem", fontWeight: 800, color: "#0f172a" }}>
                              {formatVnd(svc.price)}
                            </strong>
                            {svc.isPopular && (
                              <span style={{ fontSize: "0.68rem", fontWeight: 700, color: "#dc2626", background: "#fef2f2", padding: "2px 8px", borderRadius: "999px", border: "1px solid #fecaca" }}>
                                Phổ biến
                              </span>
                            )}
                          </div>
                        </div>
                      )
                    })}
                  </div>
                </div>
              </div>
            )}

            {/* ================= STEP 1: CHỌN CHI NHÁNH & NGÀY GIỜ (MATCHING MOCKUP SCREENSHOT 2) ================= */}
            {activeStep === 1 && (
              <div>
                {/* 1. CHỌN CHI NHÁNH */}
                <div style={{ marginBottom: "32px" }}>
                  <h2 style={{ fontSize: "1.18rem", fontWeight: 800, color: "#0f172a", margin: "0 0 4px" }}>
                    Chọn chi nhánh
                  </h2>
                  <p style={{ fontSize: "0.84rem", color: "#64748b", margin: "0 0 16px" }}>
                    Chọn chi nhánh thuận tiện nhất để mang máy đến sửa chữa
                  </p>

                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "18px", alignItems: "stretch" }}>
                    {/* BRANCH CARDS LIST */}
                    <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
                      {effectiveBranches.map((b) => {
                        const isSelected = selectedBranchId === b.id
                        return (
                          <div
                            key={b.id}
                            onClick={() => setSelectedBranchId(b.id)}
                            style={{
                              background: isSelected ? "#f0f7ff" : "#ffffff",
                              border: isSelected ? "1.5px solid #2563eb" : "1px solid #e2e8f0",
                              borderRadius: "14px",
                              padding: "12px 14px",
                              display: "flex",
                              alignItems: "center",
                              gap: "12px",
                              cursor: "pointer",
                              transition: "all 0.15s ease",
                              boxShadow: isSelected ? "0 4px 14px rgba(37,99,235,0.08)" : "none",
                            }}
                          >
                            {/* RADIO BUTTON */}
                            <div
                              style={{
                                width: "18px",
                                height: "18px",
                                borderRadius: "50%",
                                border: isSelected ? "5px solid #2563eb" : "2px solid #cbd5e1",
                                background: "#ffffff",
                                flexShrink: 0,
                              }}
                            />

                            {/* STORE THUMBNAIL */}
                            <img
                              src={b.image}
                              alt={b.name}
                              style={{
                                width: "52px",
                                height: "52px",
                                borderRadius: "8px",
                                objectFit: "cover",
                                flexShrink: 0,
                              }}
                            />

                            {/* BRANCH INFO */}
                            <div style={{ flex: 1, minWidth: 0 }}>
                              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "3px" }}>
                                <strong style={{ fontSize: "0.92rem", color: "#0f172a", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                                  {b.name}
                                </strong>
                                <span style={{ fontSize: "0.75rem", color: "#2563eb", fontWeight: 600, display: "flex", alignItems: "center", gap: "2px" }}>
                                  📍 {b.distance}
                                </span>
                              </div>

                              <p style={{ fontSize: "0.76rem", color: "#64748b", margin: "0 0 6px", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                                {b.address}
                              </p>

                              <div style={{ display: "flex", alignItems: "center", gap: "10px", fontSize: "0.74rem", color: "#64748b", marginBottom: "6px" }}>
                                <span>🕒 {b.hours}</span>
                                <span>📞 {b.phone}</span>
                              </div>

                              {/* TAGS */}
                              <div style={{ display: "flex", gap: "6px" }}>
                                {b.tags.map((t) => (
                                  <span
                                    key={t.text}
                                    style={{
                                      fontSize: "0.68rem",
                                      fontWeight: 700,
                                      background: t.bg,
                                      color: t.color,
                                      padding: "2px 8px",
                                      borderRadius: "6px",
                                    }}
                                  >
                                    {t.text}
                                  </span>
                                ))}
                              </div>
                            </div>
                          </div>
                        )
                      })}
                    </div>

                    {/* INTERACTIVE MAP PREVIEW */}
                    <div
                      style={{
                        background: "#eaf2fa",
                        borderRadius: "14px",
                        border: "1px solid #cbd5e1",
                        position: "relative",
                        overflow: "hidden",
                        minHeight: "240px",
                      }}
                    >
                      {/* MAP VECTOR BACKGROUND (SAIGON RIVER & DISTRICTS) */}
                      <svg width="100%" height="100%" style={{ position: "absolute", top: 0, left: 0 }}>
                        <rect width="100%" height="100%" fill="#edf3f9" />
                        {/* River path */}
                        <path
                          d="M -20,20 Q 80,40 140,80 T 240,160 T 360,220 T 450,280"
                          fill="none"
                          stroke="#bde0fe"
                          strokeWidth="28"
                          strokeLinecap="round"
                        />
                        <path
                          d="M 140,80 Q 220,10 320,30 T 440,70"
                          fill="none"
                          stroke="#bde0fe"
                          strokeWidth="14"
                        />
                        {/* Area roads */}
                        <line x1="0" y1="120" x2="400" y2="120" stroke="#ffffff" strokeWidth="3" />
                        <line x1="160" y1="0" x2="160" y2="300" stroke="#ffffff" strokeWidth="3" />
                        <line x1="50" y1="210" x2="350" y2="210" stroke="#ffffff" strokeWidth="2.5" />
                      </svg>

                      {/* DISTRICT LABELS */}
                      <span style={{ position: "absolute", top: "18%", left: "14%", fontSize: "0.75rem", color: "#64748b", fontWeight: 700 }}>
                        Bình Thạnh
                      </span>
                      <span style={{ position: "absolute", top: "42%", left: "54%", fontSize: "0.75rem", color: "#64748b", fontWeight: 700 }}>
                        Thảo Điền
                      </span>
                      <span style={{ position: "absolute", bottom: "24%", left: "34%", fontSize: "0.75rem", color: "#64748b", fontWeight: 700 }}>
                        Quận 4
                      </span>
                      <span style={{ position: "absolute", bottom: "12%", right: "26%", fontSize: "0.75rem", color: "#64748b", fontWeight: 700 }}>
                        Tân Thuận
                      </span>

                      {/* MARKER 1: QUẬN 1 (PIN WITH TAIL & BADGE) */}
                      <div
                        onClick={() => setSelectedBranchId(1)}
                        style={{
                          position: "absolute",
                          top: "42%",
                          left: "38%",
                          cursor: "pointer",
                          display: "flex",
                          alignItems: "center",
                          gap: "4px",
                          zIndex: 5,
                        }}
                      >
                        <div
                          style={{
                            width: "26px",
                            height: "26px",
                            borderRadius: "50%",
                            background: selectedBranchId === 1 ? "#2563eb" : "#1e293b",
                            border: "3px solid #ffffff",
                            boxShadow: "0 3px 8px rgba(0,0,0,0.25)",
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "center",
                            color: "#ffffff",
                            fontSize: "0.75rem",
                          }}
                        >
                          📍
                        </div>
                        <span
                          style={{
                            background: selectedBranchId === 1 ? "#2563eb" : "#1e293b",
                            color: "#ffffff",
                            fontSize: "0.74rem",
                            fontWeight: 800,
                            padding: "2px 8px",
                            borderRadius: "999px",
                            boxShadow: "0 2px 6px rgba(0,0,0,0.2)",
                            whiteSpace: "nowrap",
                          }}
                        >
                          Quận 1
                        </span>
                      </div>

                      {/* MARKER 2: THỦ ĐỨC */}
                      <div
                        onClick={() => setSelectedBranchId(3)}
                        style={{
                          position: "absolute",
                          top: "22%",
                          right: "22%",
                          cursor: "pointer",
                          display: "flex",
                          alignItems: "center",
                          gap: "4px",
                          zIndex: 5,
                        }}
                      >
                        <div
                          style={{
                            width: "22px",
                            height: "22px",
                            borderRadius: "50%",
                            background: selectedBranchId === 3 ? "#2563eb" : "#1e293b",
                            border: "2px solid #ffffff",
                            boxShadow: "0 3px 8px rgba(0,0,0,0.25)",
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "center",
                            color: "#ffffff",
                            fontSize: "0.7rem",
                          }}
                        >
                          📍
                        </div>
                        <span
                          style={{
                            background: selectedBranchId === 3 ? "#2563eb" : "#1e293b",
                            color: "#ffffff",
                            fontSize: "0.72rem",
                            fontWeight: 700,
                            padding: "2px 8px",
                            borderRadius: "999px",
                            boxShadow: "0 2px 6px rgba(0,0,0,0.2)",
                            whiteSpace: "nowrap",
                          }}
                        >
                          Thủ Đức
                        </span>
                      </div>

                      {/* MARKER 3: QUẬN 7 */}
                      <div
                        onClick={() => setSelectedBranchId(2)}
                        style={{
                          position: "absolute",
                          bottom: "18%",
                          right: "32%",
                          cursor: "pointer",
                          display: "flex",
                          alignItems: "center",
                          gap: "4px",
                          zIndex: 5,
                        }}
                      >
                        <div
                          style={{
                            width: "22px",
                            height: "22px",
                            borderRadius: "50%",
                            background: selectedBranchId === 2 ? "#2563eb" : "#1e293b",
                            border: "2px solid #ffffff",
                            boxShadow: "0 3px 8px rgba(0,0,0,0.25)",
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "center",
                            color: "#ffffff",
                            fontSize: "0.7rem",
                          }}
                        >
                          📍
                        </div>
                        <span
                          style={{
                            background: selectedBranchId === 2 ? "#2563eb" : "#1e293b",
                            color: "#ffffff",
                            fontSize: "0.72rem",
                            fontWeight: 700,
                            padding: "2px 8px",
                            borderRadius: "999px",
                            boxShadow: "0 2px 6px rgba(0,0,0,0.2)",
                            whiteSpace: "nowrap",
                          }}
                        >
                          Quận 7
                        </span>
                      </div>

                      {/* MAP CONTROLS DOCKED ON RIGHT */}
                      <div
                        style={{
                          position: "absolute",
                          right: "10px",
                          bottom: "12px",
                          display: "flex",
                          flexDirection: "column",
                          gap: "6px",
                          zIndex: 6,
                        }}
                      >
                        <button
                          type="button"
                          style={{
                            width: "28px",
                            height: "28px",
                            borderRadius: "6px",
                            background: "#ffffff",
                            border: "1px solid #cbd5e1",
                            boxShadow: "0 2px 4px rgba(0,0,0,0.1)",
                            cursor: "pointer",
                            fontSize: "1rem",
                            fontWeight: 700,
                            color: "#334155",
                          }}
                        >
                          +
                        </button>
                        <button
                          type="button"
                          style={{
                            width: "28px",
                            height: "28px",
                            borderRadius: "6px",
                            background: "#ffffff",
                            border: "1px solid #cbd5e1",
                            boxShadow: "0 2px 4px rgba(0,0,0,0.1)",
                            cursor: "pointer",
                            fontSize: "1rem",
                            fontWeight: 700,
                            color: "#334155",
                          }}
                        >
                          −
                        </button>
                        <button
                          type="button"
                          style={{
                            width: "28px",
                            height: "28px",
                            borderRadius: "6px",
                            background: "#ffffff",
                            border: "1px solid #cbd5e1",
                            boxShadow: "0 2px 4px rgba(0,0,0,0.1)",
                            cursor: "pointer",
                            fontSize: "0.85rem",
                            color: "#334155",
                          }}
                        >
                          🎯
                        </button>
                      </div>
                    </div>
                  </div>
                </div>

                {/* 2. CHỌN NGÀY VÀ GIỜ (MATCHING MOCKUP SCREENSHOT 2) */}
                <div>
                  <h2 style={{ fontSize: "1.18rem", fontWeight: 800, color: "#0f172a", margin: "0 0 4px" }}>
                    Chọn ngày và giờ
                  </h2>
                  <p style={{ fontSize: "0.84rem", color: "#64748b", margin: "0 0 16px" }}>
                    Chọn ngày phù hợp và khung giờ đến cửa hàng
                  </p>

                  <div style={{ display: "grid", gridTemplateColumns: "310px 1fr", gap: "20px" }}>
                    {/* LEFT: MINI CALENDAR CARD */}
                    <div style={{ background: "#ffffff", border: "1px solid #e2e8f0", borderRadius: "14px", padding: "16px" }}>
                      {/* MONTH NAVIGATION HEADER */}
                      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "16px" }}>
                        <button
                          type="button"
                          onClick={() => {
                            if (calendarMonth === 0) {
                              setCalendarMonth(11)
                              setCalendarYear((y) => y - 1)
                            } else {
                              setCalendarMonth((m) => m - 1)
                            }
                          }}
                          style={{ background: "none", border: "none", fontSize: "1.1rem", cursor: "pointer", color: "#64748b", padding: "0 6px" }}
                        >
                          ‹
                        </button>

                        <strong style={{ fontSize: "0.92rem", fontWeight: 800, color: "#0f172a" }}>
                          Tháng {calendarMonth + 1}, {calendarYear}
                        </strong>

                        <button
                          type="button"
                          onClick={() => {
                            if (calendarMonth === 11) {
                              setCalendarMonth(0)
                              setCalendarYear((y) => y + 1)
                            } else {
                              setCalendarMonth((m) => m + 1)
                            }
                          }}
                          style={{ background: "none", border: "none", fontSize: "1.1rem", cursor: "pointer", color: "#64748b", padding: "0 6px" }}
                        >
                          ›
                        </button>
                      </div>

                      {/* WEEKDAYS HEADER (T2 -> CN) */}
                      <div style={{ display: "grid", gridTemplateColumns: "repeat(7, 1fr)", gap: "4px", textAlign: "center", marginBottom: "8px" }}>
                        {["T2", "T3", "T4", "T5", "T6", "T7", "CN"].map((w) => (
                          <span key={w} style={{ fontSize: "0.74rem", fontWeight: 700, color: "#94a3b8" }}>
                            {w}
                          </span>
                        ))}
                      </div>

                      {/* DAYS GRID */}
                      <div style={{ display: "grid", gridTemplateColumns: "repeat(7, 1fr)", gap: "4px", textAlign: "center" }}>
                        {calendarDays.map((item, idx) => {
                          const isSelectedDate = item.isCurrentMonth && item.dateStr === appointmentDate
                          return (
                            <button
                              key={idx}
                              type="button"
                              disabled={!item.isCurrentMonth}
                              onClick={() => {
                                if (item.isCurrentMonth) {
                                  setAppointmentDate(item.dateStr)
                                }
                              }}
                              style={{
                                width: "34px",
                                height: "34px",
                                margin: "0 auto",
                                borderRadius: "50%",
                                border: "none",
                                background: isSelectedDate ? "#2563eb" : "transparent",
                                color: isSelectedDate ? "#ffffff" : item.isCurrentMonth ? "#1e293b" : "#cbd5e1",
                                fontWeight: isSelectedDate ? 800 : 500,
                                fontSize: "0.82rem",
                                cursor: item.isCurrentMonth ? "pointer" : "default",
                                display: "flex",
                                alignItems: "center",
                                justifyContent: "center",
                                transition: "all 0.15s ease",
                              }}
                            >
                              {item.day}
                            </button>
                          )
                        })}
                      </div>
                    </div>

                    {/* RIGHT: TIME SLOTS PICKER */}
                    <div style={{ background: "#ffffff", border: "1px solid #e2e8f0", borderRadius: "14px", padding: "16px" }}>
                      {/* DATE TITLE & LEGEND */}
                      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "14px", flexWrap: "wrap", gap: "8px" }}>
                        <strong style={{ fontSize: "0.95rem", fontWeight: 800, color: "#0f172a" }}>
                          {formatVietnameseDate(appointmentDate)}
                        </strong>

                        {/* LEGEND */}
                        <div style={{ display: "flex", alignItems: "center", gap: "12px", fontSize: "0.74rem" }}>
                          <span style={{ display: "flex", alignItems: "center", gap: "4px", color: "#16a34a" }}>
                            <span style={{ width: "8px", height: "8px", borderRadius: "50%", background: "#16a34a" }} />
                            Còn trống
                          </span>
                          <span style={{ display: "flex", alignItems: "center", gap: "4px", color: "#2563eb" }}>
                            <span style={{ width: "8px", height: "8px", borderRadius: "50%", background: "#2563eb" }} />
                            Đang chọn
                          </span>
                          <span style={{ display: "flex", alignItems: "center", gap: "4px", color: "#94a3b8" }}>
                            <span style={{ width: "8px", height: "8px", borderRadius: "50%", background: "#cbd5e1" }} />
                            Đã đầy
                          </span>
                        </div>
                      </div>

                      {/* 18 SLOTS GRID (4 COLUMNS MATCHING SCREENSHOT) */}
                      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: "8px" }}>
                        {effectiveSlots.map((s) => {
                          const isSelected = selectedSlot === s.start
                          const isFull = s.isFull
                          return (
                            <button
                              key={s.start}
                              type="button"
                              disabled={isFull}
                              onClick={() => setSelectedSlot(s.start)}
                              style={{
                                padding: "9px 6px",
                                borderRadius: "8px",
                                border: isSelected ? "1.5px solid #2563eb" : isFull ? "1px solid #f1f5f9" : "1px solid #e2e8f0",
                                background: isSelected ? "#2563eb" : isFull ? "#f8fafc" : "#ffffff",
                                color: isSelected ? "#ffffff" : isFull ? "#94a3b8" : "#0f172a",
                                fontWeight: isSelected ? 800 : 600,
                                fontSize: "0.82rem",
                                cursor: isFull ? "not-allowed" : "pointer",
                                textAlign: "center",
                                transition: "all 0.15s ease",
                                display: "flex",
                                flexDirection: "column",
                                alignItems: "center",
                                justifyContent: "center",
                                minHeight: "42px",
                              }}
                            >
                              <span>{s.start}</span>
                              {isFull && (
                                <span style={{ fontSize: "0.65rem", color: "#94a3b8", marginTop: "1px" }}>
                                  Đã đầy
                                </span>
                              )}
                            </button>
                          )
                        })}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* ================= STEP 2: THÔNG TIN KHÁCH HÀNG ================= */}
            {activeStep === 2 && (
              <div>
                <h2 style={{ fontSize: "1.25rem", fontWeight: 800, color: "#0f172a", marginBottom: "6px" }}>
                  Bước 4: Thông tin khách hàng & mô tả lỗi
                </h2>
                <p style={{ fontSize: "0.86rem", color: "#64748b", marginBottom: "20px" }}>
                  Cung cấp thông tin liên hệ và mô tả ngắn gọn về tình trạng máy:
                </p>

                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "16px", marginBottom: "18px" }}>
                  <div>
                    <label style={{ display: "block", fontSize: "0.85rem", fontWeight: 700, color: "#0f172a", marginBottom: "6px" }}>
                      Họ và tên
                    </label>
                    <input
                      type="text"
                      value={customerName}
                      onChange={(e) => setCustomerName(e.target.value)}
                      style={{ width: "100%", padding: "10px 14px", borderRadius: "10px", border: "1px solid #cbd5e1", fontSize: "0.88rem" }}
                    />
                  </div>
                  <div>
                    <label style={{ display: "block", fontSize: "0.85rem", fontWeight: 700, color: "#0f172a", marginBottom: "6px" }}>
                      Số điện thoại
                    </label>
                    <input
                      type="tel"
                      value={customerPhone}
                      onChange={(e) => setCustomerPhone(e.target.value)}
                      style={{ width: "100%", padding: "10px 14px", borderRadius: "10px", border: "1px solid #cbd5e1", fontSize: "0.88rem" }}
                    />
                  </div>
                </div>

                <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "12px", marginBottom: "18px" }}>
                  <div>
                    <label style={{ display: "block", fontSize: "0.8rem", fontWeight: 700, color: "#0f172a", marginBottom: "6px" }}>
                      Dung lượng
                    </label>
                    <select
                      value={selectedStorage}
                      onChange={(e) => setSelectedStorage(e.target.value)}
                      style={{ width: "100%", padding: "8px 12px", borderRadius: "8px", border: "1px solid #cbd5e1", fontSize: "0.85rem" }}
                    >
                      <option value="64GB">64GB</option>
                      <option value="128GB">128GB</option>
                      <option value="256GB">256GB</option>
                      <option value="512GB">512GB</option>
                      <option value="1TB">1TB</option>
                    </select>
                  </div>
                  <div>
                    <label style={{ display: "block", fontSize: "0.8rem", fontWeight: 700, color: "#0f172a", marginBottom: "6px" }}>
                      Màu sắc
                    </label>
                    <select
                      value={selectedColor}
                      onChange={(e) => setSelectedColor(e.target.value)}
                      style={{ width: "100%", padding: "8px 12px", borderRadius: "8px", border: "1px solid #cbd5e1", fontSize: "0.85rem" }}
                    >
                      <option value="Đen">Đen</option>
                      <option value="Trắng">Trắng</option>
                      <option value="Titan Tự Nhiên">Titan Tự Nhiên</option>
                      <option value="Xanh Sa Mạc">Xanh Sa Mạc</option>
                    </select>
                  </div>
                  <div>
                    <label style={{ display: "block", fontSize: "0.8rem", fontWeight: 700, color: "#0f172a", marginBottom: "6px" }}>
                      Tình trạng sơ bộ
                    </label>
                    <input
                      type="text"
                      value={selectedCondition}
                      onChange={(e) => setSelectedCondition(e.target.value)}
                      style={{ width: "100%", padding: "8px 12px", borderRadius: "8px", border: "1px solid #cbd5e1", fontSize: "0.85rem" }}
                    />
                  </div>
                </div>

                <div style={{ marginBottom: "20px" }}>
                  <label style={{ display: "block", fontSize: "0.85rem", fontWeight: 700, color: "#0f172a", marginBottom: "6px" }}>
                    Mô tả chi tiết tình trạng lỗi của thiết bị
                  </label>
                  <textarea
                    rows={4}
                    value={problemDescription}
                    onChange={(e) => setProblemDescription(e.target.value)}
                    placeholder="Ví dụ: Rơi nứt kính, pin chai nhanh, màn hình xuất hiện sọc xanh..."
                    style={{ width: "100%", padding: "12px", borderRadius: "10px", border: "1px solid #cbd5e1", fontSize: "0.88rem", resize: "vertical" }}
                  />
                </div>
              </div>
            )}

            {/* ================= STEP 3: XÁC NHẬN LỊCH HẸN ================= */}
            {activeStep === 3 && (
              <div>
                <h2 style={{ fontSize: "1.25rem", fontWeight: 800, color: "#0f172a", marginBottom: "6px" }}>
                  Bước 5: Xác nhận thông tin lịch hẹn
                </h2>
                <p style={{ fontSize: "0.86rem", color: "#64748b", marginBottom: "20px" }}>
                  Vui lòng kiểm tra lại toàn bộ thông tin trước khi hoàn tất đặt chỗ:
                </p>

                <div style={{ background: "#f8fafc", border: "1px solid #e2e8f0", borderRadius: "14px", padding: "20px", display: "grid", gridTemplateColumns: "1fr 1fr", gap: "16px", marginBottom: "20px" }}>
                  <div>
                    <span style={{ fontSize: "0.8rem", color: "#64748b", display: "block" }}>Khách hàng:</span>
                    <strong style={{ fontSize: "0.95rem", color: "#0f172a" }}>{customerName}</strong>
                    <div style={{ fontSize: "0.85rem", color: "#0f172a" }}>{customerPhone}</div>
                  </div>
                  <div>
                    <span style={{ fontSize: "0.8rem", color: "#64748b", display: "block" }}>Thiết bị:</span>
                    <strong style={{ fontSize: "0.95rem", color: "#0f172a" }}>{selectedModelName} ({selectedBrandName})</strong>
                    <div style={{ fontSize: "0.82rem", color: "#64748b" }}>{selectedStorage} - {selectedColor}</div>
                  </div>
                  <div>
                    <span style={{ fontSize: "0.8rem", color: "#64748b", display: "block" }}>Chi nhánh tiếp nhận:</span>
                    <strong style={{ fontSize: "0.95rem", color: "#0f172a" }}>{activeBranch.name}</strong>
                    <div style={{ fontSize: "0.82rem", color: "#64748b" }}>{activeBranch.address}</div>
                  </div>
                  <div>
                    <span style={{ fontSize: "0.8rem", color: "#64748b", display: "block" }}>Thời gian hẹn:</span>
                    <strong style={{ fontSize: "0.95rem", color: "#2563eb" }}>{formatVietnameseDate(appointmentDate)}</strong>
                    <div style={{ fontSize: "0.85rem", fontWeight: 700, color: "#2563eb" }}>{activeSlotObj.start} - {activeSlotObj.end}</div>
                  </div>
                </div>

                <div style={{ marginBottom: "20px" }}>
                  <span style={{ fontSize: "0.8rem", color: "#64748b", display: "block", marginBottom: "4px" }}>Mô tả lỗi:</span>
                  <div style={{ background: "#ffffff", border: "1px solid #e2e8f0", borderRadius: "10px", padding: "12px", fontSize: "0.88rem", color: "#334155" }}>
                    {problemDescription}
                  </div>
                </div>

                {!token && (
                  <div style={{ background: "#fef3c7", border: "1px solid #fde68a", borderRadius: "10px", padding: "14px", color: "#92400e", fontSize: "0.85rem", marginBottom: "20px" }}>
                    Bạn chưa đăng nhập. Vui lòng{" "}
                    <Link to="/login" style={{ color: "#2563eb", fontWeight: 700, textDecoration: "underline" }}>
                      Đăng nhập tài khoản
                    </Link>{" "}
                    để hoàn tất gửi yêu cầu đặt lịch và theo dõi tiến độ sửa chữa.
                  </div>
                )}
              </div>
            )}
          </div>

          {/* RIGHT COLUMN: STICKY BOOKING SUMMARY (MATCHING SCREENSHOT 2) */}
          <aside
            style={{
              background: "#ffffff",
              border: "1px solid #e2e8f0",
              borderRadius: "20px",
              padding: "22px",
              position: "sticky",
              top: "90px",
              boxShadow: "0 2px 10px rgba(15,23,42,0.03)",
            }}
          >
            {/* HEADER */}
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "16px", borderBottom: "1px solid #f1f5f9", paddingBottom: "12px" }}>
              <h3 style={{ fontSize: "1.1rem", fontWeight: 800, color: "#0f172a", margin: 0 }}>
                Thông tin đặt lịch
              </h3>
              <button
                type="button"
                onClick={() => setActiveStep(0)}
                style={{ background: "none", border: "none", color: "#2563eb", fontSize: "0.82rem", fontWeight: 600, cursor: "pointer", display: "flex", alignItems: "center", gap: "4px" }}
              >
                <span>✏️ Chỉnh sửa</span>
              </button>
            </div>

            {/* BLOCK 1: THIẾT BỊ CỦA BẠN */}
            <div style={{ marginBottom: "16px" }}>
              <span style={{ fontSize: "0.82rem", fontWeight: 700, color: "#0f172a", display: "block", marginBottom: "6px" }}>
                Thiết bị
              </span>
              <div
                style={{
                  background: "#f8fafc",
                  border: "1px solid #e2e8f0",
                  borderRadius: "12px",
                  padding: "10px 12px",
                  display: "flex",
                  alignItems: "flex-start",
                  gap: "12px",
                }}
              >
                <img
                  src={MOCKUP_IPHONE_MODELS.find((m) => m.name.toLowerCase() === selectedModelName.toLowerCase())?.image || MOCKUP_IPHONE_MODELS[0].image}
                  alt={selectedModelName}
                  style={{ width: "36px", height: "46px", objectFit: "contain", flexShrink: 0 }}
                />
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: "6px", marginBottom: "4px" }}>
                    <strong style={{ fontSize: "0.92rem", color: "#0f172a" }}>{selectedModelName}</strong>
                    <span style={{ fontSize: "0.68rem", background: "#e2e8f0", color: "#475569", padding: "1px 6px", borderRadius: "4px" }}>
                      {selectedBrandName}
                    </span>
                  </div>

                  <div style={{ fontSize: "0.74rem", color: "#64748b", display: "flex", flexDirection: "column", gap: "2px" }}>
                    <div style={{ display: "flex", justifyContent: "space-between" }}>
                      <span>Dung lượng</span>
                      <strong style={{ color: "#334155" }}>{selectedStorage}</strong>
                    </div>
                    <div style={{ display: "flex", justifyContent: "space-between" }}>
                      <span>Màu sắc</span>
                      <strong style={{ color: "#334155" }}>{selectedColor}</strong>
                    </div>
                    <div style={{ display: "flex", justifyContent: "space-between" }}>
                      <span>Tình trạng</span>
                      <strong style={{ color: "#334155", textAlign: "right" }}>{selectedCondition}</strong>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* BLOCK 2: DỊCH VỤ SỬA CHỮA */}
            <div style={{ marginBottom: "16px" }}>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "8px" }}>
                <span style={{ fontSize: "0.82rem", fontWeight: 700, color: "#0f172a" }}>
                  Dịch vụ sửa chữa
                </span>
              </div>

              {selectedServiceNames.length === 0 ? (
                <p style={{ fontSize: "0.78rem", color: "#94a3b8", margin: 0, fontStyle: "italic" }}>
                  Chưa chọn dịch vụ nào
                </p>
              ) : (
                <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
                  {selectedServiceNames.map((sName) => {
                    const template = SERVICE_TEMPLATES.find((t) => t.name === sName)
                    return (
                      <div
                        key={sName}
                        style={{
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "space-between",
                          padding: "6px 0",
                          borderBottom: "1px dashed #f1f5f9",
                        }}
                      >
                        <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                          {/* RED X / DELETE BUTTON (MATCHING SCREENSHOT) */}
                          <button
                            type="button"
                            onClick={() => removeService(sName)}
                            title="Xóa dịch vụ"
                            style={{
                              width: "18px",
                              height: "18px",
                              borderRadius: "4px",
                              background: "#ef4444",
                              border: "none",
                              color: "#ffffff",
                              fontSize: "0.7rem",
                              fontWeight: 800,
                              cursor: "pointer",
                              display: "flex",
                              alignItems: "center",
                              justifyContent: "center",
                              padding: 0,
                            }}
                          >
                            ✕
                          </button>
                          <div>
                            <span style={{ fontSize: "0.84rem", fontWeight: 700, color: "#0f172a", display: "block" }}>
                              {sName}
                            </span>
                            <span style={{ fontSize: "0.72rem", color: "#94a3b8" }}>
                              Linh kiện chính hãng
                            </span>
                          </div>
                        </div>

                        <strong style={{ fontSize: "0.86rem", color: "#0f172a" }}>
                          {formatVnd(template?.price ?? 0)}
                        </strong>
                      </div>
                    )
                  })}
                </div>
              )}
            </div>

            {/* BLOCK 3: TẠM TÍNH, GIẢM GIÁ & TỔNG CỘNG */}
            <div style={{ borderTop: "1px solid #f1f5f9", paddingTop: "12px", marginBottom: "16px" }}>
              <div style={{ display: "flex", justifyContent: "space-between", fontSize: "0.82rem", color: "#64748b", marginBottom: "6px" }}>
                <span>Tạm tính</span>
                <strong style={{ color: "#0f172a" }}>{formatVnd(totalAmount)}</strong>
              </div>
              <div style={{ display: "flex", justifyContent: "space-between", fontSize: "0.82rem", color: "#64748b", marginBottom: "10px" }}>
                <span>Giảm giá</span>
                <span style={{ color: "#0f172a" }}>- 0đ</span>
              </div>
              <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", paddingTop: "8px", borderTop: "1px dashed #e2e8f0" }}>
                <span style={{ fontSize: "0.95rem", fontWeight: 800, color: "#0f172a" }}>Tổng cộng</span>
                <strong style={{ fontSize: "1.35rem", fontWeight: 900, color: "#2563eb" }}>
                  {formatVnd(totalAmount)}
                </strong>
              </div>
            </div>

            {/* BLOCK 4: CHI NHÁNH & NGÀY GIỜ (WHEN ON STEP 1 OR LATER) */}
            {activeStep >= 1 && (
              <div style={{ borderTop: "1px solid #f1f5f9", paddingTop: "12px", marginBottom: "14px" }}>
                {/* CHI NHÁNH */}
                <div style={{ marginBottom: "12px" }}>
                  <span style={{ fontSize: "0.8rem", fontWeight: 700, color: "#0f172a", display: "block", marginBottom: "6px" }}>
                    Chi nhánh
                  </span>
                  <div style={{ display: "flex", alignItems: "center", gap: "10px", background: "#f8fafc", padding: "8px 10px", borderRadius: "10px", border: "1px solid #e2e8f0" }}>
                    <img
                      src={activeBranch.image}
                      alt={activeBranch.name}
                      style={{ width: "36px", height: "36px", borderRadius: "6px", objectFit: "cover" }}
                    />
                    <div>
                      <strong style={{ fontSize: "0.84rem", color: "#0f172a", display: "block" }}>{activeBranch.name}</strong>
                      <span style={{ fontSize: "0.72rem", color: "#64748b" }}>📍 {activeBranch.address}</span>
                    </div>
                  </div>
                </div>

                {/* NGÀY & GIỜ */}
                <div>
                  <span style={{ fontSize: "0.8rem", fontWeight: 700, color: "#0f172a", display: "block", marginBottom: "6px" }}>
                    Ngày & giờ
                  </span>
                  <div style={{ background: "#f8fafc", padding: "8px 10px", borderRadius: "10px", border: "1px solid #e2e8f0", fontSize: "0.82rem", color: "#334155" }}>
                    <div style={{ display: "flex", alignItems: "center", gap: "6px", marginBottom: "4px" }}>
                      <span>📅</span>
                      <strong style={{ color: "#0f172a" }}>{formatVietnameseDate(appointmentDate)}</strong>
                    </div>
                    <div style={{ display: "flex", alignItems: "center", gap: "6px" }}>
                      <span>🕒</span>
                      <strong style={{ color: "#2563eb" }}>{activeSlotObj.start} - {activeSlotObj.end}</strong>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* INFO ALERT BOX */}
            <div
              style={{
                background: "#f0f9ff",
                border: "1px solid #bae6fd",
                borderRadius: "10px",
                padding: "10px 12px",
                display: "flex",
                gap: "8px",
                fontSize: "0.72rem",
                color: "#0369a1",
                lineHeight: 1.45,
                marginBottom: "18px",
              }}
            >
              <span>ℹ️</span>
              <span>
                Vui lòng đến đúng giờ hẹn. Nếu có thay đổi, bạn có thể hủy hoặc đổi lịch trước 2 giờ.
              </span>
            </div>

            {/* ACTION BUTTONS (QUAY LẠI & TIẾP TỤC) */}
            {activeStep < 4 && (
              <div style={{ display: "flex", gap: "10px" }}>
                <button
                  type="button"
                  disabled={activeStep === 0}
                  onClick={handlePrevStep}
                  style={{
                    height: "42px",
                    padding: "0 18px",
                    borderRadius: "10px",
                    border: "1px solid #cbd5e1",
                    background: "#ffffff",
                    color: activeStep === 0 ? "#94a3b8" : "#334155",
                    fontSize: "0.86rem",
                    fontWeight: 600,
                    cursor: activeStep === 0 ? "not-allowed" : "pointer",
                  }}
                >
                  Quay lại
                </button>
                <button
                  type="button"
                  disabled={saving}
                  onClick={handleNextStep}
                  style={{
                    flex: 1,
                    height: "42px",
                    borderRadius: "10px",
                    border: "none",
                    background: "#2563eb",
                    color: "#ffffff",
                    fontSize: "0.88rem",
                    fontWeight: 700,
                    cursor: saving ? "wait" : "pointer",
                    boxShadow: "0 4px 12px rgba(37,99,235,0.3)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    gap: "6px",
                  }}
                >
                  <span>{activeStep === 3 ? (saving ? "Đang xử lý..." : "Xác nhận đặt lịch") : "Tiếp tục"}</span>
                  <span>&gt;</span>
                </button>
              </div>
            )}
          </aside>
        </div>
      </div>
    </main>
  )
}
