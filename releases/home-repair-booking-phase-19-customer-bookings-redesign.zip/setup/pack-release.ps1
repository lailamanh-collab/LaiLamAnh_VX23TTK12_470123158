param(
    [Parameter(Mandatory = $true)]
    [string]$Name
)

$ErrorActionPreference = "Stop"
$root = Resolve-Path (Join-Path $PSScriptRoot "..")
$releases = Join-Path $root "releases"
New-Item -ItemType Directory -Force -Path $releases | Out-Null

$zipPath = Join-Path $releases "$Name.zip"
if (Test-Path $zipPath) {
    throw "Release already exists: $zipPath"
}

$excludeDirs = @(
    "node_modules", "bin", "obj", ".vs", ".idea", ".git", "releases",
    "dist", ".vite", "logs", "cache", "temp", "tmp", "progress-report", "thesis"
)
$excludeFiles = @(
    "PROJECT_REQUIREMENTS.md",
    "CHECKLIST.md",
    "AGENTS.md",
    "TODO.md",
    "ROADMAP.md",
    "PROMPT.md",
    "AI_NOTES.md"
)

Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem

$zip = [System.IO.Compression.ZipFile]::Open($zipPath, [System.IO.Compression.ZipArchiveMode]::Create)
try {
    $files = Get-ChildItem -Path $root -Recurse -File -Force | Where-Object {
        $relative = $_.FullName.Substring($root.Path.Length).TrimStart("\", "/")
        $parts = $relative -split "[\\/]"
        $skip = $false
        foreach ($part in $parts) {
            if ($excludeDirs -contains $part) {
                $skip = $true
                break
            }
        }
        if ($excludeFiles -contains $_.Name) {
            $skip = $true
        }
        -not $skip
    }

    foreach ($file in $files) {
        $relative = $file.FullName.Substring($root.Path.Length).TrimStart("\", "/").Replace("\", "/")
        [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip, $file.FullName, $relative) | Out-Null
    }
}
finally {
    $zip.Dispose()
}

Write-Output $zipPath
