import { Link } from "react-router-dom"

type SiteFooterProps = {
  databaseConnected: boolean | null
}

export function SiteFooter({ databaseConnected }: SiteFooterProps) {
  let statusText = "Hệ thống sẵn sàng"
  if (databaseConnected === true) statusText = "Cơ sở dữ liệu sẵn sàng"
  if (databaseConnected === false) statusText = "Chưa kết nối cơ sở dữ liệu"

  return (
    <footer style={{ background: "#ffffff", borderTop: "1px solid #e2e8f0", paddingTop: "52px", paddingBottom: "32px", marginTop: "auto" }}>
      <div style={{ maxWidth: "1340px", margin: "0 auto", padding: "0 20px" }}>
        {/* MAIN 5-COLUMN FOOTER GRID (MATCHING HOMEPAGE SCREENSHOT) */}
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "1.3fr 1fr 1fr 1.1fr 1.4fr",
            gap: "36px",
            marginBottom: "40px",
          }}
        >
          {/* COL 1: LOGO & ABOUT */}
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "12px" }}>
              <div style={{ width: "32px", height: "32px", borderRadius: "10px", background: "#2563eb", display: "flex", alignItems: "center", justifyContent: "center" }}>
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
                  <rect x="5" y="2" width="14" height="20" rx="3" ry="3" />
                  <line x1="12" y1="18" x2="12.01" y2="18" />
                </svg>
              </div>
              <strong style={{ fontSize: "1.25rem", fontWeight: 800, letterSpacing: "-0.03em", color: "#0f172a" }}>
                Phone<span style={{ color: "#2563eb" }}>Repair</span>
              </strong>
            </div>

            <p style={{ margin: "0 0 16px", color: "#64748b", fontSize: "0.85rem", lineHeight: 1.5, maxWidth: "260px" }}>
              Sửa điện thoại nhanh chóng, uy tín, chuyên nghiệp
            </p>

            <div style={{ display: "flex", gap: "10px", alignItems: "center" }}>
              <a href="#facebook" style={{ width: "32px", height: "32px", borderRadius: "50%", background: "#eff6ff", color: "#1877F2", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "0.95rem" }} title="Facebook">
                📘
              </a>
              <a href="#youtube" style={{ width: "32px", height: "32px", borderRadius: "50%", background: "#fef2f2", color: "#ef4444", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "0.95rem" }} title="YouTube">
                ▶️
              </a>
              <a href="#tiktok" style={{ width: "32px", height: "32px", borderRadius: "50%", background: "#f1f5f9", color: "#0f172a", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "0.95rem" }} title="TikTok">
                🎵
              </a>
              <a href="#social" style={{ width: "32px", height: "32px", borderRadius: "50%", background: "#e0f2fe", color: "#0284c7", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "0.95rem" }} title="Community">
                🌐
              </a>
            </div>
          </div>

          {/* COL 2: VỀ CHÚNG TÔI */}
          <div>
            <strong style={{ display: "block", fontSize: "0.92rem", color: "#0f172a", marginBottom: "16px", fontWeight: 700 }}>
              Về chúng tôi
            </strong>
            <ul style={{ listStyle: "none", padding: 0, margin: 0, display: "flex", flexDirection: "column", gap: "10px", fontSize: "0.86rem" }}>
              <li>
                <Link to="/" style={{ color: "#64748b", textDecoration: "none" }}>Giới thiệu</Link>
              </li>
              <li>
                <Link to="/branches" style={{ color: "#64748b", textDecoration: "none" }}>Hệ thống chi nhánh</Link>
              </li>
              <li>
                <Link to="/services" style={{ color: "#64748b", textDecoration: "none" }}>Tin tức - Khuyến mãi</Link>
              </li>
              <li>
                <Link to="/support" style={{ color: "#64748b", textDecoration: "none" }}>Tuyển dụng</Link>
              </li>
            </ul>
          </div>

          {/* COL 3: DỊCH VỤ */}
          <div>
            <strong style={{ display: "block", fontSize: "0.92rem", color: "#0f172a", marginBottom: "16px", fontWeight: 700 }}>
              Dịch vụ
            </strong>
            <ul style={{ listStyle: "none", padding: 0, margin: 0, display: "flex", flexDirection: "column", gap: "10px", fontSize: "0.86rem" }}>
              <li>
                <Link to="/pricing" style={{ color: "#64748b", textDecoration: "none" }}>Bảng giá</Link>
              </li>
              <li>
                <Link to="/support" style={{ color: "#64748b", textDecoration: "none" }}>Chính sách bảo hành</Link>
              </li>
              <li>
                <Link to="/services" style={{ color: "#64748b", textDecoration: "none" }}>Quy trình sửa chữa</Link>
              </li>
              <li>
                <Link to="/support" style={{ color: "#64748b", textDecoration: "none" }}>Câu hỏi thường gặp</Link>
              </li>
            </ul>
          </div>

          {/* COL 4: HỖ TRỢ KHÁCH HÀNG */}
          <div>
            <strong style={{ display: "block", fontSize: "0.92rem", color: "#0f172a", marginBottom: "16px", fontWeight: 700 }}>
              Hỗ trợ khách hàng
            </strong>
            <ul style={{ listStyle: "none", padding: 0, margin: 0, display: "flex", flexDirection: "column", gap: "10px", fontSize: "0.86rem" }}>
              <li>
                <Link to="/support" style={{ color: "#64748b", textDecoration: "none" }}>Liên hệ</Link>
              </li>
              <li>
                <Link to="/booking" style={{ color: "#64748b", textDecoration: "none" }}>Hướng dẫn đặt lịch</Link>
              </li>
              <li>
                <Link to="/support" style={{ color: "#64748b", textDecoration: "none" }}>Chính sách bảo mật</Link>
              </li>
              <li>
                <Link to="/support" style={{ color: "#64748b", textDecoration: "none" }}>Điều khoản sử dụng</Link>
              </li>
            </ul>
          </div>

          {/* COL 5: NHẬN THÔNG TIN KHUYẾN MÃI */}
          <div>
            <strong style={{ display: "block", fontSize: "0.92rem", color: "#0f172a", marginBottom: "12px", fontWeight: 700 }}>
              Nhận thông tin khuyến mãi
            </strong>
            <p style={{ fontSize: "0.84rem", color: "#64748b", lineHeight: 1.5, margin: "0 0 14px" }}>
              Đăng ký email để nhận ưu đãi mới nhất từ HomeRepair
            </p>
            <form
              onSubmit={(e) => {
                e.preventDefault()
                alert("Cảm ơn bạn đã đăng ký nhận thông tin ưu đãi!")
              }}
              style={{ display: "flex", gap: "8px" }}
            >
              <input
                type="email"
                required
                placeholder="Nhập email của bạn"
                style={{
                  flex: 1,
                  padding: "9px 14px",
                  borderRadius: "8px",
                  border: "1px solid #cbd5e1",
                  fontSize: "0.84rem",
                  outline: "none",
                }}
              />
              <button
                type="submit"
                style={{
                  background: "#2563eb",
                  color: "#ffffff",
                  border: "none",
                  borderRadius: "8px",
                  padding: "9px 18px",
                  fontWeight: 700,
                  fontSize: "0.84rem",
                  cursor: "pointer",
                  whiteSpace: "nowrap",
                }}
              >
                Đăng ký
              </button>
            </form>
          </div>
        </div>

        {/* BOTTOM COPYRIGHT & POLICY ROW */}
        <div
          style={{
            borderTop: "1px solid #f1f5f9",
            paddingTop: "24px",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            flexWrap: "wrap",
            gap: "14px",
            fontSize: "0.82rem",
            color: "#94a3b8",
          }}
        >
          <div>
            © 2024 HomeRepair. Tất cả quyền được bảo lưu.
          </div>

          <div style={{ display: "flex", alignItems: "center", gap: "20px" }}>
            <Link to="/support" style={{ color: "#94a3b8" }}>Điều khoản sử dụng</Link>
            <span>|</span>
            <Link to="/support" style={{ color: "#94a3b8" }}>Chính sách bảo mật</Link>
            <span>|</span>
            <Link to="/support" style={{ color: "#94a3b8" }}>Sitemap</Link>
          </div>

          <div style={{ display: "inline-flex", alignItems: "center", gap: "6px" }}>
            <span
              style={{
                width: "8px",
                height: "8px",
                borderRadius: "50%",
                background: databaseConnected ? "#16a34a" : "#ca8a04",
              }}
            />
            <span>{statusText}</span>
          </div>
        </div>
      </div>
    </footer>
  )
}
