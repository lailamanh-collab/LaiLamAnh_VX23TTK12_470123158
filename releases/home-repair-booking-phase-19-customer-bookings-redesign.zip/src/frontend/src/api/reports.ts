import { api } from "./client"

export interface StatCardsData {
  bookingsToday: number
  pendingBookings: number
  confirmedBookings: number
  repairingBookings: number
  completedToday: number
  totalCustomers: number
  totalTechnicians: number
  totalRepairValue: number
  completedBookingsAllTime: number
}

export interface ChartDateItem {
  date: string
  count: number
  revenue: number
}

export interface ChartStatusItem {
  status: string
  statusLabel: string
  count: number
}

export interface ChartServiceItem {
  serviceName: string
  count: number
  revenue: number
}

export interface ChartBrandItem {
  brandName: string
  count: number
  revenue: number
}

export interface ChartModelItem {
  modelName: string
  brandName: string
  count: number
}

export interface ChartBranchItem {
  branchName: string
  count: number
  revenue: number
}

export interface ChartMonthItem {
  month: string
  revenue: number
  count: number
}

export interface AdminDashboardData {
  stats: StatCardsData
  bookingsByDate: ChartDateItem[]
  bookingsByStatus: ChartStatusItem[]
  popularServices: ChartServiceItem[]
  repairedBrands: ChartBrandItem[]
  repairedModels: ChartModelItem[]
  bookingsByBranch: ChartBranchItem[]
  revenueByMonth: ChartMonthItem[]
}

export interface ReportFilterParams {
  fromDate?: string
  toDate?: string
  branchId?: number
  technicianId?: number
  repairServiceId?: number
  brandId?: number
  phoneModelId?: number
  status?: string
}

export interface ReportSummaryData {
  totalBookings: number
  completedBookings: number
  cancelledBookings: number
  totalRevenue: number
  averageBookingValue: number
}

export interface TechnicianPerformanceItem {
  technicianId: number
  technicianName: string
  branchName: string
  totalAssigned: number
  completedJobs: number
  totalRevenue: number
  averageRating: number
  totalReviews: number
}

export interface BranchPerformanceItem {
  branchId: number
  branchName: string
  totalBookings: number
  completedBookings: number
  revenue: number
}

export interface ServicePerformanceItem {
  serviceId: number
  serviceName: string
  count: number
  totalRevenue: number
}

export interface BrandPerformanceItem {
  brandName: string
  count: number
  revenue: number
}

export interface ReportResultData {
  summary: ReportSummaryData
  technicianPerformance: TechnicianPerformanceItem[]
  branchPerformance: BranchPerformanceItem[]
  servicePerformance: ServicePerformanceItem[]
  brandPerformance: BrandPerformanceItem[]
}

export async function fetchAdminDashboard(token: string): Promise<AdminDashboardData> {
  return api<AdminDashboardData>("/api/admin/reports/dashboard", {}, token)
}

export async function fetchAdminReports(
  token: string,
  filter?: ReportFilterParams,
): Promise<ReportResultData> {
  const params = new URLSearchParams()
  if (filter?.fromDate) params.set("fromDate", filter.fromDate)
  if (filter?.toDate) params.set("toDate", filter.toDate)
  if (filter?.branchId) params.set("branchId", String(filter.branchId))
  if (filter?.technicianId) params.set("technicianId", String(filter.technicianId))
  if (filter?.repairServiceId) params.set("repairServiceId", String(filter.repairServiceId))
  if (filter?.brandId) params.set("brandId", String(filter.brandId))
  if (filter?.phoneModelId) params.set("phoneModelId", String(filter.phoneModelId))
  if (filter?.status) params.set("status", filter.status)

  const qs = params.toString() ? `?${params.toString()}` : ""
  return api<ReportResultData>(`/api/admin/reports${qs}`, {}, token)
}
