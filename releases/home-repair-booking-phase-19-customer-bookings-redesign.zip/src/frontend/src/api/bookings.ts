import { api } from "./client"
import type { PricingType } from "./catalog"

export type Slot = {
  start: string
  end: string
  capacity: number
  booked: number
  isFull: boolean
}

export type BookingLine = {
  repairServiceId: number
  serviceName: string
  pricingType: PricingType
  unitPrice: number | null
}

export type BookingSummary = {
  id: number
  bookingCode: string
  brandName: string
  phoneModelName: string
  branchName: string
  appointmentDate: string
  slotStart: string
  status: string
  estimatedTotal: number
  actualCost: number | null
  technicianName: string | null
}

export type BookingDetail = BookingSummary & {
  branchAddress: string
  slotEnd: string
  problemDescription: string
  diagnosis: string | null
  repairNotes: string | null
  repairSolution: string | null
  services: BookingLine[]
  timeline: { fromStatus: string | null; toStatus: string; note: string | null; changedAt: string }[]
}

export const statusLabel: Record<string, string> = {
  Pending: "Chờ xác nhận",
  Confirmed: "Đã xác nhận",
  Received: "Đã nhận máy",
  Inspecting: "Đang kiểm tra",
  Repairing: "Đang sửa",
  Completed: "Hoàn thành",
  Cancelled: "Đã hủy",
}

export function getSlots(branchId: number, date: string) {
  return api<Slot[]>(`/api/bookings/slots?branchId=${branchId}&date=${date}`)
}

export function createBooking(token: string, body: object) {
  return api<BookingDetail>("/api/bookings", { method: "POST", body: JSON.stringify(body) }, token)
}

export function myBookings(token: string, filter = "") {
  return api<BookingSummary[]>(`/api/bookings/mine?filter=${filter}`, {}, token)
}

export function myBooking(token: string, id: number) {
  return api<BookingDetail>(`/api/bookings/mine/${id}`, {}, token)
}

export function cancelBooking(token: string, id: number, reason = "Khách hủy lịch.") {
  return api<void>(`/api/bookings/mine/${id}/cancel`, { method: "POST", body: JSON.stringify({ reason }) }, token)
}
