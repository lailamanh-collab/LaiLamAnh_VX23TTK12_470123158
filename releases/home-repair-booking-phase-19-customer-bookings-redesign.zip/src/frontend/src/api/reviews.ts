import { api } from "./client"

export interface ReviewItem {
  id: number
  bookingId: number
  bookingCode: string
  customerId: string
  customerName: string
  rating: number
  comment?: string | null
  isVisible: boolean
  createdAt: string
  updatedAt?: string | null
  phoneModelName: string
  brandName: string
  branchName: string
  technicianName?: string | null
}

export interface ReviewStats {
  totalReviews: number
  averageRating: number
  fiveStarCount: number
  fourStarCount: number
  threeStarCount: number
  twoStarCount: number
  oneStarCount: number
  hiddenCount: number
}

export async function submitReview(
  token: string,
  bookingId: number,
  data: { rating: number; comment?: string },
): Promise<ReviewItem> {
  return api<ReviewItem>(
    `/api/reviews/bookings/${bookingId}`,
    {
      method: "POST",
      body: JSON.stringify(data),
    },
    token,
  )
}

export async function fetchBookingReview(token: string, bookingId: number): Promise<ReviewItem | null> {
  try {
    return await api<ReviewItem>(`/api/reviews/bookings/${bookingId}`, {}, token)
  } catch (err: unknown) {
    if (err && typeof err === "object" && "status" in err && (err as { status: number }).status === 404) {
      return null
    }
    throw err
  }
}

export async function fetchPublicReviews(limit?: number): Promise<ReviewItem[]> {
  const qs = limit ? `?limit=${limit}` : ""
  return api<ReviewItem[]>(`/api/reviews/public${qs}`)
}

export async function fetchAdminReviews(
  token: string,
  filter?: {
    rating?: number
    branchId?: number
    technicianId?: number
    isVisible?: boolean
    search?: string
  },
): Promise<ReviewItem[]> {
  const params = new URLSearchParams()
  if (filter?.rating) params.set("rating", String(filter.rating))
  if (filter?.branchId) params.set("branchId", String(filter.branchId))
  if (filter?.technicianId) params.set("technicianId", String(filter.technicianId))
  if (filter?.isVisible !== undefined) params.set("isVisible", String(filter.isVisible))
  if (filter?.search) params.set("search", filter.search)
  const qs = params.toString() ? `?${params.toString()}` : ""
  return api<ReviewItem[]>(`/api/admin/reviews${qs}`, {}, token)
}

export async function fetchAdminReviewStats(token: string): Promise<ReviewStats> {
  return api<ReviewStats>("/api/admin/reviews/stats", {}, token)
}

export async function updateReviewVisibility(
  token: string,
  id: number,
  isVisible: boolean,
): Promise<{ message: string }> {
  return api<{ message: string }>(
    `/api/admin/reviews/${id}/visibility`,
    {
      method: "PUT",
      body: JSON.stringify({ isVisible }),
    },
    token,
  )
}

export async function deleteReview(token: string, id: number): Promise<{ message: string }> {
  return api<{ message: string }>(
    `/api/admin/reviews/${id}`,
    {
      method: "DELETE",
    },
    token,
  )
}
