import { api } from "./client"

export interface TechnicianDashboardData {
  technicianId: number
  technicianName: string
  branchId: number
  branchName: string
  jobsToday: number
  confirmedJobs: number
  receivedJobs: number
  inspectingJobs: number
  repairingJobs: number
  completedJobs: number
  completedTodayJobs: number
  totalActiveJobs: number
}

export interface TechnicianJobSummary {
  id: number
  bookingCode: string
  customerName: string
  customerPhone?: string | null
  brandName: string
  phoneModelName: string
  branchName: string
  appointmentDate: string
  slotStart: string
  slotEnd: string
  status: string
  problemDescription: string
  estimatedTotal: number
  actualCost?: number | null
  createdAt: string
  receivedAt?: string | null
  inspectionStartedAt?: string | null
  repairStartedAt?: string | null
  completedAt?: string | null
}

export interface BookingServiceLineItem {
  repairServiceId: number
  serviceName: string
  pricingType: "FixedPrice" | "InspectionRequired"
  unitPrice?: number | null
}

export interface BookingTimelineItem {
  fromStatus?: string | null
  toStatus: string
  note?: string | null
  changedAt: string
}

export interface TechnicianJobDetail {
  id: number
  bookingCode: string
  customerId: string
  customerName: string
  customerEmail: string
  customerPhone?: string | null
  phoneModelId: number
  brandName: string
  phoneModelName: string
  branchId: number
  branchName: string
  branchAddress: string
  appointmentDate: string
  slotStart: string
  slotEnd: string
  status: string
  problemDescription: string
  estimatedTotal: number
  actualCost?: number | null
  diagnosis?: string | null
  repairNotes?: string | null
  repairSolution?: string | null
  createdAt: string
  receivedAt?: string | null
  inspectionStartedAt?: string | null
  repairStartedAt?: string | null
  completedAt?: string | null
  services: BookingServiceLineItem[]
  timeline: BookingTimelineItem[]
}

export async function fetchTechnicianDashboard(token: string): Promise<TechnicianDashboardData> {
  return api<TechnicianDashboardData>("/api/technician/dashboard", {}, token)
}

export async function fetchTechnicianJobs(
  token: string,
  filter?: { status?: string; search?: string },
): Promise<TechnicianJobSummary[]> {
  const params = new URLSearchParams()
  if (filter?.status) params.set("status", filter.status)
  if (filter?.search) params.set("search", filter.search)
  const qs = params.toString() ? `?${params.toString()}` : ""
  return api<TechnicianJobSummary[]>(`/api/technician/jobs${qs}`, {}, token)
}

export async function fetchTechnicianJobDetail(token: string, id: number): Promise<TechnicianJobDetail> {
  return api<TechnicianJobDetail>(`/api/technician/jobs/${id}`, {}, token)
}

export async function receiveJob(
  token: string,
  id: number,
  receiveNote?: string,
): Promise<TechnicianJobDetail> {
  return api<TechnicianJobDetail>(
    `/api/technician/jobs/${id}/receive`,
    {
      method: "POST",
      body: JSON.stringify({ receiveNote: receiveNote || null }),
    },
    token,
  )
}

export async function startInspection(
  token: string,
  id: number,
  data: { diagnosis?: string; repairNotes?: string; actualCost?: number | null },
): Promise<TechnicianJobDetail> {
  return api<TechnicianJobDetail>(
    `/api/technician/jobs/${id}/inspect`,
    {
      method: "POST",
      body: JSON.stringify(data),
    },
    token,
  )
}

export async function startRepair(
  token: string,
  id: number,
  data: { repairSolution?: string; repairNotes?: string; actualCost?: number | null },
): Promise<TechnicianJobDetail> {
  return api<TechnicianJobDetail>(
    `/api/technician/jobs/${id}/start-repair`,
    {
      method: "POST",
      body: JSON.stringify(data),
    },
    token,
  )
}

export async function updateRepairInfo(
  token: string,
  id: number,
  data: {
    diagnosis?: string
    repairSolution?: string
    repairNotes?: string
    actualCost?: number | null
    progressNote?: string
  },
): Promise<TechnicianJobDetail> {
  return api<TechnicianJobDetail>(
    `/api/technician/jobs/${id}/repair-info`,
    {
      method: "PUT",
      body: JSON.stringify(data),
    },
    token,
  )
}

export async function completeRepair(
  token: string,
  id: number,
  data: { repairResult?: string; repairNotes?: string; actualCost?: number | null },
): Promise<TechnicianJobDetail> {
  return api<TechnicianJobDetail>(
    `/api/technician/jobs/${id}/complete`,
    {
      method: "POST",
      body: JSON.stringify(data),
    },
    token,
  )
}
