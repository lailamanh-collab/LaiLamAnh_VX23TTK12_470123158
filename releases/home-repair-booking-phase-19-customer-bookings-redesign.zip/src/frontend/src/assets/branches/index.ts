import branchCauGiay from "./branch-caugiay.jpg"
import branchDongDa from "./branch-dongda.jpg"
import branchHaiBaTrung from "./branch-haibatrung.jpg"
import branchThanhXuan from "./branch-thanhxuan.jpg"
import branchBaDinh from "./branch-badinh.jpg"
import branchLongBien from "./branch-longbien.jpg"

export const BRANCH_IMAGES: Record<string, string> = {
  "Cầu Giấy": branchCauGiay,
  "Đống Đa": branchDongDa,
  "Hai Bà Trưng": branchHaiBaTrung,
  "Thanh Xuân": branchThanhXuan,
  "Ba Đình": branchBaDinh,
  "Long Biên": branchLongBien,
}

export function getBranchImage(nameOrAddress?: string): string {
  if (!nameOrAddress) return branchCauGiay
  const lower = nameOrAddress.toLowerCase()
  if (lower.includes("đống đa")) return branchDongDa
  if (lower.includes("hai bà trưng") || lower.includes("phố huế")) return branchHaiBaTrung
  if (lower.includes("thanh xuân") || lower.includes("nguyễn trãi")) return branchThanhXuan
  if (lower.includes("ba đình") || lower.includes("đội cấn")) return branchBaDinh
  if (lower.includes("long biên") || lower.includes("nguyễn văn cừ")) return branchLongBien
  return branchCauGiay
}

export {
  branchCauGiay,
  branchDongDa,
  branchHaiBaTrung,
  branchThanhXuan,
  branchBaDinh,
  branchLongBien,
}
