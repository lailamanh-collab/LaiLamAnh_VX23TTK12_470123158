import screenIcon from "./screen.svg"
import batteryIcon from "./battery.svg"
import cameraIcon from "./camera.svg"
import speakerIcon from "./speaker.svg"
import chargingIcon from "./charging.svg"
import cleaningIcon from "./cleaning.svg"
import backglassIcon from "./backglass.svg"
import motherboardIcon from "./motherboard.svg"

export const SERVICE_ICONS: Record<string, string> = {
  screen: screenIcon,
  battery: batteryIcon,
  camera: cameraIcon,
  speaker: speakerIcon,
  port: chargingIcon,
  charging: chargingIcon,
  clean: cleaningIcon,
  cleaning: cleaningIcon,
  backglass: backglassIcon,
  motherboard: motherboardIcon,
  mainboard: motherboardIcon,
}

export function getServiceIcon(nameOrCode?: string): string {
  if (!nameOrCode) return cleaningIcon
  const lower = nameOrCode.toLowerCase()
  if (lower.includes("màn") || lower.includes("screen") || lower.includes("kính")) return screenIcon
  if (lower.includes("pin") || lower.includes("battery")) return batteryIcon
  if (lower.includes("camera") || lower.includes("cam")) return cameraIcon
  if (lower.includes("loa") || lower.includes("speaker") || lower.includes("mic")) return speakerIcon
  if (lower.includes("sạc") || lower.includes("port") || lower.includes("cổng")) return chargingIcon
  if (lower.includes("lưng") || lower.includes("backglass") || lower.includes("vỏ")) return backglassIcon
  if (lower.includes("main") || lower.includes("nguồn") || lower.includes("motherboard")) return motherboardIcon
  return cleaningIcon
}

export {
  screenIcon,
  batteryIcon,
  cameraIcon,
  speakerIcon,
  chargingIcon,
  cleaningIcon,
  backglassIcon,
  motherboardIcon,
}
