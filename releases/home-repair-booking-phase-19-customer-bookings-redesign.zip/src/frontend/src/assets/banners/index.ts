import heroRepair from "./hero-repair.jpg"
import workshopBg from "./workshop-bg.jpg"

export const BANNER_IMAGES = {
  hero: heroRepair,
  workshop: workshopBg,
}

export {
  heroRepair,
  workshopBg,
}
