import { zodResolver } from "@hookform/resolvers/zod"
import { useState } from "react"
import { useForm } from "react-hook-form"
import { Navigate } from "react-router-dom"
import { z } from "zod"
import { changePassword, updateProfile } from "../api/auth"
import { ApiError } from "../api/client"
import { useAuth } from "../auth/AuthContext"
import { TextField } from "../components/forms/TextField"

const profileSchema = z.object({
  fullName: z.string().trim().min(1, "Nhập họ tên.").max(100),
  phoneNumber: z.string().regex(/^[0-9+\s]{8,15}$/, "Số điện thoại không hợp lệ."),
})

const passwordSchema = z.object({
  currentPassword: z.string().min(1, "Nhập mật khẩu hiện tại."),
  newPassword: z.string()
    .min(8, "Mật khẩu tối thiểu 8 ký tự.")
    .regex(/[A-Z]/, "Mật khẩu cần một chữ hoa.")
    .regex(/[a-z]/, "Mật khẩu cần một chữ thường.")
    .regex(/[0-9]/, "Mật khẩu cần một chữ số."),
  confirmPassword: z.string(),
}).refine((values) => values.newPassword === values.confirmPassword, {
  message: "Mật khẩu nhập lại chưa khớp.",
  path: ["confirmPassword"],
})

type ProfileValues = z.infer<typeof profileSchema>
type PasswordValues = z.infer<typeof passwordSchema>

const roleLabel: Record<string, string> = {
  Admin: "Quản trị",
  Technician: "Kỹ thuật viên",
  Customer: "Khách hàng",
}

export function ProfilePage() {
  const { token, user, setUser } = useAuth()
  if (user?.role === "Customer") {
    return <Navigate to="/my-bookings?tab=profile" replace />
  }
  const [profileMessage, setProfileMessage] = useState("")
  const [passwordMessage, setPasswordMessage] = useState("")
  const profileForm = useForm<ProfileValues>({
    resolver: zodResolver(profileSchema),
    values: {
      fullName: user?.fullName ?? "",
      phoneNumber: user?.phoneNumber ?? "",
    },
  })
  const passwordForm = useForm<PasswordValues>({
    resolver: zodResolver(passwordSchema),
  })

  async function onSaveProfile(values: ProfileValues) {
    if (!token) {
      return
    }
    setProfileMessage("")
    try {
      const updated = await updateProfile(token, values)
      setUser(updated)
      setProfileMessage("Đã lưu hồ sơ.")
    } catch (error) {
      const message = error instanceof ApiError ? error.message : "Không lưu được hồ sơ."
      profileForm.setError("root", { message })
    }
  }

  async function onChangePassword(values: PasswordValues) {
    if (!token) {
      return
    }
    setPasswordMessage("")
    try {
      await changePassword(token, values)
      passwordForm.reset()
      setPasswordMessage("Đã đổi mật khẩu.")
    } catch (error) {
      if (error instanceof ApiError && error.errors) {
        for (const [field, messages] of Object.entries(error.errors)) {
          passwordForm.setError(field as keyof PasswordValues, { message: messages[0] })
        }
        return
      }
      const message = error instanceof ApiError ? error.message : "Không đổi được mật khẩu."
      passwordForm.setError("root", { message })
    }
  }

  return (
    <main className="page narrow">
      <section className="card form-card">
        <h1>Hồ sơ</h1>
        <p className="section-intro">{user ? roleLabel[user.role] ?? user.role : ""} · {user?.email}</p>
        <form className="form" onSubmit={profileForm.handleSubmit(onSaveProfile)} noValidate>
          {profileForm.formState.errors.root ? <p className="form-error">{profileForm.formState.errors.root.message}</p> : null}
          {profileMessage ? <p className="form-success">{profileMessage}</p> : null}
          <TextField label="Họ tên" autoComplete="name" registration={profileForm.register("fullName")} error={profileForm.formState.errors.fullName} />
          <TextField label="Số điện thoại" autoComplete="tel" registration={profileForm.register("phoneNumber")} error={profileForm.formState.errors.phoneNumber} />
          <button className="btn" type="submit" disabled={profileForm.formState.isSubmitting}>Lưu hồ sơ</button>
        </form>
      </section>

      <section className="card form-card">
        <h2>Đổi mật khẩu</h2>
        <form className="form" onSubmit={passwordForm.handleSubmit(onChangePassword)} noValidate>
          {passwordForm.formState.errors.root ? <p className="form-error">{passwordForm.formState.errors.root.message}</p> : null}
          {passwordMessage ? <p className="form-success">{passwordMessage}</p> : null}
          <TextField label="Mật khẩu hiện tại" type="password" autoComplete="current-password" registration={passwordForm.register("currentPassword")} error={passwordForm.formState.errors.currentPassword} />
          <TextField label="Mật khẩu mới" type="password" autoComplete="new-password" registration={passwordForm.register("newPassword")} error={passwordForm.formState.errors.newPassword} />
          <TextField label="Nhập lại mật khẩu mới" type="password" autoComplete="new-password" registration={passwordForm.register("confirmPassword")} error={passwordForm.formState.errors.confirmPassword} />
          <button className="btn" type="submit" disabled={passwordForm.formState.isSubmitting}>Đổi mật khẩu</button>
        </form>
      </section>
    </main>
  )
}
