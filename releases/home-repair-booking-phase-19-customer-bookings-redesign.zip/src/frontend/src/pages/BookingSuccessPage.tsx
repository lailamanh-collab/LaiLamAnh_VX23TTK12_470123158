import { useState } from "react"
import { Link, useLocation } from "react-router-dom"
import type { BookingDetail } from "../api/bookings"
import { getPhoneImage, getBranchImage } from "../assets"

export interface BookingSuccessState {
  booking?: BookingDetail
  customerName?: string
  customerPhone?: string
  customerEmail?: string
  modelName?: string
  brandName?: string
  storage?: string
  color?: string
  condition?: string
  imei?: string
  branchName?: string
  branchAddress?: string
  branchPhone?: string
  appointmentDate?: string
  slotTime?: string
  services?: { name: string; price: number; desc?: string; icon?: string; iconBg?: string }[]
  totalAmount?: number
}

interface BookingSuccessProps {
  initialData?: BookingSuccessState
}

export function BookingSuccessPage({ initialData }: BookingSuccessProps = {}) {
  const location = useLocation()
  const state = initialData || (location.state as BookingSuccessState) || {}

  const [copiedCode, setCopiedCode] = useState(false)

  // Data with fallback to exact mockup screenshot values
  const bookingCode = state.booking?.bookingCode || "PRB-20241015-001"
  const bookingId = state.booking?.id || 1

  const customerName = state.customerName || "Nguyễn Văn A"
  const customerPhone = state.customerPhone || "0901 234 567"
  const customerEmail = state.customerEmail || "nguyenvana@gmail.com"

  const modelName = state.modelName || state.booking?.phoneModelName || "iPhone 16"
  const brandName = state.brandName || state.booking?.brandName || "Apple"
  const storage = state.storage || "128GB"
  const color = state.color || "Titan Xanh"
  const condition = state.condition || "Màn hình bị nứt, cảm ứng vẫn hoạt động"
  const imei = state.imei || "355012345678901"

  const branchName = state.branchName || state.booking?.branchName || "HomeRepair Quận 1"
  const branchAddress = state.branchAddress || state.booking?.branchAddress || "123 Nguyễn Huệ, Quận 1, TP.HCM"
  const branchPhone = state.branchPhone || "028 1234 5678"

  const appointmentDate = state.appointmentDate || "Thứ 3, 15/10/2024"
  const slotTime = state.slotTime || "14:00 - 14:30"
  const estimatedDuration = "Khoảng 60 - 90 phút"

  const services = state.services && state.services.length > 0
    ? state.services
    : [
        { name: "Thay màn hình", price: 3500000, desc: "Linh kiện chính hãng", icon: "📱", iconBg: "#eff6ff" },
        { name: "Thay pin", price: 1500000, desc: "Linh kiện chính hãng", icon: "🔋", iconBg: "#ecfdf5" },
      ]

  const totalCost = state.totalAmount ?? services.reduce((sum, s) => sum + s.price, 0)

  const formatVnd = (price: number) => {
    return price.toLocaleString("vi-VN") + "đ"
  }

  const handleCopyCode = () => {
    navigator.clipboard?.writeText(bookingCode)
    setCopiedCode(true)
    setTimeout(() => setCopiedCode(false), 2000)
  }

  return (
    <main style={{ background: "#f8fafc", minHeight: "100vh", padding: "40px 20px 80px" }}>
      <div style={{ maxWidth: "1200px", margin: "0 auto" }}>
        {/* ================= HERO CELEBRATION BANNER ================= */}
        <section style={{ textAlign: "center", position: "relative", marginBottom: "36px" }}>
          {/* CONFETTI DECORATIONS */}
          <div style={{ position: "absolute", top: "10px", left: "28%", width: "10px", height: "10px", background: "#3b82f6", borderRadius: "2px", transform: "rotate(25deg)", opacity: 0.8 }} />
          <div style={{ position: "absolute", top: "35px", left: "34%", width: "8px", height: "8px", background: "#f97316", borderRadius: "50%", opacity: 0.8 }} />
          <div style={{ position: "absolute", top: "8px", right: "28%", width: "10px", height: "10px", background: "#a855f7", borderRadius: "2px", transform: "rotate(-15deg)", opacity: 0.8 }} />
          <div style={{ position: "absolute", top: "38px", right: "33%", width: "8px", height: "8px", background: "#10b981", borderRadius: "50%", opacity: 0.8 }} />
          <div style={{ position: "absolute", top: "45px", left: "25%", width: "8px", height: "8px", background: "#06b6d4", borderRadius: "2px", transform: "rotate(45deg)", opacity: 0.7 }} />
          <div style={{ position: "absolute", top: "42px", right: "24%", width: "9px", height: "9px", background: "#f59e0b", borderRadius: "2px", transform: "rotate(30deg)", opacity: 0.7 }} />

          {/* LARGE GREEN CHECKMARK BADGE */}
          <div
            style={{
              width: "72px",
              height: "72px",
              borderRadius: "50%",
              background: "#10b981",
              color: "#ffffff",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              fontSize: "2.4rem",
              fontWeight: 900,
              margin: "0 auto 16px",
              boxShadow: "0 10px 25px rgba(16,185,129,0.35)",
            }}
          >
            ✓
          </div>

          <h1 style={{ fontSize: "2rem", fontWeight: 900, color: "#0f172a", margin: "0 0 10px", letterSpacing: "-0.02em" }}>
            Đặt lịch thành công!
          </h1>
          <p style={{ fontSize: "0.95rem", color: "#475569", margin: "0 0 4px", lineHeight: 1.5 }}>
            Cảm ơn bạn đã tin tưởng sử dụng dịch vụ của HomeRepair.
          </p>
          <p style={{ fontSize: "0.95rem", color: "#475569", margin: "0 0 24px", lineHeight: 1.5 }}>
            Thông tin đặt lịch của bạn đã được xác nhận. Chúng tôi sẽ chuẩn bị và phục vụ bạn đúng giờ.
          </p>

          {/* BOOKING CODE CARD */}
          <div
            style={{
              display: "inline-flex",
              flexDirection: "column",
              alignItems: "center",
              background: "#eff6ff",
              border: "1.5px solid #bfdbfe",
              borderRadius: "16px",
              padding: "14px 28px",
              boxShadow: "0 4px 14px rgba(37,99,235,0.08)",
              minWidth: "320px",
            }}
          >
            <span style={{ fontSize: "0.82rem", color: "#64748b", fontWeight: 600, marginBottom: "4px" }}>
              Mã đặt lịch
            </span>
            <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
              <span style={{ fontSize: "1.75rem", fontWeight: 900, color: "#1d4ed8", letterSpacing: "1.5px" }}>
                {bookingCode}
              </span>
              <button
                type="button"
                onClick={handleCopyCode}
                title="Sao chép mã"
                style={{
                  width: "36px",
                  height: "36px",
                  borderRadius: "10px",
                  background: "#ffffff",
                  border: "1px solid #cbd5e1",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  fontSize: "1.1rem",
                  cursor: "pointer",
                  color: "#334155",
                  boxShadow: "0 2px 6px rgba(0,0,0,0.05)",
                  transition: "all 0.15s ease",
                }}
              >
                {copiedCode ? "✓" : "📋"}
              </button>
            </div>
          </div>

          <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: "6px", fontSize: "0.85rem", color: "#64748b", marginTop: "14px" }}>
            <span>📅</span>
            <span>Đã gửi xác nhận qua email và tin nhắn SMS đến bạn.</span>
          </div>
        </section>

        {/* ================= 6-CARD GRID (3 COLUMNS X 2 ROWS) ================= */}
        <section
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(3, 1fr)",
            gap: "20px",
            marginBottom: "36px",
          }}
        >
          {/* CARD 1: THÔNG TIN THIẾT BỊ */}
          <div
            style={{
              background: "#ffffff",
              border: "1px solid #e2e8f0",
              borderRadius: "16px",
              padding: "20px",
              boxShadow: "0 2px 8px rgba(15,23,42,0.02)",
            }}
          >
            <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "16px" }}>
              <div style={{ width: "32px", height: "32px", borderRadius: "8px", background: "#eff6ff", color: "#2563eb", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "1.1rem" }}>
                📱
              </div>
              <h2 style={{ fontSize: "1rem", fontWeight: 800, color: "#0f172a", margin: 0 }}>
                Thông tin thiết bị
              </h2>
            </div>

            {/* DEVICE PREVIEW */}
            <div style={{ display: "flex", alignItems: "center", gap: "12px", marginBottom: "16px", paddingBottom: "14px", borderBottom: "1px solid #f1f5f9" }}>
              <img
                src={getPhoneImage(modelName)}
                alt={modelName}
                style={{ width: "40px", height: "52px", objectFit: "contain" }}
              />
              <div>
                <strong style={{ fontSize: "1rem", color: "#0f172a", display: "block" }}>{modelName}</strong>
                <span style={{ fontSize: "0.78rem", color: "#64748b" }}>{brandName}</span>
              </div>
            </div>

            {/* DETAILS TABLE */}
            <div style={{ display: "flex", flexDirection: "column", gap: "10px", fontSize: "0.84rem" }}>
              {condition ? (
                <div style={{ display: "flex", justifyContent: "space-between" }}>
                  <span style={{ color: "#64748b" }}>Tình trạng</span>
                  <span style={{ color: "#0f172a", fontWeight: 600, textAlign: "right", maxWidth: "60%" }}>{condition}</span>
                </div>
              ) : null}
              {color ? (
                <div style={{ display: "flex", justifyContent: "space-between" }}>
                  <span style={{ color: "#64748b" }}>Màu sắc</span>
                  <span style={{ color: "#0f172a", fontWeight: 600 }}>{color}</span>
                </div>
              ) : null}
              {storage ? (
                <div style={{ display: "flex", justifyContent: "space-between" }}>
                  <span style={{ color: "#64748b" }}>Dung lượng</span>
                  <span style={{ color: "#0f172a", fontWeight: 600 }}>{storage}</span>
                </div>
              ) : null}
              {imei ? (
                <div style={{ display: "flex", justifyContent: "space-between" }}>
                  <span style={{ color: "#64748b" }}>IMEI</span>
                  <span style={{ color: "#0f172a", fontWeight: 600, fontFamily: "monospace" }}>{imei}</span>
                </div>
              ) : null}
              {!condition && !color && !storage && !imei ? (
                <div style={{ color: "#94a3b8", fontStyle: "italic", fontSize: "0.8rem" }}>
                  Thông tin phần cứng tiêu chuẩn theo dòng máy
                </div>
              ) : null}
            </div>
          </div>

          {/* CARD 2: DỊCH VỤ SỬA CHỮA */}
          <div
            style={{
              background: "#ffffff",
              border: "1px solid #e2e8f0",
              borderRadius: "16px",
              padding: "20px",
              boxShadow: "0 2px 8px rgba(15,23,42,0.02)",
            }}
          >
            <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "16px" }}>
              <div style={{ width: "32px", height: "32px", borderRadius: "8px", background: "#eff6ff", color: "#2563eb", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "1.1rem" }}>
                🔧
              </div>
              <h2 style={{ fontSize: "1rem", fontWeight: 800, color: "#0f172a", margin: 0 }}>
                Dịch vụ sửa chữa
              </h2>
            </div>

            <div style={{ display: "flex", flexDirection: "column", gap: "14px" }}>
              {services.map((svc, i) => (
                <div key={i} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", paddingBottom: i < services.length - 1 ? "12px" : "0", borderBottom: i < services.length - 1 ? "1px dashed #f1f5f9" : "none" }}>
                  <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                    <div style={{ width: "36px", height: "36px", borderRadius: "8px", background: svc.iconBg || "#eff6ff", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "1.1rem", flexShrink: 0 }}>
                      {svc.icon || "📱"}
                    </div>
                    <div>
                      <strong style={{ fontSize: "0.88rem", color: "#0f172a", display: "block" }}>{svc.name}</strong>
                      <span style={{ fontSize: "0.74rem", color: "#64748b" }}>{svc.desc || "Linh kiện chính hãng"}</span>
                    </div>
                  </div>
                  <strong style={{ fontSize: "0.95rem", color: "#0f172a" }}>
                    {formatVnd(svc.price)}
                  </strong>
                </div>
              ))}
            </div>
          </div>

          {/* CARD 3: CHI NHÁNH THỰC HIỆN */}
          <div
            style={{
              background: "#ffffff",
              border: "1px solid #e2e8f0",
              borderRadius: "16px",
              padding: "20px",
              boxShadow: "0 2px 8px rgba(15,23,42,0.02)",
            }}
          >
            <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "16px" }}>
              <div style={{ width: "32px", height: "32px", borderRadius: "8px", background: "#eff6ff", color: "#2563eb", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "1.1rem" }}>
                🏢
              </div>
              <h2 style={{ fontSize: "1rem", fontWeight: 800, color: "#0f172a", margin: 0 }}>
                Chi nhánh thực hiện
              </h2>
            </div>

            {/* BRANCH PREVIEW */}
            <div style={{ display: "flex", alignItems: "center", gap: "12px", marginBottom: "14px" }}>
              <img
                src={getBranchImage(branchName)}
                alt={branchName}
                style={{ width: "68px", height: "48px", borderRadius: "8px", objectFit: "cover" }}
              />
              <strong style={{ fontSize: "0.95rem", color: "#0f172a" }}>{branchName}</strong>
            </div>

            <div style={{ display: "flex", flexDirection: "column", gap: "8px", fontSize: "0.82rem", color: "#64748b" }}>
              <div style={{ display: "flex", alignItems: "flex-start", gap: "6px" }}>
                <span>📍</span>
                <span>{branchAddress}</span>
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: "6px" }}>
                <span>📞</span>
                <span>{branchPhone}</span>
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: "6px" }}>
                <span>🕒</span>
                <span>08:00 - 20:00 (Thứ 2 - Chủ nhật)</span>
              </div>
            </div>

            <Link
              to="/branches"
              style={{
                display: "inline-flex",
                alignItems: "center",
                gap: "4px",
                fontSize: "0.82rem",
                color: "#2563eb",
                fontWeight: 700,
                textDecoration: "none",
                marginTop: "12px",
              }}
            >
              <span>📍</span>
              <span>Xem chỉ đường &gt;</span>
            </Link>
          </div>

          {/* CARD 4: THÔNG TIN KHÁCH HÀNG */}
          <div
            style={{
              background: "#ffffff",
              border: "1px solid #e2e8f0",
              borderRadius: "16px",
              padding: "20px",
              boxShadow: "0 2px 8px rgba(15,23,42,0.02)",
            }}
          >
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "16px" }}>
              <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                <div style={{ width: "32px", height: "32px", borderRadius: "8px", background: "#eff6ff", color: "#2563eb", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "1.1rem" }}>
                  👤
                </div>
                <h2 style={{ fontSize: "1rem", fontWeight: 800, color: "#0f172a", margin: 0 }}>
                  Thông tin khách hàng
                </h2>
              </div>
              <Link to="/profile" style={{ fontSize: "0.78rem", color: "#2563eb", fontWeight: 600, textDecoration: "none" }}>
                ✏️ Chỉnh sửa
              </Link>
            </div>

            <div style={{ display: "flex", flexDirection: "column", gap: "12px", fontSize: "0.85rem" }}>
              <div style={{ display: "flex", justifyContent: "space-between" }}>
                <span style={{ color: "#64748b" }}>Họ và tên</span>
                <strong style={{ color: "#0f172a" }}>{customerName}</strong>
              </div>
              <div style={{ display: "flex", justifyContent: "space-between" }}>
                <span style={{ color: "#64748b" }}>Số điện thoại</span>
                <strong style={{ color: "#0f172a" }}>{customerPhone}</strong>
              </div>
              <div style={{ display: "flex", justifyContent: "space-between" }}>
                <span style={{ color: "#64748b" }}>Email</span>
                <strong style={{ color: "#0f172a" }}>{customerEmail}</strong>
              </div>
            </div>
          </div>

          {/* CARD 5: THỜI GIAN HẸN */}
          <div
            style={{
              background: "#ffffff",
              border: "1px solid #e2e8f0",
              borderRadius: "16px",
              padding: "20px",
              boxShadow: "0 2px 8px rgba(15,23,42,0.02)",
            }}
          >
            <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "16px" }}>
              <div style={{ width: "32px", height: "32px", borderRadius: "8px", background: "#eff6ff", color: "#2563eb", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "1.1rem" }}>
                📅
              </div>
              <h2 style={{ fontSize: "1rem", fontWeight: 800, color: "#0f172a", margin: 0 }}>
                Thời gian hẹn
              </h2>
            </div>

            <div style={{ display: "flex", flexDirection: "column", gap: "12px", fontSize: "0.85rem" }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <span style={{ color: "#64748b" }}>Ngày hẹn</span>
                <span style={{ color: "#0f172a", fontWeight: 700, display: "flex", alignItems: "center", gap: "6px" }}>
                  <span>📅</span>
                  <span>{appointmentDate}</span>
                </span>
              </div>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <span style={{ color: "#64748b" }}>Khung giờ</span>
                <span style={{ color: "#2563eb", fontWeight: 700, display: "flex", alignItems: "center", gap: "6px" }}>
                  <span>🕒</span>
                  <span>{slotTime}</span>
                </span>
              </div>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <span style={{ color: "#64748b" }}>Thời gian dự kiến</span>
                <span style={{ color: "#0f172a", fontWeight: 600, display: "flex", alignItems: "center", gap: "6px" }}>
                  <span>🕒</span>
                  <span>{estimatedDuration}</span>
                </span>
              </div>
            </div>
          </div>

          {/* CARD 6: TỔNG CHI PHÍ DỰ KIẾN */}
          <div
            style={{
              background: "#ffffff",
              border: "1px solid #e2e8f0",
              borderRadius: "16px",
              padding: "20px",
              boxShadow: "0 2px 8px rgba(15,23,42,0.02)",
            }}
          >
            <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "16px" }}>
              <div style={{ width: "32px", height: "32px", borderRadius: "8px", background: "#eff6ff", color: "#2563eb", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "1.1rem" }}>
                🧾
              </div>
              <h2 style={{ fontSize: "1rem", fontWeight: 800, color: "#0f172a", margin: 0 }}>
                Tổng chi phí dự kiến
              </h2>
            </div>

            <div style={{ display: "flex", flexDirection: "column", gap: "8px", fontSize: "0.85rem", marginBottom: "12px" }}>
              <div style={{ display: "flex", justifyContent: "space-between" }}>
                <span style={{ color: "#64748b" }}>Tạm tính dịch vụ ({services.length})</span>
                <strong style={{ color: "#0f172a" }}>{formatVnd(totalCost)}</strong>
              </div>
              <div style={{ display: "flex", justifyContent: "space-between" }}>
                <span style={{ color: "#64748b" }}>Giảm giá</span>
                <span style={{ color: "#0f172a" }}>0đ</span>
              </div>
            </div>

            <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", paddingTop: "10px", borderTop: "1px dashed #cbd5e1", marginBottom: "10px" }}>
              <span style={{ fontSize: "0.95rem", fontWeight: 800, color: "#0f172a" }}>Tổng cộng</span>
              <strong style={{ fontSize: "1.45rem", fontWeight: 900, color: "#2563eb" }}>
                {formatVnd(totalCost)}
              </strong>
            </div>

            <p style={{ fontSize: "0.72rem", color: "#64748b", margin: 0, lineHeight: 1.4 }}>
              ℹ️ Giá có thể thay đổi sau khi kỹ thuật viên kiểm tra thực tế tình trạng máy.
            </p>
          </div>
        </section>

        {/* ================= ACTION BUTTONS ================= */}
        <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: "14px", marginBottom: "48px" }}>
          <Link
            to={`/my-bookings/${bookingId}`}
            style={{
              background: "#2563eb",
              color: "#ffffff",
              padding: "12px 28px",
              borderRadius: "12px",
              fontWeight: 700,
              fontSize: "0.92rem",
              textDecoration: "none",
              display: "flex",
              alignItems: "center",
              gap: "8px",
              boxShadow: "0 4px 14px rgba(37,99,235,0.3)",
              transition: "all 0.15s ease",
            }}
          >
            <span>📄</span>
            <span>Xem chi tiết đơn hẹn</span>
          </Link>
          <Link
            to="/"
            style={{
              background: "#ffffff",
              color: "#334155",
              border: "1px solid #cbd5e1",
              padding: "12px 28px",
              borderRadius: "12px",
              fontWeight: 700,
              fontSize: "0.92rem",
              textDecoration: "none",
              display: "flex",
              alignItems: "center",
              gap: "8px",
              transition: "all 0.15s ease",
            }}
          >
            <span>🏠</span>
            <span>Về trang chủ</span>
          </Link>
        </div>

        {/* ================= FOOTER TRUST BADGES (4 COLUMNS) ================= */}
        <section
          style={{
            background: "#ffffff",
            border: "1px solid #e2e8f0",
            borderRadius: "16px",
            padding: "24px 20px",
            display: "grid",
            gridTemplateColumns: "repeat(4, 1fr)",
            gap: "20px",
            boxShadow: "0 2px 8px rgba(15,23,42,0.02)",
          }}
        >
          {/* BADGE 1: XÁC NHẬN QUA EMAIL */}
          <div style={{ display: "flex", alignItems: "flex-start", gap: "12px" }}>
            <div style={{ width: "38px", height: "38px", borderRadius: "50%", background: "#eff6ff", color: "#2563eb", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "1.1rem", flexShrink: 0 }}>
              ✉️
            </div>
            <div>
              <strong style={{ fontSize: "0.88rem", color: "#0f172a", display: "block", marginBottom: "4px" }}>
                Xác nhận qua email
              </strong>
              <p style={{ fontSize: "0.76rem", color: "#64748b", margin: 0, lineHeight: 1.4 }}>
                Chúng tôi đã gửi thông tin chi tiết đơn hẹn vào email của bạn.
              </p>
            </div>
          </div>

          {/* BADGE 2: NHẮC LỊCH TỰ ĐỘNG */}
          <div style={{ display: "flex", alignItems: "flex-start", gap: "12px" }}>
            <div style={{ width: "38px", height: "38px", borderRadius: "50%", background: "#eff6ff", color: "#2563eb", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "1.1rem", flexShrink: 0 }}>
              💬
            </div>
            <div>
              <strong style={{ fontSize: "0.88rem", color: "#0f172a", display: "block", marginBottom: "4px" }}>
                Nhắc lịch tự động
              </strong>
              <p style={{ fontSize: "0.76rem", color: "#64748b", margin: 0, lineHeight: 1.4 }}>
                Bạn sẽ nhận được tin nhắn nhắc lịch trước khi đến 1 ngày.
              </p>
            </div>
          </div>

          {/* BADGE 3: KỸ THUẬT VIÊN CHUYÊN NGHIỆP */}
          <div style={{ display: "flex", alignItems: "flex-start", gap: "12px" }}>
            <div style={{ width: "38px", height: "38px", borderRadius: "50%", background: "#eff6ff", color: "#2563eb", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "1.1rem", flexShrink: 0 }}>
              🛡️
            </div>
            <div>
              <strong style={{ fontSize: "0.88rem", color: "#0f172a", display: "block", marginBottom: "4px" }}>
                Kỹ thuật viên chuyên nghiệp
              </strong>
              <p style={{ fontSize: "0.76rem", color: "#64748b", margin: 0, lineHeight: 1.4 }}>
                Thiết bị của bạn sẽ được xử lý bởi đội ngũ kỹ thuật viên giàu kinh nghiệm.
              </p>
            </div>
          </div>

          {/* BADGE 4: HỖ TRỢ KHÁCH HÀNG */}
          <div style={{ display: "flex", alignItems: "flex-start", gap: "12px" }}>
            <div style={{ width: "38px", height: "38px", borderRadius: "50%", background: "#eff6ff", color: "#2563eb", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "1.1rem", flexShrink: 0 }}>
              🎧
            </div>
            <div>
              <strong style={{ fontSize: "0.88rem", color: "#0f172a", display: "block", marginBottom: "4px" }}>
                Hỗ trợ khách hàng
              </strong>
              <p style={{ fontSize: "0.76rem", color: "#64748b", margin: 0, lineHeight: 1.4 }}>
                Mọi thắc mắc vui lòng liên hệ 028 1234 5678
              </p>
            </div>
          </div>
        </section>
      </div>
    </main>
  )
}
