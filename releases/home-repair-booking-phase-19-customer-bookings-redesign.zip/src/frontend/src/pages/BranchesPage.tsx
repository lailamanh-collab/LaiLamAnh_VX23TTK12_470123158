import { useEffect, useState } from "react"
import { useNavigate } from "react-router-dom"
import { getBranches, type Branch } from "../api/branches"
import {
  branchCauGiay,
  branchDongDa,
  branchHaiBaTrung,
  branchThanhXuan,
  branchBaDinh,
  branchLongBien,
  workshopBg,
} from "../assets"

interface BranchItem extends Branch {
  distance: string
  image: string
  district: string
  rating: number
  hasParking: boolean
  featuredServices: Array<{ name: string; icon: string }>
  mapCoordinates: { x: number; y: number }
}

const FALLBACK_BRANCHES: BranchItem[] = [
  {
    id: 1,
    name: "HomeRepair Cầu Giấy",
    address: "123 Cầu Giấy, Quan Hoa, Cầu Giấy, Hà Nội",
    phone: "024 1234 5678",
    capacityPerSlot: 4,
    slotMinutes: 30,
    isActive: true,
    openingHours: [],
    distance: "2.1 km",
    image: branchCauGiay,
    district: "Cầu Giấy",
    rating: 4.9,
    hasParking: true,
    featuredServices: [
      { name: "Thay màn hình", icon: "📱" },
      { name: "Thay pin", icon: "🔋" },
      { name: "Sửa camera", icon: "📷" },
      { name: "Sửa loa", icon: "🔊" },
      { name: "Vệ sinh máy", icon: "🪄" },
    ],
    mapCoordinates: { x: 58, y: 50 },
  },
  {
    id: 2,
    name: "HomeRepair Đống Đa",
    address: "456 Xã Đàn, Nam Đồng, Đống Đa, Hà Nội",
    phone: "024 2345 6789",
    capacityPerSlot: 4,
    slotMinutes: 30,
    isActive: true,
    openingHours: [],
    distance: "3.5 km",
    image: branchDongDa,
    district: "Đống Đa",
    rating: 4.8,
    hasParking: true,
    featuredServices: [
      { name: "Thay màn hình", icon: "📱" },
      { name: "Thay pin", icon: "🔋" },
      { name: "Sửa sạc", icon: "⚡" },
      { name: "Sửa Face ID", icon: "⊡" },
      { name: "Vệ sinh máy", icon: "🪄" },
    ],
    mapCoordinates: { x: 49, y: 48 },
  },
  {
    id: 3,
    name: "HomeRepair Hai Bà Trưng",
    address: "789 Phố Huế, Hàng Bài, Hai Bà Trưng, Hà Nội",
    phone: "024 3456 7890",
    capacityPerSlot: 4,
    slotMinutes: 30,
    isActive: true,
    openingHours: [],
    distance: "5.3 km",
    image: branchHaiBaTrung,
    district: "Hai Bà Trưng",
    rating: 4.9,
    hasParking: true,
    featuredServices: [
      { name: "Thay màn hình", icon: "📱" },
      { name: "Thay pin", icon: "🔋" },
      { name: "Sửa loa", icon: "🔊" },
      { name: "Vệ sinh máy", icon: "🪄" },
    ],
    mapCoordinates: { x: 81, y: 60 },
  },
  {
    id: 4,
    name: "HomeRepair Thanh Xuân",
    address: "321 Nguyễn Trãi, Thanh Xuân, Hà Nội",
    phone: "024 3456 7890",
    capacityPerSlot: 4,
    slotMinutes: 30,
    isActive: true,
    openingHours: [],
    distance: "7.8 km",
    image: branchThanhXuan,
    district: "Thanh Xuân",
    rating: 4.8,
    hasParking: true,
    featuredServices: [
      { name: "Thay màn hình", icon: "📱" },
      { name: "Thay pin", icon: "🔋" },
      { name: "Sửa camera", icon: "📷" },
      { name: "Sửa micro", icon: "🎙️" },
    ],
    mapCoordinates: { x: 80, y: 17 },
  },
  {
    id: 5,
    name: "HomeRepair Ba Đình",
    address: "567 Đội Cấn, Liễu Giai, Ba Đình, Hà Nội",
    phone: "024 6789 1234",
    capacityPerSlot: 4,
    slotMinutes: 30,
    isActive: true,
    openingHours: [],
    distance: "6.2 km",
    image: branchBaDinh,
    district: "Ba Đình",
    rating: 4.7,
    hasParking: true,
    featuredServices: [
      { name: "Thay màn hình", icon: "📱" },
      { name: "Thay pin", icon: "🔋" },
      { name: "Vệ sinh máy", icon: "🪄" },
    ],
    mapCoordinates: { x: 34, y: 35 },
  },
  {
    id: 6,
    name: "HomeRepair Long Biên",
    address: "890 Nguyễn Văn Cừ, Long Biên, Hà Nội",
    phone: "024 6789 5678",
    capacityPerSlot: 4,
    slotMinutes: 30,
    isActive: true,
    openingHours: [],
    distance: "8.1 km",
    image: branchLongBien,
    district: "Long Biên",
    rating: 4.8,
    hasParking: true,
    featuredServices: [
      { name: "Thay màn hình", icon: "📱" },
      { name: "Thay pin", icon: "🔋" },
      { name: "Sửa loa", icon: "🔊" },
      { name: "Sửa sạc", icon: "⚡" },
    ],
    mapCoordinates: { x: 45, y: 16 },
  },
]

export function BranchesPage() {
  const navigate = useNavigate()
  const [branches, setBranches] = useState<BranchItem[]>(FALLBACK_BRANCHES)
  const [selectedBranchId, setSelectedBranchId] = useState<number>(1)
  const [searchKeyword, setSearchKeyword] = useState("")
  const [selectedCity, setSelectedCity] = useState("TP. Hồ Chí Minh")
  const [selectedService, setSelectedService] = useState("all")
  const [showDetail, setShowDetail] = useState(false)

  useEffect(() => {
    getBranches()
      .then((serverBranches) => {
        if (serverBranches && serverBranches.length > 0) {
          const enriched: BranchItem[] = serverBranches.map((b, index) => {
            const fallback = FALLBACK_BRANCHES.find((f) => f.id === b.id) || FALLBACK_BRANCHES[index % FALLBACK_BRANCHES.length]
            return {
              ...b,
              distance: fallback?.distance || `${(index + 1) * 2}.1 km`,
              image: fallback?.image || FALLBACK_BRANCHES[0].image,
              district: fallback?.district || "TP.HCM",
              rating: fallback?.rating || 4.9,
              hasParking: fallback?.hasParking ?? true,
              featuredServices: fallback?.featuredServices || FALLBACK_BRANCHES[0].featuredServices,
              mapCoordinates: fallback?.mapCoordinates || { x: 30 + (index % 4) * 15, y: 30 + (index % 3) * 15 },
            }
          })
          setBranches(enriched)
          if (enriched[0]) setSelectedBranchId(enriched[0].id)
        }
      })
      .catch(() => {})
  }, [])

  const filteredBranches = branches.filter((b) => {
    const matchKeyword =
      b.name.toLowerCase().includes(searchKeyword.toLowerCase()) ||
      b.address.toLowerCase().includes(searchKeyword.toLowerCase()) ||
      b.district.toLowerCase().includes(searchKeyword.toLowerCase())
    return matchKeyword
  })

  const selectedBranch = branches.find((b) => b.id === selectedBranchId) || branches[0] || FALLBACK_BRANCHES[0]

  const handleSelectBranch = (branchId: number) => {
    setSelectedBranchId(branchId)
  }

  const handleBookAtBranch = (branchId: number) => {
    navigate(`/booking?branchId=${branchId}`)
  }

  return (
    <main style={{ background: "#f8fafc", minHeight: "100vh", paddingBottom: "50px" }}>
      {/* 1. HERO HEADER WITH SAIGON SKYLINE BACKGROUND (MATCHING SCREENSHOT) */}
      <section
        style={{
          background: `linear-gradient(180deg, rgba(239, 246, 255, 0.90) 0%, rgba(248, 250, 252, 0.96) 100%), url('${workshopBg}') center/cover no-repeat`,
          padding: "44px 20px 36px",
          borderBottom: "1px solid #e2e8f0",
          marginBottom: "24px",
        }}
      >
        <div style={{ maxWidth: "1340px", margin: "0 auto" }}>
          <h1 style={{ fontSize: "2.35rem", fontWeight: 800, color: "#0f172a", margin: "0 0 10px", letterSpacing: "-0.03em" }}>
            Hệ thống chi nhánh HomeRepair
          </h1>
          <p style={{ fontSize: "1rem", color: "#475569", margin: "0 0 28px", lineHeight: 1.5 }}>
            Tìm chi nhánh gần bạn nhất tại TP. Hồ Chí Minh để được hỗ trợ nhanh chóng, chuyên nghiệp
          </p>

          {/* 4 FEATURE PILLS IN A ROW */}
          <div style={{ display: "flex", flexWrap: "wrap", gap: "16px" }}>
            {/* Pill 1 */}
            <div
              style={{
                background: "#ffffff",
                border: "1px solid #e2e8f0",
                borderRadius: "999px",
                padding: "8px 18px",
                display: "flex",
                alignItems: "center",
                gap: "10px",
                boxShadow: "0 2px 6px rgba(15,23,42,0.03)",
              }}
            >
              <div style={{ width: "26px", height: "26px", borderRadius: "50%", background: "#eff6ff", color: "#2563eb", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "0.85rem" }}>
                📍
              </div>
              <div style={{ fontSize: "0.86rem" }}>
                <strong style={{ color: "#0f172a" }}>Nhiều chi nhánh</strong>
                <span style={{ color: "#64748b", marginLeft: "6px" }}>thuận tiện di chuyển</span>
              </div>
            </div>

            {/* Pill 2 */}
            <div
              style={{
                background: "#ffffff",
                border: "1px solid #e2e8f0",
                borderRadius: "999px",
                padding: "8px 18px",
                display: "flex",
                alignItems: "center",
                gap: "10px",
                boxShadow: "0 2px 6px rgba(15,23,42,0.03)",
              }}
            >
              <div style={{ width: "26px", height: "26px", borderRadius: "50%", background: "#eff6ff", color: "#0284c7", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "0.85rem" }}>
                🕒
              </div>
              <div style={{ fontSize: "0.86rem" }}>
                <strong style={{ color: "#0f172a" }}>Giờ mở cửa linh hoạt</strong>
                <span style={{ color: "#64748b", marginLeft: "6px" }}>8:00 - 20:00 hàng ngày</span>
              </div>
            </div>

            {/* Pill 3 */}
            <div
              style={{
                background: "#ffffff",
                border: "1px solid #e2e8f0",
                borderRadius: "999px",
                padding: "8px 18px",
                display: "flex",
                alignItems: "center",
                gap: "10px",
                boxShadow: "0 2px 6px rgba(15,23,42,0.03)",
              }}
            >
              <div style={{ width: "26px", height: "26px", borderRadius: "50%", background: "#eff6ff", color: "#16a34a", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "0.85rem" }}>
                🛡️
              </div>
              <div style={{ fontSize: "0.86rem" }}>
                <strong style={{ color: "#0f172a" }}>Kỹ thuật viên chuyên nghiệp</strong>
                <span style={{ color: "#64748b", marginLeft: "6px" }}>Tại tất cả chi nhánh</span>
              </div>
            </div>

            {/* Pill 4 */}
            <div
              style={{
                background: "#ffffff",
                border: "1px solid #e2e8f0",
                borderRadius: "999px",
                padding: "8px 18px",
                display: "flex",
                alignItems: "center",
                gap: "10px",
                boxShadow: "0 2px 6px rgba(15,23,42,0.03)",
              }}
            >
              <div style={{ width: "26px", height: "26px", borderRadius: "50%", background: "#fef9c3", color: "#eab308", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "0.85rem" }}>
                ⭐
              </div>
              <div style={{ fontSize: "0.86rem" }}>
                <strong style={{ color: "#0f172a" }}>Dịch vụ đồng nhất</strong>
                <span style={{ color: "#64748b", marginLeft: "6px" }}>Chất lượng toàn hệ thống</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 2. SEARCH & FILTER TOOLBAR (MATCHING SCREENSHOT) */}
      <div style={{ maxWidth: "1340px", margin: "0 auto 24px", padding: "0 20px" }}>
        <div
          style={{
            background: "#ffffff",
            border: "1px solid #e2e8f0",
            borderRadius: "16px",
            padding: "12px 16px",
            display: "grid",
            gridTemplateColumns: "2.4fr 1.3fr 1.3fr 1fr",
            gap: "14px",
            alignItems: "center",
            boxShadow: "0 4px 14px rgba(15,23,42,0.03)",
          }}
        >
          {/* SEARCH INPUT */}
          <div style={{ position: "relative", display: "flex", alignItems: "center" }}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#94a3b8" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" style={{ position: "absolute", left: "14px" }}>
              <circle cx="11" cy="11" r="8" />
              <line x1="21" y1="21" x2="16.65" y2="16.65" />
            </svg>
            <input
              type="text"
              placeholder="Tìm kiếm chi nhánh, quận, địa chỉ..."
              value={searchKeyword}
              onChange={(e) => setSearchKeyword(e.target.value)}
              style={{
                width: "100%",
                height: "44px",
                padding: "0 14px 0 42px",
                borderRadius: "10px",
                border: "1px solid #cbd5e1",
                background: "#f8fafc",
                fontSize: "0.88rem",
                color: "#0f172a",
                outline: "none",
              }}
            />
          </div>

          {/* CITY DROPDOWN */}
          <div style={{ position: "relative" }}>
            <select
              value={selectedCity}
              onChange={(e) => setSelectedCity(e.target.value)}
              style={{
                width: "100%",
                height: "44px",
                padding: "0 14px",
                borderRadius: "10px",
                border: "1px solid #cbd5e1",
                background: "#f8fafc",
                fontSize: "0.88rem",
                color: "#0f172a",
                fontWeight: 600,
                outline: "none",
                cursor: "pointer",
              }}
            >
              <option value="TP. Hồ Chí Minh">📍 TP. Hồ Chí Minh</option>
              <option value="Hà Nội">📍 Hà Nội</option>
              <option value="Đà Nẵng">📍 Đà Nẵng</option>
            </select>
          </div>

          {/* SERVICE DROPDOWN */}
          <div style={{ position: "relative" }}>
            <select
              value={selectedService}
              onChange={(e) => setSelectedService(e.target.value)}
              style={{
                width: "100%",
                height: "44px",
                padding: "0 14px",
                borderRadius: "10px",
                border: "1px solid #cbd5e1",
                background: "#f8fafc",
                fontSize: "0.88rem",
                color: "#0f172a",
                fontWeight: 600,
                outline: "none",
                cursor: "pointer",
              }}
            >
              <option value="all">⚙️ Tất cả dịch vụ</option>
              <option value="screen">Thay màn hình</option>
              <option value="battery">Thay pin</option>
              <option value="camera">Sửa camera</option>
              <option value="clean">Vệ sinh máy</option>
            </select>
          </div>

          {/* SEARCH BUTTON */}
          <button
            type="button"
            style={{
              height: "44px",
              padding: "0 24px",
              borderRadius: "10px",
              background: "#2563eb",
              color: "#ffffff",
              border: "none",
              fontWeight: 700,
              fontSize: "0.9rem",
              cursor: "pointer",
              boxShadow: "0 2px 8px rgba(37,99,235,0.25)",
              whiteSpace: "nowrap",
            }}
          >
            Tìm chi nhánh
          </button>
        </div>
      </div>

      {/* 3. MAIN 2-COLUMN SPLIT VIEW: LIST (LEFT) & MAP + DETAILS (RIGHT) */}
      <div style={{ maxWidth: "1340px", margin: "0 auto", padding: "0 20px" }}>
        <div style={{ display: "grid", gridTemplateColumns: "520px 1fr", gap: "24px", alignItems: "flex-start" }}>
          {/* LEFT LIST COLUMN */}
          <div>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "14px" }}>
              <strong style={{ fontSize: "1.05rem", color: "#0f172a" }}>
                Danh sách chi nhánh tại TP. Hồ Chí Minh ({filteredBranches.length} chi nhánh)
              </strong>
              <span style={{ fontSize: "0.84rem", color: "#64748b" }}>
                Sắp xếp: <strong style={{ color: "#0f172a" }}>Gần nhất ⌄</strong>
              </span>
            </div>

            <div style={{ display: "flex", flexDirection: "column", gap: "14px" }}>
              {filteredBranches.map((b) => {
                const isSelected = b.id === selectedBranchId
                return (
                  <article
                    key={b.id}
                    onClick={() => handleSelectBranch(b.id)}
                    style={{
                      background: "#ffffff",
                      border: isSelected ? "1.5px solid #2563eb" : "1px solid #e2e8f0",
                      borderRadius: "16px",
                      padding: "14px",
                      display: "flex",
                      gap: "14px",
                      boxShadow: isSelected ? "0 4px 16px rgba(37,99,235,0.12)" : "0 2px 8px rgba(15,23,42,0.02)",
                      cursor: "pointer",
                      transition: "all 0.15s ease",
                    }}
                  >
                    <img
                      src={b.image}
                      alt={b.name}
                      style={{
                        width: "115px",
                        height: "90px",
                        borderRadius: "10px",
                        objectFit: "cover",
                        flexShrink: 0,
                      }}
                    />

                    <div style={{ flex: 1, display: "flex", flexDirection: "column", justifyContent: "space-between" }}>
                      <div>
                        <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: "8px", marginBottom: "4px" }}>
                          <h2 style={{ fontSize: "0.98rem", fontWeight: 800, color: "#0f172a", margin: 0 }}>
                            {b.name}
                          </h2>
                          <span
                            style={{
                              fontSize: "0.76rem",
                              fontWeight: 700,
                              color: "#2563eb",
                              background: "#eff6ff",
                              padding: "2px 8px",
                              borderRadius: "6px",
                              display: "inline-flex",
                              alignItems: "center",
                              gap: "3px",
                              whiteSpace: "nowrap",
                            }}
                          >
                            ↗ {b.distance}
                          </span>
                        </div>

                        <div style={{ fontSize: "0.78rem", color: "#64748b", display: "flex", flexDirection: "column", gap: "2px" }}>
                          <div>📍 {b.address}</div>
                          <div>🕒 08:00 - 20:00 (T2 - CN)</div>
                          <div>📞 {b.phone}</div>
                        </div>
                      </div>

                      <div style={{ display: "flex", gap: "8px", marginTop: "10px" }}>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation()
                            setSelectedBranchId(b.id)
                            setShowDetail(true)
                          }}
                          style={{
                            padding: "6px 14px",
                            borderRadius: "8px",
                            background: "#2563eb",
                            color: "#ffffff",
                            border: "none",
                            fontSize: "0.78rem",
                            fontWeight: 700,
                            cursor: "pointer",
                          }}
                        >
                          Xem chi tiết
                        </button>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation()
                            handleBookAtBranch(b.id)
                          }}
                          style={{
                            padding: "6px 14px",
                            borderRadius: "8px",
                            background: "#ffffff",
                            color: "#2563eb",
                            border: "1px solid #cbd5e1",
                            fontSize: "0.78rem",
                            fontWeight: 700,
                            cursor: "pointer",
                            display: "inline-flex",
                            alignItems: "center",
                            gap: "4px",
                          }}
                        >
                          <span>↗</span>
                          <span>Chọn chi nhánh</span>
                        </button>
                      </div>
                    </div>
                  </article>
                )
              })}
            </div>
          </div>

          {/* RIGHT MAP COLUMN WITH REAL GOOGLE MAP & CONDITIONAL BRANCH DETAIL */}
          <div
            style={{
              background: "#ffffff",
              border: "1px solid #e2e8f0",
              borderRadius: "18px",
              overflow: "hidden",
              boxShadow: "0 2px 10px rgba(15,23,42,0.03)",
              position: "sticky",
              top: "20px",
            }}
          >
            {/* MAP HEADER */}
            <div
              style={{
                padding: "12px 18px",
                background: "#f8fafc",
                borderBottom: "1px solid #e2e8f0",
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                gap: "12px",
              }}
            >
              <div style={{ display: "flex", alignItems: "center", gap: "8px", minWidth: 0 }}>
                <span style={{ fontSize: "1rem" }}>📍</span>
                <div style={{ minWidth: 0 }}>
                  <strong style={{ fontSize: "0.88rem", color: "#0f172a", display: "block", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                    {selectedBranch.name}
                  </strong>
                  <span style={{ fontSize: "0.74rem", color: "#64748b", display: "block", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                    {selectedBranch.address}
                  </span>
                </div>
              </div>

              <div style={{ display: "flex", alignItems: "center", gap: "8px", flexShrink: 0 }}>
                <a
                  href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
                    `${selectedBranch.name}, ${selectedBranch.address}`
                  )}`}
                  target="_blank"
                  rel="noreferrer"
                  style={{
                    fontSize: "0.78rem",
                    color: "#2563eb",
                    textDecoration: "none",
                    fontWeight: 700,
                    background: "#eff6ff",
                    padding: "6px 12px",
                    borderRadius: "8px",
                    border: "1px solid #bfdbfe",
                    display: "inline-flex",
                    alignItems: "center",
                    gap: "4px",
                  }}
                >
                  <span>Chỉ đường</span>
                  <span>↗</span>
                </a>
              </div>
            </div>

            {/* REAL GOOGLE MAP IFRAME */}
            <div
              style={{
                width: "100%",
                height: showDetail ? "300px" : "540px",
                transition: "height 0.3s ease",
                background: "#f1f5f9",
              }}
            >
              <iframe
                title={`Google Map - ${selectedBranch.name}`}
                width="100%"
                height="100%"
                style={{ border: 0, display: "block" }}
                loading="lazy"
                allowFullScreen
                referrerPolicy="no-referrer-when-downgrade"
                src={`https://maps.google.com/maps?q=${encodeURIComponent(
                  `${selectedBranch.name}, ${selectedBranch.address}`
                )}&t=&z=16&ie=UTF8&iwloc=&output=embed`}
              />
            </div>

            {/* IF DETAIL IS HIDDEN: HINT ROW TO CLICK "XEM CHI TIẾT" */}
            {!showDetail ? (
              <div
                style={{
                  padding: "16px 20px",
                  borderTop: "1px solid #e2e8f0",
                  background: "#ffffff",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                  gap: "12px",
                }}
              >
                <div style={{ fontSize: "0.84rem", color: "#64748b" }}>
                  Bấm <strong>"Xem chi tiết"</strong> ở danh sách bên trái để xem đầy đủ thông tin dịch vụ và tiện ích chi nhánh.
                </div>
                <button
                  type="button"
                  onClick={() => setShowDetail(true)}
                  style={{
                    padding: "8px 16px",
                    borderRadius: "10px",
                    background: "#2563eb",
                    color: "#ffffff",
                    border: "none",
                    fontSize: "0.82rem",
                    fontWeight: 700,
                    cursor: "pointer",
                    whiteSpace: "nowrap",
                    boxShadow: "0 2px 8px rgba(37,99,235,0.25)",
                  }}
                >
                  Xem chi tiết {selectedBranch.name} →
                </button>
              </div>
            ) : (
              /* DOCKED SELECTED BRANCH CARD WHEN showDetail IS TRUE */
              <div style={{ padding: "20px", borderTop: "1px solid #e2e8f0", background: "#ffffff" }}>
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "14px" }}>
                  <span style={{ fontSize: "0.82rem", fontWeight: 700, color: "#2563eb", textTransform: "uppercase", letterSpacing: "0.04em" }}>
                    Thông tin chi tiết chi nhánh
                  </span>
                  <button
                    type="button"
                    onClick={() => setShowDetail(false)}
                    style={{
                      border: "none",
                      background: "#f1f5f9",
                      color: "#64748b",
                      padding: "4px 10px",
                      borderRadius: "6px",
                      fontSize: "0.78rem",
                      fontWeight: 700,
                      cursor: "pointer",
                    }}
                  >
                    ✕ Đóng chi tiết
                  </button>
                </div>

                <div style={{ display: "grid", gridTemplateColumns: "140px 1fr", gap: "16px", alignItems: "flex-start", marginBottom: "16px" }}>
                  <img
                    src={selectedBranch.image}
                    alt={selectedBranch.name}
                    style={{
                      width: "140px",
                      height: "110px",
                      borderRadius: "12px",
                      objectFit: "cover",
                    }}
                  />

                  <div>
                    <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "6px" }}>
                      <h3 style={{ fontSize: "1.15rem", fontWeight: 800, margin: 0, color: "#0f172a" }}>
                        {selectedBranch.name}
                      </h3>
                      <span
                        style={{
                          background: "#eff6ff",
                          color: "#2563eb",
                          fontSize: "0.74rem",
                          fontWeight: 700,
                          padding: "2px 8px",
                          borderRadius: "999px",
                          border: "1px solid #bfdbfe",
                          display: "inline-flex",
                          alignItems: "center",
                          gap: "4px",
                        }}
                      >
                        📍 {selectedBranch.district}
                      </span>
                    </div>

                    <div style={{ display: "flex", flexDirection: "column", gap: "4px", fontSize: "0.8rem", color: "#64748b", marginBottom: "8px" }}>
                      <div>📍 {selectedBranch.address}</div>
                      <div>🕒 08:00 - 20:00 (Thứ 2 - Chủ nhật)</div>
                      <div>📞 {selectedBranch.phone}</div>
                    </div>

                    <div style={{ display: "flex", gap: "8px", flexWrap: "wrap" }}>
                      <span style={{ color: "#0284c7", background: "#f0f9ff", border: "1px solid #bae6fd", padding: "2px 8px", borderRadius: "6px", fontSize: "0.74rem", fontWeight: 600 }}>
                        🚗 Có chỗ đỗ xe
                      </span>
                      <span style={{ color: "#16a34a", background: "#f0fdf4", border: "1px solid #bbf7d0", padding: "2px 8px", borderRadius: "6px", fontSize: "0.74rem", fontWeight: 600 }}>
                        ⭐ Đánh giá {selectedBranch.rating || "4.9"}/5
                      </span>
                    </div>
                  </div>
                </div>

                {/* HIGHLIGHT SERVICES OF THIS BRANCH */}
                {selectedBranch.featuredServices && selectedBranch.featuredServices.length > 0 && (
                  <div style={{ marginBottom: "16px" }}>
                    <span style={{ fontSize: "0.8rem", fontWeight: 700, color: "#0f172a", display: "block", marginBottom: "8px" }}>
                      Dịch vụ sửa chữa tại chi nhánh:
                    </span>
                    <div style={{ display: "flex", gap: "8px", overflowX: "auto", paddingBottom: "4px" }}>
                      {selectedBranch.featuredServices.map((svc, i) => (
                        <div
                          key={i}
                          style={{
                            padding: "6px 12px",
                            background: "#f8fafc",
                            border: "1px solid #e2e8f0",
                            borderRadius: "8px",
                            display: "flex",
                            alignItems: "center",
                            gap: "6px",
                            flexShrink: 0,
                            fontSize: "0.78rem",
                            color: "#334155",
                            fontWeight: 600,
                          }}
                        >
                          <span>{svc.icon}</span>
                          <span>{svc.name}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* 2 ACTION BUTTONS */}
                <div style={{ display: "flex", gap: "10px" }}>
                  <button
                    type="button"
                    onClick={() => setShowDetail(false)}
                    style={{
                      flex: 1,
                      height: "38px",
                      borderRadius: "10px",
                      border: "1px solid #cbd5e1",
                      background: "#ffffff",
                      fontSize: "0.84rem",
                      fontWeight: 600,
                      color: "#475569",
                      cursor: "pointer",
                    }}
                  >
                    Ẩn chi tiết
                  </button>
                  <button
                    type="button"
                    onClick={() => handleBookAtBranch(selectedBranch.id)}
                    style={{
                      flex: 2,
                      height: "38px",
                      borderRadius: "10px",
                      border: "none",
                      background: "#2563eb",
                      color: "#ffffff",
                      fontSize: "0.86rem",
                      fontWeight: 700,
                      cursor: "pointer",
                      display: "inline-flex",
                      alignItems: "center",
                      justifyContent: "center",
                      gap: "8px",
                      boxShadow: "0 4px 12px rgba(37,99,235,0.3)",
                    }}
                  >
                    <span>📅</span>
                    <span>Đặt lịch tại chi nhánh này</span>
                  </button>
                </div>
              </div>
            )}
          </div>        </div>
      </div>
    </main>
  )
}
