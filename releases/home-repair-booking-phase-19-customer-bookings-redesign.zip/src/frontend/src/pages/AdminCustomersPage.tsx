import { useEffect, useState } from "react"
import { Link } from "react-router-dom"
import {
  adminGetCustomerDetail,
  adminGetCustomers,
  adminToggleCustomerStatus,
  type CustomerDetail,
  type CustomerSummary,
} from "../api/adminBookings"
import { statusLabel } from "../api/bookings"
import { ApiError } from "../api/client"
import { useAuth } from "../auth/AuthContext"

export function AdminCustomersPage() {
  const { token } = useAuth()
  const [customers, setCustomers] = useState<CustomerSummary[]>([])
  const [search, setSearch] = useState("")
  const [loading, setLoading] = useState(false)
  const [message, setMessage] = useState("")

  // Selected customer for history modal
  const [selectedCustomer, setSelectedCustomer] = useState<CustomerDetail | null>(null)
  const [historyLoading, setHistoryLoading] = useState(false)

  async function loadCustomers() {
    if (!token) return
    setLoading(true)
    setMessage("")
    try {
      const data = await adminGetCustomers(token, search)
      setCustomers(data)
    } catch (err) {
      setMessage(err instanceof ApiError ? err.message : "Không tải được danh sách khách hàng.")
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    void loadCustomers()
  }, [token])

  function handleSearchSubmit(e: React.FormEvent) {
    e.preventDefault()
    void loadCustomers()
  }

  async function handleToggleStatus(c: CustomerSummary) {
    if (!token) return
    try {
      await adminToggleCustomerStatus(token, c.id)
      setMessage(`Đã ${c.isActive ? "vô hiệu hóa" : "kích hoạt"} tài khoản ${c.fullName}.`)
      await loadCustomers()
    } catch (err) {
      setMessage(err instanceof ApiError ? err.message : "Không đổi được trạng thái tài khoản.")
    }
  }

  async function handleViewHistory(c: CustomerSummary) {
    if (!token) return
    setHistoryLoading(true)
    try {
      const detail = await adminGetCustomerDetail(token, c.id)
      setSelectedCustomer(detail)
    } catch (err) {
      setMessage(err instanceof ApiError ? err.message : "Không tải được lịch sử khách hàng.")
    } finally {
      setHistoryLoading(false)
    }
  }

  return (
    <main className="page">
      <section className="section-head" style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: "12px" }}>
        <div>
          <h1>Quản lý khách hàng</h1>
          <p className="section-intro">Danh sách tài khoản khách hàng, lịch sử đặt hẹn và phân quyền kích hoạt tài khoản.</p>
        </div>
      </section>

      {message ? <p className="form-success" style={{ margin: "12px 0" }}>{message}</p> : null}

      {/* SEARCH TOOLBAR */}
      <form className="card form" onSubmit={handleSearchSubmit} style={{ marginTop: "16px", padding: "16px 20px" }}>
        <div style={{ display: "flex", gap: "12px", alignItems: "flex-end", flexWrap: "wrap" }}>
          <label className="field" style={{ flex: 1, minWidth: "260px", margin: 0 }}>
            <span>Tìm kiếm khách hàng</span>
            <input
              className="input"
              type="search"
              placeholder="Nhập tên, email hoặc số điện thoại..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </label>
          <button className="btn" type="submit">
            Tìm kiếm
          </button>
          {search ? (
            <button
              className="btn btn-quiet"
              type="button"
              onClick={() => {
                setSearch("")
                void loadCustomers()
              }}
            >
              Xem tất cả
            </button>
          ) : null}
        </div>
      </form>

      {/* CUSTOMERS TABLE */}
      <section className="card" style={{ marginTop: "20px", overflowX: "auto" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "12px" }}>
          <strong>Khách hàng ({customers.length})</strong>
          {loading ? <span className="muted">Đang tải...</span> : null}
        </div>

        {customers.length === 0 && !loading ? (
          <p className="muted" style={{ padding: "20px 0", textAlign: "center" }}>
            Không tìm thấy khách hàng nào.
          </p>
        ) : (
          <table style={{ width: "100%", borderCollapse: "collapse", textAlign: "left", fontSize: "0.92rem" }}>
            <thead>
              <tr style={{ borderBottom: "2px solid var(--color-line)", color: "var(--color-muted)" }}>
                <th style={{ padding: "10px 8px" }}>Họ tên</th>
                <th style={{ padding: "10px 8px" }}>Email</th>
                <th style={{ padding: "10px 8px" }}>Số điện thoại</th>
                <th style={{ padding: "10px 8px" }}>Ngày tạo</th>
                <th style={{ padding: "10px 8px" }}>Tổng lịch đặt</th>
                <th style={{ padding: "10px 8px" }}>Hoàn thành</th>
                <th style={{ padding: "10px 8px" }}>Trạng thái</th>
                <th style={{ padding: "10px 8px", textAlign: "right" }}>Thao tác</th>
              </tr>
            </thead>
            <tbody>
              {customers.map((c) => (
                <tr key={c.id} style={{ borderBottom: "1px solid var(--color-line)" }}>
                  <td style={{ padding: "10px 8px", fontWeight: 600 }}>
                    {c.fullName}
                  </td>
                  <td style={{ padding: "10px 8px" }}>
                    {c.email}
                  </td>
                  <td style={{ padding: "10px 8px" }}>
                    {c.phoneNumber || "—"}
                  </td>
                  <td style={{ padding: "10px 8px", color: "var(--color-muted)" }}>
                    {new Date(c.createdAt).toLocaleDateString("vi-VN")}
                  </td>
                  <td style={{ padding: "10px 8px", fontWeight: 600 }}>
                    {c.totalBookings}
                  </td>
                  <td style={{ padding: "10px 8px", color: "var(--color-ok)", fontWeight: 600 }}>
                    {c.completedBookings}
                  </td>
                  <td style={{ padding: "10px 8px" }}>
                    <span className={c.isActive ? "badge badge-completed" : "badge badge-cancelled"}>
                      {c.isActive ? "Hoạt động" : "Đã khóa"}
                    </span>
                  </td>
                  <td style={{ padding: "10px 8px", textAlign: "right" }}>
                    <div style={{ display: "flex", gap: "6px", justifyContent: "flex-end" }}>
                      <button
                        className="btn btn-quiet"
                        type="button"
                        style={{ padding: "4px 10px", fontSize: "0.8rem" }}
                        disabled={historyLoading}
                        onClick={() => void handleViewHistory(c)}
                      >
                        Lịch sử đặt ({c.totalBookings})
                      </button>
                      <button
                        className="btn btn-quiet"
                        type="button"
                        style={{
                          padding: "4px 10px",
                          fontSize: "0.8rem",
                          color: c.isActive ? "var(--color-danger)" : "var(--color-ok)",
                        }}
                        onClick={() => void handleToggleStatus(c)}
                      >
                        {c.isActive ? "Khóa" : "Mở khóa"}
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </section>

      {/* CUSTOMER HISTORY MODAL */}
      {selectedCustomer ? (
        <div
          style={{
            position: "fixed",
            inset: 0,
            background: "rgba(0,0,0,0.5)",
            backdropFilter: "blur(4px)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 100,
            padding: "16px",
          }}
          onClick={(e) => {
            if (e.target === e.currentTarget) setSelectedCustomer(null)
          }}
        >
          <div
            className="card"
            style={{
              maxWidth: "760px",
              width: "100%",
              maxHeight: "85vh",
              overflowY: "auto",
              padding: "24px",
            }}
          >
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: "16px" }}>
              <div>
                <span className="eyebrow">Lịch sử khách hàng</span>
                <h2 style={{ margin: "2px 0 0" }}>{selectedCustomer.fullName}</h2>
                <p className="muted" style={{ margin: "4px 0 0" }}>
                  {selectedCustomer.email} · {selectedCustomer.phoneNumber || "Không có SĐT"}
                </p>
              </div>
              <button
                className="btn btn-quiet"
                type="button"
                onClick={() => setSelectedCustomer(null)}
                style={{ padding: "4px 10px" }}
              >
                ✕ Đóng
              </button>
            </div>

            <h3>Danh sách lịch hẹn ({selectedCustomer.bookings.length})</h3>
            {selectedCustomer.bookings.length === 0 ? (
              <p className="muted">Khách hàng chưa tạo lịch hẹn nào.</p>
            ) : (
              <div style={{ display: "flex", flexDirection: "column", gap: "10px", marginTop: "12px" }}>
                {selectedCustomer.bookings.map((b) => (
                  <div
                    key={b.id}
                    style={{
                      padding: "12px",
                      background: "#f8fafc",
                      borderRadius: "10px",
                      border: "1px solid var(--color-line)",
                      display: "flex",
                      justifyContent: "space-between",
                      alignItems: "center",
                      flexWrap: "wrap",
                      gap: "8px",
                    }}
                  >
                    <div>
                      <strong style={{ color: "var(--color-accent-strong)" }}>{b.bookingCode}</strong>
                      <p style={{ margin: "2px 0", fontSize: "0.95rem" }}>
                        {b.brandName} {b.phoneModelName} · 📍 {b.branchName}
                      </p>
                      <p style={{ margin: "2px 0", color: "var(--color-muted)", fontSize: "0.85rem" }}>
                        Ngày {b.appointmentDate} lúc {b.slotStart} · Tạm tính: {new Intl.NumberFormat("vi-VN").format(b.estimatedTotal)} đ
                      </p>
                    </div>

                    <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                      <span className="badge">
                        {statusLabel[b.status] ?? b.status}
                      </span>
                      <Link
                        className="btn btn-quiet"
                        to={`/my-bookings/${b.id}`}
                        style={{ padding: "4px 8px", fontSize: "0.8rem" }}
                      >
                        Chi tiết
                      </Link>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      ) : null}
    </main>
  )
}
