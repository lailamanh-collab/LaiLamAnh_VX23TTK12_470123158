import { useEffect, useState } from "react"
import { useSearchParams } from "react-router-dom"
import { formatPrice, getBrands, getModels, getPrices, pricingLabel, type Brand, type PhoneModel, type ServicePrice } from "../api/catalog"
import { BRAND_LOGOS, getPhoneImage } from "../assets"

export function ModelsPage() {
  const [params, setParams] = useSearchParams()
  const brandId = params.get("brandId") ?? ""
  const [brands, setBrands] = useState<Brand[]>([])
  const [models, setModels] = useState<PhoneModel[]>([])
  const [selectedId, setSelectedId] = useState<number | null>(null)
  const [prices, setPrices] = useState<ServicePrice[]>([])

  useEffect(() => {
    getBrands().then(setBrands).catch(() => setBrands([]))
  }, [])

  useEffect(() => {
    getModels(brandId ? Number(brandId) : undefined).then(setModels).catch(() => setModels([]))
  }, [brandId])

  useEffect(() => {
    if (!selectedId) {
      setPrices([])
      return
    }
    getPrices(selectedId).then(setPrices).catch(() => setPrices([]))
  }, [selectedId])

  return (
    <main className="page">
      <section className="section-head">
        <h1>Dòng máy</h1>
        <p className="section-intro">Mỗi dòng máy có bảng giá dịch vụ riêng.</p>
      </section>
      <label className="field toolbar-single">
        <span>Lọc theo hãng</span>
        <select className="input" value={brandId} onChange={(event) => setParams(event.target.value ? { brandId: event.target.value } : {})}>
          <option value="">Tất cả</option>
          {brands.map((brand) => <option key={brand.id} value={brand.id}>{brand.name}</option>)}
        </select>
      </label>
      <div className="split">
        <div className="result-list">
          {models.map((model) => {
            const isWordmark = ["Samsung", "Oppo", "Vivo", "Honor", "Realme"].includes(model.brandName)
            return (
              <button className={selectedId === model.id ? "card card-button card-selected" : "card card-button"} key={model.id} type="button" onClick={() => setSelectedId(model.id)}>
                <img className="model-image" src={model.imageUrl || getPhoneImage(model.name)} alt={model.name} loading="lazy" />
                <div style={{ display: "flex", alignItems: "center", gap: "6px", height: "20px" }}>
                  {BRAND_LOGOS[model.brandName] && (
                    <img
                      src={BRAND_LOGOS[model.brandName]}
                      alt={model.brandName}
                      style={
                        isWordmark
                          ? { height: "14px", maxWidth: "56px", objectFit: "contain" }
                          : { width: "16px", height: "16px", objectFit: "contain" }
                      }
                    />
                  )}
                  {!isWordmark && <strong>{model.brandName}</strong>}
                </div>
                <span>{model.name}</span>
              </button>
            )
          })}
        </div>
        <aside className="card">
          <h2>Dịch vụ hỗ trợ</h2>
          {prices.length === 0 ? (
            <p>Chọn một dòng máy để xem giá.</p>
          ) : (
            <>
              {prices.map((price) => (
                <p key={price.id}>
                  {price.repairServiceName} · {pricingLabel(price.pricingType)} · {formatPrice(price.pricingType, price.price)}
                </p>
              ))}
              <div style={{ marginTop: "20px", paddingTop: "14px", borderTop: "1px solid var(--color-line)" }}>
                <a
                  href={`/booking?modelId=${selectedId}`}
                  className="btn"
                  style={{ width: "100%", justifyContent: "center", textDecoration: "none" }}
                >
                  📅 Đặt lịch cho dòng máy này
                </a>
              </div>
            </>
          )}
        </aside>
      </div>
    </main>
  )
}
