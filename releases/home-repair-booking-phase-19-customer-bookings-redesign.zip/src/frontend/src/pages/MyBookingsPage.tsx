import { useEffect, useState } from "react"
import { Link, useNavigate, useParams, useSearchParams } from "react-router-dom"
import { myBookings, type BookingSummary } from "../api/bookings"
import { updateProfile, changePassword } from "../api/auth"
import { submitReview } from "../api/reviews"
import { useAuth } from "../auth/AuthContext"
import { getPhoneImage, getAvatarImage } from "../assets"

type PortalTabId = "overview" | "bookings" | "profile" | "devices" | "reviews" | "vouchers" | "notifications"

interface MockBookingItem {
  id: number
  bookingCode: string
  phoneModelName: string
  brandName: string
  status: "InProgress" | "Completed" | "Cancelled" | "Pending"
  statusLabel: string
  statusBg: string
  statusColor: string
  appointmentDate: string
  appointmentTime: string
  estimatedTotal: number
  branchName: string
  branchAddress: string
  image: string
  storage?: string
  color?: string
  serial?: string
  technicianName?: string
  technicianRole?: string
  technicianRating?: string
  technicianAvatar?: string
  services?: { id: number; name: string; price: number; quantity: number }[]
  timeline?: { time: string; title: string; desc: string; isDone: boolean }[]
  customerNote?: string
  technicianNote?: string
}

const MOCKUP_BOOKINGS: MockBookingItem[] = [
  {
    id: 1,
    bookingCode: "PRB-20241015-001",
    phoneModelName: "iPhone 16",
    brandName: "Apple",
    status: "InProgress",
    statusLabel: "Đang sửa chữa",
    statusBg: "#e0f2fe",
    statusColor: "#0284c7",
    appointmentDate: "Thứ 3, 15/10/2024",
    appointmentTime: "14:30 - 15:00",
    estimatedTotal: 5000000,
    branchName: "HomeRepair Cầu Giấy",
    branchAddress: "123 Cầu Giấy, Quan Hoa, Cầu Giấy, Hà Nội",
    image: getPhoneImage("iPhone 16"),
    storage: "512GB",
    color: "Titan Tự Nhiên",
    serial: "H4K2L3M9N0",
    technicianName: "Trần Minh Đức",
    technicianRole: "Kỹ thuật viên cao cấp",
    technicianRating: "4.9 (128 đánh giá)",
    technicianAvatar: getAvatarImage("Trần Minh Đức", true),
    services: [
      { id: 1, name: "Thay màn hình (chính hãng)", price: 3500000, quantity: 1 },
      { id: 2, name: "Thay pin", price: 1500000, quantity: 1 },
    ],
    timeline: [
      { time: "15/10/2024 15:20", title: "Đang kiểm tra thiết bị", desc: "Kỹ thuật viên đang kiểm tra chi tiết tình trạng máy.", isDone: true },
      { time: "15/10/2024 14:40", title: "Đã tiếp nhận thiết bị", desc: "Thiết bị đã được tiếp nhận tại chi nhánh.", isDone: true },
      { time: "15/10/2024 10:35", title: "Đã xác nhận lịch hẹn", desc: "HomeRepair đã xác nhận lịch hẹn của bạn.", isDone: true },
      { time: "15/10/2024 10:20", title: "Đặt lịch thành công", desc: "Bạn đã đặt lịch sửa chữa thành công.", isDone: true },
    ],
    customerNote: "Thay màn hình và pin. Kiểm tra thêm loa ngoài nếu có vấn đề.",
    technicianNote: "Máy bị vỡ màn hình, pin chai 78%. Đang tiến hành kiểm tra tổng thể trước khi sửa chữa.",
  },
  {
    id: 2,
    bookingCode: "PRB-20241001-002",
    phoneModelName: "Samsung Galaxy S23",
    brandName: "Samsung",
    status: "Completed",
    statusLabel: "Hoàn thành",
    statusBg: "#dcfce7",
    statusColor: "#16a34a",
    appointmentDate: "Thứ 3, 01/10/2024",
    appointmentTime: "10:00 - 10:30",
    estimatedTotal: 1500000,
    branchName: "HomeRepair Đống Đa",
    branchAddress: "456 Xã Đàn, Nam Đồng, Đống Đa, Hà Nội",
    image: getPhoneImage("Samsung Galaxy S23"),
    storage: "128GB",
    color: "Phantom Black",
    serial: "SS23B89211",
    technicianName: "Lê Văn Hùng",
    technicianRole: "Chuyên viên phần cứng",
    technicianRating: "4.8 (95 đánh giá)",
    technicianAvatar: getAvatarImage("Lê Văn Hùng", true),
    services: [
      { id: 1, name: "Thay pin chính hãng", price: 1500000, quantity: 1 },
    ],
    timeline: [
      { time: "01/10/2024 11:30", title: "Hoàn thành sửa chữa", desc: "Thiết bị đã được sửa xong và bàn giao cho khách hàng.", isDone: true },
    ],
    customerNote: "Pin tụt nhanh, máy nóng.",
    technicianNote: "Đã vệ sinh điều hòa mới chính hãng, test sạc xả ổn định.",
  },
  {
    id: 3,
    bookingCode: "PRB-20240915-003",
    phoneModelName: "iPhone 14",
    brandName: "Apple",
    status: "Completed",
    statusLabel: "Hoàn thành",
    statusBg: "#dcfce7",
    statusColor: "#16a34a",
    appointmentDate: "Chủ nhật, 15/09/2024",
    appointmentTime: "09:00 - 09:30",
    estimatedTotal: 2000000,
    branchName: "HomeRepair Hai Bà Trưng",
    branchAddress: "789 Phố Huế, Hàng Bài, Hai Bà Trưng, Hà Nội",
    image: getPhoneImage("iPhone 14"),
    storage: "128GB",
    color: "Tím Ánh Kim",
    serial: "IP14T78912",
    technicianName: "Nguyễn Tuấn Kiệt",
    technicianRole: "Kỹ thuật viên trưởng",
    technicianRating: "5.0 (210 đánh giá)",
    technicianAvatar: getAvatarImage("Nguyễn Tuấn Kiệt", true),
    services: [
      { id: 1, name: "Thay kính lưng & vệ sinh máy", price: 2000000, quantity: 1 },
    ],
    timeline: [
      { time: "15/09/2024 11:30", title: "Đã bàn giao", desc: "Khách hàng đã thanh toán và nhận máy.", isDone: true },
    ],
    customerNote: "Rơi nứt mặt lưng kính sau.",
    technicianNote: "Ép kính lưng laser hoàn thiện đẹp như mới.",
  },
  {
    id: 4,
    bookingCode: "PRB-20240901-004",
    phoneModelName: "Xiaomi 13",
    brandName: "Xiaomi",
    status: "Cancelled",
    statusLabel: "Đã hủy",
    statusBg: "#fee2e2",
    statusColor: "#ef4444",
    appointmentDate: "Chủ nhật, 01/09/2024",
    appointmentTime: "16:00 - 16:30",
    estimatedTotal: 0,
    branchName: "HomeRepair Cầu Giấy",
    branchAddress: "123 Cầu Giấy, Quan Hoa, Cầu Giấy, Hà Nội",
    image: getPhoneImage("Xiaomi 13"),
    storage: "256GB",
    color: "Xanh Flora",
    serial: "MI13X90123",
    services: [],
    timeline: [
      { time: "01/09/2024 14:00", title: "Lịch hẹn đã bị hủy", desc: "Khách hàng bận việc đột xuất và đã hủy lịch trước 2 giờ.", isDone: true },
    ],
    customerNote: "Bận việc đột xuất xin hủy lịch.",
  },
  {
    id: 5,
    bookingCode: "PRB-20240820-005",
    phoneModelName: "iPhone 13",
    brandName: "Apple",
    status: "Completed",
    statusLabel: "Hoàn thành",
    statusBg: "#dcfce7",
    statusColor: "#16a34a",
    appointmentDate: "Thứ 3, 20/08/2024",
    appointmentTime: "11:30 - 12:00",
    estimatedTotal: 800000,
    branchName: "HomeRepair Đống Đa",
    branchAddress: "456 Xã Đàn, Nam Đồng, Đống Đa, Hà Nội",
    image: getPhoneImage("iPhone 13"),
    storage: "128GB",
    color: "Xanh Midnight",
    serial: "IP13M45678",
    technicianName: "Lê Văn Hùng",
    technicianRole: "Chuyên viên phần cứng",
    technicianRating: "4.8 (95 đánh giá)",
    technicianAvatar: getAvatarImage("Lê Văn Hùng", true),
    services: [
      { id: 1, name: "Thay camera trước", price: 800000, quantity: 1 },
    ],
    timeline: [
      { time: "20/08/2024 13:00", title: "Hoàn thành sửa chữa", desc: "Khách hàng nghiệm thu và nhận máy.", isDone: true },
    ],
    customerNote: "Camera trước bị mờ đục.",
    technicianNote: "Thay camera selfie chính hãng, chụp nét chuẩn.",
  },
  {
    id: 6,
    bookingCode: "PRB-20240805-006",
    phoneModelName: "iPhone 12",
    brandName: "Apple",
    status: "Completed",
    statusLabel: "Hoàn thành",
    statusBg: "#dcfce7",
    statusColor: "#16a34a",
    appointmentDate: "Thứ 2, 05/08/2024",
    appointmentTime: "15:00 - 15:30",
    estimatedTotal: 1200000,
    branchName: "HomeRepair Hai Bà Trưng",
    branchAddress: "789 Phố Huế, Hàng Bài, Hai Bà Trưng, Hà Nội",
    image: getPhoneImage("iPhone 12"),
    storage: "128GB",
    color: "Trắng Ngọc",
    serial: "IP12W12345",
    technicianName: "Nguyễn Tuấn Kiệt",
    technicianRole: "Kỹ thuật viên trưởng",
    technicianRating: "5.0 (210 đánh giá)",
    technicianAvatar: getAvatarImage("Nguyễn Tuấn Kiệt", true),
    services: [
      { id: 1, name: "Thay vỏ chính hãng", price: 1200000, quantity: 1 },
    ],
    timeline: [
      { time: "05/08/2024 17:00", title: "Hoàn thành", desc: "Máy đã được bàn giao cho khách hàng.", isDone: true },
    ],
    customerNote: "Vỏ bị cấn móp 4 góc.",
    technicianNote: "Thay bộ vỏ khung viền mới tinh, khít đẹp.",
  },
]

interface UserDeviceItem {
  id: string
  modelName: string
  brandName: string
  storage: string
  color: string
  serial: string
  status: "good" | "needs_service"
  lastServiceDate?: string
}

const INITIAL_DEVICES: UserDeviceItem[] = [
  {
    id: "dev-1",
    modelName: "iPhone 16 Pro Max",
    brandName: "Apple",
    storage: "256GB",
    color: "Titan Tự Nhiên",
    serial: "H4K2L3M9N0",
    status: "needs_service",
    lastServiceDate: "15/10/2024",
  },
  {
    id: "dev-2",
    modelName: "Samsung Galaxy S23",
    brandName: "Samsung",
    storage: "128GB",
    color: "Phantom Black",
    serial: "SS23-889922",
    status: "good",
    lastServiceDate: "01/10/2024",
  },
  {
    id: "dev-3",
    modelName: "iPhone 13",
    brandName: "Apple",
    storage: "128GB",
    color: "Xanh Midnight",
    serial: "IP13M45678",
    status: "good",
    lastServiceDate: "20/08/2024",
  },
]

interface VoucherItem {
  id: string
  code: string
  title: string
  discount: string
  desc: string
  minOrder: string
  expiry: string
  icon: string
  color: string
  bg: string
}

const VOUCHERS_LIST: VoucherItem[] = [
  {
    id: "v-1",
    code: "WELCOME50",
    title: "Ưu đãi khách hàng mới",
    discount: "Giảm 50.000đ",
    desc: "Áp dụng cho mọi dịch vụ sửa chữa đầu tiên",
    minOrder: "Đơn từ 200.000đ",
    expiry: "Còn 30 ngày",
    icon: "🎟️",
    color: "#2563eb",
    bg: "#eff6ff",
  },
  {
    id: "v-2",
    code: "PIN10PRO",
    title: "Chăm sóc nguồn & pin",
    discount: "Giảm 10%",
    desc: "Thay pin chính hãng bảo hành 12 tháng",
    minOrder: "Mọi dòng máy",
    expiry: "Còn 45 ngày",
    icon: "🔋",
    color: "#16a34a",
    bg: "#f0fdf4",
  },
  {
    id: "v-3",
    code: "SCREEN100",
    title: "Chuyên gia ép kính & màn",
    discount: "Giảm 100.000đ",
    desc: "Thay màn hình chính hãng lấy ngay trong ngày",
    minOrder: "Đơn từ 1.000.000đ",
    expiry: "Còn 60 ngày",
    icon: "📱",
    color: "#9333ea",
    bg: "#faf5ff",
  },
  {
    id: "v-4",
    code: "FREECARE",
    title: "Bảo dưỡng chuyên sâu",
    discount: "Miễn phí 100%",
    desc: "Vệ sinh tổng thể, sấy khô bụi và tản nhiệt máy",
    minOrder: "Áp dụng kèm dịch vụ bất kỳ",
    expiry: "Còn 90 ngày",
    icon: "🧼",
    color: "#0891b2",
    bg: "#ecfeff",
  },
]

interface CustomerReviewRow {
  id: number
  bookingId: number
  bookingCode: string
  phoneModelName: string
  services: string
  technicianName: string
  rating: number
  comment: string
  createdAt: string
  reply?: string
  isReviewed: boolean
}

const INITIAL_REVIEWS: CustomerReviewRow[] = [
  {
    id: 1,
    bookingId: 5,
    bookingCode: "PRB-20240820-005",
    phoneModelName: "iPhone 13",
    services: "Thay camera trước",
    technicianName: "Lê Văn Hùng",
    rating: 5,
    comment: "Kỹ thuật viên Hùng làm rất nhiệt tình, thay xong camera selfie chụp nét căng như mới mua, thời gian sửa chỉ mất 40 phút.",
    createdAt: "20/08/2024",
    reply: "Cảm ơn quý khách đã tin tưởng dịch vụ của HomeRepair. Chúc quý khách có trải nghiệm tuyệt vời!",
    isReviewed: true,
  },
  {
    id: 2,
    bookingId: 6,
    bookingCode: "PRB-20240805-006",
    phoneModelName: "iPhone 12",
    services: "Thay vỏ chính hãng",
    technicianName: "Nguyễn Tuấn Kiệt",
    rating: 5,
    comment: "Vỏ thay vào khít 100%, màu sắc chuẩn chỉ không tì vết. Rất hài lòng về chất lượng!",
    createdAt: "05/08/2024",
    reply: "HomeRepair chân thành cảm ơn đánh giá của quý khách! Cần hỗ trợ gì cứ ghé chi nhánh nhé ạ.",
    isReviewed: true,
  },
  {
    id: 3,
    bookingId: 2,
    bookingCode: "PRB-20241001-002",
    phoneModelName: "Samsung Galaxy S23",
    services: "Thay pin chính hãng",
    technicianName: "Lê Văn Hùng",
    rating: 0,
    comment: "",
    createdAt: "01/10/2024",
    isReviewed: false,
  },
]

interface NotificationItem {
  id: string
  title: string
  desc: string
  time: string
  isRead: boolean
  type: "booking" | "tech" | "promo" | "done"
}

const INITIAL_NOTIFICATIONS: NotificationItem[] = [
  {
    id: "n-1",
    title: "Lịch hẹn PRB-20241015-001 đã được xác nhận",
    desc: "Chi nhánh Cầu Giấy đã xác nhận lịch hẹn của bạn lúc 14:30. Kỹ thuật viên sẵn sàng phục vụ.",
    time: "10 phút trước",
    isRead: false,
    type: "booking",
  },
  {
    id: "n-2",
    title: "Kỹ thuật viên đang kiểm tra thiết bị",
    desc: "Kỹ thuật viên Trần Minh Đức đang tiến hành kiểm tra tổng thể phần cứng iPhone 16 của bạn.",
    time: "2 giờ trước",
    isRead: false,
    type: "tech",
  },
  {
    id: "n-3",
    title: "Tặng bạn voucher giảm 10% Thay pin",
    desc: "Mã PIN10PRO đã được thêm vào kho ưu đãi của bạn. Hạn dùng 45 ngày.",
    time: "1 ngày trước",
    isRead: false,
    type: "promo",
  },
  {
    id: "n-4",
    title: "Đơn sửa chữa PRB-20241001-002 đã hoàn tất",
    desc: "Thiết bị Samsung Galaxy S23 đã hoàn thành vệ sinh điều hòa và sẵn sàng bàn giao.",
    time: "3 ngày trước",
    isRead: true,
    type: "done",
  },
  {
    id: "n-5",
    title: "Nhắc hẹn trước 24h",
    desc: "Bạn có lịch hẹn sửa chữa vào ngày mai lúc 14:30 tại 123 Cầu Giấy, Hà Nội.",
    time: "4 ngày trước",
    isRead: true,
    type: "booking",
  },
]

export function MyBookingsPage() {
  const { token, user, setUser, logout } = useAuth()
  const navigate = useNavigate()
  const { id } = useParams()
  const [searchParams, setSearchParams] = useSearchParams()

  // Portal active tab
  const portalTab = (searchParams.get("tab") as PortalTabId) || "bookings"

  const handleSelectPortalTab = (tabId: PortalTabId) => {
    setSearchParams({ tab: tabId })
  }

  // Bookings list state
  const [activeTab, setActiveTab] = useState<"all" | "inprogress" | "completed" | "cancelled">("all")
  const [selectedBookingId, setSelectedBookingId] = useState<number>(id ? Number(id) : 1)
  const [newNoteText, setNewNoteText] = useState("")
  const [copiedCode, setCopiedCode] = useState(false)
  const [bookingsList, setBookingsList] = useState<MockBookingItem[]>(MOCKUP_BOOKINGS)

  // Profile edit state
  const [profileFullName, setProfileFullName] = useState(user?.fullName || "")
  const [profilePhone, setProfilePhone] = useState(user?.phoneNumber || "")
  const [profileAddress, setProfileAddress] = useState("Hà Nội, Việt Nam")
  const [profileMessage, setProfileMessage] = useState("")
  const [profileSaving, setProfileSaving] = useState(false)

  // Password change state
  const [currentPassword, setCurrentPassword] = useState("")
  const [newPassword, setNewPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [passwordMessage, setPasswordMessage] = useState("")
  const [passwordError, setPasswordError] = useState("")
  const [passwordSaving, setPasswordSaving] = useState(false)

  // Devices state
  const [devicesList, setDevicesList] = useState<UserDeviceItem[]>(INITIAL_DEVICES)
  const [showAddDevice, setShowAddDevice] = useState(false)
  const [newDevBrand, setNewDevBrand] = useState("Apple")
  const [newDevModel, setNewDevModel] = useState("")
  const [newDevStorage, setNewDevStorage] = useState("128GB")
  const [newDevColor, setNewDevColor] = useState("")
  const [newDevSerial, setNewDevSerial] = useState("")

  // Reviews state
  const [reviewsList, setReviewsList] = useState<CustomerReviewRow[]>(INITIAL_REVIEWS)
  const [reviewsTab, setReviewsTab] = useState<"pending" | "reviewed">("pending")
  const [reviewRating, setReviewRating] = useState(5)
  const [reviewComment, setReviewComment] = useState("")
  const [reviewSuccess, setReviewSuccess] = useState("")

  // Vouchers state
  const [copiedVoucher, setCopiedVoucher] = useState<string | null>(null)

  // Notifications state
  const [notificationsList, setNotificationsList] = useState<NotificationItem[]>(INITIAL_NOTIFICATIONS)

  // Sync profile fields when user loads
  useEffect(() => {
    if (user) {
      if (!profileFullName && user.fullName) setProfileFullName(user.fullName)
      if (!profilePhone && user.phoneNumber) setProfilePhone(user.phoneNumber)
    }
  }, [user])

  // Try to load user bookings from API if token exists
  useEffect(() => {
    if (!token) return
    myBookings(token)
      .then((apiRows: BookingSummary[]) => {
        if (apiRows && apiRows.length > 0) {
          const merged: MockBookingItem[] = apiRows.map((r, i) => {
            const fallback = MOCKUP_BOOKINGS[i % MOCKUP_BOOKINGS.length]
            const isCompleted = r.status === "Completed"
            const isCancelled = r.status === "Cancelled"
            return {
              id: r.id,
              bookingCode: r.bookingCode,
              phoneModelName: r.phoneModelName,
              brandName: r.brandName,
              status: isCompleted ? "Completed" : isCancelled ? "Cancelled" : "InProgress",
              statusLabel: isCompleted ? "Hoàn thành" : isCancelled ? "Đã hủy" : "Đang sửa chữa",
              statusBg: isCompleted ? "#dcfce7" : isCancelled ? "#fee2e2" : "#e0f2fe",
              statusColor: isCompleted ? "#16a34a" : isCancelled ? "#ef4444" : "#0284c7",
              appointmentDate: r.appointmentDate,
              appointmentTime: r.slotStart,
              estimatedTotal: r.estimatedTotal,
              branchName: r.branchName,
              branchAddress: fallback.branchAddress,
              image: fallback.image,
              storage: fallback.storage,
              color: fallback.color,
              serial: fallback.serial,
              technicianName: r.technicianName || fallback.technicianName,
              technicianRole: fallback.technicianRole,
              technicianRating: fallback.technicianRating,
              technicianAvatar: fallback.technicianAvatar,
              services: fallback.services,
              timeline: fallback.timeline,
              customerNote: fallback.customerNote,
              technicianNote: fallback.technicianNote,
            }
          })
          setBookingsList(merged)
        }
      })
      .catch(() => {})
  }, [token])

  // Filter bookings based on active tab
  const filteredBookings = bookingsList.filter((b) => {
    if (activeTab === "inprogress") return b.status === "InProgress"
    if (activeTab === "completed") return b.status === "Completed"
    if (activeTab === "cancelled") return b.status === "Cancelled"
    return true
  })

  // Selected booking detail
  const selectedBooking = bookingsList.find((b) => b.id === selectedBookingId) || bookingsList[0]

  const formatVnd = (price: number) => {
    if (price === 0) return "-"
    return price.toLocaleString("vi-VN") + "đ"
  }

  const handleCopyCode = (code: string) => {
    navigator.clipboard?.writeText(code)
    setCopiedCode(true)
    setTimeout(() => setCopiedCode(false), 2000)
  }

  const handleCopyVoucher = (code: string) => {
    navigator.clipboard?.writeText(code)
    setCopiedVoucher(code)
    setTimeout(() => setCopiedVoucher(null), 2000)
  }

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!token) return
    setProfileSaving(true)
    setProfileMessage("")
    try {
      const updated = await updateProfile(token, {
        fullName: profileFullName.trim(),
        phoneNumber: profilePhone.trim(),
      })
      setUser(updated)
      setProfileMessage("Cập nhật thông tin cá nhân thành công!")
      setTimeout(() => setProfileMessage(""), 3500)
    } catch {
      setProfileMessage("Không thể cập nhật hồ sơ. Vui lòng thử lại.")
    } finally {
      setProfileSaving(false)
    }
  }

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!token) return
    setPasswordError("")
    setPasswordMessage("")
    if (newPassword !== confirmPassword) {
      setPasswordError("Mật khẩu xác nhận không khớp.")
      return
    }
    if (newPassword.length < 8) {
      setPasswordError("Mật khẩu mới phải có tối thiểu 8 ký tự.")
      return
    }

    setPasswordSaving(true)
    try {
      await changePassword(token, {
        currentPassword,
        newPassword,
        confirmPassword,
      })
      setPasswordMessage("Đổi mật khẩu thành công!")
      setCurrentPassword("")
      setNewPassword("")
      setConfirmPassword("")
      setTimeout(() => setPasswordMessage(""), 3500)
    } catch {
      setPasswordError("Đổi mật khẩu thất bại. Vui lòng kiểm tra lại mật khẩu hiện tại.")
    } finally {
      setPasswordSaving(false)
    }
  }

  const handleAddDevice = (e: React.FormEvent) => {
    e.preventDefault()
    if (!newDevModel.trim()) return
    const newDev: UserDeviceItem = {
      id: `dev-${Date.now()}`,
      modelName: newDevModel.trim(),
      brandName: newDevBrand,
      storage: newDevStorage,
      color: newDevColor.trim() || "Tiêu chuẩn",
      serial: newDevSerial.trim() || `SN-${Math.floor(100000 + Math.random() * 900000)}`,
      status: "good",
      lastServiceDate: "Chưa sửa chữa",
    }
    setDevicesList((prev) => [newDev, ...prev])
    setNewDevModel("")
    setNewDevColor("")
    setNewDevSerial("")
    setShowAddDevice(false)
  }

  const handleDeleteDevice = (id: string) => {
    setDevicesList((prev) => prev.filter((d) => d.id !== id))
  }

  const handleSubmitReview = async (bookingId: number) => {
    if (!reviewComment.trim()) return
    if (token) {
      try {
        await submitReview(token, bookingId, {
          rating: reviewRating,
          comment: reviewComment.trim(),
        })
      } catch {
        // Fallback update locally
      }
    }

    setReviewsList((prev) =>
      prev.map((r) =>
        r.bookingId === bookingId
          ? {
              ...r,
              rating: reviewRating,
              comment: reviewComment.trim(),
              createdAt: "Vừa xong",
              isReviewed: true,
              reply: "Cảm ơn bạn đã tin tưởng dịch vụ của HomeRepair. Chúc bạn có trải nghiệm tuyệt vời!",
            }
          : r
      )
    )
    setReviewComment("")
    setReviewSuccess("Cảm ơn bạn đã gửi đánh giá dịch vụ!")
    setTimeout(() => {
      setReviewSuccess("")
      setReviewsTab("reviewed")
    }, 1500)
  }

  const handleMarkAllRead = () => {
    setNotificationsList((prev) => prev.map((n) => ({ ...n, isRead: true })))
  }

  const handleDeleteNotification = (id: string) => {
    setNotificationsList((prev) => prev.filter((n) => n.id !== id))
  }

  const unreadNotifCount = notificationsList.filter((n) => !n.isRead).length
  const pendingReviewsCount = reviewsList.filter((r) => !r.isReviewed).length
  const inProgressCount = bookingsList.filter((b) => b.status === "InProgress").length
  const completedCount = bookingsList.filter((b) => b.status === "Completed").length

  // ================= RENDER SIDEBAR COLUMN =================
  const renderSidebar = () => {
    const navItems: { id: PortalTabId; label: string; icon: string; badge?: number }[] = [
      { id: "overview", label: "Tổng quan", icon: "🏠" },
      { id: "bookings", label: "Lịch hẹn của tôi", icon: "🗓️" },
      { id: "profile", label: "Thông tin cá nhân", icon: "👤" },
      { id: "devices", label: "Thiết bị của tôi", icon: "📱" },
      { id: "reviews", label: "Đánh giá dịch vụ", icon: "⭐", badge: pendingReviewsCount > 0 ? pendingReviewsCount : undefined },
      { id: "vouchers", label: "Ưu đãi của tôi", icon: "🎁" },
      { id: "notifications", label: "Thông báo", icon: "🔔", badge: unreadNotifCount > 0 ? unreadNotifCount : undefined },
    ]

    return (
      <aside
        style={{
          background: "#ffffff",
          border: "1px solid #e2e8f0",
          borderRadius: "16px",
          padding: "20px 14px",
          boxShadow: "0 2px 8px rgba(15,23,42,0.02)",
        }}
      >
        <h2 style={{ fontSize: "1.05rem", fontWeight: 800, color: "#0f172a", margin: "0 0 16px 10px" }}>
          Tài khoản của tôi
        </h2>

        <nav style={{ display: "flex", flexDirection: "column", gap: "4px" }}>
          {navItems.map((item) => {
            const isActive = portalTab === item.id
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => handleSelectPortalTab(item.id)}
                style={{
                  width: "100%",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                  padding: "10px 12px",
                  borderRadius: "10px",
                  fontSize: "0.86rem",
                  color: isActive ? "#2563eb" : "#475569",
                  background: isActive ? "#eff6ff" : "transparent",
                  fontWeight: isActive ? 700 : 500,
                  border: "none",
                  cursor: "pointer",
                  textAlign: "left",
                  transition: "all 0.15s ease",
                }}
              >
                <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                  <span>{item.icon}</span>
                  <span>{item.label}</span>
                </div>
                {item.badge !== undefined && (
                  <span
                    style={{
                      background: "#ef4444",
                      color: "#ffffff",
                      borderRadius: "999px",
                      fontSize: "0.68rem",
                      fontWeight: 800,
                      padding: "1px 6px",
                      lineHeight: "1.2",
                    }}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            )
          })}

          <button
            type="button"
            onClick={() => {
              logout()
              navigate("/login")
            }}
            style={{
              display: "flex",
              alignItems: "center",
              gap: "10px",
              padding: "10px 12px",
              borderRadius: "10px",
              fontSize: "0.86rem",
              color: "#ef4444",
              background: "none",
              border: "none",
              fontWeight: 600,
              cursor: "pointer",
              textAlign: "left",
              marginTop: "8px",
            }}
          >
            <span>🚪</span>
            <span>Đăng xuất</span>
          </button>
        </nav>

        {/* CẦN HỖ TRỢ CARD */}
        <div
          style={{
            marginTop: "30px",
            background: "#f8fafc",
            border: "1px solid #e2e8f0",
            borderRadius: "14px",
            padding: "16px 14px",
            textAlign: "left",
          }}
        >
          <div
            style={{
              width: "32px",
              height: "32px",
              borderRadius: "50%",
              background: "#eff6ff",
              color: "#2563eb",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              fontSize: "1rem",
              marginBottom: "8px",
            }}
          >
            🎧
          </div>
          <strong style={{ fontSize: "0.88rem", color: "#0f172a", display: "block", marginBottom: "4px" }}>
            Cần hỗ trợ?
          </strong>
          <p style={{ fontSize: "0.76rem", color: "#64748b", margin: "0 0 12px", lineHeight: 1.4 }}>
            Liên hệ đội ngũ chăm sóc khách hàng của chúng tôi
          </p>
          <Link
            to="/support"
            style={{
              display: "inline-flex",
              alignItems: "center",
              gap: "4px",
              padding: "6px 12px",
              borderRadius: "8px",
              border: "1px solid #cbd5e1",
              background: "#ffffff",
              color: "#0f172a",
              fontSize: "0.78rem",
              fontWeight: 700,
              textDecoration: "none",
            }}
          >
            <span>Liên hệ ngay</span>
            <span>&gt;</span>
          </Link>
        </div>
      </aside>
    )
  }

  // ================= TAB: OVERVIEW =================
  const renderOverviewTab = () => {
    return (
      <div style={{ display: "flex", flexDirection: "column", gap: "22px" }}>
        {/* WELCOME BANNER */}
        <div
          style={{
            background: "linear-gradient(135deg, #1e3a8a 0%, #2563eb 100%)",
            borderRadius: "20px",
            padding: "26px 30px",
            color: "#ffffff",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            boxShadow: "0 4px 18px rgba(37,99,235,0.22)",
          }}
        >
          <div style={{ display: "flex", alignItems: "center", gap: "18px" }}>
            <img
              src={getAvatarImage(user?.fullName || "Khách hàng")}
              alt="Avatar"
              style={{ width: "60px", height: "60px", borderRadius: "50%", border: "2px solid rgba(255,255,255,0.8)", objectFit: "cover" }}
            />
            <div>
              <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "4px" }}>
                <h1 style={{ fontSize: "1.4rem", fontWeight: 800, margin: 0 }}>
                  Xin chào, {user?.fullName || "Khách hàng"}!
                </h1>
                <span style={{ fontSize: "0.72rem", background: "rgba(255,255,255,0.2)", padding: "2px 8px", borderRadius: "999px", fontWeight: 700 }}>
                  ⭐ Khách hàng thân thiết
                </span>
              </div>
              <p style={{ fontSize: "0.85rem", opacity: 0.9, margin: 0 }}>
                {user?.email} • SĐT: {user?.phoneNumber || "Chưa cập nhật"}
              </p>
            </div>
          </div>

          <Link
            to="/booking"
            style={{
              background: "#ffffff",
              color: "#2563eb",
              padding: "10px 20px",
              borderRadius: "10px",
              fontWeight: 700,
              fontSize: "0.85rem",
              textDecoration: "none",
              boxShadow: "0 2px 8px rgba(0,0,0,0.12)",
              display: "inline-flex",
              alignItems: "center",
              gap: "6px",
            }}
          >
            <span>+ Đặt lịch sửa ngay</span>
          </Link>
        </div>

        {/* 4 STAT CARDS */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: "16px" }}>
          <div style={{ background: "#ffffff", border: "1px solid #e2e8f0", borderRadius: "14px", padding: "18px", boxShadow: "0 2px 8px rgba(15,23,42,0.02)" }}>
            <span style={{ fontSize: "0.78rem", color: "#64748b", display: "block", marginBottom: "6px" }}>Tổng lịch hẹn</span>
            <div style={{ display: "flex", alignItems: "baseline", gap: "8px" }}>
              <span style={{ fontSize: "1.8rem", fontWeight: 900, color: "#0f172a" }}>{bookingsList.length}</span>
              <span style={{ fontSize: "0.75rem", color: "#64748b" }}>lịch hẹn</span>
            </div>
          </div>

          <div style={{ background: "#ffffff", border: "1px solid #e2e8f0", borderRadius: "14px", padding: "18px", boxShadow: "0 2px 8px rgba(15,23,42,0.02)" }}>
            <span style={{ fontSize: "0.78rem", color: "#0284c7", display: "block", marginBottom: "6px" }}>Đang xử lý</span>
            <div style={{ display: "flex", alignItems: "baseline", gap: "8px" }}>
              <span style={{ fontSize: "1.8rem", fontWeight: 900, color: "#0284c7" }}>{inProgressCount}</span>
              <span style={{ fontSize: "0.75rem", color: "#64748b" }}>đơn hẹn</span>
            </div>
          </div>

          <div style={{ background: "#ffffff", border: "1px solid #e2e8f0", borderRadius: "14px", padding: "18px", boxShadow: "0 2px 8px rgba(15,23,42,0.02)" }}>
            <span style={{ fontSize: "0.78rem", color: "#16a34a", display: "block", marginBottom: "6px" }}>Đã hoàn thành</span>
            <div style={{ display: "flex", alignItems: "baseline", gap: "8px" }}>
              <span style={{ fontSize: "1.8rem", fontWeight: 900, color: "#16a34a" }}>{completedCount}</span>
              <span style={{ fontSize: "0.75rem", color: "#64748b" }}>đơn sửa</span>
            </div>
          </div>

          <div style={{ background: "#ffffff", border: "1px solid #e2e8f0", borderRadius: "14px", padding: "18px", boxShadow: "0 2px 8px rgba(15,23,42,0.02)" }}>
            <span style={{ fontSize: "0.78rem", color: "#9333ea", display: "block", marginBottom: "6px" }}>Thiết bị đã lưu</span>
            <div style={{ display: "flex", alignItems: "baseline", gap: "8px" }}>
              <span style={{ fontSize: "1.8rem", fontWeight: 900, color: "#9333ea" }}>{devicesList.length}</span>
              <span style={{ fontSize: "0.75rem", color: "#64748b" }}>máy</span>
            </div>
          </div>
        </div>

        {/* LATEST APPOINTMENT PREVIEW */}
        <div style={{ background: "#ffffff", border: "1px solid #e2e8f0", borderRadius: "16px", padding: "22px", boxShadow: "0 2px 8px rgba(15,23,42,0.02)" }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "16px" }}>
            <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
              <span style={{ fontSize: "1.2rem" }}>📍</span>
              <h3 style={{ fontSize: "1.05rem", fontWeight: 800, color: "#0f172a", margin: 0 }}>
                Lịch hẹn gần nhất
              </h3>
            </div>
            <button
              type="button"
              onClick={() => handleSelectPortalTab("bookings")}
              style={{ background: "none", border: "none", color: "#2563eb", fontSize: "0.82rem", fontWeight: 700, cursor: "pointer" }}
            >
              Xem tất cả lịch hẹn →
            </button>
          </div>

          {selectedBooking ? (
            <div style={{ background: "#f8fafc", border: "1px solid #e2e8f0", borderRadius: "12px", padding: "16px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
              <div style={{ display: "flex", alignItems: "center", gap: "16px" }}>
                <img src={selectedBooking.image} alt={selectedBooking.phoneModelName} style={{ width: "42px", height: "54px", objectFit: "contain" }} />
                <div>
                  <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "4px" }}>
                    <strong style={{ fontSize: "0.95rem", color: "#0f172a" }}>{selectedBooking.phoneModelName}</strong>
                    <span style={{ background: selectedBooking.statusBg, color: selectedBooking.statusColor, fontSize: "0.7rem", fontWeight: 700, padding: "2px 8px", borderRadius: "999px" }}>
                      {selectedBooking.statusLabel}
                    </span>
                  </div>
                  <div style={{ fontSize: "0.8rem", color: "#64748b" }}>
                    Mã: <strong>{selectedBooking.bookingCode}</strong> • Ngày hẹn: <strong>{selectedBooking.appointmentDate} ({selectedBooking.appointmentTime})</strong>
                  </div>
                  <div style={{ fontSize: "0.78rem", color: "#64748b", marginTop: "2px" }}>
                    Chi nhánh: {selectedBooking.branchName}
                  </div>
                </div>
              </div>

              <button
                type="button"
                onClick={() => handleSelectPortalTab("bookings")}
                style={{ background: "#2563eb", color: "#ffffff", padding: "8px 16px", borderRadius: "8px", border: "none", fontSize: "0.82rem", fontWeight: 700, cursor: "pointer" }}
              >
                Chi tiết tiến độ
              </button>
            </div>
          ) : (
            <p style={{ color: "#94a3b8", fontStyle: "italic", margin: 0 }}>Bạn chưa có lịch hẹn nào.</p>
          )}
        </div>

        {/* QUICK SHORTCUTS GRID */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: "16px" }}>
          <Link to="/booking" style={{ background: "#ffffff", border: "1px solid #e2e8f0", borderRadius: "14px", padding: "18px", textDecoration: "none", transition: "transform 0.15s ease" }}>
            <div style={{ fontSize: "1.5rem", marginBottom: "8px" }}>🔧</div>
            <strong style={{ fontSize: "0.9rem", color: "#0f172a", display: "block", marginBottom: "4px" }}>Đặt lịch sửa</strong>
            <span style={{ fontSize: "0.75rem", color: "#64748b" }}>Chủ động chọn giờ, có mặt sửa ngay</span>
          </Link>

          <Link to="/pricing" style={{ background: "#ffffff", border: "1px solid #e2e8f0", borderRadius: "14px", padding: "18px", textDecoration: "none", transition: "transform 0.15s ease" }}>
            <div style={{ fontSize: "1.5rem", marginBottom: "8px" }}>💰</div>
            <strong style={{ fontSize: "0.9rem", color: "#0f172a", display: "block", marginBottom: "4px" }}>Bảng giá dịch vụ</strong>
            <span style={{ fontSize: "0.75rem", color: "#64748b" }}>Tra cứu giá linh kiện minh bạch</span>
          </Link>

          <Link to="/branches" style={{ background: "#ffffff", border: "1px solid #e2e8f0", borderRadius: "14px", padding: "18px", textDecoration: "none", transition: "transform 0.15s ease" }}>
            <div style={{ fontSize: "1.5rem", marginBottom: "8px" }}>📍</div>
            <strong style={{ fontSize: "0.9rem", color: "#0f172a", display: "block", marginBottom: "4px" }}>Tìm chi nhánh</strong>
            <span style={{ fontSize: "0.75rem", color: "#64748b" }}>Hệ thống 6 điểm tiếp nhận</span>
          </Link>

          <button
            type="button"
            onClick={() => handleSelectPortalTab("vouchers")}
            style={{ background: "#ffffff", border: "1px solid #e2e8f0", borderRadius: "14px", padding: "18px", textAlign: "left", cursor: "pointer" }}
          >
            <div style={{ fontSize: "1.5rem", marginBottom: "8px" }}>🎁</div>
            <strong style={{ fontSize: "0.9rem", color: "#0f172a", display: "block", marginBottom: "4px" }}>Kho voucher</strong>
            <span style={{ fontSize: "0.75rem", color: "#64748b" }}>4 mã ưu đãi sẵn sàng sử dụng</span>
          </button>
        </div>
      </div>
    )
  }

  // ================= TAB: PROFILE =================
  const renderProfileTab = () => {
    return (
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "22px" }}>
        {/* CARD 1: EDIT PROFILE */}
        <div style={{ background: "#ffffff", border: "1px solid #e2e8f0", borderRadius: "16px", padding: "24px", boxShadow: "0 2px 8px rgba(15,23,42,0.02)" }}>
          <h3 style={{ fontSize: "1.1rem", fontWeight: 800, color: "#0f172a", margin: "0 0 6px" }}>
            Thông tin cá nhân
          </h3>
          <p style={{ fontSize: "0.8rem", color: "#64748b", margin: "0 0 20px" }}>
            Cập nhật họ tên và số điện thoại liên lạc của bạn
          </p>

          {profileMessage && (
            <div style={{ background: "#f0fdf4", border: "1px solid #bbf7d0", color: "#16a34a", padding: "10px 14px", borderRadius: "8px", fontSize: "0.82rem", marginBottom: "16px" }}>
              {profileMessage}
            </div>
          )}

          <form onSubmit={handleSaveProfile} style={{ display: "flex", flexDirection: "column", gap: "14px" }}>
            <div>
              <label style={{ display: "block", fontSize: "0.82rem", fontWeight: 700, color: "#0f172a", marginBottom: "6px" }}>
                Họ và tên
              </label>
              <input
                type="text"
                value={profileFullName}
                onChange={(e) => setProfileFullName(e.target.value)}
                required
                style={{ width: "100%", padding: "10px 12px", borderRadius: "8px", border: "1px solid #cbd5e1", fontSize: "0.88rem" }}
              />
            </div>

            <div>
              <label style={{ display: "block", fontSize: "0.82rem", fontWeight: 700, color: "#0f172a", marginBottom: "6px" }}>
                Số điện thoại
              </label>
              <input
                type="tel"
                value={profilePhone}
                onChange={(e) => setProfilePhone(e.target.value)}
                required
                style={{ width: "100%", padding: "10px 12px", borderRadius: "8px", border: "1px solid #cbd5e1", fontSize: "0.88rem" }}
              />
            </div>

            <div>
              <label style={{ display: "block", fontSize: "0.82rem", fontWeight: 700, color: "#0f172a", marginBottom: "6px" }}>
                Email đăng nhập
              </label>
              <input
                type="email"
                value={user?.email || ""}
                disabled
                style={{ width: "100%", padding: "10px 12px", borderRadius: "8px", border: "1px solid #e2e8f0", background: "#f8fafc", color: "#64748b", fontSize: "0.88rem" }}
              />
              <span style={{ fontSize: "0.72rem", color: "#94a3b8", marginTop: "4px", display: "block" }}>
                Email tài khoản được dùng để nhận xác nhận lịch hẹn.
              </span>
            </div>

            <div>
              <label style={{ display: "block", fontSize: "0.82rem", fontWeight: 700, color: "#0f172a", marginBottom: "6px" }}>
                Địa chỉ mặc định
              </label>
              <input
                type="text"
                value={profileAddress}
                onChange={(e) => setProfileAddress(e.target.value)}
                style={{ width: "100%", padding: "10px 12px", borderRadius: "8px", border: "1px solid #cbd5e1", fontSize: "0.88rem" }}
              />
            </div>

            <button
              type="submit"
              disabled={profileSaving}
              style={{
                marginTop: "10px",
                background: "#2563eb",
                color: "#ffffff",
                border: "none",
                padding: "10px 18px",
                borderRadius: "8px",
                fontSize: "0.85rem",
                fontWeight: 700,
                cursor: profileSaving ? "wait" : "pointer",
                boxShadow: "0 2px 6px rgba(37,99,235,0.25)",
              }}
            >
              {profileSaving ? "Đang lưu..." : "Lưu thay đổi"}
            </button>
          </form>
        </div>

        {/* CARD 2: CHANGE PASSWORD */}
        <div style={{ background: "#ffffff", border: "1px solid #e2e8f0", borderRadius: "16px", padding: "24px", boxShadow: "0 2px 8px rgba(15,23,42,0.02)" }}>
          <h3 style={{ fontSize: "1.1rem", fontWeight: 800, color: "#0f172a", margin: "0 0 6px" }}>
            Đổi mật khẩu
          </h3>
          <p style={{ fontSize: "0.8rem", color: "#64748b", margin: "0 0 20px" }}>
            Đảm bảo tài khoản được an toàn với mật khẩu mạnh tối thiểu 8 ký tự
          </p>

          {passwordMessage && (
            <div style={{ background: "#f0fdf4", border: "1px solid #bbf7d0", color: "#16a34a", padding: "10px 14px", borderRadius: "8px", fontSize: "0.82rem", marginBottom: "16px" }}>
              {passwordMessage}
            </div>
          )}
          {passwordError && (
            <div style={{ background: "#fef2f2", border: "1px solid #fecaca", color: "#dc2626", padding: "10px 14px", borderRadius: "8px", fontSize: "0.82rem", marginBottom: "16px" }}>
              {passwordError}
            </div>
          )}

          <form onSubmit={handleChangePassword} style={{ display: "flex", flexDirection: "column", gap: "14px" }}>
            <div>
              <label style={{ display: "block", fontSize: "0.82rem", fontWeight: 700, color: "#0f172a", marginBottom: "6px" }}>
                Mật khẩu hiện tại
              </label>
              <input
                type="password"
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                required
                style={{ width: "100%", padding: "10px 12px", borderRadius: "8px", border: "1px solid #cbd5e1", fontSize: "0.88rem" }}
              />
            </div>

            <div>
              <label style={{ display: "block", fontSize: "0.82rem", fontWeight: 700, color: "#0f172a", marginBottom: "6px" }}>
                Mật khẩu mới
              </label>
              <input
                type="password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                required
                minLength={8}
                style={{ width: "100%", padding: "10px 12px", borderRadius: "8px", border: "1px solid #cbd5e1", fontSize: "0.88rem" }}
              />
            </div>

            <div>
              <label style={{ display: "block", fontSize: "0.82rem", fontWeight: 700, color: "#0f172a", marginBottom: "6px" }}>
                Xác nhận mật khẩu mới
              </label>
              <input
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                required
                style={{ width: "100%", padding: "10px 12px", borderRadius: "8px", border: "1px solid #cbd5e1", fontSize: "0.88rem" }}
              />
            </div>

            <button
              type="submit"
              disabled={passwordSaving}
              style={{
                marginTop: "10px",
                background: "#0f172a",
                color: "#ffffff",
                border: "none",
                padding: "10px 18px",
                borderRadius: "8px",
                fontSize: "0.85rem",
                fontWeight: 700,
                cursor: passwordSaving ? "wait" : "pointer",
              }}
            >
              {passwordSaving ? "Đang đổi..." : "Cập nhật mật khẩu"}
            </button>
          </form>
        </div>
      </div>
    )
  }

  // ================= TAB: DEVICES =================
  const renderDevicesTab = () => {
    return (
      <div style={{ display: "flex", flexDirection: "column", gap: "20px" }}>
        {/* HEADER */}
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div>
            <h2 style={{ fontSize: "1.2rem", fontWeight: 800, color: "#0f172a", margin: "0 0 4px" }}>
              Thiết bị của tôi
            </h2>
            <p style={{ fontSize: "0.8rem", color: "#64748b", margin: 0 }}>
              Quản lý các dòng máy của bạn để đặt lịch sửa chữa và tra cứu bảo hành nhanh chóng.
            </p>
          </div>

          <button
            type="button"
            onClick={() => setShowAddDevice((prev) => !prev)}
            style={{
              background: "#2563eb",
              color: "#ffffff",
              border: "none",
              padding: "8px 16px",
              borderRadius: "8px",
              fontSize: "0.82rem",
              fontWeight: 700,
              cursor: "pointer",
              boxShadow: "0 2px 6px rgba(37,99,235,0.25)",
            }}
          >
            {showAddDevice ? "Đóng form" : "+ Thêm thiết bị mới"}
          </button>
        </div>

        {/* ADD DEVICE FORM */}
        {showAddDevice && (
          <form
            onSubmit={handleAddDevice}
            style={{
              background: "#ffffff",
              border: "1.5px dashed #2563eb",
              borderRadius: "14px",
              padding: "20px",
              display: "grid",
              gridTemplateColumns: "repeat(3, 1fr)",
              gap: "14px",
            }}
          >
            <div>
              <label style={{ display: "block", fontSize: "0.8rem", fontWeight: 700, marginBottom: "4px" }}>Hãng máy</label>
              <select
                value={newDevBrand}
                onChange={(e) => setNewDevBrand(e.target.value)}
                style={{ width: "100%", padding: "8px 10px", borderRadius: "8px", border: "1px solid #cbd5e1", fontSize: "0.85rem" }}
              >
                {["Apple", "Samsung", "Xiaomi", "Oppo", "Vivo", "Realme", "Google", "Honor"].map((b) => (
                  <option key={b} value={b}>{b}</option>
                ))}
              </select>
            </div>

            <div>
              <label style={{ display: "block", fontSize: "0.8rem", fontWeight: 700, marginBottom: "4px" }}>Tên dòng máy</label>
              <input
                type="text"
                placeholder="VD: iPhone 15 Pro, Galaxy S24..."
                value={newDevModel}
                onChange={(e) => setNewDevModel(e.target.value)}
                required
                style={{ width: "100%", padding: "8px 10px", borderRadius: "8px", border: "1px solid #cbd5e1", fontSize: "0.85rem" }}
              />
            </div>

            <div>
              <label style={{ display: "block", fontSize: "0.8rem", fontWeight: 700, marginBottom: "4px" }}>Dung lượng</label>
              <select
                value={newDevStorage}
                onChange={(e) => setNewDevStorage(e.target.value)}
                style={{ width: "100%", padding: "8px 10px", borderRadius: "8px", border: "1px solid #cbd5e1", fontSize: "0.85rem" }}
              >
                {["64GB", "128GB", "256GB", "512GB", "1TB"].map((s) => (
                  <option key={s} value={s}>{s}</option>
                ))}
              </select>
            </div>

            <div>
              <label style={{ display: "block", fontSize: "0.8rem", fontWeight: 700, marginBottom: "4px" }}>Màu sắc</label>
              <input
                type="text"
                placeholder="VD: Đen, Titan, Trắng..."
                value={newDevColor}
                onChange={(e) => setNewDevColor(e.target.value)}
                style={{ width: "100%", padding: "8px 10px", borderRadius: "8px", border: "1px solid #cbd5e1", fontSize: "0.85rem" }}
              />
            </div>

            <div>
              <label style={{ display: "block", fontSize: "0.8rem", fontWeight: 700, marginBottom: "4px" }}>Số Serial / IMEI</label>
              <input
                type="text"
                placeholder="Tùy chọn"
                value={newDevSerial}
                onChange={(e) => setNewDevSerial(e.target.value)}
                style={{ width: "100%", padding: "8px 10px", borderRadius: "8px", border: "1px solid #cbd5e1", fontSize: "0.85rem" }}
              />
            </div>

            <div style={{ display: "flex", alignItems: "flex-end", gap: "8px" }}>
              <button
                type="submit"
                style={{ flex: 1, background: "#2563eb", color: "#ffffff", border: "none", padding: "9px", borderRadius: "8px", fontWeight: 700, fontSize: "0.85rem", cursor: "pointer" }}
              >
                Lưu máy
              </button>
              <button
                type="button"
                onClick={() => setShowAddDevice(false)}
                style={{ padding: "9px 14px", borderRadius: "8px", border: "1px solid #cbd5e1", background: "#ffffff", fontSize: "0.85rem", cursor: "pointer" }}
              >
                Hủy
              </button>
            </div>
          </form>
        )}

        {/* DEVICES GRID */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "16px" }}>
          {devicesList.map((dev) => (
            <div
              key={dev.id}
              style={{
                background: "#ffffff",
                border: "1px solid #e2e8f0",
                borderRadius: "14px",
                padding: "18px",
                boxShadow: "0 2px 8px rgba(15,23,42,0.02)",
                display: "flex",
                flexDirection: "column",
                justifyContent: "space-between",
              }}
            >
              <div>
                <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", marginBottom: "12px" }}>
                  <img
                    src={getPhoneImage(dev.modelName)}
                    alt={dev.modelName}
                    style={{ width: "48px", height: "64px", objectFit: "contain" }}
                  />
                  <button
                    type="button"
                    onClick={() => handleDeleteDevice(dev.id)}
                    title="Xóa thiết bị"
                    style={{ background: "none", border: "none", color: "#94a3b8", cursor: "pointer", fontSize: "1rem" }}
                  >
                    ×
                  </button>
                </div>

                <div style={{ display: "flex", alignItems: "center", gap: "6px", marginBottom: "4px" }}>
                  <strong style={{ fontSize: "0.95rem", color: "#0f172a" }}>{dev.modelName}</strong>
                  <span style={{ fontSize: "0.68rem", background: "#f1f5f9", color: "#475569", padding: "1px 6px", borderRadius: "4px" }}>
                    {dev.brandName}
                  </span>
                </div>

                <div style={{ fontSize: "0.78rem", color: "#64748b", display: "flex", flexDirection: "column", gap: "2px", margin: "8px 0" }}>
                  <div>Dung lượng: <strong style={{ color: "#334155" }}>{dev.storage}</strong></div>
                  <div>Màu sắc: <strong style={{ color: "#334155" }}>{dev.color}</strong></div>
                  <div>Serial/IMEI: <span style={{ fontFamily: "monospace", color: "#64748b" }}>{dev.serial}</span></div>
                  <div>Lần sửa gần nhất: <span>{dev.lastServiceDate}</span></div>
                </div>
              </div>

              <div style={{ borderTop: "1px solid #f1f5f9", paddingTop: "12px", marginTop: "8px" }}>
                <Link
                  to={`/booking?brand=${encodeURIComponent(dev.brandName)}&model=${encodeURIComponent(dev.modelName)}`}
                  style={{
                    display: "block",
                    textAlign: "center",
                    background: "#eff6ff",
                    color: "#2563eb",
                    border: "1px solid #bfdbfe",
                    padding: "8px 12px",
                    borderRadius: "8px",
                    fontWeight: 700,
                    fontSize: "0.8rem",
                    textDecoration: "none",
                  }}
                >
                  🔧 Đặt lịch sửa máy này
                </Link>
              </div>
            </div>
          ))}
        </div>
      </div>
    )
  }

  // ================= TAB: REVIEWS =================
  const renderReviewsTab = () => {
    const pendingReviews = reviewsList.filter((r) => !r.isReviewed)
    const submittedReviews = reviewsList.filter((r) => r.isReviewed)

    return (
      <div style={{ display: "flex", flexDirection: "column", gap: "20px" }}>
        {/* HEADER */}
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div>
            <h2 style={{ fontSize: "1.2rem", fontWeight: 800, color: "#0f172a", margin: "0 0 4px" }}>
              Đánh giá dịch vụ
            </h2>
            <p style={{ fontSize: "0.8rem", color: "#64748b", margin: 0 }}>
              Nhận xét của bạn sau khi hoàn thành sửa chữa giúp chúng tôi ngày một hoàn thiện.
            </p>
          </div>

          <div style={{ display: "flex", gap: "8px" }}>
            <button
              type="button"
              onClick={() => setReviewsTab("pending")}
              style={{
                padding: "6px 14px",
                borderRadius: "8px",
                border: reviewsTab === "pending" ? "1px solid #2563eb" : "1px solid #e2e8f0",
                background: reviewsTab === "pending" ? "#eff6ff" : "#ffffff",
                color: reviewsTab === "pending" ? "#2563eb" : "#64748b",
                fontWeight: 700,
                fontSize: "0.82rem",
                cursor: "pointer",
              }}
            >
              Chờ đánh giá ({pendingReviews.length})
            </button>
            <button
              type="button"
              onClick={() => setReviewsTab("reviewed")}
              style={{
                padding: "6px 14px",
                borderRadius: "8px",
                border: reviewsTab === "reviewed" ? "1px solid #2563eb" : "1px solid #e2e8f0",
                background: reviewsTab === "reviewed" ? "#eff6ff" : "#ffffff",
                color: reviewsTab === "reviewed" ? "#2563eb" : "#64748b",
                fontWeight: 700,
                fontSize: "0.82rem",
                cursor: "pointer",
              }}
            >
              Đã đánh giá ({submittedReviews.length})
            </button>
          </div>
        </div>

        {reviewSuccess && (
          <div style={{ background: "#f0fdf4", border: "1px solid #bbf7d0", color: "#16a34a", padding: "12px 16px", borderRadius: "10px", fontSize: "0.85rem", fontWeight: 600 }}>
            {reviewSuccess}
          </div>
        )}

        {/* REVIEWS CONTENT */}
        {reviewsTab === "pending" ? (
          pendingReviews.length === 0 ? (
            <div style={{ background: "#ffffff", border: "1px solid #e2e8f0", borderRadius: "16px", padding: "40px", textAlign: "center", color: "#64748b" }}>
              <span style={{ fontSize: "2rem", display: "block", marginBottom: "8px" }}>🎉</span>
              <strong>Bạn không có ca sửa nào đang chờ đánh giá!</strong>
              <p style={{ fontSize: "0.8rem", margin: "4px 0 0" }}>Cảm ơn bạn đã đồng hành cùng HomeRepair.</p>
            </div>
          ) : (
            <div style={{ display: "flex", flexDirection: "column", gap: "16px" }}>
              {pendingReviews.map((item) => (
                <div
                  key={item.id}
                  style={{
                    background: "#ffffff",
                    border: "1px solid #e2e8f0",
                    borderRadius: "16px",
                    padding: "20px",
                    boxShadow: "0 2px 8px rgba(15,23,42,0.02)",
                  }}
                >
                  <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "14px", borderBottom: "1px solid #f1f5f9", paddingBottom: "10px" }}>
                    <div>
                      <strong style={{ fontSize: "0.95rem", color: "#0f172a" }}>{item.phoneModelName}</strong>
                      <span style={{ fontSize: "0.8rem", color: "#64748b", marginLeft: "10px" }}>{item.services}</span>
                    </div>
                    <span style={{ fontSize: "0.78rem", color: "#2563eb", fontWeight: 700 }}>
                      Mã: {item.bookingCode}
                    </span>
                  </div>

                  <div style={{ marginBottom: "14px" }}>
                    <span style={{ fontSize: "0.82rem", fontWeight: 700, color: "#0f172a", display: "block", marginBottom: "6px" }}>
                      Mức độ hài lòng của bạn:
                    </span>
                    <div style={{ display: "flex", gap: "6px" }}>
                      {[1, 2, 3, 4, 5].map((star) => (
                        <button
                          key={star}
                          type="button"
                          onClick={() => setReviewRating(star)}
                          style={{
                            background: "none",
                            border: "none",
                            fontSize: "1.6rem",
                            cursor: "pointer",
                            padding: "0 2px",
                            filter: star <= reviewRating ? "none" : "grayscale(100%) opacity(30%)",
                            transition: "transform 0.15s ease",
                          }}
                        >
                          ⭐
                        </button>
                      ))}
                    </div>
                  </div>

                  <div style={{ marginBottom: "14px" }}>
                    <textarea
                      rows={3}
                      placeholder="Chia sẻ nhận xét của bạn về kỹ thuật viên và chất lượng sửa chữa..."
                      value={reviewComment}
                      onChange={(e) => setReviewComment(e.target.value)}
                      style={{ width: "100%", padding: "10px 12px", borderRadius: "10px", border: "1px solid #cbd5e1", fontSize: "0.86rem", resize: "vertical" }}
                    />
                  </div>

                  <button
                    type="button"
                    onClick={() => handleSubmitReview(item.bookingId)}
                    style={{
                      background: "#2563eb",
                      color: "#ffffff",
                      border: "none",
                      padding: "8px 18px",
                      borderRadius: "8px",
                      fontSize: "0.82rem",
                      fontWeight: 700,
                      cursor: "pointer",
                    }}
                  >
                    Gửi đánh giá
                  </button>
                </div>
              ))}
            </div>
          )
        ) : (
          <div style={{ display: "flex", flexDirection: "column", gap: "16px" }}>
            {submittedReviews.map((item) => (
              <div
                key={item.id}
                style={{
                  background: "#ffffff",
                  border: "1px solid #e2e8f0",
                  borderRadius: "16px",
                  padding: "20px",
                  boxShadow: "0 2px 8px rgba(15,23,42,0.02)",
                }}
              >
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "8px" }}>
                  <div>
                    <strong style={{ fontSize: "0.95rem", color: "#0f172a" }}>{item.phoneModelName}</strong>
                    <span style={{ fontSize: "0.8rem", color: "#64748b", marginLeft: "10px" }}>{item.services}</span>
                  </div>
                  <span style={{ fontSize: "0.76rem", color: "#94a3b8" }}>{item.createdAt}</span>
                </div>

                <div style={{ display: "flex", alignItems: "center", gap: "4px", marginBottom: "8px" }}>
                  {"⭐".repeat(item.rating)}
                  <span style={{ fontSize: "0.8rem", fontWeight: 700, color: "#d97706", marginLeft: "4px" }}>
                    {item.rating}/5 sao
                  </span>
                </div>

                <p style={{ fontSize: "0.86rem", color: "#334155", margin: "0 0 12px", lineHeight: 1.5 }}>
                  "{item.comment}"
                </p>

                {item.reply && (
                  <div style={{ background: "#f8fafc", borderLeft: "3px solid #2563eb", padding: "10px 14px", borderRadius: "0 8px 8px 0" }}>
                    <strong style={{ fontSize: "0.78rem", color: "#2563eb", display: "block", marginBottom: "2px" }}>
                      HomeRepair phản hồi:
                    </strong>
                    <p style={{ fontSize: "0.8rem", color: "#64748b", margin: 0 }}>{item.reply}</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    )
  }

  // ================= TAB: VOUCHERS =================
  const renderVouchersTab = () => {
    return (
      <div style={{ display: "flex", flexDirection: "column", gap: "20px" }}>
        <div>
          <h2 style={{ fontSize: "1.2rem", fontWeight: 800, color: "#0f172a", margin: "0 0 4px" }}>
            Ưu đãi của tôi
          </h2>
          <p style={{ fontSize: "0.8rem", color: "#64748b", margin: 0 }}>
            Danh sách voucher & mã giảm giá độc quyền dành riêng cho khách hàng HomeRepair.
          </p>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: "16px" }}>
          {VOUCHERS_LIST.map((v) => {
            const isCopied = copiedVoucher === v.code
            return (
              <div
                key={v.id}
                style={{
                  background: "#ffffff",
                  border: "1px solid #e2e8f0",
                  borderRadius: "16px",
                  padding: "20px",
                  display: "flex",
                  gap: "16px",
                  boxShadow: "0 2px 8px rgba(15,23,42,0.02)",
                  position: "relative",
                  overflow: "hidden",
                }}
              >
                <div
                  style={{
                    width: "48px",
                    height: "48px",
                    borderRadius: "12px",
                    background: v.bg,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    fontSize: "1.5rem",
                    flexShrink: 0,
                  }}
                >
                  {v.icon}
                </div>

                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "4px" }}>
                    <strong style={{ fontSize: "0.98rem", color: "#0f172a" }}>{v.title}</strong>
                    <span style={{ fontSize: "0.95rem", fontWeight: 900, color: v.color }}>{v.discount}</span>
                  </div>

                  <p style={{ fontSize: "0.78rem", color: "#64748b", margin: "0 0 8px", lineHeight: 1.4 }}>
                    {v.desc}
                  </p>

                  <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", fontSize: "0.74rem", color: "#94a3b8", marginBottom: "12px" }}>
                    <span>{v.minOrder}</span>
                    <span>⏳ {v.expiry}</span>
                  </div>

                  <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                    <button
                      type="button"
                      onClick={() => handleCopyVoucher(v.code)}
                      style={{
                        padding: "6px 12px",
                        borderRadius: "8px",
                        border: "1px dashed #2563eb",
                        background: "#eff6ff",
                        color: "#2563eb",
                        fontSize: "0.78rem",
                        fontWeight: 700,
                        cursor: "pointer",
                      }}
                    >
                      {isCopied ? "✓ Đã chép mã" : `Mã: ${v.code} 📋`}
                    </button>

                    <Link
                      to="/booking"
                      style={{
                        padding: "6px 14px",
                        borderRadius: "8px",
                        background: "#2563eb",
                        color: "#ffffff",
                        fontSize: "0.78rem",
                        fontWeight: 700,
                        textDecoration: "none",
                      }}
                    >
                      Dùng ngay
                    </Link>
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      </div>
    )
  }

  // ================= TAB: NOTIFICATIONS =================
  const renderNotificationsTab = () => {
    return (
      <div style={{ display: "flex", flexDirection: "column", gap: "20px" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div>
            <h2 style={{ fontSize: "1.2rem", fontWeight: 800, color: "#0f172a", margin: "0 0 4px" }}>
              Thông báo
            </h2>
            <p style={{ fontSize: "0.8rem", color: "#64748b", margin: 0 }}>
              Cập nhật trạng thái đơn hẹn, tiến độ sửa chữa và các ưu đãi mới nhất.
            </p>
          </div>

          <button
            type="button"
            onClick={handleMarkAllRead}
            style={{ background: "none", border: "none", color: "#2563eb", fontSize: "0.82rem", fontWeight: 700, cursor: "pointer" }}
          >
            Đánh dấu đã đọc tất cả
          </button>
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
          {notificationsList.map((notif) => (
            <div
              key={notif.id}
              style={{
                background: notif.isRead ? "#ffffff" : "#f0f7ff",
                border: notif.isRead ? "1px solid #e2e8f0" : "1.5px solid #bfdbfe",
                borderRadius: "14px",
                padding: "16px 20px",
                display: "flex",
                alignItems: "flex-start",
                justifyContent: "space-between",
                gap: "14px",
                transition: "all 0.15s ease",
              }}
            >
              <div style={{ display: "flex", alignItems: "flex-start", gap: "12px", flex: 1 }}>
                <span style={{ fontSize: "1.3rem", marginTop: "2px" }}>
                  {notif.type === "booking" ? "📅" : notif.type === "tech" ? "🔧" : notif.type === "promo" ? "🎁" : "✅"}
                </span>
                <div>
                  <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "4px" }}>
                    <strong style={{ fontSize: "0.9rem", color: "#0f172a" }}>{notif.title}</strong>
                    {!notif.isRead && (
                      <span style={{ width: "8px", height: "8px", borderRadius: "50%", background: "#2563eb", display: "inline-block" }} />
                    )}
                  </div>
                  <p style={{ fontSize: "0.82rem", color: "#64748b", margin: "0 0 6px", lineHeight: 1.45 }}>
                    {notif.desc}
                  </p>
                  <span style={{ fontSize: "0.72rem", color: "#94a3b8" }}>{notif.time}</span>
                </div>
              </div>

              <button
                type="button"
                onClick={() => handleDeleteNotification(notif.id)}
                title="Xóa thông báo"
                style={{ background: "none", border: "none", color: "#cbd5e1", fontSize: "1.1rem", cursor: "pointer", padding: "0 4px" }}
              >
                ×
              </button>
            </div>
          ))}
        </div>
      </div>
    )
  }

  // ================= MAIN RENDER =================
  return (
    <main style={{ background: "#f8fafc", minHeight: "100vh", padding: "26px 20px 60px" }}>
      <div style={{ maxWidth: "1400px", margin: "0 auto" }}>
        {portalTab === "bookings" ? (
          /* 3-COLUMN BOOKINGS LAYOUT MATCHING MOCKUP */
          <div style={{ display: "grid", gridTemplateColumns: "220px 380px 1fr", gap: "24px", alignItems: "flex-start" }}>
            {/* COLUMN 1: SIDEBAR */}
            {renderSidebar()}

            {/* COLUMN 2: BOOKINGS LIST */}
            <section
              style={{
                background: "#ffffff",
                border: "1px solid #e2e8f0",
                borderRadius: "16px",
                padding: "20px",
                boxShadow: "0 2px 8px rgba(15,23,42,0.02)",
              }}
            >
              {/* HEADER & NEW BOOKING BUTTON */}
              <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", marginBottom: "14px" }}>
                <div>
                  <h2 style={{ fontSize: "1.2rem", fontWeight: 800, color: "#0f172a", margin: "0 0 4px" }}>
                    Lịch hẹn của tôi
                  </h2>
                  <p style={{ fontSize: "0.78rem", color: "#64748b", margin: 0 }}>
                    Theo dõi tình trạng sửa chữa các thiết bị của bạn
                  </p>
                </div>

                <Link
                  to="/booking"
                  style={{
                    background: "#2563eb",
                    color: "#ffffff",
                    padding: "7px 14px",
                    borderRadius: "8px",
                    fontSize: "0.8rem",
                    fontWeight: 700,
                    textDecoration: "none",
                    whiteSpace: "nowrap",
                    boxShadow: "0 2px 6px rgba(37,99,235,0.25)",
                  }}
                >
                  + Đặt lịch mới
                </Link>
              </div>

              {/* TABS FILTER PILLS */}
              <div style={{ display: "flex", gap: "6px", marginBottom: "16px", overflowX: "auto", paddingBottom: "4px" }}>
                {[
                  { key: "all", label: `Tất cả (${bookingsList.length})` },
                  { key: "inprogress", label: `Đang xử lý (${bookingsList.filter((b) => b.status === "InProgress").length})` },
                  { key: "completed", label: `Hoàn thành (${bookingsList.filter((b) => b.status === "Completed").length})` },
                  { key: "cancelled", label: `Đã hủy (${bookingsList.filter((b) => b.status === "Cancelled").length})` },
                ].map((tab) => {
                  const isActive = activeTab === tab.key
                  return (
                    <button
                      key={tab.key}
                      type="button"
                      onClick={() => setActiveTab(tab.key as any)}
                      style={{
                        padding: "5px 12px",
                        borderRadius: "8px",
                        border: isActive ? "1px solid #2563eb" : "1px solid #e2e8f0",
                        background: isActive ? "#ffffff" : "#f8fafc",
                        color: isActive ? "#2563eb" : "#64748b",
                        fontWeight: isActive ? 700 : 500,
                        fontSize: "0.78rem",
                        cursor: "pointer",
                        whiteSpace: "nowrap",
                        boxShadow: isActive ? "0 2px 4px rgba(37,99,235,0.12)" : "none",
                        transition: "all 0.15s ease",
                      }}
                    >
                      {tab.label}
                    </button>
                  )
                })}
              </div>

              {/* LIST OF BOOKING CARDS */}
              <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
                {filteredBookings.map((b) => {
                  const isSelected = selectedBookingId === b.id
                  return (
                    <div
                      key={b.id}
                      onClick={() => setSelectedBookingId(b.id)}
                      style={{
                        background: isSelected ? "#f0f7ff" : "#ffffff",
                        border: isSelected ? "1.5px solid #2563eb" : "1px solid #e2e8f0",
                        borderRadius: "14px",
                        padding: "14px 16px",
                        cursor: "pointer",
                        transition: "all 0.15s ease",
                        boxShadow: isSelected ? "0 4px 12px rgba(37,99,235,0.08)" : "none",
                      }}
                    >
                      <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", marginBottom: "8px" }}>
                        <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
                          <img
                            src={b.image}
                            alt={b.phoneModelName}
                            style={{ width: "36px", height: "48px", objectFit: "contain", flexShrink: 0 }}
                          />
                          <div>
                            <span style={{ fontSize: "0.78rem", fontWeight: 800, color: "#1e40af", display: "block" }}>
                              {b.bookingCode}
                            </span>
                            <strong style={{ fontSize: "0.92rem", color: "#0f172a" }}>
                              {b.phoneModelName}
                            </strong>
                          </div>
                        </div>

                        <div style={{ textAlign: "right" }}>
                          <span
                            style={{
                              background: b.statusBg,
                              color: b.statusColor,
                              fontSize: "0.7rem",
                              fontWeight: 700,
                              padding: "2px 8px",
                              borderRadius: "999px",
                              display: "inline-block",
                              marginBottom: "4px",
                            }}
                          >
                            {b.statusLabel}
                          </span>
                          <div style={{ fontSize: "0.85rem", fontWeight: 800, color: "#0f172a" }}>
                            {formatVnd(b.estimatedTotal)}
                          </div>
                        </div>
                      </div>

                      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", fontSize: "0.74rem", color: "#64748b", borderTop: "1px dashed #f1f5f9", paddingTop: "8px", marginTop: "4px" }}>
                        <div style={{ display: "flex", alignItems: "center", gap: "4px" }}>
                          <span>📅</span>
                          <span>{b.appointmentDate} • {b.appointmentTime}</span>
                        </div>
                        <div style={{ display: "flex", alignItems: "center", gap: "4px" }}>
                          <span>📍</span>
                          <span>{b.branchName}</span>
                        </div>
                      </div>
                    </div>
                  )
                })}
              </div>

              <div style={{ fontSize: "0.74rem", color: "#94a3b8", textAlign: "center", marginTop: "16px" }}>
                Hiển thị 1 - {filteredBookings.length} của {filteredBookings.length} lịch hẹn
              </div>
            </section>

            {/* COLUMN 3: BOOKING DETAIL VIEW */}
            <section
              style={{
                background: "#ffffff",
                border: "1px solid #e2e8f0",
                borderRadius: "16px",
                padding: "24px",
                boxShadow: "0 2px 8px rgba(15,23,42,0.02)",
              }}
            >
              {/* TOP BAR: BACK & ACTIONS */}
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "14px" }}>
                <button
                  type="button"
                  onClick={() => navigate("/my-bookings")}
                  style={{ background: "none", border: "none", color: "#2563eb", fontSize: "0.82rem", fontWeight: 600, cursor: "pointer", display: "flex", alignItems: "center", gap: "4px", padding: 0 }}
                >
                  <span>←</span>
                  <span>Quay lại danh sách</span>
                </button>

                <div style={{ display: "flex", gap: "8px" }}>
                  <button
                    type="button"
                    onClick={() => window.print()}
                    style={{
                      padding: "6px 12px",
                      borderRadius: "8px",
                      border: "1px solid #cbd5e1",
                      background: "#ffffff",
                      color: "#334155",
                      fontSize: "0.78rem",
                      fontWeight: 600,
                      cursor: "pointer",
                      display: "flex",
                      alignItems: "center",
                      gap: "4px",
                    }}
                  >
                    <span>📥</span>
                    <span>Tải phiếu</span>
                  </button>
                  <Link
                    to="/support"
                    style={{
                      padding: "6px 12px",
                      borderRadius: "8px",
                      border: "1px solid #cbd5e1",
                      background: "#ffffff",
                      color: "#334155",
                      fontSize: "0.78rem",
                      fontWeight: 600,
                      textDecoration: "none",
                      display: "flex",
                      alignItems: "center",
                      gap: "4px",
                    }}
                  >
                    <span>💬</span>
                    <span>Hỗ trợ</span>
                  </Link>
                </div>
              </div>

              {/* HEADER & STATUS BADGE */}
              <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", marginBottom: "20px" }}>
                <div>
                  <h1 style={{ fontSize: "1.35rem", fontWeight: 800, color: "#0f172a", margin: "0 0 4px" }}>
                    Chi tiết lịch hẹn
                  </h1>
                  <p style={{ fontSize: "0.82rem", color: "#64748b", margin: 0 }}>
                    Theo dõi tình trạng sửa chữa và thông tin chi tiết của lịch hẹn
                  </p>
                </div>

                <span
                  style={{
                    background: selectedBooking.statusBg,
                    color: selectedBooking.statusColor,
                    fontWeight: 700,
                    fontSize: "0.8rem",
                    padding: "5px 12px",
                    borderRadius: "999px",
                    display: "flex",
                    alignItems: "center",
                    gap: "6px",
                  }}
                >
                  <span>⚙️</span>
                  <span>{selectedBooking.statusLabel}</span>
                </span>
              </div>

              {/* 3 TOP SUMMARY CARDS */}
              <div style={{ display: "grid", gridTemplateColumns: "1.1fr 1fr 1.2fr", gap: "12px", marginBottom: "24px" }}>
                <div style={{ background: "#f8fafc", border: "1px solid #e2e8f0", borderRadius: "12px", padding: "12px 14px" }}>
                  <span style={{ fontSize: "0.74rem", color: "#64748b", display: "block", marginBottom: "4px" }}>Mã lịch hẹn</span>
                  <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                    <strong style={{ fontSize: "0.95rem", color: "#1d4ed8" }}>{selectedBooking.bookingCode}</strong>
                    <button
                      type="button"
                      onClick={() => handleCopyCode(selectedBooking.bookingCode)}
                      title="Sao chép mã"
                      style={{ background: "none", border: "none", cursor: "pointer", fontSize: "0.85rem", padding: 0 }}
                    >
                      {copiedCode ? "✓" : "📋"}
                    </button>
                  </div>
                </div>

                <div style={{ background: "#f8fafc", border: "1px solid #e2e8f0", borderRadius: "12px", padding: "12px 14px" }}>
                  <span style={{ fontSize: "0.74rem", color: "#64748b", display: "block", marginBottom: "4px" }}>Ngày đặt lịch</span>
                  <strong style={{ fontSize: "0.9rem", color: "#0f172a", display: "block" }}>{selectedBooking.appointmentDate}</strong>
                  <span style={{ fontSize: "0.74rem", color: "#64748b" }}>{selectedBooking.appointmentTime}</span>
                </div>

                <div style={{ background: "#f8fafc", border: "1px solid #e2e8f0", borderRadius: "12px", padding: "12px 14px" }}>
                  <span style={{ fontSize: "0.74rem", color: "#64748b", display: "block", marginBottom: "4px" }}>Chi nhánh</span>
                  <strong style={{ fontSize: "0.9rem", color: "#0f172a", display: "block" }}>{selectedBooking.branchName}</strong>
                  <span style={{ fontSize: "0.72rem", color: "#64748b", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", display: "block" }}>
                    📍 {selectedBooking.branchAddress}
                  </span>
                </div>
              </div>

              {/* 6-STEP PROGRESS TRACKER */}
              <div style={{ marginBottom: "28px" }}>
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", position: "relative" }}>
                  {[
                    { num: 1, title: "Đặt lịch", time: "15/10 10:20", done: true },
                    { num: 2, title: "Xác nhận", time: "15/10 10:35", done: true },
                    { num: 3, title: "Đã tiếp nhận", time: "15/10 14:40", done: true },
                    { num: 4, title: "Đang kiểm tra", time: "15/10 15:20", done: true },
                    { num: 5, title: "Đang sửa chữa", time: "- - : - -", done: false, active: true },
                    { num: 6, title: "Hoàn thành", time: "- - : - -", done: false },
                  ].map((step) => (
                    <div key={step.num} style={{ display: "flex", flexDirection: "column", alignItems: "center", zIndex: 2, flex: 1 }}>
                      <div
                        style={{
                          width: "28px",
                          height: "28px",
                          borderRadius: "50%",
                          background: step.done ? "#2563eb" : step.active ? "#3b82f6" : "#e2e8f0",
                          color: step.done || step.active ? "#ffffff" : "#94a3b8",
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                          fontSize: "0.78rem",
                          fontWeight: 800,
                          marginBottom: "6px",
                          boxShadow: step.active ? "0 0 0 3px rgba(37,99,235,0.2)" : "none",
                        }}
                      >
                        {step.done ? "✓" : step.num}
                      </div>
                      <span style={{ fontSize: "0.78rem", fontWeight: step.active || step.done ? 700 : 500, color: step.active ? "#2563eb" : step.done ? "#0f172a" : "#94a3b8", textAlign: "center" }}>
                        {step.title}
                      </span>
                      <span style={{ fontSize: "0.68rem", color: "#94a3b8", marginTop: "2px" }}>{step.time}</span>
                    </div>
                  ))}

                  <div
                    style={{
                      position: "absolute",
                      top: "14px",
                      left: "8%",
                      right: "8%",
                      height: "2px",
                      background: "#e2e8f0",
                      zIndex: 1,
                    }}
                  >
                    <div style={{ height: "100%", width: "70%", background: "#2563eb" }} />
                  </div>
                </div>
              </div>

              {/* 2-COLUMN SPLIT: DEVICE INFO & TECHNICIAN */}
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "16px", marginBottom: "24px" }}>
                <div style={{ background: "#f8fafc", border: "1px solid #e2e8f0", borderRadius: "14px", padding: "16px" }}>
                  <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "12px" }}>
                    <span style={{ fontSize: "0.85rem", fontWeight: 700, color: "#0f172a" }}>Thông tin thiết bị</span>
                    <button type="button" onClick={() => navigate("/booking")} style={{ background: "none", border: "none", color: "#2563eb", fontSize: "0.75rem", fontWeight: 600, cursor: "pointer" }}>
                      Thay đổi
                    </button>
                  </div>
                  <div style={{ display: "flex", alignItems: "center", gap: "14px" }}>
                    <img src={selectedBooking.image} alt={selectedBooking.phoneModelName} style={{ width: "42px", height: "56px", objectFit: "contain" }} />
                    <div style={{ fontSize: "0.8rem", color: "#64748b", display: "flex", flexDirection: "column", gap: "2px" }}>
                      <strong style={{ fontSize: "0.95rem", color: "#0f172a" }}>{selectedBooking.phoneModelName}</strong>
                      <span>Dung lượng: <strong style={{ color: "#334155" }}>{selectedBooking.storage || "Chưa ghi nhận"}</strong></span>
                      <span>Màu sắc: <strong style={{ color: "#334155" }}>{selectedBooking.color || "Chưa ghi nhận"}</strong></span>
                      <span>Số seri: <span style={{ fontFamily: "monospace" }}>{selectedBooking.serial || "Chưa có"}</span></span>
                    </div>
                  </div>
                </div>

                <div style={{ background: "#f8fafc", border: "1px solid #e2e8f0", borderRadius: "14px", padding: "16px" }}>
                  <span style={{ fontSize: "0.85rem", fontWeight: 700, color: "#0f172a", display: "block", marginBottom: "12px" }}>
                    Kỹ thuật viên phụ trách
                  </span>
                  <div style={{ display: "flex", alignItems: "center", gap: "14px" }}>
                    <img
                      src={selectedBooking.technicianAvatar || getAvatarImage("Trần Minh Đức", true)}
                      alt={selectedBooking.technicianName}
                      style={{ width: "48px", height: "48px", borderRadius: "50%", objectFit: "cover" }}
                    />
                    <div style={{ flex: 1 }}>
                      <strong style={{ fontSize: "0.95rem", color: "#0f172a", display: "block" }}>
                        {selectedBooking.technicianName || "Chưa phân công"}
                      </strong>
                      <span style={{ fontSize: "0.76rem", color: "#64748b", display: "block" }}>
                        {selectedBooking.technicianRole || "Kỹ thuật viên chuyên nghiệp"}
                      </span>
                      <span style={{ fontSize: "0.74rem", color: "#f59e0b", fontWeight: 700 }}>
                        ★ {selectedBooking.technicianRating || "4.9 (128 đánh giá)"}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* SERVICES TABLE & PRICING */}
              <div style={{ display: "grid", gridTemplateColumns: "1.3fr 0.7fr", gap: "16px", marginBottom: "24px" }}>
                <div>
                  <span style={{ fontSize: "0.85rem", fontWeight: 700, color: "#0f172a", display: "block", marginBottom: "10px" }}>
                    Dịch vụ sửa chữa
                  </span>
                  <div style={{ border: "1px solid #e2e8f0", borderRadius: "10px", overflow: "hidden", fontSize: "0.82rem" }}>
                    <div style={{ display: "grid", gridTemplateColumns: "30px 1fr 100px 70px 110px", background: "#f8fafc", padding: "8px 12px", fontWeight: 700, color: "#475569", borderBottom: "1px solid #e2e8f0" }}>
                      <span>#</span>
                      <span>Dịch vụ</span>
                      <span style={{ textAlign: "right" }}>Đơn giá</span>
                      <span style={{ textAlign: "center" }}>Số lượng</span>
                      <span style={{ textAlign: "right" }}>Thành tiền</span>
                    </div>
                    {selectedBooking.services && selectedBooking.services.length > 0 ? (
                      selectedBooking.services.map((s, idx) => (
                        <div key={s.id} style={{ display: "grid", gridTemplateColumns: "30px 1fr 100px 70px 110px", padding: "10px 12px", borderBottom: "1px dashed #f1f5f9", alignItems: "center" }}>
                          <span style={{ color: "#94a3b8" }}>{idx + 1}</span>
                          <strong style={{ color: "#0f172a" }}>{s.name}</strong>
                          <span style={{ textAlign: "right", color: "#64748b" }}>{formatVnd(s.price)}</span>
                          <span style={{ textAlign: "center", color: "#64748b" }}>{s.quantity}</span>
                          <strong style={{ textAlign: "right", color: "#0f172a" }}>{formatVnd(s.price * s.quantity)}</strong>
                        </div>
                      ))
                    ) : (
                      <div style={{ padding: "12px", color: "#94a3b8", fontStyle: "italic", textAlign: "center" }}>
                        Chưa có dịch vụ nào
                      </div>
                    )}
                  </div>
                </div>

                <div style={{ background: "#f8fafc", border: "1px solid #e2e8f0", borderRadius: "14px", padding: "16px", display: "flex", flexDirection: "column", justifyContent: "space-between" }}>
                  <div>
                    <span style={{ fontSize: "0.85rem", fontWeight: 700, color: "#0f172a", display: "block", marginBottom: "10px" }}>
                      Chi phí
                    </span>
                    <div style={{ display: "flex", justifyContent: "space-between", fontSize: "0.82rem", color: "#64748b", marginBottom: "6px" }}>
                      <span>Tạm tính</span>
                      <span>{formatVnd(selectedBooking.estimatedTotal)}</span>
                    </div>
                    <div style={{ display: "flex", justifyContent: "space-between", fontSize: "0.82rem", color: "#64748b", marginBottom: "10px" }}>
                      <span>Giảm giá</span>
                      <span>0đ</span>
                    </div>
                    <div style={{ borderTop: "1px solid #e2e8f0", paddingTop: "8px", display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
                      <strong style={{ fontSize: "0.9rem", color: "#0f172a" }}>Tổng cộng (dự kiến)</strong>
                      <strong style={{ fontSize: "1.15rem", color: "#2563eb", fontWeight: 900 }}>{formatVnd(selectedBooking.estimatedTotal)}</strong>
                    </div>
                  </div>
                </div>
              </div>

              {/* TIMELINE & NOTES */}
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "16px" }}>
                <div>
                  <span style={{ fontSize: "0.85rem", fontWeight: 700, color: "#0f172a", display: "block", marginBottom: "10px" }}>
                    Lịch sử cập nhật
                  </span>
                  <div style={{ border: "1px solid #e2e8f0", borderRadius: "12px", padding: "14px" }}>
                    {selectedBooking.timeline?.map((item, idx) => (
                      <div key={idx} style={{ display: "flex", gap: "10px", marginBottom: "12px" }}>
                        <span style={{ color: "#2563eb", fontSize: "0.9rem" }}>✓</span>
                        <div>
                          <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                            <strong style={{ fontSize: "0.82rem", color: "#0f172a" }}>{item.title}</strong>
                            <span style={{ fontSize: "0.72rem", color: "#94a3b8" }}>{item.time}</span>
                          </div>
                          <p style={{ fontSize: "0.76rem", color: "#64748b", margin: "2px 0 0" }}>{item.desc}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <span style={{ fontSize: "0.85rem", fontWeight: 700, color: "#0f172a", display: "block", marginBottom: "10px" }}>
                    Ghi chú
                  </span>
                  <div style={{ border: "1px solid #e2e8f0", borderRadius: "12px", padding: "14px", display: "flex", flexDirection: "column", gap: "10px" }}>
                    {selectedBooking.customerNote && (
                      <div style={{ background: "#f8fafc", padding: "10px", borderRadius: "8px", fontSize: "0.8rem" }}>
                        <strong style={{ color: "#0f172a", display: "block", marginBottom: "2px" }}>Yêu cầu của bạn:</strong>
                        <span style={{ color: "#64748b" }}>{selectedBooking.customerNote}</span>
                      </div>
                    )}
                    {selectedBooking.technicianNote && (
                      <div style={{ background: "#eff6ff", padding: "10px", borderRadius: "8px", fontSize: "0.8rem" }}>
                        <strong style={{ color: "#1d4ed8", display: "block", marginBottom: "2px" }}>Ghi chú từ kỹ thuật viên:</strong>
                        <span style={{ color: "#334155" }}>{selectedBooking.technicianNote}</span>
                      </div>
                    )}

                    <div style={{ display: "flex", gap: "8px", marginTop: "4px" }}>
                      <input
                        type="text"
                        placeholder="Thêm ghi chú hoặc câu hỏi cho kỹ thuật viên..."
                        value={newNoteText}
                        onChange={(e) => setNewNoteText(e.target.value)}
                        style={{ flex: 1, padding: "8px 10px", borderRadius: "8px", border: "1px solid #cbd5e1", fontSize: "0.8rem" }}
                      />
                      <button
                        type="button"
                        onClick={() => {
                          if (newNoteText.trim()) {
                            alert("Đã gửi ghi chú đến kỹ thuật viên!")
                            setNewNoteText("")
                          }
                        }}
                        style={{ background: "#2563eb", color: "#ffffff", border: "none", borderRadius: "8px", padding: "0 12px", cursor: "pointer" }}
                      >
                        ➤
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </section>
          </div>
        ) : (
          /* 2-COLUMN UNIFIED PORTAL LAYOUT */
          <div style={{ display: "grid", gridTemplateColumns: "220px 1fr", gap: "24px", alignItems: "flex-start" }}>
            {/* COLUMN 1: SIDEBAR */}
            {renderSidebar()}

            {/* COLUMN 2: ACTIVE TAB CONTENT */}
            <section style={{ minWidth: 0 }}>
              {portalTab === "overview" && renderOverviewTab()}
              {portalTab === "profile" && renderProfileTab()}
              {portalTab === "devices" && renderDevicesTab()}
              {portalTab === "reviews" && renderReviewsTab()}
              {portalTab === "vouchers" && renderVouchersTab()}
              {portalTab === "notifications" && renderNotificationsTab()}
            </section>
          </div>
        )}
      </div>
    </main>
  )
}
