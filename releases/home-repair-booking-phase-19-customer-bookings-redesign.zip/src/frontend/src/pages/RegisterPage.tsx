import { zodResolver } from "@hookform/resolvers/zod"
import { useState } from "react"
import { useForm } from "react-hook-form"
import { Link, Navigate, useNavigate } from "react-router-dom"
import { z } from "zod"
import { register as registerAccount } from "../api/auth"
import { ApiError } from "../api/client"
import { useAuth } from "../auth/AuthContext"

const schema = z
  .object({
    fullName: z.string().trim().min(1, "Vui lòng nhập họ và tên.").max(100),
    phoneNumber: z.string().regex(/^[0-9+\s]{8,15}$/, "Số điện thoại không hợp lệ."),
    email: z.string().email("Email không hợp lệ."),
    password: z
      .string()
      .min(6, "Mật khẩu tối thiểu 6 ký tự.")
      .regex(/[A-Z]/, "Mật khẩu cần ít nhất 1 chữ hoa.")
      .regex(/[a-z]/, "Mật khẩu cần ít nhất 1 chữ thường.")
      .regex(/[0-9]/, "Mật khẩu cần ít nhất 1 chữ số."),
    confirmPassword: z.string().min(1, "Vui lòng xác nhận mật khẩu."),
    city: z.string().optional(),
    agreeTerms: z.boolean().refine((val) => val === true, "Vui lòng đồng ý với điều khoản sử dụng."),
  })
  .refine((values) => values.password === values.confirmPassword, {
    message: "Mật khẩu nhập lại chưa khớp.",
    path: ["confirmPassword"],
  })

type RegisterValues = z.infer<typeof schema>

export function RegisterPage() {
  const navigate = useNavigate()
  const { user, setSession } = useAuth()
  const [showPassword, setShowPassword] = useState(false)
  const [showConfirmPassword, setShowConfirmPassword] = useState(false)

  const {
    register,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<RegisterValues>({
    resolver: zodResolver(schema),
    defaultValues: {
      fullName: "",
      phoneNumber: "",
      email: "",
      password: "",
      confirmPassword: "",
      city: "TP. Hồ Chí Minh",
      agreeTerms: true,
    },
  })

  if (user) {
    return <Navigate to="/" replace />
  }

  async function onSubmit(values: RegisterValues) {
    try {
      const result = await registerAccount({
        fullName: values.fullName,
        email: values.email,
        phoneNumber: values.phoneNumber,
        password: values.password,
        confirmPassword: values.confirmPassword,
      })
      setSession(result.accessToken, result.user)
      navigate("/")
    } catch (error) {
      if (error instanceof ApiError && error.errors) {
        for (const [field, messages] of Object.entries(error.errors)) {
          setError(field as keyof RegisterValues, { message: messages[0] })
        }
        return
      }
      const message = error instanceof ApiError ? error.message : "Không tạo được tài khoản. Vui lòng thử lại."
      setError("root", { message })
    }
  }

  return (
    <main className="auth-page-container">
      <div className="auth-split-card">
        {/* LEFT SHOWCASE PANEL (IMAGE 1) */}
        <div className="auth-showcase-side">
          <div>
            <div className="auth-trust-pill">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#38bdf8" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
                <path d="m9 12 2 2 4-4" />
              </svg>
              <span>Hơn 50.000+ khách hàng tin tưởng</span>
            </div>

            <h1 className="auth-showcase-title">
              Tham gia <span>HomeRepair</span>
              <br />
              Để trải nghiệm dịch vụ sửa chữa tốt hơn
            </h1>

            <p className="auth-showcase-desc">
              Tạo tài khoản để đặt lịch nhanh chóng, theo dõi lịch sử sửa chữa, nhận ưu đãi và nhiều tiện ích khác.
            </p>

            <div className="auth-feature-list">
              <div className="auth-feature-item">
                <div className="auth-feature-icon" style={{ background: "#0284c7", color: "white" }}>
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                    <rect x="3" y="4" width="18" height="18" rx="2" ry="2" />
                    <line x1="16" y1="2" x2="16" y2="6" />
                    <line x1="8" y1="2" x2="8" y2="6" />
                    <line x1="3" y1="10" x2="21" y2="10" />
                  </svg>
                </div>
                <div className="auth-feature-text">
                  <strong>Đặt lịch dễ dàng</strong>
                  <span>Chỉ vài bước, tiết kiệm thời gian</span>
                </div>
              </div>

              <div className="auth-feature-item">
                <div className="auth-feature-icon" style={{ background: "#7c3aed", color: "white" }}>
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                    <line x1="8" y1="6" x2="21" y2="6" />
                    <line x1="8" y1="12" x2="21" y2="12" />
                    <line x1="8" y1="18" x2="21" y2="18" />
                    <line x1="3" y1="6" x2="3.01" y2="6" />
                    <line x1="3" y1="12" x2="3.01" y2="12" />
                    <line x1="3" y1="18" x2="3.01" y2="18" />
                  </svg>
                </div>
                <div className="auth-feature-text">
                  <strong>Theo dõi lịch sử</strong>
                  <span>Quản lý các lần sửa chữa của bạn</span>
                </div>
              </div>

              <div className="auth-feature-item">
                <div className="auth-feature-icon" style={{ background: "#ea580c", color: "white" }}>
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" />
                    <path d="M13.73 21a2 2 0 0 1-3.46 0" />
                  </svg>
                </div>
                <div className="auth-feature-text">
                  <strong>Nhận ưu đãi đặc biệt</strong>
                  <span>Cập nhật khuyến mãi dành riêng cho thành viên</span>
                </div>
              </div>

              <div className="auth-feature-item">
                <div className="auth-feature-icon" style={{ background: "#16a34a", color: "white" }}>
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" />
                  </svg>
                </div>
                <div className="auth-feature-text">
                  <strong>Trải nghiệm cá nhân hóa</strong>
                  <span>Đề xuất dịch vụ phù hợp với thiết bị của bạn</span>
                </div>
              </div>
            </div>
          </div>

          {/* PHONE VISUAL SHOWCASE */}
          <div className="auth-phone-visual">
            <div style={{ display: "flex", gap: "12px", alignItems: "flex-end" }}>
              <div
                style={{
                  width: "120px",
                  height: "170px",
                  background: "#1e293b",
                  borderRadius: "20px 20px 0 0",
                  border: "2px solid #334155",
                  borderBottom: "none",
                  padding: "8px",
                  position: "relative",
                  boxShadow: "0 10px 30px rgba(0,0,0,0.5)",
                }}
              >
                <div style={{ width: "30px", height: "4px", background: "#475569", borderRadius: "2px", margin: "0 auto 8px" }} />
                <div
                  style={{
                    width: "100%",
                    height: "calc(100% - 12px)",
                    background: "linear-gradient(180deg, #1d4ed8 0%, #0f172a 100%)",
                    borderRadius: "14px",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <span style={{ fontSize: "1.8rem" }}>📱</span>
                </div>
              </div>

              <div
                style={{
                  width: "140px",
                  height: "200px",
                  background: "#0f172a",
                  borderRadius: "24px 24px 0 0",
                  border: "3px solid #475569",
                  borderBottom: "none",
                  padding: "10px",
                  boxShadow: "0 16px 40px rgba(0,0,0,0.6)",
                }}
              >
                <div style={{ width: "40px", height: "5px", background: "#64748b", borderRadius: "3px", margin: "0 auto 10px" }} />
                <div
                  style={{
                    width: "100%",
                    height: "calc(100% - 15px)",
                    background: "linear-gradient(180deg, #0284c7 0%, #1e3a8a 100%)",
                    borderRadius: "16px",
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "center",
                    justifyContent: "center",
                    padding: "10px",
                    textAlign: "center",
                  }}
                >
                  <span style={{ fontSize: "2rem", marginBottom: "4px" }}>🛡️</span>
                  <strong style={{ fontSize: "0.75rem", color: "white" }}>HomeRepair</strong>
                </div>
              </div>
            </div>

            {/* FLOATING BLUE PILL */}
            <div className="auth-floating-badge">
              <div style={{ width: "32px", height: "32px", borderRadius: "8px", background: "#0284c7", display: "flex", alignItems: "center", justifyContent: "center" }}>
                🔧
              </div>
              <div>
                <strong style={{ display: "block", fontSize: "0.82rem", color: "white" }}>Thiết bị của bạn</strong>
                <span style={{ fontSize: "0.72rem", color: "#93c5fd" }}>Luôn được chăm sóc tốt nhất</span>
              </div>
            </div>
          </div>
        </div>

        {/* RIGHT REGISTRATION FORM (IMAGE 1) */}
        <div className="auth-form-side">
          <div className="auth-form-header">
            <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between" }}>
              <h2 className="auth-form-title">Tạo tài khoản mới</h2>
              <span style={{ fontSize: "0.85rem", color: "#64748b" }}>
                Đã có tài khoản?{" "}
                <Link to="/login" style={{ color: "#2563eb", fontWeight: 700 }}>
                  Đăng nhập
                </Link>
              </span>
            </div>
            <p className="auth-form-subtitle">
              Tham gia HomeRepair để bắt đầu trải nghiệm dịch vụ sửa chữa chuyên nghiệp, nhanh chóng và tiện lợi.
            </p>
          </div>

          <form onSubmit={handleSubmit(onSubmit)} noValidate>
            {errors.root && (
              <div style={{ padding: "12px", background: "#fef2f2", border: "1px solid #fecaca", borderRadius: "10px", color: "#b91c1c", fontSize: "0.88rem", marginBottom: "16px" }}>
                {errors.root.message}
              </div>
            )}

            {/* HỌ VÀ TÊN */}
            <div className="auth-input-group">
              <label className="auth-input-label">
                Họ và tên <span style={{ color: "#dc2626" }}>*</span>
              </label>
              <div className="auth-input-wrapper">
                <span className="auth-input-icon">👤</span>
                <input
                  type="text"
                  className="auth-input"
                  placeholder="Nhập họ và tên của bạn"
                  {...register("fullName")}
                />
              </div>
              {errors.fullName && <p style={{ color: "#dc2626", fontSize: "0.78rem", margin: "4px 0 0" }}>{errors.fullName.message}</p>}
            </div>

            {/* SỐ ĐIỆN THOẠI */}
            <div className="auth-input-group">
              <label className="auth-input-label">
                Số điện thoại <span style={{ color: "#dc2626" }}>*</span>
              </label>
              <div className="auth-input-wrapper">
                <span className="auth-input-icon">📞</span>
                <input
                  type="tel"
                  className="auth-input"
                  placeholder="Nhập số điện thoại"
                  {...register("phoneNumber")}
                />
              </div>
              {errors.phoneNumber && <p style={{ color: "#dc2626", fontSize: "0.78rem", margin: "4px 0 0" }}>{errors.phoneNumber.message}</p>}
            </div>

            {/* EMAIL */}
            <div className="auth-input-group">
              <label className="auth-input-label">
                Email <span style={{ color: "#dc2626" }}>*</span>
              </label>
              <div className="auth-input-wrapper">
                <span className="auth-input-icon">✉️</span>
                <input
                  type="email"
                  className="auth-input"
                  placeholder="Nhập địa chỉ email của bạn"
                  {...register("email")}
                />
              </div>
              {errors.email && <p style={{ color: "#dc2626", fontSize: "0.78rem", margin: "4px 0 0" }}>{errors.email.message}</p>}
            </div>

            {/* MẬT KHẨU */}
            <div className="auth-input-group">
              <label className="auth-input-label">
                Mật khẩu <span style={{ color: "#dc2626" }}>*</span>
              </label>
              <div className="auth-input-wrapper">
                <span className="auth-input-icon">🔒</span>
                <input
                  type={showPassword ? "text" : "password"}
                  className="auth-input"
                  placeholder="Tạo mật khẩu (ít nhất 6 ký tự)"
                  {...register("password")}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  style={{ position: "absolute", right: "12px", background: "none", border: "none", color: "#94a3b8", cursor: "pointer", fontSize: "1rem" }}
                  title="Hiện/ẩn mật khẩu"
                >
                  {showPassword ? "👁️" : "👁️‍🗨️"}
                </button>
              </div>
              {errors.password && <p style={{ color: "#dc2626", fontSize: "0.78rem", margin: "4px 0 0" }}>{errors.password.message}</p>}
            </div>

            {/* XÁC NHẬN MẬT KHẨU */}
            <div className="auth-input-group">
              <label className="auth-input-label">
                Xác nhận mật khẩu <span style={{ color: "#dc2626" }}>*</span>
              </label>
              <div className="auth-input-wrapper">
                <span className="auth-input-icon">🔒</span>
                <input
                  type={showConfirmPassword ? "text" : "password"}
                  className="auth-input"
                  placeholder="Nhập lại mật khẩu"
                  {...register("confirmPassword")}
                />
                <button
                  type="button"
                  onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                  style={{ position: "absolute", right: "12px", background: "none", border: "none", color: "#94a3b8", cursor: "pointer", fontSize: "1rem" }}
                  title="Hiện/ẩn mật khẩu"
                >
                  {showConfirmPassword ? "👁️" : "👁️‍🗨️"}
                </button>
              </div>
              {errors.confirmPassword && <p style={{ color: "#dc2626", fontSize: "0.78rem", margin: "4px 0 0" }}>{errors.confirmPassword.message}</p>}
            </div>

            {/* TỈNH / THÀNH PHỐ */}
            <div className="auth-input-group">
              <label className="auth-input-label">Tỉnh / Thành phố (tùy chọn)</label>
              <div className="auth-input-wrapper">
                <span className="auth-input-icon">📍</span>
                <select className="auth-input" {...register("city")}>
                  <option value="TP. Hồ Chí Minh">TP. Hồ Chí Minh</option>
                  <option value="Hà Nội">Hà Nội</option>
                  <option value="Đà Nẵng">Đà Nẵng</option>
                  <option value="Cần Thơ">Cần Thơ</option>
                  <option value="Hải Phòng">Hải Phòng</option>
                </select>
              </div>
              <span style={{ fontSize: "0.76rem", color: "#94a3b8", display: "block", marginTop: "4px" }}>
                Chọn khu vực để chúng tôi gợi ý chi nhánh gần bạn nhất.
              </span>
            </div>

            {/* ĐIỀU KHOẢN SỬ DỤNG */}
            <div style={{ margin: "16px 0 20px" }}>
              <label style={{ display: "flex", alignItems: "flex-start", gap: "10px", fontSize: "0.84rem", color: "#475569", cursor: "pointer" }}>
                <input
                  type="checkbox"
                  style={{ marginTop: "3px", width: "16px", height: "16px", accentColor: "#2563eb" }}
                  {...register("agreeTerms")}
                />
                <span>
                  Tôi đồng ý với{" "}
                  <Link to="/support" style={{ color: "#2563eb", fontWeight: 600 }}>
                    Điều khoản sử dụng
                  </Link>{" "}
                  và{" "}
                  <Link to="/support" style={{ color: "#2563eb", fontWeight: 600 }}>
                    Chính sách bảo mật
                  </Link>{" "}
                  của HomeRepair <span style={{ color: "#dc2626" }}>*</span>
                </span>
              </label>
              {errors.agreeTerms && <p style={{ color: "#dc2626", fontSize: "0.78rem", margin: "4px 0 0" }}>{errors.agreeTerms.message}</p>}
            </div>

            <button type="submit" className="auth-btn-primary" disabled={isSubmitting}>
              {isSubmitting ? "Đang xử lý..." : "Tạo tài khoản →"}
            </button>
          </form>

          <div className="auth-divider">Hoặc đăng ký nhanh với</div>

          <div className="auth-social-row">
            <button
              type="button"
              className="auth-social-btn"
              onClick={() => alert("Tính năng đăng nhập với Apple sẽ sớm ra mắt.")}
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
                <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.81-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M15.97 6.47c.61-.75 1.04-1.8 1.01-2.87-.96.04-2.11.64-2.77 1.41-.58.68-.99 1.74-.95 2.79 1.07.08 2.1-.58 2.71-1.33z" />
              </svg>
              <span>Apple</span>
            </button>

            <button
              type="button"
              className="auth-social-btn"
              onClick={() => alert("Tính năng đăng nhập với Google sẽ sớm ra mắt.")}
            >
              <svg width="18" height="18" viewBox="0 0 24 24">
                <path fill="#4285F4" d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17z" />
                <path fill="#34A853" d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.34 24 12 24z" />
                <path fill="#FBBC05" d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.18 0 10.03 0 12s.45 3.82 1.25 5.42l4.03-3.15z" />
                <path fill="#EA4335" d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.34 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z" />
              </svg>
              <span>Google</span>
            </button>

            <button
              type="button"
              className="auth-social-btn"
              onClick={() => alert("Tính năng đăng nhập với Facebook sẽ sớm ra mắt.")}
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="#1877F2">
                <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
              </svg>
              <span>Facebook</span>
            </button>
          </div>

          <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: "8px", fontSize: "0.78rem", color: "#64748b", textAlign: "center" }}>
            <span>🔒 Thông tin của bạn được bảo mật tuyệt đối và chỉ sử dụng cho mục đích cung cấp dịch vụ.</span>
          </div>
        </div>
      </div>
    </main>
  )
}
