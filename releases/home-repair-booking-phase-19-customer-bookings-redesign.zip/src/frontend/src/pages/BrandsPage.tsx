import { useEffect, useState } from "react"
import { Link } from "react-router-dom"
import { getBrands, type Brand } from "../api/catalog"
import { BRAND_LOGOS } from "../assets"

export function BrandsPage() {
  const [brands, setBrands] = useState<Brand[]>([])
  const [search, setSearch] = useState("")

  useEffect(() => {
    getBrands(search).then(setBrands).catch(() => setBrands([]))
  }, [search])

  return (
    <main style={{ background: "#f8fafc", minHeight: "100vh", padding: "36px 20px 80px" }}>
      <div style={{ maxWidth: "1200px", margin: "0 auto" }}>
        {/* HEADER */}
        <section style={{ marginBottom: "32px", textAlign: "center" }}>
          <span style={{ fontSize: "0.82rem", fontWeight: 700, color: "#2563eb", background: "#eff6ff", padding: "4px 12px", borderRadius: "999px", display: "inline-block", marginBottom: "8px" }}>
            HỆ THỐNG THƯƠNG HIỆU
          </span>
          <h1 style={{ fontSize: "2rem", fontWeight: 900, color: "#0f172a", margin: "0 0 8px" }}>
            Hãng điện thoại hỗ trợ
          </h1>
          <p style={{ fontSize: "0.95rem", color: "#64748b", margin: "0 auto 24px", maxWidth: "560px" }}>
            Chúng tôi hỗ trợ sửa chữa và bảo hành chính hãng linh kiện cho tất cả các thương hiệu điện thoại phổ biến.
          </p>

          {/* SEARCH BAR */}
          <div style={{ position: "relative", maxWidth: "420px", margin: "0 auto" }}>
            <span style={{ position: "absolute", left: "14px", top: "12px", fontSize: "1rem", color: "#94a3b8" }}>🔍</span>
            <input
              type="text"
              placeholder="Tìm kiếm thương hiệu..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              style={{
                width: "100%",
                height: "44px",
                padding: "0 16px 0 42px",
                borderRadius: "12px",
                border: "1px solid #cbd5e1",
                background: "#ffffff",
                fontSize: "0.9rem",
                outline: "none",
                boxShadow: "0 2px 8px rgba(0,0,0,0.04)",
              }}
            />
          </div>
        </section>

        {/* BRANDS GRID */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))", gap: "20px" }}>
          {brands.map((brand) => {
            const isWordmark = ["Samsung", "Oppo", "Vivo", "Honor", "Realme"].includes(brand.name)
            return (
              <article
                key={brand.id}
                style={{
                  background: "#ffffff",
                  border: "1px solid #e2e8f0",
                  borderRadius: "16px",
                  padding: "24px 20px",
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  textAlign: "center",
                  boxShadow: "0 2px 8px rgba(15,23,42,0.03)",
                  transition: "all 0.2s ease",
                }}
              >
                {/* LOGO CONTAINER */}
                <div
                  style={{
                    width: "120px",
                    height: "58px",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    marginBottom: isWordmark ? "18px" : "12px",
                    background: "#f8fafc",
                    borderRadius: "12px",
                    padding: "8px 12px",
                  }}
                >
                  {BRAND_LOGOS[brand.name] ? (
                    <img
                      src={BRAND_LOGOS[brand.name]}
                      alt={brand.name}
                      style={{
                        height: isWordmark ? "22px" : "36px",
                        maxWidth: isWordmark ? "88px" : "36px",
                        objectFit: "contain",
                      }}
                    />
                  ) : (
                    <span style={{ fontSize: "1.8rem" }}>📱</span>
                  )}
                </div>

                {!isWordmark ? (
                  <h2 style={{ fontSize: "1.15rem", fontWeight: 800, color: "#0f172a", margin: "0 0 6px" }}>
                    {brand.name}
                  </h2>
                ) : (
                  <div style={{ height: "4px" }} />
                )}
                <span style={{ fontSize: "0.8rem", color: "#64748b", background: "#f1f5f9", padding: "3px 12px", borderRadius: "999px", marginBottom: "18px" }}>
                  {brand.modelCount} dòng máy
                </span>

                {/* ACTION BUTTONS */}
                <div style={{ display: "flex", gap: "10px", width: "100%", marginTop: "auto" }}>
                  <Link
                    to={`/booking?brand=${encodeURIComponent(brand.name)}`}
                    style={{
                      flex: 1,
                      padding: "8px 0",
                      background: "#2563eb",
                      color: "#ffffff",
                      borderRadius: "8px",
                      fontSize: "0.82rem",
                      fontWeight: 700,
                      textDecoration: "none",
                      textAlign: "center",
                    }}
                  >
                    Đặt lịch
                  </Link>
                  <Link
                    to={`/models?brandId=${brand.id}`}
                    style={{
                      flex: 1,
                      padding: "8px 0",
                      background: "#f1f5f9",
                      color: "#334155",
                      borderRadius: "8px",
                      fontSize: "0.82rem",
                      fontWeight: 600,
                      textDecoration: "none",
                      textAlign: "center",
                    }}
                  >
                    Xem máy
                  </Link>
                </div>
              </article>
            )
          })}
        </div>
      </div>
    </main>
  )
}
