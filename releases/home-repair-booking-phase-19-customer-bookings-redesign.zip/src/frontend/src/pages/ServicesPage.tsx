import { useEffect, useState } from "react"
import { Link, useSearchParams } from "react-router-dom"
import { getServices } from "../api/catalog"
import {
  heroRepair,
  cameraIcon,
  speakerIcon,
  chargingIcon,
  cleaningIcon,
  iphone16,
  BRAND_LOGOS,
} from "../assets"

interface ServiceCardData {
  id: number
  key: string
  name: string
  category: string
  description: string
  imageType: "screen" | "battery" | "port" | "camera" | "speaker" | "clean" | "faceid" | "mic"
  imageUrl?: string
  badge1: { type: "check"; text: string }
  badge2: { type: "clock" | "shield"; text: string }
  fromPrice: number
}

const FEATURED_SERVICES: ServiceCardData[] = [
  {
    id: 1,
    key: "screen",
    name: "Thay màn hình",
    category: "screen",
    description: "Thay màn hình chính hãng, hiển thị sắc nét, cảm ứng mượt mà.",
    imageType: "screen",
    imageUrl: iphone16,
    badge1: { type: "check", text: "Chính hãng" },
    badge2: { type: "clock", text: "Bảo hành dài hạn" },
    fromPrice: 1500000,
  },
  {
    id: 2,
    key: "battery",
    name: "Thay pin",
    category: "battery",
    description: "Thay pin dung lượng chuẩn, ổn định và an toàn.",
    imageType: "battery",
    badge1: { type: "check", text: "Chính hãng" },
    badge2: { type: "clock", text: "Bảo hành 6 tháng" },
    fromPrice: 500000,
  },
  {
    id: 3,
    key: "port",
    name: "Sửa cổng sạc",
    category: "battery",
    description: "Khắc phục lỗi sạc, sạc không vào, lỏng cổng sạc.",
    imageType: "port",
    imageUrl: chargingIcon,
    badge1: { type: "check", text: "Kiểm tra miễn phí" },
    badge2: { type: "clock", text: "Bảo hành 3 tháng" },
    fromPrice: 400000,
  },
  {
    id: 4,
    key: "camera",
    name: "Sửa camera",
    category: "camera",
    description: "Sửa lỗi camera mờ, không lấy nét, không hoạt động.",
    imageType: "camera",
    imageUrl: cameraIcon,
    badge1: { type: "check", text: "Kiểm tra miễn phí" },
    badge2: { type: "clock", text: "Bảo hành 3 tháng" },
    fromPrice: 300000,
  },
  {
    id: 5,
    key: "speaker",
    name: "Sửa loa",
    category: "camera",
    description: "Sửa loa trong, loa ngoài bị rè, mất tiếng, âm thanh nhỏ.",
    imageType: "speaker",
    imageUrl: speakerIcon,
    badge1: { type: "check", text: "Kiểm tra miễn phí" },
    badge2: { type: "clock", text: "Bảo hành 3 tháng" },
    fromPrice: 250000,
  },
  {
    id: 6,
    key: "clean",
    name: "Vệ sinh máy",
    category: "maintenance",
    description: "Vệ sinh tổng thể, loại bỏ bụi bẩn, tăng hiệu suất hoạt động.",
    imageType: "clean",
    imageUrl: cleaningIcon,
    badge1: { type: "check", text: "Làm sạch chuyên sâu" },
    badge2: { type: "shield", text: "An toàn thiết bị" },
    fromPrice: 150000,
  },
  {
    id: 7,
    key: "faceid",
    name: "Sửa Face ID",
    category: "sensor",
    description: "Sửa lỗi Face ID, không nhận diện, nhận diện chậm.",
    imageType: "faceid",
    badge1: { type: "check", text: "Kiểm tra miễn phí" },
    badge2: { type: "clock", text: "Bảo hành 3 tháng" },
    fromPrice: 600000,
  },
  {
    id: 8,
    key: "mic",
    name: "Sửa micro",
    category: "camera",
    description: "Sửa lỗi micro, không thu âm, âm thanh nhỏ, bị rè.",
    imageType: "mic",
    badge1: { type: "check", text: "Kiểm tra miễn phí" },
    badge2: { type: "clock", text: "Bảo hành 3 tháng" },
    fromPrice: 250000,
  },
]

const CATEGORIES = [
  { id: "all", label: "Tất cả dịch vụ", iconType: "all" },
  { id: "screen", label: "Màn hình", iconType: "screen" },
  { id: "battery", label: "Pin - Sạc", iconType: "battery" },
  { id: "camera", label: "Camera - Âm thanh", iconType: "camera" },
  { id: "maintenance", label: "Vệ sinh - Bảo dưỡng", iconType: "clean" },
  { id: "sensor", label: "Face ID - Cảm biến", iconType: "sensor" },
  { id: "other", label: "Khác", iconType: "other" },
]

const BRAND_CHECKBOXES = [
  { id: "apple", label: "Apple (iPhone)", brandName: "Apple" },
  { id: "samsung", label: "Samsung (Galaxy)", brandName: "Samsung" },
  { id: "xiaomi", label: "Xiaomi", brandName: "Xiaomi" },
  { id: "oppo", label: "Oppo", brandName: "Oppo" },
  { id: "vivo", label: "Vivo", brandName: "Vivo" },
  { id: "realme", label: "Realme", brandName: "Realme" },
  { id: "google", label: "Google (Pixel)", brandName: "Google" },
  { id: "honor", label: "Honor", brandName: "Honor" },
]

/** Renders custom sharp SVG card media matching screenshot */
function ServiceCardGraphic({ type, imageUrl, title }: { type: ServiceCardData["imageType"]; imageUrl?: string; title: string }) {
  if (type === "battery") {
    return (
      <div
        style={{
          width: "100%",
          height: "100%",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          background: "radial-gradient(circle, #f0fdf4 0%, #f8fafc 70%)",
        }}
      >
        <svg width="68" height="85" viewBox="0 0 68 85" fill="none">
          {/* Top Battery Terminal */}
          <rect x="25" y="2" width="18" height="6" rx="3" fill="#94a3b8" />
          {/* Main Battery Body */}
          <rect x="12" y="8" width="44" height="72" rx="10" fill="url(#batteryGrad)" stroke="#16a34a" strokeWidth="2.5" />
          {/* Lightning Bolt */}
          <path
            d="M36 22L24 43H34L32 64L44 41H34L36 22Z"
            fill="#ffffff"
            filter="drop-shadow(0 2px 4px rgba(0,0,0,0.15))"
          />
          <defs>
            <linearGradient id="batteryGrad" x1="12" y1="8" x2="56" y2="80" gradientUnits="userSpaceOnUse">
              <stop stopColor="#22c55e" />
              <stop offset="1" stopColor="#15803d" />
            </linearGradient>
          </defs>
        </svg>
      </div>
    )
  }

  if (type === "faceid") {
    return (
      <div
        style={{
          width: "100%",
          height: "100%",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          background: "radial-gradient(circle, #f0f9ff 0%, #f8fafc 70%)",
        }}
      >
        <svg width="74" height="74" viewBox="0 0 74 74" fill="none">
          {/* Corner Viewfinder brackets */}
          <path d="M12 24V14C12 12.8954 12.8954 12 14 12H24" stroke="#0284c7" strokeWidth="3" strokeLinecap="round" />
          <path d="M62 24V14C62 12.8954 61.1046 12 60 12H50" stroke="#0284c7" strokeWidth="3" strokeLinecap="round" />
          <path d="M12 50V60C12 61.1046 12.8954 62 14 62H24" stroke="#0284c7" strokeWidth="3" strokeLinecap="round" />
          <path d="M62 50V60C62 61.1046 61.1046 62 60 62H50" stroke="#0284c7" strokeWidth="3" strokeLinecap="round" />
          {/* Eyes */}
          <circle cx="28" cy="32" r="3.5" fill="#0284c7" />
          <circle cx="46" cy="32" r="3.5" fill="#0284c7" />
          {/* Nose */}
          <path d="M37 32V42H34" stroke="#0284c7" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
          {/* Smile */}
          <path d="M28 48C30.5 53 43.5 53 46 48" stroke="#0284c7" strokeWidth="2.5" strokeLinecap="round" />
        </svg>
      </div>
    )
  }

  if (type === "mic") {
    return (
      <div
        style={{
          width: "100%",
          height: "100%",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          background: "radial-gradient(circle, #eff6ff 0%, #f8fafc 70%)",
        }}
      >
        <svg width="74" height="74" viewBox="0 0 74 74" fill="none">
          {/* Microphone Body */}
          <rect x="30" y="16" width="14" height="26" rx="7" fill="#1e293b" />
          {/* Sound Cradle */}
          <path d="M22 35C22 43.2843 28.7157 50 37 50C45.2843 50 52 43.2843 52 35" stroke="#1e293b" strokeWidth="3" strokeLinecap="round" />
          {/* Stand */}
          <path d="M37 50V60M27 60H47" stroke="#1e293b" strokeWidth="3" strokeLinecap="round" />
          {/* Sound wave bars left */}
          <line x1="15" y1="30" x2="15" y2="40" stroke="#0284c7" strokeWidth="2.5" strokeLinecap="round" />
          <line x1="9" y1="33" x2="9" y2="37" stroke="#0284c7" strokeWidth="2" strokeLinecap="round" />
          {/* Sound wave bars right */}
          <line x1="59" y1="30" x2="59" y2="40" stroke="#0284c7" strokeWidth="2.5" strokeLinecap="round" />
          <line x1="65" y1="33" x2="65" y2="37" stroke="#0284c7" strokeWidth="2" strokeLinecap="round" />
        </svg>
      </div>
    )
  }

  if (type === "screen") {
    return (
      <div
        style={{
          width: "100%",
          height: "100%",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          background: "#f8fafc",
        }}
      >
        {/* Smartphone with OLED colorful wallpaper */}
        <div
          style={{
            width: "56px",
            height: "98px",
            background: "#0f172a",
            borderRadius: "14px",
            padding: "3px",
            boxShadow: "0 8px 18px rgba(15,23,42,0.18)",
            border: "1.5px solid #cbd5e1",
            position: "relative",
          }}
        >
          {/* Notch / Dynamic Island */}
          <div
            style={{
              position: "absolute",
              top: "5px",
              left: "50%",
              transform: "translateX(-50%)",
              width: "16px",
              height: "4px",
              background: "#0f172a",
              borderRadius: "3px",
              zIndex: 2,
            }}
          />
          <div
            style={{
              width: "100%",
              height: "100%",
              borderRadius: "10px",
              background: "linear-gradient(135deg, #ec4899 0%, #8b5cf6 50%, #3b82f6 100%)",
            }}
          />
        </div>
      </div>
    )
  }

  return (
    <div
      style={{
        width: "100%",
        height: "100%",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        background: "#f8fafc",
        overflow: "hidden",
      }}
    >
      <img
        src={imageUrl}
        alt={title}
        style={{
          maxHeight: "90px",
          maxWidth: "115px",
          objectFit: "contain",
          borderRadius: "8px",
        }}
        loading="lazy"
      />
    </div>
  )
}

export function ServicesPage() {
  const [searchParams] = useSearchParams()
  const qParam = searchParams.get("q") || ""

  const [services, setServices] = useState<ServiceCardData[]>(FEATURED_SERVICES)
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [searchQuery, setSearchQuery] = useState(qParam)
  const [selectedBrands, setSelectedBrands] = useState<string[]>(["apple"])
  const [maxPrice, setMaxPrice] = useState(10000000)
  const [sortBy, setSortBy] = useState("popular")

  useEffect(() => {
    if (qParam) {
      setSearchQuery(qParam)
    }
  }, [qParam])

  useEffect(() => {
    getServices()
      .then((serverServices) => {
        if (serverServices && serverServices.length > 0) {
          const merged = FEATURED_SERVICES.map((feat) => {
            const found = serverServices.find((s) => s.name.toLowerCase() === feat.name.toLowerCase())
            return found ? { ...feat, id: found.id } : feat
          })
          setServices(merged)
        }
      })
      .catch(() => {})
  }, [])

  const toggleBrand = (brandId: string) => {
    setSelectedBrands((prev) =>
      prev.includes(brandId) ? prev.filter((b) => b !== brandId) : [...prev, brandId]
    )
  }

  const resetFilters = () => {
    setSelectedCategory("all")
    setSearchQuery("")
    setSelectedBrands(["apple"])
    setMaxPrice(10000000)
  }

  const filteredServices = services
    .filter((svc) => {
      if (selectedCategory !== "all" && svc.category !== selectedCategory) return false
      if (searchQuery.trim() && !svc.name.toLowerCase().includes(searchQuery.toLowerCase())) return false
      if (svc.fromPrice > maxPrice) return false
      return true
    })
    .sort((a, b) => {
      if (sortBy === "price-asc") return a.fromPrice - b.fromPrice
      if (sortBy === "price-desc") return b.fromPrice - a.fromPrice
      return 0
    })

  const formatVndNumber = (price: number) => {
    return price.toLocaleString("vi-VN") + "đ"
  }

  return (
    <main style={{ background: "#f8fafc", minHeight: "100vh", paddingBottom: "60px" }}>
      {/* 1. DARK WORKSHOP HERO BANNER (MATCHING SCREENSHOT) */}
      <section
        style={{
          background: `linear-gradient(135deg, rgba(8, 15, 30, 0.94) 0%, rgba(15, 23, 42, 0.92) 55%, rgba(30, 58, 138, 0.88) 100%), url('${heroRepair}') center/cover no-repeat`,
          color: "#ffffff",
          padding: "52px 24px 44px",
          position: "relative",
          overflow: "hidden",
          marginBottom: "36px",
          borderBottom: "1px solid rgba(255,255,255,0.08)",
        }}
      >
        <div
          style={{
            maxWidth: "1340px",
            margin: "0 auto",
            display: "grid",
            gridTemplateColumns: "1.25fr 0.75fr",
            gap: "40px",
            alignItems: "center",
          }}
        >
          {/* HERO LEFT TEXT & SEARCH */}
          <div>
            <h1 style={{ fontSize: "2.5rem", fontWeight: 800, margin: "0 0 10px", letterSpacing: "-0.03em", color: "#ffffff" }}>
              Dịch vụ sửa chữa nhà cửa
            </h1>
            <p style={{ fontSize: "1.05rem", color: "#cbd5e1", margin: "0 0 28px", lineHeight: 1.5 }}>
              Sửa chữa nhanh chóng, minh bạch, chính hãng – Lấy máy đúng hẹn
            </p>

            {/* SEARCH INPUT */}
            <div
              style={{
                background: "#ffffff",
                borderRadius: "999px",
                padding: "6px 8px 6px 22px",
                display: "flex",
                alignItems: "center",
                maxWidth: "600px",
                boxShadow: "0 12px 32px rgba(0, 0, 0, 0.35)",
                marginBottom: "32px",
              }}
            >
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#94a3b8" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" style={{ marginRight: "12px", flexShrink: 0 }}>
                <circle cx="11" cy="11" r="8" />
                <line x1="21" y1="21" x2="16.65" y2="16.65" />
              </svg>
              <input
                type="text"
                placeholder="Tìm kiếm dịch vụ (ví dụ: sửa chữa điện nước, vệ sinh điều hòa, sửa loa...)"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                style={{
                  flex: 1,
                  border: "none",
                  outline: "none",
                  fontSize: "0.94rem",
                  color: "#0f172a",
                  background: "transparent",
                }}
              />
              <button
                type="button"
                style={{
                  height: "42px",
                  padding: "0 28px",
                  borderRadius: "999px",
                  background: "#2563eb",
                  color: "#ffffff",
                  border: "none",
                  fontWeight: 700,
                  fontSize: "0.92rem",
                  cursor: "pointer",
                  boxShadow: "0 4px 14px rgba(37,99,235,0.4)",
                  transition: "background 0.15s ease",
                }}
              >
                Tìm kiếm
              </button>
            </div>

            {/* 4 QUALITY BADGES ROW (MATCHING SCREENSHOT) */}
            <div style={{ display: "flex", flexWrap: "wrap", gap: "24px", alignItems: "center" }}>
              {/* Badge 1: Linh kiện chính hãng */}
              <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
                <div style={{ width: "40px", height: "40px", borderRadius: "10px", background: "rgba(255,255,255,0.12)", backdropFilter: "blur(4px)", display: "flex", alignItems: "center", justifyContent: "center" }}>
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#60a5fa" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
                    <path d="M9 12l2 2 4-4" />
                  </svg>
                </div>
                <div>
                  <strong style={{ display: "block", fontSize: "0.86rem", color: "#ffffff", fontWeight: 700 }}>Linh kiện chính hãng</strong>
                  <span style={{ fontSize: "0.76rem", color: "#94a3b8" }}>Chất lượng đảm bảo</span>
                </div>
              </div>

              {/* Badge 2: Sửa nhanh lấy liền */}
              <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
                <div style={{ width: "40px", height: "40px", borderRadius: "10px", background: "rgba(255,255,255,0.12)", backdropFilter: "blur(4px)", display: "flex", alignItems: "center", justifyContent: "center" }}>
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#60a5fa" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                    <circle cx="12" cy="12" r="10" />
                    <polyline points="12 6 12 12 16 14" />
                  </svg>
                </div>
                <div>
                  <strong style={{ display: "block", fontSize: "0.86rem", color: "#ffffff", fontWeight: 700 }}>Sửa nhanh lấy liền</strong>
                  <span style={{ fontSize: "0.76rem", color: "#94a3b8" }}>Tiết kiệm thời gian</span>
                </div>
              </div>

              {/* Badge 3: Kỹ thuật viên chuyên nghiệp */}
              <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
                <div style={{ width: "40px", height: "40px", borderRadius: "10px", background: "rgba(255,255,255,0.12)", backdropFilter: "blur(4px)", display: "flex", alignItems: "center", justifyContent: "center" }}>
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#60a5fa" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
                    <circle cx="12" cy="7" r="4" />
                  </svg>
                </div>
                <div>
                  <strong style={{ display: "block", fontSize: "0.86rem", color: "#ffffff", fontWeight: 700 }}>Kỹ thuật viên chuyên nghiệp</strong>
                  <span style={{ fontSize: "0.76rem", color: "#94a3b8" }}>Nhiều năm kinh nghiệm</span>
                </div>
              </div>

              {/* Badge 4: Hệ thống chi nhánh */}
              <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
                <div style={{ width: "40px", height: "40px", borderRadius: "10px", background: "rgba(255,255,255,0.12)", backdropFilter: "blur(4px)", display: "flex", alignItems: "center", justifyContent: "center" }}>
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#60a5fa" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z" />
                    <circle cx="12" cy="10" r="3" />
                  </svg>
                </div>
                <div>
                  <strong style={{ display: "block", fontSize: "0.86rem", color: "#ffffff", fontWeight: 700 }}>Hệ thống chi nhánh</strong>
                  <span style={{ fontSize: "0.76rem", color: "#94a3b8" }}>Phủ khắp TP.HCM và các tỉnh</span>
                </div>
              </div>
            </div>
          </div>

          {/* HERO RIGHT: 4 SMARTPHONES CLUSTER + BLUE FLOATING PILL */}
          <div style={{ position: "relative", display: "flex", alignItems: "flex-end", justifyContent: "center", minHeight: "260px" }}>
            <div style={{ display: "flex", alignItems: "flex-end", gap: "10px" }}>
              {/* Phone 1 (left blue) */}
              <div
                style={{
                  width: "82px",
                  height: "170px",
                  background: "#1e293b",
                  borderRadius: "18px 18px 0 0",
                  border: "2px solid #38bdf8",
                  borderBottom: "none",
                  padding: "5px",
                  boxShadow: "0 14px 30px rgba(0,0,0,0.5)",
                }}
              >
                <div style={{ width: "20px", height: "3px", background: "#475569", borderRadius: "2px", margin: "0 auto 6px" }} />
                <div style={{ width: "100%", height: "calc(100% - 9px)", background: "linear-gradient(180deg, #0284c7 0%, #0369a1 100%)", borderRadius: "12px" }} />
              </div>

              {/* Phone 2 (dark back with camera module) */}
              <div
                style={{
                  width: "92px",
                  height: "195px",
                  background: "#0f172a",
                  borderRadius: "20px 20px 0 0",
                  border: "2.5px solid #475569",
                  borderBottom: "none",
                  padding: "6px",
                  boxShadow: "0 18px 38px rgba(0,0,0,0.6)",
                }}
              >
                {/* Dual camera cluster */}
                <div style={{ width: "32px", height: "32px", borderRadius: "8px", background: "#1e293b", border: "1px solid #334155", padding: "4px", display: "flex", flexDirection: "column", gap: "4px" }}>
                  <div style={{ width: "10px", height: "10px", borderRadius: "50%", background: "#0284c7", border: "1.5px solid #0f172a" }} />
                  <div style={{ width: "10px", height: "10px", borderRadius: "50%", background: "#0284c7", border: "1.5px solid #0f172a" }} />
                </div>
              </div>

              {/* Phone 3 (tall center titanium with screen) */}
              <div
                style={{
                  width: "115px",
                  height: "230px",
                  background: "#0f172a",
                  borderRadius: "22px 22px 0 0",
                  border: "3px solid #94a3b8",
                  borderBottom: "none",
                  padding: "7px",
                  boxShadow: "0 24px 50px rgba(0,0,0,0.7)",
                }}
              >
                <div style={{ width: "28px", height: "4px", background: "#64748b", borderRadius: "2px", margin: "0 auto 8px" }} />
                <div
                  style={{
                    width: "100%",
                    height: "calc(100% - 12px)",
                    background: "linear-gradient(180deg, #1e3a8a 0%, #0f172a 100%)",
                    borderRadius: "14px",
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <span style={{ fontSize: "1.5rem", fontWeight: 800, color: "#ffffff", letterSpacing: "-0.02em" }}>9:41</span>
                  <span style={{ fontSize: "0.74rem", color: "#93c5fd", fontWeight: 600 }}>HomeRepair</span>
                </div>
              </div>

              {/* Phone 4 (right cyan) */}
              <div
                style={{
                  width: "88px",
                  height: "185px",
                  background: "#1e293b",
                  borderRadius: "18px 18px 0 0",
                  border: "2px solid #60a5fa",
                  borderBottom: "none",
                  padding: "5px",
                  boxShadow: "0 16px 36px rgba(0,0,0,0.5)",
                }}
              >
                <div style={{ width: "22px", height: "3px", background: "#475569", borderRadius: "2px", margin: "0 auto 6px" }} />
                <div style={{ width: "100%", height: "calc(100% - 9px)", background: "linear-gradient(180deg, #2563eb 0%, #1e3a8a 100%)", borderRadius: "12px" }} />
              </div>
            </div>

            {/* FLOATING BLUE PILL WITH WRENCH (MATCHING SCREENSHOT) */}
            <div
              style={{
                position: "absolute",
                bottom: "16px",
                right: "-6px",
                background: "#2563eb",
                boxShadow: "0 16px 36px rgba(37,99,235,0.45), 0 4px 12px rgba(0,0,0,0.3)",
                padding: "10px 18px",
                borderRadius: "14px",
                display: "flex",
                alignItems: "center",
                gap: "12px",
                color: "#ffffff",
                fontSize: "0.86rem",
                fontWeight: 700,
                border: "1px solid rgba(255,255,255,0.2)",
              }}
            >
              <span>Sửa chữa chuyên nghiệp cho mọi dòng máy</span>
              <div
                style={{
                  width: "28px",
                  height: "28px",
                  borderRadius: "8px",
                  background: "rgba(255,255,255,0.2)",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z" />
                </svg>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 2. CATALOG CONTENT: SIDEBAR + 8 CARDS GRID */}
      <div
        style={{
          maxWidth: "1340px",
          margin: "0 auto",
          display: "grid",
          gridTemplateColumns: "270px 1fr",
          gap: "28px",
          padding: "0 20px",
        }}
      >
        {/* LEFT SIDEBAR: BỘ LỌC DỊCH VỤ */}
        <aside
          style={{
            background: "#ffffff",
            border: "1px solid #e2e8f0",
            borderRadius: "16px",
            padding: "22px 20px",
            height: "fit-content",
            boxShadow: "0 2px 10px rgba(15,23,42,0.03)",
          }}
        >
          {/* HEADER */}
          <div
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              marginBottom: "18px",
              paddingBottom: "14px",
              borderBottom: "1px solid #f1f5f9",
            }}
          >
            <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#2563eb" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
                <line x1="4" y1="6" x2="20" y2="6" />
                <line x1="8" y1="12" x2="20" y2="12" />
                <line x1="12" y1="18" x2="20" y2="18" />
              </svg>
              <strong style={{ fontSize: "1rem", color: "#0f172a", fontWeight: 700 }}>Bộ lọc dịch vụ</strong>
            </div>
            <button
              type="button"
              onClick={resetFilters}
              style={{ background: "none", border: "none", color: "#2563eb", fontSize: "0.82rem", fontWeight: 600, cursor: "pointer", padding: 0 }}
            >
              Xóa tất cả
            </button>
          </div>

          {/* DANH MỤC DỊCH VỤ */}
          <div style={{ marginBottom: "24px" }}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "12px", fontSize: "0.88rem", fontWeight: 700, color: "#0f172a" }}>
              <span>Danh mục dịch vụ</span>
              <span style={{ color: "#94a3b8", fontSize: "0.8rem" }}>⌃</span>
            </div>

            <div style={{ display: "flex", flexDirection: "column", gap: "3px" }}>
              {CATEGORIES.map((cat) => {
                const isActive = selectedCategory === cat.id
                return (
                  <div
                    key={cat.id}
                    onClick={() => setSelectedCategory(cat.id)}
                    style={{
                      display: "flex",
                      alignItems: "center",
                      gap: "10px",
                      padding: "8px 12px",
                      borderRadius: "10px",
                      fontSize: "0.86rem",
                      cursor: "pointer",
                      transition: "all 0.15s ease",
                      background: isActive ? "#eff6ff" : "transparent",
                      color: isActive ? "#2563eb" : "#334155",
                      fontWeight: isActive ? 700 : 500,
                    }}
                  >
                    {/* Active check icon / category icon */}
                    {isActive ? (
                      <div
                        style={{
                          width: "18px",
                          height: "18px",
                          borderRadius: "50%",
                          background: "#2563eb",
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                          color: "#ffffff",
                          fontSize: "0.7rem",
                          flexShrink: 0,
                        }}
                      >
                        ✓
                      </div>
                    ) : (
                      <div
                        style={{
                          width: "18px",
                          height: "18px",
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                          color: "#64748b",
                          fontSize: "0.88rem",
                          flexShrink: 0,
                        }}
                      >
                        {cat.iconType === "screen" && "📱"}
                        {cat.iconType === "battery" && "🔋"}
                        {cat.iconType === "camera" && "📷"}
                        {cat.iconType === "clean" && "🛠️"}
                        {cat.iconType === "sensor" && "⊡"}
                        {cat.iconType === "other" && "⚙️"}
                        {cat.iconType === "all" && "✓"}
                      </div>
                    )}
                    <span>{cat.label}</span>
                  </div>
                )
              })}
            </div>
          </div>

          <div style={{ borderTop: "1px solid #f1f5f9", margin: "18px 0" }} />

          {/* HÃNG ĐIỆN THOẠI */}
          <div style={{ marginBottom: "24px" }}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "12px", fontSize: "0.88rem", fontWeight: 700, color: "#0f172a" }}>
              <span>Hãng điện thoại</span>
              <span style={{ color: "#94a3b8", fontSize: "0.8rem" }}>⌃</span>
            </div>

            <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
              {BRAND_CHECKBOXES.map((b) => {
                const isWordmark = ["samsung", "oppo", "vivo", "honor", "realme"].includes(b.id)
                return (
                  <label key={b.id} style={{ display: "flex", alignItems: "center", gap: "10px", fontSize: "0.85rem", color: "#334155", cursor: "pointer" }}>
                    <input
                      type="checkbox"
                      checked={selectedBrands.includes(b.id)}
                      onChange={() => toggleBrand(b.id)}
                      style={{ width: "16px", height: "16px", accentColor: "#2563eb", cursor: "pointer" }}
                    />
                    {BRAND_LOGOS[b.brandName] && (
                      <img
                        src={BRAND_LOGOS[b.brandName]}
                        alt={b.brandName}
                        style={
                          isWordmark
                            ? { height: "15px", maxWidth: "68px", objectFit: "contain", display: "block" }
                            : { width: "16px", height: "16px", objectFit: "contain" }
                        }
                      />
                    )}
                    {!isWordmark && <span>{b.label}</span>}
                  </label>
                )
              })}
            </div>
          </div>

          <div style={{ borderTop: "1px solid #f1f5f9", margin: "18px 0" }} />

          {/* KHOẢNG GIÁ */}
          <div>
            <div style={{ fontSize: "0.88rem", fontWeight: 700, color: "#0f172a", marginBottom: "12px" }}>
              Khoảng giá
            </div>
            <input
              type="range"
              min="150000"
              max="10000000"
              step="100000"
              value={maxPrice}
              onChange={(e) => setMaxPrice(Number(e.target.value))}
              style={{ width: "100%", accentColor: "#2563eb", cursor: "pointer" }}
            />
            <div style={{ display: "flex", justifyContent: "space-between", fontSize: "0.78rem", color: "#64748b", marginTop: "6px" }}>
              <span>0đ</span>
              <span>10.000.000đ+</span>
            </div>
          </div>
        </aside>

        {/* RIGHT CONTENT: GRID OF 8 CARDS */}
        <div>
          {/* HEADER ROW */}
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "20px" }}>
            <strong style={{ fontSize: "1.15rem", color: "#0f172a", fontWeight: 800 }}>
              Tổng {filteredServices.length} dịch vụ
            </strong>

            <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
              <span style={{ fontSize: "0.88rem", color: "#64748b" }}>Sắp xếp theo:</span>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                style={{
                  padding: "7px 14px",
                  borderRadius: "10px",
                  border: "1px solid #cbd5e1",
                  background: "#ffffff",
                  fontSize: "0.88rem",
                  color: "#1e293b",
                  fontWeight: 600,
                  cursor: "pointer",
                  outline: "none",
                }}
              >
                <option value="popular">Phổ biến nhất</option>
                <option value="price-asc">Giá tăng dần</option>
                <option value="price-desc">Giá giảm dần</option>
              </select>
            </div>
          </div>

          {/* 8 CARDS (4 COLUMNS X 2 ROWS MATCHING SCREENSHOT) */}
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(4, 1fr)",
              gap: "18px",
            }}
          >
            {filteredServices.map((svc) => (
              <article
                key={svc.id}
                style={{
                  background: "#ffffff",
                  border: "1px solid #e2e8f0",
                  borderRadius: "16px",
                  padding: "16px",
                  display: "flex",
                  flexDirection: "column",
                  position: "relative",
                  boxShadow: "0 2px 8px rgba(15,23,42,0.03)",
                  transition: "all 0.2s ease",
                }}
              >
                {/* TOP RIGHT CHEVRON CIRCLE */}
                <Link
                  to={`/pricing?service=${svc.key}`}
                  style={{
                    position: "absolute",
                    top: "14px",
                    right: "14px",
                    width: "24px",
                    height: "24px",
                    borderRadius: "50%",
                    background: "#f8fafc",
                    border: "1px solid #e2e8f0",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    color: "#64748b",
                    fontSize: "0.8rem",
                    textDecoration: "none",
                    zIndex: 2,
                  }}
                  title="Xem chi tiết"
                >
                  ›
                </Link>

                {/* IMAGE BOX */}
                <div
                  style={{
                    width: "100%",
                    height: "120px",
                    background: "#f8fafc",
                    borderRadius: "12px",
                    marginBottom: "14px",
                    overflow: "hidden",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <ServiceCardGraphic type={svc.imageType} imageUrl={svc.imageUrl} title={svc.name} />
                </div>

                {/* TITLE & DESCRIPTION */}
                <h3 style={{ fontSize: "1rem", fontWeight: 800, color: "#0f172a", margin: "0 0 6px", letterSpacing: "-0.01em" }}>
                  {svc.name}
                </h3>
                <p
                  style={{
                    fontSize: "0.8rem",
                    color: "#64748b",
                    lineHeight: 1.45,
                    margin: "0 0 12px",
                    minHeight: "36px",
                    display: "-webkit-box",
                    WebkitLineClamp: 2,
                    WebkitBoxOrient: "vertical",
                    overflow: "hidden",
                  }}
                >
                  {svc.description}
                </p>

                {/* BADGES ROW */}
                <div style={{ display: "flex", flexWrap: "wrap", gap: "6px", marginBottom: "16px" }}>
                  {/* Badge 1: Checkmark badge */}
                  <span
                    style={{
                      fontSize: "0.72rem",
                      fontWeight: 600,
                      color: "#0284c7",
                      background: "#f0f9ff",
                      border: "1px solid #bae6fd",
                      padding: "3px 8px",
                      borderRadius: "6px",
                      display: "inline-flex",
                      alignItems: "center",
                      gap: "4px",
                    }}
                  >
                    <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="#0284c7" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                      <polyline points="20 6 9 17 4 12" />
                    </svg>
                    <span>{svc.badge1.text}</span>
                  </span>

                  {/* Badge 2: Clock or Shield badge */}
                  <span
                    style={{
                      fontSize: "0.72rem",
                      fontWeight: 600,
                      color: "#0284c7",
                      background: "#f0f9ff",
                      border: "1px solid #bae6fd",
                      padding: "3px 8px",
                      borderRadius: "6px",
                      display: "inline-flex",
                      alignItems: "center",
                      gap: "4px",
                    }}
                  >
                    {svc.badge2.type === "clock" ? (
                      <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="#0284c7" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                        <circle cx="12" cy="12" r="10" />
                        <polyline points="12 6 12 12 16 14" />
                      </svg>
                    ) : (
                      <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="#0284c7" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
                      </svg>
                    )}
                    <span>{svc.badge2.text}</span>
                  </span>
                </div>

                {/* PRICE ROW & BUTTONS */}
                <div style={{ marginTop: "auto", paddingTop: "12px", borderTop: "1px solid #f1f5f9" }}>
                  <div style={{ marginBottom: "12px", display: "flex", alignItems: "baseline", gap: "6px" }}>
                    <span style={{ fontSize: "0.82rem", color: "#64748b" }}>
                      Giá từ
                    </span>
                    <strong style={{ fontSize: "1.12rem", fontWeight: 800, color: "#0f172a", letterSpacing: "-0.01em" }}>
                      {formatVndNumber(svc.fromPrice)}
                    </strong>
                  </div>

                  <div style={{ display: "flex", gap: "8px" }}>
                    <Link
                      to={`/pricing?service=${svc.key}`}
                      style={{
                        flex: 1,
                        height: "36px",
                        border: "1px solid #cbd5e1",
                        background: "#ffffff",
                        color: "#2563eb",
                        fontSize: "0.8rem",
                        fontWeight: 600,
                        borderRadius: "8px",
                        display: "inline-flex",
                        alignItems: "center",
                        justifyContent: "center",
                        textDecoration: "none",
                        transition: "all 0.15s ease",
                      }}
                    >
                      Xem chi tiết
                    </Link>

                    <Link
                      to={`/booking?serviceId=${svc.id}`}
                      style={{
                        flex: 1,
                        height: "36px",
                        background: "#2563eb",
                        color: "#ffffff",
                        fontSize: "0.8rem",
                        fontWeight: 700,
                        borderRadius: "8px",
                        display: "inline-flex",
                        alignItems: "center",
                        justifyContent: "center",
                        textDecoration: "none",
                        boxShadow: "0 2px 8px rgba(37,99,235,0.25)",
                        transition: "all 0.15s ease",
                      }}
                    >
                      Đặt lịch
                    </Link>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </div>
    </main>
  )
}
