namespace HomeRepairBooking.Api.DTOs;

public record StatCardsDto(
    int BookingsToday,
    int PendingBookings,
    int ConfirmedBookings,
    int RepairingBookings,
    int CompletedToday,
    int TotalCustomers,
    int TotalTechnicians,
    decimal TotalRepairValue,
    int CompletedBookingsAllTime);

public record ChartDateItem(string Date, int Count, decimal Revenue);

public record ChartStatusItem(string Status, string StatusLabel, int Count);

public record ChartServiceItem(string ServiceName, int Count, decimal Revenue);

public record ChartBrandItem(string BrandName, int Count, decimal Revenue);

public record ChartModelItem(string ModelName, string BrandName, int Count);

public record ChartBranchItem(string BranchName, int Count, decimal Revenue);

public record ChartMonthItem(string Month, decimal Revenue, int Count);

public record AdminDashboardDto(
    StatCardsDto Stats,
    List<ChartDateItem> BookingsByDate,
    List<ChartStatusItem> BookingsByStatus,
    List<ChartServiceItem> PopularServices,
    List<ChartBrandItem> RepairedBrands,
    List<ChartModelItem> RepairedModels,
    List<ChartBranchItem> BookingsByBranch,
    List<ChartMonthItem> RevenueByMonth);

public class ReportFilterRequest
{
    public string? FromDate { get; set; }

    public string? ToDate { get; set; }

    public int? BranchId { get; set; }

    public int? TechnicianId { get; set; }

    public int? RepairServiceId { get; set; }

    public int? BrandId { get; set; }

    public int? PhoneModelId { get; set; }

    public string? Status { get; set; }
}

public record ReportSummaryDto(
    int TotalBookings,
    int CompletedBookings,
    int CancelledBookings,
    decimal TotalRevenue,
    decimal AverageBookingValue);

public record TechnicianPerformanceItem(
    int TechnicianId,
    string TechnicianName,
    string BranchName,
    int TotalAssigned,
    int CompletedJobs,
    decimal TotalRevenue,
    double AverageRating,
    int TotalReviews);

public record BranchPerformanceItem(
    int BranchId,
    string BranchName,
    int TotalBookings,
    int CompletedBookings,
    decimal Revenue);

public record ServicePerformanceItem(
    int ServiceId,
    string ServiceName,
    int Count,
    decimal TotalRevenue);

public record BrandPerformanceItem(
    string BrandName,
    int Count,
    decimal Revenue);

public record ReportResultDto(
    ReportSummaryDto Summary,
    List<TechnicianPerformanceItem> TechnicianPerformance,
    List<BranchPerformanceItem> BranchPerformance,
    List<ServicePerformanceItem> ServicePerformance,
    List<BrandPerformanceItem> BrandPerformance);
