using HomeRepairBooking.Api.Domain;

namespace HomeRepairBooking.Api.DTOs;

public record BrandDto(int Id, string Name, string Slug, string? Description, bool IsActive, int ModelCount);

public record PhoneModelDto(
    int Id,
    int BrandId,
    string BrandName,
    string Name,
    string Slug,
    string? ImageUrl,
    string? Description,
    int? ReleaseYear,
    bool IsActive);

public record RepairServiceDto(
    int Id,
    string Name,
    string Slug,
    string? Description,
    PricingType PricingType,
    bool IsActive);

public record ServicePriceDto(
    int Id,
    int PhoneModelId,
    string PhoneModelName,
    string BrandName,
    int RepairServiceId,
    string RepairServiceName,
    PricingType PricingType,
    decimal? Price,
    bool IsActive);

public record CatalogSearchItemDto(
    int PhoneModelId,
    string BrandName,
    string PhoneModelName,
    int RepairServiceId,
    string RepairServiceName,
    PricingType PricingType,
    decimal? Price);

public class BrandRequest
{
    public string Name { get; set; } = string.Empty;

    public string? Description { get; set; }

    public bool IsActive { get; set; } = true;
}

public class PhoneModelRequest
{
    public int BrandId { get; set; }

    public string Name { get; set; } = string.Empty;

    public string? ImageUrl { get; set; }

    public string? Description { get; set; }

    public int? ReleaseYear { get; set; }

    public bool IsActive { get; set; } = true;
}

public class RepairServiceRequest
{
    public string Name { get; set; } = string.Empty;

    public string? Description { get; set; }

    public PricingType PricingType { get; set; }

    public bool IsActive { get; set; } = true;
}

public class ServicePriceRequest
{
    public int PhoneModelId { get; set; }

    public int RepairServiceId { get; set; }

    public decimal? Price { get; set; }

    public bool IsActive { get; set; } = true;
}
