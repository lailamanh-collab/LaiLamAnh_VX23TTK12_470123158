using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using HomeRepairBooking.Api.Data;
using HomeRepairBooking.Api.Domain;
using HomeRepairBooking.Api.DTOs;

namespace HomeRepairBooking.Api.Services;

public class BranchService
{
    private readonly AppDbContext _db;
    private readonly UserManager<ApplicationUser> _users;

    public BranchService(AppDbContext db, UserManager<ApplicationUser> users)
    {
        _db = db;
        _users = users;
    }

    public async Task<List<BranchDto>> GetBranchesAsync(bool includeInactive)
    {
        var query = _db.Branches.AsNoTracking().Include(item => item.OpeningHours).AsQueryable();
        if (!includeInactive)
        {
            query = query.Where(item => item.IsActive);
        }

        var branches = await query.OrderBy(item => item.Name).ToListAsync();
        return branches.Select(ToBranch).ToList();
    }

    public async Task<(BranchDto? Data, ApiError? Error, int Status)> SaveBranchAsync(int? id, BranchRequest request)
    {
        if (string.IsNullOrWhiteSpace(request.Name) || string.IsNullOrWhiteSpace(request.Address) || string.IsNullOrWhiteSpace(request.Phone))
        {
            return (null, new ApiError { Message = "Nhập tên, địa chỉ và số điện thoại." }, StatusCodes.Status400BadRequest);
        }

        if (request.CapacityPerSlot < 1 || request.SlotMinutes is < 15 or > 120)
        {
            return (null, new ApiError { Message = "Sức chứa hoặc thời lượng slot không hợp lệ." }, StatusCodes.Status400BadRequest);
        }

        var hoursError = ValidateHours(request.OpeningHours);
        if (hoursError is not null)
        {
            return (null, new ApiError { Message = hoursError }, StatusCodes.Status400BadRequest);
        }

        Branch branch;
        if (id is null)
        {
            branch = new Branch { CreatedAt = DateTime.UtcNow };
            _db.Branches.Add(branch);
        }
        else
        {
            var existing = await _db.Branches.Include(item => item.OpeningHours).FirstOrDefaultAsync(item => item.Id == id);
            if (existing is null)
            {
                return (null, new ApiError { Message = "Không tìm thấy chi nhánh." }, StatusCodes.Status404NotFound);
            }

            branch = existing;
            _db.BranchOpeningHours.RemoveRange(branch.OpeningHours);
        }

        branch.Name = request.Name.Trim();
        branch.Address = request.Address.Trim();
        branch.Phone = request.Phone.Trim();
        branch.CapacityPerSlot = request.CapacityPerSlot;
        branch.SlotMinutes = request.SlotMinutes;
        branch.IsActive = request.IsActive;
        branch.OpeningHours = request.OpeningHours.Select(item => new BranchOpeningHour
        {
            DayOfWeek = item.DayOfWeek,
            IsOpen = item.IsOpen,
            OpenTime = TimeOnly.Parse(item.OpenTime),
            CloseTime = TimeOnly.Parse(item.CloseTime)
        }).ToList();

        await _db.SaveChangesAsync();
        return (ToBranch(branch), null, id is null ? StatusCodes.Status201Created : StatusCodes.Status200OK);
    }

    public async Task<List<TechnicianDto>> GetTechniciansAsync(bool includeInactive)
    {
        var query = _db.Technicians.AsNoTracking()
            .Include(item => item.User)
            .Include(item => item.Branch)
            .Include(item => item.Schedules)
            .AsQueryable();
        if (!includeInactive)
        {
            query = query.Where(item => item.IsActive);
        }

        var rows = await query.OrderBy(item => item.User.FullName).ToListAsync();
        return rows.Select(ToTechnician).ToList();
    }

    public async Task<(TechnicianDto? Data, ApiError? Error, int Status)> CreateTechnicianAsync(CreateTechnicianRequest request)
    {
        var branch = await _db.Branches.FirstOrDefaultAsync(item => item.Id == request.BranchId && item.IsActive);
        if (branch is null)
        {
            return (null, new ApiError { Message = "Chi nhánh không hợp lệ." }, StatusCodes.Status400BadRequest);
        }

        var email = request.Email.Trim().ToLowerInvariant();
        if (await _users.FindByEmailAsync(email) is not null)
        {
            return (null, new ApiError { Message = "Email đã được dùng." }, StatusCodes.Status409Conflict);
        }

        var user = new ApplicationUser
        {
            UserName = email,
            Email = email,
            FullName = request.FullName.Trim(),
            PhoneNumber = request.PhoneNumber.Trim(),
            IsActive = true,
            CreatedAt = DateTime.UtcNow
        };
        var created = await _users.CreateAsync(user, request.Password);
        if (!created.Succeeded)
        {
            return (null, new ApiError { Message = "Không tạo được tài khoản kỹ thuật viên." }, StatusCodes.Status400BadRequest);
        }

        await _users.AddToRoleAsync(user, AppRoles.Technician);
        var technician = new Technician
        {
            UserId = user.Id,
            User = user,
            BranchId = branch.Id,
            Branch = branch,
            IsActive = request.IsActive,
            CreatedAt = DateTime.UtcNow,
            Schedules = DefaultSchedule()
        };
        _db.Technicians.Add(technician);
        await _db.SaveChangesAsync();
        return (ToTechnician(technician), null, StatusCodes.Status201Created);
    }

    public async Task<(TechnicianDto? Data, ApiError? Error, int Status)> UpdateTechnicianAsync(int id, UpdateTechnicianRequest request)
    {
        var technician = await _db.Technicians.Include(item => item.User).Include(item => item.Branch).Include(item => item.Schedules)
            .FirstOrDefaultAsync(item => item.Id == id);
        if (technician is null)
        {
            return (null, new ApiError { Message = "Không tìm thấy kỹ thuật viên." }, StatusCodes.Status404NotFound);
        }

        var branch = await _db.Branches.FirstOrDefaultAsync(item => item.Id == request.BranchId);
        if (branch is null)
        {
            return (null, new ApiError { Message = "Chi nhánh không hợp lệ." }, StatusCodes.Status400BadRequest);
        }

        technician.User.FullName = request.FullName.Trim();
        technician.User.PhoneNumber = request.PhoneNumber.Trim();
        technician.BranchId = branch.Id;
        technician.Branch = branch;
        technician.IsActive = request.IsActive;
        await _users.UpdateAsync(technician.User);
        await _db.SaveChangesAsync();
        return (ToTechnician(technician), null, StatusCodes.Status200OK);
    }

    public async Task<(TechnicianDto? Data, ApiError? Error, int Status)> SaveScheduleAsync(int id, ScheduleRequest request)
    {
        var technician = await _db.Technicians.Include(item => item.User).Include(item => item.Branch).Include(item => item.Schedules)
            .FirstOrDefaultAsync(item => item.Id == id);
        if (technician is null)
        {
            return (null, new ApiError { Message = "Không tìm thấy kỹ thuật viên." }, StatusCodes.Status404NotFound);
        }

        foreach (var item in request.Schedules.Where(item => item.IsWorking))
        {
            if (!TimeOnly.TryParse(item.StartTime, out var start) || !TimeOnly.TryParse(item.EndTime, out var end) || end <= start)
            {
                return (null, new ApiError { Message = "Giờ làm việc không hợp lệ." }, StatusCodes.Status400BadRequest);
            }
        }

        _db.TechnicianSchedules.RemoveRange(technician.Schedules);
        technician.Schedules = request.Schedules.Select(item => new TechnicianSchedule
        {
            DayOfWeek = item.DayOfWeek,
            IsWorking = item.IsWorking,
            StartTime = TimeOnly.Parse(string.IsNullOrWhiteSpace(item.StartTime) ? "08:00" : item.StartTime),
            EndTime = TimeOnly.Parse(string.IsNullOrWhiteSpace(item.EndTime) ? "17:00" : item.EndTime)
        }).ToList();
        await _db.SaveChangesAsync();
        return (ToTechnician(technician), null, StatusCodes.Status200OK);
    }

    public async Task<TechnicianDto?> GetOwnProfileAsync(string userId)
    {
        var technician = await _db.Technicians.AsNoTracking()
            .Include(item => item.User)
            .Include(item => item.Branch)
            .Include(item => item.Schedules)
            .FirstOrDefaultAsync(item => item.UserId == userId);
        return technician is null ? null : ToTechnician(technician);
    }

    public static List<OpeningHourDto> DefaultHours()
    {
        return Enum.GetValues<DayOfWeek>().Select(day =>
        {
            var open = day is not DayOfWeek.Sunday;
            return new OpeningHourDto(day, open, "08:00", "17:30");
        }).ToList();
    }

    private static List<TechnicianSchedule> DefaultSchedule()
    {
        return Enum.GetValues<DayOfWeek>().Select(day => new TechnicianSchedule
        {
            DayOfWeek = day,
            IsWorking = day is not DayOfWeek.Sunday,
            StartTime = new TimeOnly(8, 0),
            EndTime = new TimeOnly(17, 0)
        }).ToList();
    }

    private static string? ValidateHours(List<OpeningHourDto> hours)
    {
        if (hours.Count == 0)
        {
            return "Chưa có giờ mở cửa.";
        }

        foreach (var hour in hours.Where(item => item.IsOpen))
        {
            if (!TimeOnly.TryParse(hour.OpenTime, out var open) || !TimeOnly.TryParse(hour.CloseTime, out var close) || close <= open)
            {
                return "Giờ đóng cửa phải sau giờ mở cửa.";
            }
        }

        return null;
    }

    private static BranchDto ToBranch(Branch branch) => new(
        branch.Id,
        branch.Name,
        branch.Address,
        branch.Phone,
        branch.CapacityPerSlot,
        branch.SlotMinutes,
        branch.IsActive,
        branch.OpeningHours.OrderBy(item => item.DayOfWeek).Select(item =>
            new OpeningHourDto(item.DayOfWeek, item.IsOpen, item.OpenTime.ToString("HH:mm"), item.CloseTime.ToString("HH:mm"))).ToList());

    private static TechnicianDto ToTechnician(Technician technician) => new(
        technician.Id,
        technician.User.FullName,
        technician.User.Email ?? string.Empty,
        technician.User.PhoneNumber,
        technician.BranchId,
        technician.Branch.Name,
        technician.IsActive,
        technician.Schedules.OrderBy(item => item.DayOfWeek).Select(item =>
            new ScheduleDto(item.DayOfWeek, item.IsWorking, item.StartTime.ToString("HH:mm"), item.EndTime.ToString("HH:mm"))).ToList());
}
