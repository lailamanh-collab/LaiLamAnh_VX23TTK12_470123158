using Microsoft.EntityFrameworkCore;
using HomeRepairBooking.Api.Data;
using HomeRepairBooking.Api.Domain;
using HomeRepairBooking.Api.DTOs;

namespace HomeRepairBooking.Api.Services;

public class CatalogService
{
    private readonly AppDbContext _db;

    public CatalogService(AppDbContext db)
    {
        _db = db;
    }

    public async Task<List<BrandDto>> GetBrandsAsync(bool includeInactive, string? search)
    {
        var query = _db.Brands.AsNoTracking().AsQueryable();
        if (!includeInactive)
        {
            query = query.Where(item => item.IsActive);
        }

        if (!string.IsNullOrWhiteSpace(search))
        {
            var term = search.Trim();
            query = query.Where(item => item.Name.Contains(term));
        }

        return await query
            .OrderBy(item => item.Name)
            .Select(item => new BrandDto(
                item.Id,
                item.Name,
                item.Slug,
                item.Description,
                item.IsActive,
                item.Models.Count(model => includeInactive || model.IsActive)))
            .ToListAsync();
    }

    public async Task<List<PhoneModelDto>> GetModelsAsync(bool includeInactive, int? brandId, string? search)
    {
        var query = _db.PhoneModels.AsNoTracking().Include(item => item.Brand).AsQueryable();
        if (!includeInactive)
        {
            query = query.Where(item => item.IsActive && item.Brand.IsActive);
        }

        if (brandId is not null)
        {
            query = query.Where(item => item.BrandId == brandId);
        }

        if (!string.IsNullOrWhiteSpace(search))
        {
            var term = search.Trim();
            query = query.Where(item => item.Name.Contains(term) || item.Brand.Name.Contains(term));
        }

        return await query.OrderBy(item => item.Brand.Name).ThenBy(item => item.Name)
            .Select(item => ToModel(item))
            .ToListAsync();
    }

    public async Task<List<RepairServiceDto>> GetServicesAsync(bool includeInactive, string? search, PricingType? pricingType)
    {
        var query = _db.RepairServices.AsNoTracking().AsQueryable();
        if (!includeInactive)
        {
            query = query.Where(item => item.IsActive);
        }

        if (pricingType is not null)
        {
            query = query.Where(item => item.PricingType == pricingType);
        }

        if (!string.IsNullOrWhiteSpace(search))
        {
            var term = search.Trim();
            query = query.Where(item => item.Name.Contains(term));
        }

        return await query.OrderBy(item => item.Name).Select(item => ToService(item)).ToListAsync();
    }

    public async Task<List<ServicePriceDto>> GetPricesAsync(bool includeInactive, int? modelId, int? serviceId)
    {
        var query = _db.ServicePrices.AsNoTracking()
            .Include(item => item.PhoneModel).ThenInclude(item => item.Brand)
            .Include(item => item.RepairService)
            .AsQueryable();

        if (!includeInactive)
        {
            query = query.Where(item =>
                item.IsActive &&
                item.PhoneModel.IsActive &&
                item.PhoneModel.Brand.IsActive &&
                item.RepairService.IsActive);
        }

        if (modelId is not null)
        {
            query = query.Where(item => item.PhoneModelId == modelId);
        }

        if (serviceId is not null)
        {
            query = query.Where(item => item.RepairServiceId == serviceId);
        }

        return await query
            .OrderBy(item => item.PhoneModel.Brand.Name)
            .ThenBy(item => item.PhoneModel.Name)
            .ThenBy(item => item.RepairService.Name)
            .Select(item => ToPrice(item))
            .ToListAsync();
    }

    public async Task<List<CatalogSearchItemDto>> SearchAsync(string? queryText, int? brandId, PricingType? pricingType)
    {
        var query = _db.ServicePrices.AsNoTracking()
            .Include(item => item.PhoneModel).ThenInclude(item => item.Brand)
            .Include(item => item.RepairService)
            .Where(item =>
                item.IsActive &&
                item.PhoneModel.IsActive &&
                item.PhoneModel.Brand.IsActive &&
                item.RepairService.IsActive);

        if (brandId is not null)
        {
            query = query.Where(item => item.PhoneModel.BrandId == brandId);
        }

        if (pricingType is not null)
        {
            query = query.Where(item => item.RepairService.PricingType == pricingType);
        }

        var items = await query.ToListAsync();
        var tokens = (queryText ?? string.Empty)
            .Split(' ', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);

        if (tokens.Length > 0)
        {
            items = items.Where(item =>
            {
                var haystack = $"{item.PhoneModel.Brand.Name} {item.PhoneModel.Name} {item.RepairService.Name}";
                return tokens.All(token => haystack.Contains(token, StringComparison.OrdinalIgnoreCase));
            }).ToList();
        }

        return items
            .OrderBy(item => item.PhoneModel.Brand.Name)
            .ThenBy(item => item.PhoneModel.Name)
            .ThenBy(item => item.RepairService.Name)
            .Select(item => new CatalogSearchItemDto(
                item.PhoneModelId,
                item.PhoneModel.Brand.Name,
                item.PhoneModel.Name,
                item.RepairServiceId,
                item.RepairService.Name,
                item.RepairService.PricingType,
                item.Price))
            .ToList();
    }

    public async Task<(BrandDto? Data, ApiError? Error, int Status)> CreateBrandAsync(BrandRequest request)
    {
        var name = request.Name.Trim();
        if (string.IsNullOrWhiteSpace(name))
        {
            return (null, new ApiError { Message = "Nhập tên hãng." }, StatusCodes.Status400BadRequest);
        }

        if (await _db.Brands.AnyAsync(item => item.Name == name))
        {
            return (null, new ApiError { Message = "Hãng đã tồn tại." }, StatusCodes.Status409Conflict);
        }

        var brand = new Brand
        {
            Name = name,
            Slug = await UniqueSlugAsync(_db.Brands.Select(item => item.Slug), Slugger.Make(name)),
            Description = Clean(request.Description),
            IsActive = request.IsActive,
            CreatedAt = DateTime.UtcNow
        };
        _db.Brands.Add(brand);
        await _db.SaveChangesAsync();
        return (new BrandDto(brand.Id, brand.Name, brand.Slug, brand.Description, brand.IsActive, 0), null, StatusCodes.Status201Created);
    }

    public async Task<(BrandDto? Data, ApiError? Error, int Status)> UpdateBrandAsync(int id, BrandRequest request)
    {
        var brand = await _db.Brands.Include(item => item.Models).FirstOrDefaultAsync(item => item.Id == id);
        if (brand is null)
        {
            return (null, new ApiError { Message = "Không tìm thấy hãng." }, StatusCodes.Status404NotFound);
        }

        var name = request.Name.Trim();
        if (string.IsNullOrWhiteSpace(name))
        {
            return (null, new ApiError { Message = "Nhập tên hãng." }, StatusCodes.Status400BadRequest);
        }

        if (await _db.Brands.AnyAsync(item => item.Id != id && item.Name == name))
        {
            return (null, new ApiError { Message = "Hãng đã tồn tại." }, StatusCodes.Status409Conflict);
        }

        brand.Name = name;
        brand.Slug = await UniqueSlugAsync(_db.Brands.Where(item => item.Id != id).Select(item => item.Slug), Slugger.Make(name));
        brand.Description = Clean(request.Description);
        brand.IsActive = request.IsActive;
        await _db.SaveChangesAsync();
        return (new BrandDto(brand.Id, brand.Name, brand.Slug, brand.Description, brand.IsActive, brand.Models.Count), null, StatusCodes.Status200OK);
    }

    public async Task<(bool Ok, ApiError? Error, int Status)> DeleteBrandAsync(int id)
    {
        var brand = await _db.Brands.Include(item => item.Models).FirstOrDefaultAsync(item => item.Id == id);
        if (brand is null)
        {
            return (false, new ApiError { Message = "Không tìm thấy hãng." }, StatusCodes.Status404NotFound);
        }

        if (brand.Models.Count > 0)
        {
            return (false, new ApiError { Message = "Hãng còn dòng máy. Hãy tắt hãng thay vì xóa." }, StatusCodes.Status409Conflict);
        }

        _db.Brands.Remove(brand);
        await _db.SaveChangesAsync();
        return (true, null, StatusCodes.Status204NoContent);
    }

    public async Task<(PhoneModelDto? Data, ApiError? Error, int Status)> CreateModelAsync(PhoneModelRequest request)
    {
        var brand = await _db.Brands.FirstOrDefaultAsync(item => item.Id == request.BrandId);
        if (brand is null)
        {
            return (null, new ApiError { Message = "Không tìm thấy hãng." }, StatusCodes.Status400BadRequest);
        }

        var name = request.Name.Trim();
        if (await _db.PhoneModels.AnyAsync(item => item.BrandId == brand.Id && item.Name == name))
        {
            return (null, new ApiError { Message = "Dòng máy đã tồn tại trong hãng này." }, StatusCodes.Status409Conflict);
        }

        var model = new PhoneModel
        {
            BrandId = brand.Id,
            Brand = brand,
            Name = name,
            Slug = Slugger.Make($"{brand.Name}-{name}"),
            ImageUrl = Clean(request.ImageUrl),
            Description = Clean(request.Description),
            ReleaseYear = request.ReleaseYear,
            IsActive = request.IsActive,
            CreatedAt = DateTime.UtcNow
        };
        _db.PhoneModels.Add(model);
        await _db.SaveChangesAsync();
        return (ToModel(model), null, StatusCodes.Status201Created);
    }

    public async Task<(PhoneModelDto? Data, ApiError? Error, int Status)> UpdateModelAsync(int id, PhoneModelRequest request)
    {
        var model = await _db.PhoneModels.Include(item => item.Brand).FirstOrDefaultAsync(item => item.Id == id);
        if (model is null)
        {
            return (null, new ApiError { Message = "Không tìm thấy dòng máy." }, StatusCodes.Status404NotFound);
        }

        var brand = await _db.Brands.FirstOrDefaultAsync(item => item.Id == request.BrandId);
        if (brand is null)
        {
            return (null, new ApiError { Message = "Không tìm thấy hãng." }, StatusCodes.Status400BadRequest);
        }

        var name = request.Name.Trim();
        if (await _db.PhoneModels.AnyAsync(item => item.Id != id && item.BrandId == brand.Id && item.Name == name))
        {
            return (null, new ApiError { Message = "Dòng máy đã tồn tại trong hãng này." }, StatusCodes.Status409Conflict);
        }

        model.BrandId = brand.Id;
        model.Brand = brand;
        model.Name = name;
        model.Slug = Slugger.Make($"{brand.Name}-{name}");
        model.ImageUrl = Clean(request.ImageUrl);
        model.Description = Clean(request.Description);
        model.ReleaseYear = request.ReleaseYear;
        model.IsActive = request.IsActive;
        await _db.SaveChangesAsync();
        return (ToModel(model), null, StatusCodes.Status200OK);
    }

    public async Task<(RepairServiceDto? Data, ApiError? Error, int Status)> SaveServiceAsync(int? id, RepairServiceRequest request)
    {
        var name = request.Name.Trim();
        if (await _db.RepairServices.AnyAsync(item => item.Id != id && item.Name == name))
        {
            return (null, new ApiError { Message = "Dịch vụ đã tồn tại." }, StatusCodes.Status409Conflict);
        }

        RepairService service;
        if (id is null)
        {
            service = new RepairService { CreatedAt = DateTime.UtcNow };
            _db.RepairServices.Add(service);
        }
        else
        {
            var existing = await _db.RepairServices.FirstOrDefaultAsync(item => item.Id == id);
            if (existing is null)
            {
                return (null, new ApiError { Message = "Không tìm thấy dịch vụ." }, StatusCodes.Status404NotFound);
            }

            service = existing;
        }

        service.Name = name;
        service.Slug = Slugger.Make(name);
        service.Description = Clean(request.Description);
        service.PricingType = request.PricingType;
        service.IsActive = request.IsActive;
        await _db.SaveChangesAsync();

        if (service.PricingType == PricingType.InspectionRequired)
        {
            var prices = await _db.ServicePrices.Where(item => item.RepairServiceId == service.Id).ToListAsync();
            foreach (var price in prices)
            {
                price.Price = null;
            }

            await _db.SaveChangesAsync();
        }

        return (ToService(service), null, id is null ? StatusCodes.Status201Created : StatusCodes.Status200OK);
    }

    public async Task<(ServicePriceDto? Data, ApiError? Error, int Status)> SavePriceAsync(int? id, ServicePriceRequest request)
    {
        var model = await _db.PhoneModels.Include(item => item.Brand).FirstOrDefaultAsync(item => item.Id == request.PhoneModelId);
        var service = await _db.RepairServices.FirstOrDefaultAsync(item => item.Id == request.RepairServiceId);
        if (model is null || service is null)
        {
            return (null, new ApiError { Message = "Dòng máy hoặc dịch vụ không tồn tại." }, StatusCodes.Status400BadRequest);
        }

        if (service.PricingType == PricingType.FixedPrice && (request.Price is null || request.Price <= 0))
        {
            return (null, new ApiError { Message = "Dịch vụ giá cố định phải có đơn giá lớn hơn 0." }, StatusCodes.Status400BadRequest);
        }

        if (service.PricingType == PricingType.InspectionRequired && request.Price is not null)
        {
            return (null, new ApiError { Message = "Dịch vụ cần kiểm tra không lưu giá niêm yết." }, StatusCodes.Status400BadRequest);
        }

        if (await _db.ServicePrices.AnyAsync(item => item.Id != id && item.PhoneModelId == model.Id && item.RepairServiceId == service.Id))
        {
            return (null, new ApiError { Message = "Cặp dòng máy và dịch vụ đã có giá." }, StatusCodes.Status409Conflict);
        }

        ServicePrice price;
        if (id is null)
        {
            price = new ServicePrice();
            _db.ServicePrices.Add(price);
        }
        else
        {
            var existing = await _db.ServicePrices.FirstOrDefaultAsync(item => item.Id == id);
            if (existing is null)
            {
                return (null, new ApiError { Message = "Không tìm thấy giá." }, StatusCodes.Status404NotFound);
            }

            price = existing;
        }

        price.PhoneModelId = model.Id;
        price.PhoneModel = model;
        price.RepairServiceId = service.Id;
        price.RepairService = service;
        price.Price = service.PricingType == PricingType.FixedPrice ? request.Price : null;
        price.IsActive = request.IsActive;
        await _db.SaveChangesAsync();
        return (ToPrice(price), null, id is null ? StatusCodes.Status201Created : StatusCodes.Status200OK);
    }

    private static async Task<string> UniqueSlugAsync(IQueryable<string> existing, string slug)
    {
        var baseSlug = string.IsNullOrWhiteSpace(slug) ? "item" : slug;
        var candidate = baseSlug;
        var index = 2;
        var taken = await existing.ToListAsync();
        while (taken.Contains(candidate))
        {
            candidate = $"{baseSlug}-{index}";
            index++;
        }

        return candidate;
    }

    private static string? Clean(string? value)
    {
        var text = value?.Trim();
        return string.IsNullOrWhiteSpace(text) ? null : text;
    }

    private static PhoneModelDto ToModel(PhoneModel item) => new(
        item.Id,
        item.BrandId,
        item.Brand.Name,
        item.Name,
        item.Slug,
        item.ImageUrl,
        item.Description,
        item.ReleaseYear,
        item.IsActive);

    private static RepairServiceDto ToService(RepairService item) => new(
        item.Id, item.Name, item.Slug, item.Description, item.PricingType, item.IsActive);

    private static ServicePriceDto ToPrice(ServicePrice item) => new(
        item.Id,
        item.PhoneModelId,
        item.PhoneModel.Name,
        item.PhoneModel.Brand.Name,
        item.RepairServiceId,
        item.RepairService.Name,
        item.RepairService.PricingType,
        item.Price,
        item.IsActive);
}
