using FluentValidation;
using Microsoft.AspNetCore.Mvc;
using HomeRepairBooking.Api.DTOs;
using HomeRepairBooking.Api.Services;

namespace HomeRepairBooking.Api.Controllers;

[ApiController]
[Route("api/auth")]
public class AuthController : ControllerBase
{
    private readonly AuthService _auth;
    private readonly IValidator<RegisterRequest> _registerValidator;
    private readonly IValidator<LoginRequest> _loginValidator;

    public AuthController(
        AuthService auth,
        IValidator<RegisterRequest> registerValidator,
        IValidator<LoginRequest> loginValidator)
    {
        _auth = auth;
        _registerValidator = registerValidator;
        _loginValidator = loginValidator;
    }

    [HttpPost("register")]
    public async Task<ActionResult<AuthResponse>> Register(RegisterRequest request)
    {
        var invalid = await ValidateAsync(_registerValidator, request);
        if (invalid is not null)
        {
            return BadRequest(invalid);
        }

        var (response, error, statusCode) = await _auth.RegisterAsync(request);
        if (error is not null)
        {
            return StatusCode(statusCode, error);
        }

        return Ok(response);
    }

    [HttpPost("login")]
    public async Task<ActionResult<AuthResponse>> Login(LoginRequest request)
    {
        var invalid = await ValidateAsync(_loginValidator, request);
        if (invalid is not null)
        {
            return BadRequest(invalid);
        }

        var (response, error, statusCode) = await _auth.LoginAsync(request);
        if (error is not null)
        {
            return StatusCode(statusCode, error);
        }

        return Ok(response);
    }

    private static async Task<ApiError?> ValidateAsync<T>(IValidator<T> validator, T request)
    {
        var result = await validator.ValidateAsync(request);
        if (result.IsValid)
        {
            return null;
        }

        return new ApiError
        {
            Message = "Dữ liệu chưa hợp lệ.",
            Errors = result.Errors
                .GroupBy(error => ToCamel(error.PropertyName))
                .ToDictionary(group => group.Key, group => group.Select(error => error.ErrorMessage).ToArray())
        };
    }

    private static string ToCamel(string name)
    {
        if (string.IsNullOrEmpty(name) || char.IsLower(name[0]))
        {
            return name;
        }

        return char.ToLowerInvariant(name[0]) + name[1..];
    }
}
