namespace HomeRepairBooking.Api.Domain;

public class Brand
{
    public int Id { get; set; }

    public string Name { get; set; } = string.Empty;

    public string Slug { get; set; } = string.Empty;

    public string? Description { get; set; }

    public bool IsActive { get; set; } = true;

    public DateTime CreatedAt { get; set; }

    public ICollection<PhoneModel> Models { get; set; } = new List<PhoneModel>();
}
