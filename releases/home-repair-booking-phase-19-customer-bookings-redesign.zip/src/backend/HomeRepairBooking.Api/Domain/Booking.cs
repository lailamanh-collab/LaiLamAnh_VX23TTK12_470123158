namespace HomeRepairBooking.Api.Domain;

public class Booking
{
    public int Id { get; set; }

    public string BookingCode { get; set; } = string.Empty;

    public string CustomerId { get; set; } = string.Empty;

    public ApplicationUser Customer { get; set; } = null!;

    public int PhoneModelId { get; set; }

    public PhoneModel PhoneModel { get; set; } = null!;

    public int BranchId { get; set; }

    public Branch Branch { get; set; } = null!;

    public int? TechnicianId { get; set; }

    public Technician? Technician { get; set; }

    public DateOnly AppointmentDate { get; set; }

    public TimeOnly SlotStart { get; set; }

    public TimeOnly SlotEnd { get; set; }

    public BookingStatus Status { get; set; } = BookingStatus.Pending;

    public string ProblemDescription { get; set; } = string.Empty;

    public decimal EstimatedTotal { get; set; }

    public decimal? ActualCost { get; set; }

    public string? Diagnosis { get; set; }

    public string? RepairNotes { get; set; }

    public string? RepairSolution { get; set; }

    public DateTime? ReceivedAt { get; set; }

    public DateTime? InspectionStartedAt { get; set; }

    public DateTime? RepairStartedAt { get; set; }

    public DateTime? CompletedAt { get; set; }

    public DateTime? CancelledAt { get; set; }

    public string? CancelReason { get; set; }

    public DateTime CreatedAt { get; set; }

    public ICollection<BookingServiceLine> Services { get; set; } = new List<BookingServiceLine>();

    public ICollection<BookingStatusHistory> StatusHistory { get; set; } = new List<BookingStatusHistory>();

    public Review? Review { get; set; }
}
