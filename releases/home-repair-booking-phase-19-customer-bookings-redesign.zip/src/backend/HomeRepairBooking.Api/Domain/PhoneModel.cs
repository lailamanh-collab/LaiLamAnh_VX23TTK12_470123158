namespace HomeRepairBooking.Api.Domain;

public class PhoneModel
{
    public int Id { get; set; }

    public int BrandId { get; set; }

    public Brand Brand { get; set; } = null!;

    public string Name { get; set; } = string.Empty;

    public string Slug { get; set; } = string.Empty;

    public string? ImageUrl { get; set; }

    public string? Description { get; set; }

    public int? ReleaseYear { get; set; }

    public bool IsActive { get; set; } = true;

    public DateTime CreatedAt { get; set; }

    public ICollection<ServicePrice> ServicePrices { get; set; } = new List<ServicePrice>();
}
