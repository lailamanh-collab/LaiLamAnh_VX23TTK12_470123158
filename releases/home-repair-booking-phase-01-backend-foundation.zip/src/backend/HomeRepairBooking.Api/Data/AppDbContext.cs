using Microsoft.EntityFrameworkCore;

namespace HomeRepairBooking.Api.Data;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
    {
    }
}
