import { useEffect, useMemo, useState } from "react"
import { Link, useSearchParams } from "react-router-dom"
import { getBrands, getModels, getPrices, type Brand, type PhoneModel, type ServicePrice } from "../api/catalog"
import { getBranches, type Branch } from "../api/branches"
import { createBooking, getSlots, type BookingDetail, type Slot } from "../api/bookings"
import { ApiError } from "../api/client"
import { useAuth } from "../auth/AuthContext"
import { BookingSuccessPage } from "./BookingSuccessPage"
import { BRAND_LOGOS, getPhoneImage, getBranchImage, SERVICE_ICONS } from "../assets"

interface MockupModel {
  name: string
  year: number
  image: string
}

const BRAND_MODELS_CATALOG: Record<string, MockupModel[]> = {
  Apple: [
    { name: "iPhone 16 Pro Max", year: 2024, image: getPhoneImage("iPhone 16") },
    { name: "iPhone 16 Pro", year: 2024, image: getPhoneImage("iPhone 16") },
    { name: "iPhone 16", year: 2024, image: getPhoneImage("iPhone 16") },
    { name: "iPhone 15 Pro Max", year: 2023, image: getPhoneImage("iPhone 15") },
    { name: "iPhone 15", year: 2023, image: getPhoneImage("iPhone 15") },
    { name: "iPhone 14 Pro Max", year: 2022, image: getPhoneImage("iPhone 14") },
    { name: "iPhone 14", year: 2022, image: getPhoneImage("iPhone 14") },
    { name: "iPhone 13", year: 2021, image: getPhoneImage("iPhone 13") },
    { name: "iPhone 12", year: 2020, image: getPhoneImage("iPhone 12") },
    { name: "iPhone 11", year: 2019, image: getPhoneImage("iPhone 11") },
    { name: "iPhone XS", year: 2018, image: getPhoneImage("iPhone XS") },
    { name: "iPhone SE", year: 2022, image: getPhoneImage("iPhone SE") },
  ],
  Samsung: [
    { name: "Galaxy S24 Ultra", year: 2024, image: getPhoneImage("Galaxy S24") },
    { name: "Galaxy S24", year: 2024, image: getPhoneImage("Galaxy S24") },
    { name: "Galaxy S23 Ultra", year: 2023, image: getPhoneImage("Galaxy S23") },
    { name: "Galaxy S23", year: 2023, image: getPhoneImage("Galaxy S23") },
    { name: "Galaxy Z Fold 5", year: 2023, image: getPhoneImage("Galaxy S24") },
    { name: "Galaxy Z Flip 5", year: 2023, image: getPhoneImage("Galaxy S23") },
    { name: "Galaxy A55 5G", year: 2024, image: getPhoneImage("Galaxy S23") },
    { name: "Galaxy A54 5G", year: 2023, image: getPhoneImage("Galaxy S23") },
    { name: "Galaxy A35 5G", year: 2024, image: getPhoneImage("Galaxy S23") },
    { name: "Galaxy Note 20 Ultra", year: 2020, image: getPhoneImage("Galaxy S23") },
    { name: "Galaxy S22 Ultra", year: 2022, image: getPhoneImage("Galaxy S23") },
    { name: "Galaxy S21 5G", year: 2021, image: getPhoneImage("Galaxy S23") },
  ],
  Xiaomi: [
    { name: "Xiaomi 14 Ultra", year: 2024, image: getPhoneImage("Xiaomi 14") },
    { name: "Xiaomi 14", year: 2024, image: getPhoneImage("Xiaomi 14") },
    { name: "Xiaomi 13 Pro", year: 2023, image: getPhoneImage("Xiaomi 14") },
    { name: "Xiaomi 13", year: 2023, image: getPhoneImage("Xiaomi 14") },
    { name: "Redmi Note 13 Pro+", year: 2024, image: getPhoneImage("Xiaomi 14") },
    { name: "Redmi Note 13", year: 2024, image: getPhoneImage("Xiaomi 14") },
    { name: "Redmi Note 12", year: 2023, image: getPhoneImage("Xiaomi 14") },
    { name: "POCO X6 Pro", year: 2024, image: getPhoneImage("Xiaomi 14") },
    { name: "POCO F5 Pro", year: 2023, image: getPhoneImage("Xiaomi 14") },
    { name: "Xiaomi 12T Pro", year: 2022, image: getPhoneImage("Xiaomi 14") },
  ],
  Oppo: [
    { name: "Find X7 Ultra", year: 2024, image: getPhoneImage("Oppo") },
    { name: "Find N3 Flip", year: 2023, image: getPhoneImage("Oppo") },
    { name: "Reno 12 Pro", year: 2024, image: getPhoneImage("Oppo") },
    { name: "Reno 12", year: 2024, image: getPhoneImage("Oppo") },
    { name: "Reno 11 Pro", year: 2023, image: getPhoneImage("Oppo") },
    { name: "Reno 10 5G", year: 2023, image: getPhoneImage("Oppo") },
    { name: "Oppo A79 5G", year: 2023, image: getPhoneImage("Oppo") },
    { name: "Oppo A58", year: 2023, image: getPhoneImage("Oppo") },
  ],
  Vivo: [
    { name: "Vivo X100 Pro", year: 2024, image: getPhoneImage("Vivo") },
    { name: "Vivo X90 Pro", year: 2023, image: getPhoneImage("Vivo") },
    { name: "Vivo V30 Pro", year: 2024, image: getPhoneImage("Vivo") },
    { name: "Vivo V30 5G", year: 2024, image: getPhoneImage("Vivo") },
    { name: "Vivo V29 5G", year: 2023, image: getPhoneImage("Vivo") },
    { name: "Vivo Y100 5G", year: 2024, image: getPhoneImage("Vivo") },
    { name: "Vivo Y36", year: 2023, image: getPhoneImage("Vivo") },
  ],
  Realme: [
    { name: "Realme GT 5 Pro", year: 2024, image: getPhoneImage("Realme") },
    { name: "Realme 12 Pro+ 5G", year: 2024, image: getPhoneImage("Realme") },
    { name: "Realme 12 5G", year: 2024, image: getPhoneImage("Realme") },
    { name: "Realme 11 Pro+ 5G", year: 2023, image: getPhoneImage("Realme") },
    { name: "Realme C67", year: 2023, image: getPhoneImage("Realme") },
    { name: "Realme C55", year: 2023, image: getPhoneImage("Realme") },
  ],
  Google: [
    { name: "Pixel 9 Pro XL", year: 2024, image: getPhoneImage("Google") },
    { name: "Pixel 9 Pro", year: 2024, image: getPhoneImage("Google") },
    { name: "Pixel 9", year: 2024, image: getPhoneImage("Google") },
    { name: "Pixel 8 Pro", year: 2023, image: getPhoneImage("Google") },
    { name: "Pixel 8", year: 2023, image: getPhoneImage("Google") },
    { name: "Pixel 7 Pro", year: 2022, image: getPhoneImage("Google") },
    { name: "Pixel 7a", year: 2023, image: getPhoneImage("Google") },
  ],
  Honor: [
    { name: "Honor Magic 6 Pro", year: 2024, image: getPhoneImage("Honor") },
    { name: "Honor 200 Pro", year: 2024, image: getPhoneImage("Honor") },
    { name: "Honor 200", year: 2024, image: getPhoneImage("Honor") },
    { name: "Honor 90 5G", year: 2023, image: getPhoneImage("Honor") },
    { name: "Honor X9b 5G", year: 2023, image: getPhoneImage("Honor") },
    { name: "Honor X8b", year: 2024, image: getPhoneImage("Honor") },
  ],
}

interface ServiceTemplate {
  key: string
  name: string
  desc: string
  price: number
  icon: string
  iconBg: string
  isPopular?: boolean
}

const SERVICE_TEMPLATES: ServiceTemplate[] = [
  { key: "screen", name: "Thay màn hình", desc: "Màn hình chính hãng, hiển thị sắc nét, cảm ứng mượt mà", price: 3500000, icon: "📱", iconBg: "#eff6ff", isPopular: true },
  { key: "battery", name: "Thay pin", desc: "Pin chính hãng, dung lượng chuẩn, bảo hành dài hạn", price: 1500000, icon: "🔋", iconBg: "#ecfdf5", isPopular: true },
  { key: "camera", name: "Thay camera", desc: "Camera chính hãng, chụp ảnh sắc nét, lấy nét nhanh", price: 800000, icon: "📷", iconBg: "#eff6ff" },
  { key: "speaker", name: "Sửa loa", desc: "Khôi phục âm thanh rõ ràng, không rè, không nhỏ", price: 300000, icon: "🔊", iconBg: "#f5f3ff" },
  { key: "port", name: "Sửa cổng sạc", desc: "Sạc ổn định, tiếp xúc tốt, không lỏng lẻo", price: 400000, icon: "🔌", iconBg: "#eff6ff" },
  { key: "case", name: "Thay vỏ", desc: "Vỏ chính hãng, khôi phục ngoại hình như mới", price: 1200000, icon: "📱", iconBg: "#f5f3ff" },
  { key: "power", name: "Sửa nút nguồn", desc: "Khắc phục lỗi nút nguồn, nhạy và bền bỉ", price: 350000, icon: "⏻", iconBg: "#eff6ff" },
  { key: "clean", name: "Vệ sinh máy", desc: "Vệ sinh tổng thể, tản nhiệt tốt hơn, tăng hiệu năng", price: 200000, icon: "🪄", iconBg: "#eff6ff" },
  { key: "software", name: "Cài đặt phần mềm", desc: "Cài đặt iOS, khôi phục dữ liệu, kiểm tra phần mềm", price: 150000, icon: "⚙️", iconBg: "#eff6ff" },
]

const BRAND_TABS = [
  { name: "Apple", logo: "apple" },
  { name: "Samsung", logo: "samsung" },
  { name: "Xiaomi", logo: "xiaomi" },
  { name: "Oppo", logo: "oppo" },
  { name: "Vivo", logo: "vivo" },
  { name: "Realme", logo: "realme" },
  { name: "Google", logo: "google" },
  { name: "Honor", logo: "honor" },
]

interface BranchMeta {
  id: number
  name: string
  address: string
  distance: string
  hours: string
  phone: string
  tags: { text: string; bg: string; color: string }[]
  image: string
  mapX: number // percentage for svg map
  mapY: number
}

const MOCKUP_BRANCHES: BranchMeta[] = [
  {
    id: 1,
    name: "PhoneRepair Cầu Giấy",
    address: "123 Cầu Giấy, Quan Hoa, Cầu Giấy, Hà Nội",
    distance: "2.1 km",
    hours: "08:00 - 20:00",
    phone: "024 1234 5678",
    tags: [
      { text: "Gần bạn", bg: "#dcfce7", color: "#16a34a" },
      { text: "Đông khách", bg: "#ffedd5", color: "#ea580c" },
    ],
    image: getBranchImage("Cầu Giấy"),
    mapX: 42,
    mapY: 48,
  },
  {
    id: 2,
    name: "PhoneRepair Đống Đa",
    address: "456 Xã Đàn, Nam Đồng, Đống Đa, Hà Nội",
    distance: "5.3 km",
    hours: "08:00 - 20:00",
    phone: "024 2345 6789",
    tags: [
      { text: "Bãi đỗ xe", bg: "#e0f2fe", color: "#0284c7" },
      { text: "Thoáng hơn", bg: "#dcfce7", color: "#16a34a" },
    ],
    image: getBranchImage("Đống Đa"),
    mapX: 58,
    mapY: 76,
  },
  {
    id: 3,
    name: "PhoneRepair Hai Bà Trưng",
    address: "789 Phố Huế, Hàng Bài, Hai Bà Trưng, Hà Nội",
    distance: "8.7 km",
    hours: "08:00 - 20:00",
    phone: "024 3456 7890",
    tags: [
      { text: "Rộng rãi", bg: "#e0f2fe", color: "#0284c7" },
      { text: "Ít chờ đợi", bg: "#dcfce7", color: "#16a34a" },
    ],
    image: getBranchImage("Hai Bà Trưng"),
    mapX: 72,
    mapY: 28,
  },
]

// 18 standard time slots matching mockup screenshot
const TIME_SLOTS_PRESET = [
  { start: "08:00", end: "08:30", isFull: false },
  { start: "08:30", end: "09:00", isFull: false },
  { start: "09:00", end: "09:30", isFull: false },
  { start: "09:30", end: "10:00", isFull: false },
  { start: "10:00", end: "10:30", isFull: false },
  { start: "10:30", end: "11:00", isFull: false },
  { start: "11:00", end: "11:30", isFull: false },
  { start: "11:30", end: "12:00", isFull: false },
  { start: "13:00", end: "13:30", isFull: false },
  { start: "13:30", end: "14:00", isFull: false },
  { start: "14:00", end: "14:30", isFull: false },
  { start: "14:30", end: "15:00", isFull: false },
  { start: "15:00", end: "15:30", isFull: false },
  { start: "15:30", end: "16:00", isFull: false },
  { start: "16:00", end: "16:30", isFull: true },
  { start: "16:30", end: "17:00", isFull: true },
  { start: "17:00", end: "17:30", isFull: false },
  { start: "17:30", end: "18:00", isFull: true },
]

function formatVietnameseDate(isoDate: string) {
  if (!isoDate) return ""
  const [y, m, d] = isoDate.split("-").map(Number)
  const dt = new Date(y, m - 1, d)
  const days = ["Chủ Nhật", "Thứ Hai", "Thứ Ba", "Thứ Tư", "Thứ Năm", "Thứ Sáu", "Thứ Bảy"]
  const dayName = days[dt.getDay()]
  return `${dayName}, ${d} tháng ${m}, ${y}`
}

export function BookingWizardPage() {
  const { token, user, openAuthModal } = useAuth()
  const [searchParams] = useSearchParams()
  const initialBranchParam = searchParams.get("branchId")
  const initialBrandParam = searchParams.get("brand")
  const initialModelParam = searchParams.get("model") || searchParams.get("modelName")

  const resolvedInitialBrand = useMemo(() => {
    if (!initialBrandParam) return "Apple"
    const matched = BRAND_TABS.find((b) => b.name.toLowerCase() === initialBrandParam.toLowerCase())
    return matched ? matched.name : "Apple"
  }, [initialBrandParam])

  // Wizard state:
  // 0 = Bước 1: Chọn máy & dịch vụ
  // 1 = Bước 2: Chọn chi nhánh
  // 2 = Bước 3: Ngày & giờ
  // 3 = Bước 4: Thông tin khách hàng & mô tả lỗi
  // 4 = Bước 5: Xác nhận đặt lịch
  // 5 = Thành công (BookingSuccessPage)
  const [activeStep, setActiveStep] = useState(0)

  // Data from backend
  const [brands, setBrands] = useState<Brand[]>([])
  const [models, setModels] = useState<PhoneModel[]>([])
  const [prices, setPrices] = useState<ServicePrice[]>([])
  const [branches, setBranches] = useState<Branch[]>([])
  const [slots, setSlots] = useState<Slot[]>([])

  // User selections
  const [selectedBrandName, setSelectedBrandName] = useState(resolvedInitialBrand)
  const [selectedModelName, setSelectedModelName] = useState(() => {
    if (initialModelParam) return initialModelParam
    const first = BRAND_MODELS_CATALOG[resolvedInitialBrand]?.[0]?.name
    return first || "iPhone 16"
  })
  const [modelSearch, setModelSearch] = useState("")

  // Sync search param changes
  useEffect(() => {
    if (initialBrandParam) {
      const matched = BRAND_TABS.find((b) => b.name.toLowerCase() === initialBrandParam.toLowerCase())
      if (matched) {
        setSelectedBrandName(matched.name)
        if (!initialModelParam) {
          const first = BRAND_MODELS_CATALOG[matched.name]?.[0]?.name
          if (first) setSelectedModelName(first)
        }
      }
    }
    if (initialModelParam) {
      setSelectedModelName(initialModelParam)
    }
  }, [initialBrandParam, initialModelParam])

  // Models filtered by selected brand and keyword
  const displayedModels: MockupModel[] = useMemo(() => {
    const brandList = BRAND_MODELS_CATALOG[selectedBrandName] || BRAND_MODELS_CATALOG["Apple"] || []
    if (!modelSearch.trim()) return brandList
    return brandList.filter((m) => m.name.toLowerCase().includes(modelSearch.toLowerCase()))
  }, [selectedBrandName, modelSearch])
  const [selectedStorage, setSelectedStorage] = useState("")
  const [selectedColor, setSelectedColor] = useState("")
  const [selectedCondition, setSelectedCondition] = useState("")

  const initialServiceParam = searchParams.get("service") || searchParams.get("serviceName")
  // Selected services: pre-select if URL parameter passed, otherwise let customer choose
  const [selectedServiceNames, setSelectedServiceNames] = useState<string[]>(() => {
    return initialServiceParam ? [initialServiceParam] : []
  })
  const [selectedBranchId, setSelectedBranchId] = useState<number>(initialBranchParam ? Number(initialBranchParam) : 1)

  // Calendar & Slot selection: default to today or selected date
  const today = new Date()
  const todayIso = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, "0")}-${String(today.getDate()).padStart(2, "0")}`
  const [appointmentDate, setAppointmentDate] = useState(todayIso)
  const [calendarMonth, setCalendarMonth] = useState(today.getMonth())
  const [calendarYear, setCalendarYear] = useState(today.getFullYear())
  const [selectedSlot, setSelectedSlot] = useState("08:30")

  // Customer info & description (use logged-in profile if available, otherwise empty)
  const [customerName, setCustomerName] = useState(user?.fullName || "")
  const [customerPhone, setCustomerPhone] = useState(user?.phoneNumber || "")
  const [problemDescription, setProblemDescription] = useState("")

  // Auto-sync customer info when auth user profile is loaded
  useEffect(() => {
    if (user) {
      if (!customerName && user.fullName) setCustomerName(user.fullName)
      if (!customerPhone && user.phoneNumber) setCustomerPhone(user.phoneNumber)
    }
  }, [user])

  const [saving, setSaving] = useState(false)
  const [errorMessage, setErrorMessage] = useState("")
  const [createdBooking, setCreatedBooking] = useState<BookingDetail | null>(null)

  // Fetch catalog brands & branches
  useEffect(() => {
    getBrands().then(setBrands).catch(() => {})
    getBranches()
      .then((brList) => {
        setBranches(brList)
        if (!selectedBranchId && brList.length > 0) {
          setSelectedBranchId(brList[0].id)
        }
      })
      .catch(() => {})
  }, [selectedBranchId])

  // Fetch models for brand
  useEffect(() => {
    const brand = brands.find((b) => b.name.toLowerCase() === selectedBrandName.toLowerCase())
    if (brand) {
      getModels(brand.id)
        .then(setModels)
        .catch(() => setModels([]))
    }
  }, [brands, selectedBrandName])

  // Fetch prices for selected model
  const activeModel = models.find((m) => m.name.toLowerCase() === selectedModelName.toLowerCase())
  useEffect(() => {
    if (activeModel) {
      getPrices(activeModel.id)
        .then(setPrices)
        .catch(() => setPrices([]))
    }
  }, [activeModel])

  // Fetch time slots when branch and date change
  useEffect(() => {
    if (selectedBranchId && appointmentDate) {
      getSlots(selectedBranchId, appointmentDate)
        .then((s) => {
          setSlots(s)
        })
        .catch(() => setSlots([]))
    }
  }, [selectedBranchId, appointmentDate])

  // Calculate pricing
  const totalAmount = useMemo(() => {
    return selectedServiceNames.reduce((sum, sName) => {
      const template = SERVICE_TEMPLATES.find((t) => t.name === sName)
      const serverPrice = prices.find((p) => p.repairServiceName.toLowerCase() === sName.toLowerCase() && p.price)
      return sum + (serverPrice?.price ?? template?.price ?? 0)
    }, 0)
  }, [selectedServiceNames, prices])

  // Merge backend slots with preset slots
  const effectiveSlots = useMemo(() => {
    if (!slots || slots.length === 0) return TIME_SLOTS_PRESET
    return TIME_SLOTS_PRESET.map((p) => {
      const match = slots.find((s) => s.start === p.start)
      return match ? { ...p, isFull: match.isFull } : p
    })
  }, [slots])

  const effectiveBranches = useMemo(() => {
    if (branches.length === 0) return MOCKUP_BRANCHES
    return MOCKUP_BRANCHES.map((mb) => {
      const match = branches.find((b) => b.id === mb.id)
      return match ? { ...mb, name: match.name, address: match.address, phone: match.phone } : mb
    })
  }, [branches])

  const toggleService = (sName: string) => {
    setSelectedServiceNames((prev) =>
      prev.includes(sName) ? prev.filter((n) => n !== sName) : [...prev, sName]
    )
  }

  const removeService = (sName: string) => {
    setSelectedServiceNames((prev) => prev.filter((n) => n !== sName))
  }

  const handleNextStep = () => {
    setErrorMessage("")
    if (activeStep === 0) {
      if (selectedServiceNames.length === 0) {
        setErrorMessage("Vui lòng chọn ít nhất một dịch vụ sửa chữa.")
        return
      }
      setActiveStep(1) // Move to Bước 2: Chọn chi nhánh
    } else if (activeStep === 1) {
      if (!selectedBranchId) {
        setErrorMessage("Vui lòng chọn một chi nhánh.")
        return
      }
      setActiveStep(2) // Move to Bước 3: Ngày & giờ
    } else if (activeStep === 2) {
      if (!appointmentDate || !selectedSlot) {
        setErrorMessage("Vui lòng chọn ngày và giờ hẹn.")
        return
      }
      setActiveStep(3) // Move to Bước 4: Thông tin
    } else if (activeStep === 3) {
      if (!customerName.trim() || !customerPhone.trim()) {
        setErrorMessage("Vui lòng nhập họ tên và số điện thoại liên hệ.")
        return
      }
      if (!problemDescription.trim()) {
        setErrorMessage("Vui lòng nhập mô tả tình trạng máy.")
        return
      }
      setActiveStep(4) // Move to Bước 5: Xác nhận
    } else if (activeStep === 4) {
      handleSubmitBooking()
    }
  }

  const handlePrevStep = () => {
    setErrorMessage("")
    if (activeStep > 0) setActiveStep((prev) => prev - 1)
  }

  const handleSubmitBooking = async () => {
    if (!token) {
      setErrorMessage("Vui lòng đăng nhập để hoàn tất đặt lịch.")
      return
    }

    const modelToBook = models.find((m) => m.name.toLowerCase() === selectedModelName.toLowerCase()) || models[0]
    if (!modelToBook || !selectedBranchId || !appointmentDate || !selectedSlot) {
      setErrorMessage("Thông tin đặt lịch chưa đầy đủ.")
      return
    }

    const serviceIdsToBook = prices
      .filter((p) => selectedServiceNames.some((sn) => sn.toLowerCase() === p.repairServiceName.toLowerCase()))
      .map((p) => p.repairServiceId)

    setSaving(true)
    setErrorMessage("")
    try {
      const extraDetails: string[] = []
      if (selectedStorage) extraDetails.push(`Dung lượng: ${selectedStorage}`)
      if (selectedColor) extraDetails.push(`Màu: ${selectedColor}`)
      if (selectedCondition) extraDetails.push(`Tình trạng: ${selectedCondition}`)

      const fullDescription = extraDetails.length > 0
        ? `${problemDescription.trim()} [${extraDetails.join(" | ")}]`
        : problemDescription.trim()

      const created = await createBooking(token, {
        phoneModelId: modelToBook.id,
        repairServiceIds: serviceIdsToBook.length > 0 ? serviceIdsToBook : [1],
        branchId: selectedBranchId,
        appointmentDate,
        slotStart: selectedSlot,
        problemDescription: fullDescription,
      })
      setCreatedBooking(created)
      setActiveStep(5)
    } catch (err) {
      if (err instanceof ApiError) {
        setErrorMessage(err.message)
      } else {
        setErrorMessage("Không thể tạo lịch hẹn. Vui lòng thử lại.")
      }
    } finally {
      setSaving(false)
    }
  }

  const formatVnd = (price: number) => {
    return price.toLocaleString("vi-VN") + "đ"
  }

  const activeBranch = effectiveBranches.find((b) => b.id === selectedBranchId) || effectiveBranches[0]
  const activeSlotObj = effectiveSlots.find((s) => s.start === selectedSlot) || effectiveSlots[1]

  // Calendar days generation for current calendarMonth & calendarYear
  const calendarDays = useMemo(() => {
    const daysInMonth = new Date(calendarYear, calendarMonth + 1, 0).getDate()
    const firstDayOfWeek = new Date(calendarYear, calendarMonth, 1).getDay() // 0 = Sun, 1 = Mon
    // Convert to Mon=0..Sun=6
    const offset = (firstDayOfWeek + 6) % 7

    const days: { day: number; isCurrentMonth: boolean; dateStr: string }[] = []

    // Previous month filler
    const prevMonthDays = new Date(calendarYear, calendarMonth, 0).getDate()
    for (let i = offset - 1; i >= 0; i--) {
      const d = prevMonthDays - i
      days.push({ day: d, isCurrentMonth: false, dateStr: "" })
    }

    // Current month days
    for (let d = 1; d <= daysInMonth; d++) {
      const monthStr = String(calendarMonth + 1).padStart(2, "0")
      const dayStr = String(d).padStart(2, "0")
      days.push({
        day: d,
        isCurrentMonth: true,
        dateStr: `${calendarYear}-${monthStr}-${dayStr}`,
      })
    }

    return days
  }, [calendarMonth, calendarYear])

  if (createdBooking) {
    return (
      <BookingSuccessPage
        initialData={{
          booking: createdBooking,
          customerName,
          customerPhone,
          customerEmail: user?.email || "",
          modelName: selectedModelName,
          brandName: selectedBrandName,
          storage: selectedStorage,
          color: selectedColor,
          condition: selectedCondition,
          imei: "",
          branchName: activeBranch.name,
          branchAddress: activeBranch.address,
          branchPhone: activeBranch.phone,
          appointmentDate: formatVietnameseDate(appointmentDate),
          slotTime: `${activeSlotObj.start} - ${activeSlotObj.end}`,
          services: selectedServiceNames.map((sn) => {
            const tmpl = SERVICE_TEMPLATES.find((t) => t.name === sn)
            const sPrice = prices.find((p) => p.repairServiceName.toLowerCase() === sn.toLowerCase() && p.price)
            return {
              name: sn,
              price: sPrice?.price ?? tmpl?.price ?? 0,
              desc: tmpl?.desc,
              icon: tmpl?.icon,
              iconBg: tmpl?.iconBg,
            }
          }),
          totalAmount,
        }}
      />
    )
  }

  return (
    <main style={{ background: "#f8fafc", minHeight: "100vh", padding: "24px 20px 60px" }}>
      <div style={{ maxWidth: "1340px", margin: "0 auto" }}>
        {/* TOP BREADCRUMB & PAGE TITLE */}
        <div style={{ marginBottom: "20px" }}>
          <Link
            to="/"
            style={{
              display: "inline-flex",
              alignItems: "center",
              gap: "6px",
              fontSize: "0.85rem",
              color: "#64748b",
              textDecoration: "none",
              marginBottom: "12px",
              fontWeight: 500,
            }}
          >
            <span>←</span>
            <span>Quay lại trang chủ</span>
          </Link>

          <h1 style={{ fontSize: "1.75rem", fontWeight: 800, color: "#0f172a", margin: "0 0 24px", letterSpacing: "-0.02em" }}>
            Đặt lịch sửa chữa
          </h1>

          {/* STEPPER PROGRESS BAR (5 STEPS MATCHING SCREENSHOT) */}
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", maxWidth: "860px", position: "relative" }}>
            {[
              { num: 1, label: "Chọn máy" },
              { num: 2, label: "Chọn chi nhánh" },
              { num: 3, label: "Ngày & giờ" },
              { num: 4, label: "Thông tin" },
              { num: 5, label: "Xác nhận" },
            ].map((st, i) => {
              const isDone = activeStep > i
              const isCurrent = activeStep === i

              return (
                <div key={st.num} style={{ display: "flex", flexDirection: "column", alignItems: "center", position: "relative", zIndex: 2 }}>
                  <div
                    onClick={() => {
                      if (i < activeStep) setActiveStep(i)
                    }}
                    style={{
                      width: "32px",
                      height: "32px",
                      borderRadius: "50%",
                      background: isDone || isCurrent ? "#2563eb" : "#ffffff",
                      border: isDone || isCurrent ? "2px solid #2563eb" : "2px solid #cbd5e1",
                      color: isDone || isCurrent ? "#ffffff" : "#64748b",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      fontSize: "0.85rem",
                      fontWeight: 800,
                      cursor: i < activeStep ? "pointer" : "default",
                      boxShadow: isCurrent ? "0 4px 12px rgba(37,99,235,0.3)" : "none",
                      transition: "all 0.2s ease",
                    }}
                  >
                    {isDone ? "✓" : st.num}
                  </div>
                  <span
                    style={{
                      fontSize: "0.82rem",
                      fontWeight: isCurrent ? 800 : 600,
                      color: isCurrent ? "#0f172a" : "#64748b",
                      marginTop: "6px",
                      whiteSpace: "nowrap",
                    }}
                  >
                    {st.label}
                  </span>
                </div>
              )
            })}

            {/* CONNECTING STEP LINE */}
            <div
              style={{
                position: "absolute",
                top: "16px",
                left: "40px",
                right: "40px",
                height: "2px",
                background: "#e2e8f0",
                zIndex: 1,
              }}
            >
              <div
                style={{
                  height: "100%",
                  width: `${(Math.min(activeStep, 4) / 4) * 100}%`,
                  background: "#2563eb",
                  transition: "width 0.3s ease",
                }}
              />
            </div>
          </div>
        </div>

        {errorMessage && (
          <div style={{ background: "#fef2f2", border: "1px solid #fecaca", color: "#dc2626", borderRadius: "10px", padding: "12px 16px", marginBottom: "20px", fontSize: "0.88rem" }}>
            {errorMessage}
          </div>
        )}

        {/* MAIN 2-COLUMN LAYOUT: WIZARD BODY (LEFT) & STICKY SUMMARY (RIGHT) */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 360px", gap: "28px", alignItems: "flex-start" }}>
          {/* LEFT COLUMN */}
          <div style={{ background: "#ffffff", border: "1px solid #e2e8f0", borderRadius: "20px", padding: "26px", boxShadow: "0 2px 10px rgba(15,23,42,0.03)" }}>
            {/* ================= STEP 0: CHỌN MÁY & DỊCH VỤ ================= */}
            {activeStep === 0 && (
              <div>
                {/* 1. CHỌN HÃNG VÀ DÒNG MÁY */}
                <div style={{ marginBottom: "28px" }}>
                  <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "4px" }}>
                    <div style={{ width: "24px", height: "24px", borderRadius: "50%", background: "#2563eb", color: "#ffffff", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "0.8rem", fontWeight: 800 }}>
                      1
                    </div>
                    <h2 style={{ fontSize: "1.05rem", fontWeight: 800, color: "#0f172a", margin: 0 }}>
                      Chọn hãng và dòng máy
                    </h2>
                  </div>
                  <p style={{ fontSize: "0.82rem", color: "#64748b", margin: "0 0 16px 34px" }}>
                    Chọn thương hiệu điện thoại và model thiết bị của bạn
                  </p>

                  {/* 8 BRAND PILL BUTTONS */}
                  <div style={{ display: "flex", gap: "10px", overflowX: "auto", paddingBottom: "6px", marginBottom: "22px" }}>
                    {BRAND_TABS.map((b) => {
                      const isActive = selectedBrandName === b.name
                      const isWordmark = ["Samsung", "Oppo", "Vivo", "Honor", "Realme"].includes(b.name)
                      return (
                        <button
                          key={b.name}
                          type="button"
                          onClick={() => {
                            setSelectedBrandName(b.name)
                            const first = BRAND_MODELS_CATALOG[b.name]?.[0]?.name
                            if (first) {
                              setSelectedModelName(first)
                            }
                          }}
                          style={{
                            padding: isWordmark ? "8px 20px" : "8px 18px",
                            height: "38px",
                            borderRadius: "10px",
                            border: isActive ? "1.5px solid #2563eb" : "1px solid #e2e8f0",
                            background: isActive ? "#eff6ff" : "#ffffff",
                            color: isActive ? "#2563eb" : "#334155",
                            fontWeight: isActive ? 700 : 500,
                            fontSize: "0.86rem",
                            cursor: "pointer",
                            display: "inline-flex",
                            alignItems: "center",
                            justifyContent: "center",
                            gap: "8px",
                            whiteSpace: "nowrap",
                            transition: "all 0.15s ease",
                          }}
                        >
                          {BRAND_LOGOS[b.name] && (
                            <img
                              src={BRAND_LOGOS[b.name]}
                              alt={b.name}
                              style={
                                isWordmark
                                  ? { height: "15px", maxWidth: "75px", width: "auto", objectFit: "contain", display: "block" }
                                  : { width: "16px", height: "16px", objectFit: "contain", flexShrink: 0 }
                              }
                            />
                          )}
                          {!isWordmark && <span>{b.name}</span>}
                        </button>
                      )
                    })}
                  </div>

                  {/* CHỌN DÒNG MÁY HEADER & SEARCH */}
                  <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "16px" }}>
                    <span style={{ fontSize: "0.95rem", fontWeight: 800, color: "#0f172a" }}>
                      Chọn dòng máy {selectedBrandName}
                    </span>

                    <div style={{ position: "relative", width: "230px" }}>
                      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#94a3b8" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" style={{ position: "absolute", left: "10px", top: "10px" }}>
                        <circle cx="11" cy="11" r="8" />
                        <line x1="21" y1="21" x2="16.65" y2="16.65" />
                      </svg>
                      <input
                        type="text"
                        placeholder={`Tìm kiếm model ${selectedBrandName}...`}
                        value={modelSearch}
                        onChange={(e) => setModelSearch(e.target.value)}
                        style={{
                          width: "100%",
                          height: "34px",
                          padding: "0 10px 0 32px",
                          borderRadius: "8px",
                          border: "1px solid #cbd5e1",
                          fontSize: "0.82rem",
                          background: "#f8fafc",
                          outline: "none",
                        }}
                      />
                    </div>
                  </div>

                  {/* PHONE MODEL CARDS */}
                  {displayedModels.length === 0 ? (
                    <div
                      style={{
                        textAlign: "center",
                        padding: "36px 16px",
                        color: "#64748b",
                        background: "#f8fafc",
                        borderRadius: "12px",
                        border: "1px dashed #cbd5e1",
                      }}
                    >
                      <div style={{ fontSize: "1.8rem", marginBottom: "8px" }}>🔍</div>
                      <strong style={{ display: "block", color: "#0f172a", marginBottom: "4px" }}>
                        Không tìm thấy dòng máy phù hợp
                      </strong>
                      <span style={{ fontSize: "0.82rem" }}>
                        Không có model {selectedBrandName} nào khớp với từ khóa "{modelSearch}".
                      </span>
                    </div>
                  ) : (
                    <div style={{ display: "grid", gridTemplateColumns: "repeat(6, 1fr)", gap: "12px" }}>
                      {displayedModels.map((m) => {
                        const isSelected = selectedModelName.toLowerCase() === m.name.toLowerCase()
                        return (
                          <div
                            key={m.name}
                            onClick={() => setSelectedModelName(m.name)}
                            style={{
                              background: isSelected ? "#eff6ff" : "#ffffff",
                              border: isSelected ? "1.5px solid #2563eb" : "1px solid #e2e8f0",
                              borderRadius: "12px",
                              padding: "12px 8px 10px",
                              display: "flex",
                              flexDirection: "column",
                              alignItems: "center",
                              cursor: "pointer",
                              position: "relative",
                              transition: "all 0.15s ease",
                              boxShadow: isSelected ? "0 4px 12px rgba(37,99,235,0.12)" : "none",
                            }}
                          >
                            {/* CHECKBOX INDICATOR TOP-LEFT */}
                            <div
                              style={{
                                position: "absolute",
                                top: "6px",
                                left: "6px",
                                width: "18px",
                                height: "18px",
                                borderRadius: "4px",
                                border: isSelected ? "none" : "1.5px solid #cbd5e1",
                                background: isSelected ? "#2563eb" : "#ffffff",
                                display: "flex",
                                alignItems: "center",
                                justifyContent: "center",
                                color: "#ffffff",
                                fontSize: "0.72rem",
                                fontWeight: 800,
                              }}
                            >
                              {isSelected ? "✓" : ""}
                            </div>

                            {/* SMARTPHONE IMAGE */}
                            <img
                              src={m.image}
                              alt={m.name}
                              style={{
                                width: "58px",
                                height: "76px",
                                objectFit: "contain",
                                marginBottom: "8px",
                                filter: "drop-shadow(0 4px 6px rgba(0,0,0,0.06))",
                              }}
                            />

                            <strong style={{ fontSize: "0.84rem", color: "#0f172a", textAlign: "center", display: "block" }}>
                              {m.name}
                            </strong>
                            <span style={{ fontSize: "0.72rem", color: "#94a3b8", textAlign: "center" }}>
                              ({m.year})
                            </span>
                          </div>
                        )
                      })}
                    </div>
                  )}
                </div>

                {/* 2. CHỌN DỊCH VỤ SỬA CHỮA */}
                <div>
                  <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "4px" }}>
                    <div style={{ width: "24px", height: "24px", borderRadius: "50%", background: "#2563eb", color: "#ffffff", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "0.8rem", fontWeight: 800 }}>
                      2
                    </div>
                    <h2 style={{ fontSize: "1.05rem", fontWeight: 800, color: "#0f172a", margin: 0 }}>
                      Chọn dịch vụ sửa chữa
                    </h2>
                  </div>
                  <p style={{ fontSize: "0.82rem", color: "#64748b", margin: "0 0 18px 34px" }}>
                    Chọn một hoặc nhiều dịch vụ cần sửa chữa cho {selectedModelName}. Bạn có thể chọn nhiều dịch vụ cùng lúc.
                  </p>

                  {/* 9 REPAIR SERVICE CARDS */}
                  <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "14px" }}>
                    {SERVICE_TEMPLATES.map((svc) => {
                      const isChecked = selectedServiceNames.includes(svc.name)
                      return (
                        <div
                          key={svc.key}
                          onClick={() => toggleService(svc.name)}
                          style={{
                            background: isChecked ? "#eff6ff" : "#ffffff",
                            border: isChecked ? "1.5px solid #2563eb" : "1px solid #e2e8f0",
                            borderRadius: "14px",
                            padding: "14px",
                            display: "flex",
                            flexDirection: "column",
                            justifyContent: "space-between",
                            cursor: "pointer",
                            position: "relative",
                            transition: "all 0.15s ease",
                            minHeight: "115px",
                          }}
                        >
                          <div style={{ display: "flex", alignItems: "flex-start", gap: "10px" }}>
                            <div
                              style={{
                                width: "18px",
                                height: "18px",
                                borderRadius: "4px",
                                border: isChecked ? "none" : "1.5px solid #cbd5e1",
                                background: isChecked ? "#2563eb" : "#ffffff",
                                display: "flex",
                                alignItems: "center",
                                justifyContent: "center",
                                color: "#ffffff",
                                fontSize: "0.72rem",
                                fontWeight: 800,
                                flexShrink: 0,
                                marginTop: "2px",
                              }}
                            >
                              {isChecked ? "✓" : ""}
                            </div>

                            <div
                              style={{
                                width: "36px",
                                height: "36px",
                                borderRadius: "8px",
                                background: svc.iconBg,
                                display: "flex",
                                alignItems: "center",
                                justifyContent: "center",
                                fontSize: "1.2rem",
                                flexShrink: 0,
                              }}
                            >
                              {SERVICE_ICONS[svc.key] ? (
                                <img src={SERVICE_ICONS[svc.key]} alt={svc.name} style={{ width: "20px", height: "20px" }} />
                              ) : (
                                svc.icon
                              )}
                            </div>

                            <div style={{ flex: 1 }}>
                              <h3 style={{ fontSize: "0.92rem", fontWeight: 800, color: "#0f172a", margin: "0 0 4px" }}>
                                {svc.name}
                              </h3>
                              <p style={{ fontSize: "0.75rem", color: "#64748b", margin: 0, lineHeight: 1.35 }}>
                                {svc.desc}
                              </p>
                            </div>
                          </div>

                          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginTop: "12px", paddingLeft: "28px" }}>
                            <strong style={{ fontSize: "0.95rem", fontWeight: 800, color: "#0f172a" }}>
                              {formatVnd(svc.price)}
                            </strong>
                            {svc.isPopular && (
                              <span style={{ fontSize: "0.68rem", fontWeight: 700, color: "#dc2626", background: "#fef2f2", padding: "2px 8px", borderRadius: "999px", border: "1px solid #fecaca" }}>
                                Phổ biến
                              </span>
                            )}
                          </div>
                        </div>
                      )
                    })}
                  </div>
                </div>
              </div>
            )}

            {/* ================= STEP 1: CHỌN CHI NHÁNH ================= */}
            {activeStep === 1 && (
              <div>
                <h2 style={{ fontSize: "1.25rem", fontWeight: 800, color: "#0f172a", margin: "0 0 6px" }}>
                  Bước 2: Chọn chi nhánh
                </h2>
                <p style={{ fontSize: "0.86rem", color: "#64748b", margin: "0 0 20px" }}>
                  Chọn chi nhánh thuận tiện nhất để mang máy đến sửa chữa:
                </p>

                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "18px", alignItems: "stretch" }}>
                    {/* BRANCH CARDS LIST */}
                    <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
                      {effectiveBranches.map((b) => {
                        const isSelected = selectedBranchId === b.id
                        return (
                          <div
                            key={b.id}
                            onClick={() => setSelectedBranchId(b.id)}
                            style={{
                              background: isSelected ? "#f0f7ff" : "#ffffff",
                              border: isSelected ? "1.5px solid #2563eb" : "1px solid #e2e8f0",
                              borderRadius: "14px",
                              padding: "12px 14px",
                              display: "flex",
                              alignItems: "center",
                              gap: "12px",
                              cursor: "pointer",
                              transition: "all 0.15s ease",
                              boxShadow: isSelected ? "0 4px 14px rgba(37,99,235,0.08)" : "none",
                            }}
                          >
                            {/* RADIO BUTTON */}
                            <div
                              style={{
                                width: "18px",
                                height: "18px",
                                borderRadius: "50%",
                                border: isSelected ? "5px solid #2563eb" : "2px solid #cbd5e1",
                                background: "#ffffff",
                                flexShrink: 0,
                              }}
                            />

                            {/* STORE THUMBNAIL */}
                            <img
                              src={b.image}
                              alt={b.name}
                              style={{
                                width: "52px",
                                height: "52px",
                                borderRadius: "8px",
                                objectFit: "cover",
                                flexShrink: 0,
                              }}
                            />

                            {/* BRANCH INFO */}
                            <div style={{ flex: 1, minWidth: 0 }}>
                              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "3px" }}>
                                <strong style={{ fontSize: "0.92rem", color: "#0f172a", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                                  {b.name}
                                </strong>
                                <span style={{ fontSize: "0.75rem", color: "#2563eb", fontWeight: 600, display: "flex", alignItems: "center", gap: "2px" }}>
                                  📍 {b.distance}
                                </span>
                              </div>

                              <p style={{ fontSize: "0.76rem", color: "#64748b", margin: "0 0 6px", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                                {b.address}
                              </p>

                              <div style={{ display: "flex", alignItems: "center", gap: "10px", fontSize: "0.74rem", color: "#64748b", marginBottom: "6px" }}>
                                <span>🕒 {b.hours}</span>
                                <span>📞 {b.phone}</span>
                              </div>

                              {/* TAGS */}
                              <div style={{ display: "flex", gap: "6px" }}>
                                {b.tags.map((t) => (
                                  <span
                                    key={t.text}
                                    style={{
                                      fontSize: "0.68rem",
                                      fontWeight: 700,
                                      background: t.bg,
                                      color: t.color,
                                      padding: "2px 8px",
                                      borderRadius: "6px",
                                    }}
                                  >
                                    {t.text}
                                  </span>
                                ))}
                              </div>
                            </div>
                          </div>
                        )
                      })}
                    </div>

                    {/* REAL GOOGLE MAP PREVIEW */}
                    <div
                      style={{
                        background: "#ffffff",
                        borderRadius: "14px",
                        border: "1px solid #cbd5e1",
                        overflow: "hidden",
                        minHeight: "360px",
                        boxShadow: "0 2px 10px rgba(0,0,0,0.04)",
                        display: "flex",
                        flexDirection: "column",
                      }}
                    >
                      <div
                        style={{
                          padding: "10px 14px",
                          background: "#f8fafc",
                          borderBottom: "1px solid #e2e8f0",
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "space-between",
                        }}
                      >
                        <div style={{ display: "flex", alignItems: "center", gap: "6px", fontSize: "0.82rem" }}>
                          <span style={{ color: "#2563eb", fontWeight: 700 }}>📍 Google Maps:</span>
                          <strong style={{ color: "#0f172a" }}>{activeBranch.name}</strong>
                        </div>
                        <a
                          href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
                            `${activeBranch.name}, ${activeBranch.address}`
                          )}`}
                          target="_blank"
                          rel="noreferrer"
                          style={{
                            fontSize: "0.76rem",
                            color: "#2563eb",
                            textDecoration: "none",
                            fontWeight: 600,
                          }}
                        >
                          Mở bản đồ lớn ↗
                        </a>
                      </div>

                      <iframe
                        title={`Bản đồ ${activeBranch.name}`}
                        width="100%"
                        height="100%"
                        style={{ border: 0, flex: 1, minHeight: "320px", display: "block" }}
                        loading="lazy"
                        allowFullScreen
                        referrerPolicy="no-referrer-when-downgrade"
                        src={`https://maps.google.com/maps?q=${encodeURIComponent(
                          `${activeBranch.name}, ${activeBranch.address}`
                        )}&t=&z=15&ie=UTF8&iwloc=&output=embed`}
                      />
                    </div>
                  </div>
                </div>
            )}

            {/* ================= STEP 2: CHỌN NGÀY VÀ GIỜ ================= */}
            {activeStep === 2 && (
              <div>
                <h2 style={{ fontSize: "1.25rem", fontWeight: 800, color: "#0f172a", margin: "0 0 6px" }}>
                  Bước 3: Chọn ngày và giờ
                </h2>
                <p style={{ fontSize: "0.86rem", color: "#64748b", margin: "0 0 16px" }}>
                  Chọn ngày phù hợp và khung giờ đến cửa hàng:
                </p>

                {/* SELECTED BRANCH BANNER */}
                <div
                  style={{
                    background: "#eff6ff",
                    border: "1px solid #bfdbfe",
                    borderRadius: "12px",
                    padding: "12px 16px",
                    marginBottom: "20px",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                  }}
                >
                  <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                    <span style={{ fontSize: "1.2rem" }}>📍</span>
                    <div>
                      <strong style={{ fontSize: "0.9rem", color: "#1e3a8a", display: "block" }}>
                        Chi nhánh đã chọn: {activeBranch.name}
                      </strong>
                      <span style={{ fontSize: "0.78rem", color: "#3b82f6" }}>
                        {activeBranch.address} • Hotline: {activeBranch.phone}
                      </span>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => setActiveStep(1)}
                    style={{
                      background: "#ffffff",
                      border: "1px solid #bfdbfe",
                      color: "#2563eb",
                      borderRadius: "8px",
                      padding: "6px 12px",
                      fontSize: "0.78rem",
                      fontWeight: 700,
                      cursor: "pointer",
                    }}
                  >
                    Đổi chi nhánh
                  </button>
                </div>

                  <div style={{ display: "grid", gridTemplateColumns: "310px 1fr", gap: "20px" }}>
                    {/* LEFT: MINI CALENDAR CARD */}
                    <div style={{ background: "#ffffff", border: "1px solid #e2e8f0", borderRadius: "14px", padding: "16px" }}>
                      {/* MONTH NAVIGATION HEADER */}
                      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "16px" }}>
                        <button
                          type="button"
                          onClick={() => {
                            if (calendarMonth === 0) {
                              setCalendarMonth(11)
                              setCalendarYear((y) => y - 1)
                            } else {
                              setCalendarMonth((m) => m - 1)
                            }
                          }}
                          style={{ background: "none", border: "none", fontSize: "1.1rem", cursor: "pointer", color: "#64748b", padding: "0 6px" }}
                        >
                          ‹
                        </button>

                        <strong style={{ fontSize: "0.92rem", fontWeight: 800, color: "#0f172a" }}>
                          Tháng {calendarMonth + 1}, {calendarYear}
                        </strong>

                        <button
                          type="button"
                          onClick={() => {
                            if (calendarMonth === 11) {
                              setCalendarMonth(0)
                              setCalendarYear((y) => y + 1)
                            } else {
                              setCalendarMonth((m) => m + 1)
                            }
                          }}
                          style={{ background: "none", border: "none", fontSize: "1.1rem", cursor: "pointer", color: "#64748b", padding: "0 6px" }}
                        >
                          ›
                        </button>
                      </div>

                      {/* WEEKDAYS HEADER (T2 -> CN) */}
                      <div style={{ display: "grid", gridTemplateColumns: "repeat(7, 1fr)", gap: "4px", textAlign: "center", marginBottom: "8px" }}>
                        {["T2", "T3", "T4", "T5", "T6", "T7", "CN"].map((w) => (
                          <span key={w} style={{ fontSize: "0.74rem", fontWeight: 700, color: "#94a3b8" }}>
                            {w}
                          </span>
                        ))}
                      </div>

                      {/* DAYS GRID */}
                      <div style={{ display: "grid", gridTemplateColumns: "repeat(7, 1fr)", gap: "4px", textAlign: "center" }}>
                        {calendarDays.map((item, idx) => {
                          const isSelectedDate = item.isCurrentMonth && item.dateStr === appointmentDate
                          return (
                            <button
                              key={idx}
                              type="button"
                              disabled={!item.isCurrentMonth}
                              onClick={() => {
                                if (item.isCurrentMonth) {
                                  setAppointmentDate(item.dateStr)
                                }
                              }}
                              style={{
                                width: "34px",
                                height: "34px",
                                margin: "0 auto",
                                borderRadius: "50%",
                                border: "none",
                                background: isSelectedDate ? "#2563eb" : "transparent",
                                color: isSelectedDate ? "#ffffff" : item.isCurrentMonth ? "#1e293b" : "#cbd5e1",
                                fontWeight: isSelectedDate ? 800 : 500,
                                fontSize: "0.82rem",
                                cursor: item.isCurrentMonth ? "pointer" : "default",
                                display: "flex",
                                alignItems: "center",
                                justifyContent: "center",
                                transition: "all 0.15s ease",
                              }}
                            >
                              {item.day}
                            </button>
                          )
                        })}
                      </div>
                    </div>

                    {/* RIGHT: TIME SLOTS PICKER */}
                    <div style={{ background: "#ffffff", border: "1px solid #e2e8f0", borderRadius: "14px", padding: "16px" }}>
                      {/* DATE TITLE & LEGEND */}
                      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "14px", flexWrap: "wrap", gap: "8px" }}>
                        <strong style={{ fontSize: "0.95rem", fontWeight: 800, color: "#0f172a" }}>
                          {formatVietnameseDate(appointmentDate)}
                        </strong>

                        {/* LEGEND */}
                        <div style={{ display: "flex", alignItems: "center", gap: "12px", fontSize: "0.74rem" }}>
                          <span style={{ display: "flex", alignItems: "center", gap: "4px", color: "#16a34a" }}>
                            <span style={{ width: "8px", height: "8px", borderRadius: "50%", background: "#16a34a" }} />
                            Còn trống
                          </span>
                          <span style={{ display: "flex", alignItems: "center", gap: "4px", color: "#2563eb" }}>
                            <span style={{ width: "8px", height: "8px", borderRadius: "50%", background: "#2563eb" }} />
                            Đang chọn
                          </span>
                          <span style={{ display: "flex", alignItems: "center", gap: "4px", color: "#94a3b8" }}>
                            <span style={{ width: "8px", height: "8px", borderRadius: "50%", background: "#cbd5e1" }} />
                            Đã đầy
                          </span>
                        </div>
                      </div>

                      {/* 18 SLOTS GRID (4 COLUMNS MATCHING SCREENSHOT) */}
                      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: "8px" }}>
                        {effectiveSlots.map((s) => {
                          const isSelected = selectedSlot === s.start
                          const isFull = s.isFull
                          return (
                            <button
                              key={s.start}
                              type="button"
                              disabled={isFull}
                              onClick={() => setSelectedSlot(s.start)}
                              style={{
                                padding: "9px 6px",
                                borderRadius: "8px",
                                border: isSelected ? "1.5px solid #2563eb" : isFull ? "1px solid #f1f5f9" : "1px solid #e2e8f0",
                                background: isSelected ? "#2563eb" : isFull ? "#f8fafc" : "#ffffff",
                                color: isSelected ? "#ffffff" : isFull ? "#94a3b8" : "#0f172a",
                                fontWeight: isSelected ? 800 : 600,
                                fontSize: "0.82rem",
                                cursor: isFull ? "not-allowed" : "pointer",
                                textAlign: "center",
                                transition: "all 0.15s ease",
                                display: "flex",
                                flexDirection: "column",
                                alignItems: "center",
                                justifyContent: "center",
                                minHeight: "42px",
                              }}
                            >
                              <span>{s.start}</span>
                              {isFull && (
                                <span style={{ fontSize: "0.65rem", color: "#94a3b8", marginTop: "1px" }}>
                                  Đã đầy
                                </span>
                              )}
                            </button>
                          )
                        })}
                      </div>
                    </div>
                  </div>
                </div>
            )}

            {/* ================= STEP 3: THÔNG TIN KHÁCH HÀNG ================= */}
            {activeStep === 3 && (
              <div>
                <h2 style={{ fontSize: "1.25rem", fontWeight: 800, color: "#0f172a", marginBottom: "6px" }}>
                  Bước 4: Thông tin khách hàng & mô tả lỗi
                </h2>
                <p style={{ fontSize: "0.86rem", color: "#64748b", marginBottom: "20px" }}>
                  Cung cấp thông tin liên hệ và mô tả ngắn gọn về tình trạng máy:
                </p>

                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "16px", marginBottom: "18px" }}>
                  <div>
                    <label style={{ display: "block", fontSize: "0.85rem", fontWeight: 700, color: "#0f172a", marginBottom: "6px" }}>
                      Họ và tên
                    </label>
                    <input
                      type="text"
                      value={customerName}
                      onChange={(e) => setCustomerName(e.target.value)}
                      style={{ width: "100%", padding: "10px 14px", borderRadius: "10px", border: "1px solid #cbd5e1", fontSize: "0.88rem" }}
                    />
                  </div>
                  <div>
                    <label style={{ display: "block", fontSize: "0.85rem", fontWeight: 700, color: "#0f172a", marginBottom: "6px" }}>
                      Số điện thoại <span style={{ color: "#ef4444" }}>*</span>
                    </label>
                    <input
                      type="tel"
                      value={customerPhone}
                      placeholder="Nhập số điện thoại liên hệ"
                      onChange={(e) => setCustomerPhone(e.target.value)}
                      style={{ width: "100%", padding: "10px 14px", borderRadius: "10px", border: "1px solid #cbd5e1", fontSize: "0.88rem" }}
                    />
                  </div>
                </div>

                <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "12px", marginBottom: "18px" }}>
                  <div>
                    <label style={{ display: "block", fontSize: "0.8rem", fontWeight: 700, color: "#0f172a", marginBottom: "6px" }}>
                      Dung lượng <span style={{ fontSize: "0.75rem", color: "#64748b", fontWeight: 400 }}>(tùy chọn)</span>
                    </label>
                    <select
                      value={selectedStorage}
                      onChange={(e) => setSelectedStorage(e.target.value)}
                      style={{ width: "100%", padding: "8px 12px", borderRadius: "8px", border: "1px solid #cbd5e1", fontSize: "0.85rem" }}
                    >
                      <option value="">-- Chọn dung lượng --</option>
                      <option value="64GB">64GB</option>
                      <option value="128GB">128GB</option>
                      <option value="256GB">256GB</option>
                      <option value="512GB">512GB</option>
                      <option value="1TB">1TB</option>
                    </select>
                  </div>
                  <div>
                    <label style={{ display: "block", fontSize: "0.8rem", fontWeight: 700, color: "#0f172a", marginBottom: "6px" }}>
                      Màu sắc <span style={{ fontSize: "0.75rem", color: "#64748b", fontWeight: 400 }}>(tùy chọn)</span>
                    </label>
                    <input
                      type="text"
                      placeholder="VD: Đen, Trắng, Tự nhiên..."
                      value={selectedColor}
                      onChange={(e) => setSelectedColor(e.target.value)}
                      style={{ width: "100%", padding: "8px 12px", borderRadius: "8px", border: "1px solid #cbd5e1", fontSize: "0.85rem" }}
                    />
                  </div>
                  <div>
                    <label style={{ display: "block", fontSize: "0.8rem", fontWeight: 700, color: "#0f172a", marginBottom: "6px" }}>
                      Tình trạng sơ bộ <span style={{ fontSize: "0.75rem", color: "#64748b", fontWeight: 400 }}>(tùy chọn)</span>
                    </label>
                    <input
                      type="text"
                      placeholder="VD: Còn nguồn, vỡ kính..."
                      value={selectedCondition}
                      onChange={(e) => setSelectedCondition(e.target.value)}
                      style={{ width: "100%", padding: "8px 12px", borderRadius: "8px", border: "1px solid #cbd5e1", fontSize: "0.85rem" }}
                    />
                  </div>
                </div>

                <div style={{ marginBottom: "20px" }}>
                  <label style={{ display: "block", fontSize: "0.85rem", fontWeight: 700, color: "#0f172a", marginBottom: "6px" }}>
                    Mô tả chi tiết tình trạng lỗi của thiết bị <span style={{ color: "#ef4444" }}>*</span>
                  </label>
                  <textarea
                    rows={4}
                    value={problemDescription}
                    onChange={(e) => setProblemDescription(e.target.value)}
                    placeholder="Ví dụ: Rơi nứt kính, pin chai nhanh, màn hình xuất hiện sọc xanh..."
                    style={{ width: "100%", padding: "12px", borderRadius: "10px", border: "1px solid #cbd5e1", fontSize: "0.88rem", resize: "vertical" }}
                  />
                </div>
              </div>
            )}

            {/* ================= STEP 4: XÁC NHẬN LỊCH HẸN ================= */}
            {activeStep === 4 && (
              <div>
                <h2 style={{ fontSize: "1.25rem", fontWeight: 800, color: "#0f172a", marginBottom: "6px" }}>
                  Bước 5: Xác nhận thông tin lịch hẹn
                </h2>
                <p style={{ fontSize: "0.86rem", color: "#64748b", marginBottom: "20px" }}>
                  Vui lòng kiểm tra lại toàn bộ thông tin trước khi hoàn tất đặt chỗ:
                </p>

                <div style={{ background: "#f8fafc", border: "1px solid #e2e8f0", borderRadius: "14px", padding: "20px", display: "grid", gridTemplateColumns: "1fr 1fr", gap: "16px", marginBottom: "20px" }}>
                  <div>
                    <span style={{ fontSize: "0.8rem", color: "#64748b", display: "block" }}>Khách hàng:</span>
                    <strong style={{ fontSize: "0.95rem", color: "#0f172a" }}>{customerName || "Khách hàng"}</strong>
                    <div style={{ fontSize: "0.85rem", color: "#0f172a" }}>{customerPhone || "Chưa có SĐT"}</div>
                  </div>
                  <div>
                    <span style={{ fontSize: "0.8rem", color: "#64748b", display: "block" }}>Thiết bị:</span>
                    <strong style={{ fontSize: "0.95rem", color: "#0f172a" }}>{selectedModelName} ({selectedBrandName})</strong>
                    {(selectedStorage || selectedColor) ? (
                      <div style={{ fontSize: "0.82rem", color: "#64748b" }}>
                        {[selectedStorage, selectedColor].filter(Boolean).join(" - ")}
                      </div>
                    ) : null}
                    {selectedCondition ? (
                      <div style={{ fontSize: "0.8rem", color: "#64748b", fontStyle: "italic", marginTop: "2px" }}>
                        Tình trạng: {selectedCondition}
                      </div>
                    ) : null}
                  </div>
                  <div>
                    <span style={{ fontSize: "0.8rem", color: "#64748b", display: "block" }}>Chi nhánh tiếp nhận:</span>
                    <strong style={{ fontSize: "0.95rem", color: "#0f172a" }}>{activeBranch.name}</strong>
                    <div style={{ fontSize: "0.82rem", color: "#64748b" }}>{activeBranch.address}</div>
                  </div>
                  <div>
                    <span style={{ fontSize: "0.8rem", color: "#64748b", display: "block" }}>Thời gian hẹn:</span>
                    <strong style={{ fontSize: "0.95rem", color: "#2563eb" }}>{formatVietnameseDate(appointmentDate)}</strong>
                    <div style={{ fontSize: "0.85rem", fontWeight: 700, color: "#2563eb" }}>{activeSlotObj.start} - {activeSlotObj.end}</div>
                  </div>
                </div>

                <div style={{ marginBottom: "20px" }}>
                  <span style={{ fontSize: "0.8rem", color: "#64748b", display: "block", marginBottom: "4px" }}>Mô tả lỗi:</span>
                  <div style={{ background: "#ffffff", border: "1px solid #e2e8f0", borderRadius: "10px", padding: "12px", fontSize: "0.88rem", color: "#334155" }}>
                    {problemDescription}
                  </div>
                </div>

                {!token && (
                  <div style={{ background: "#fef3c7", border: "1px solid #fde68a", borderRadius: "10px", padding: "14px", color: "#92400e", fontSize: "0.85rem", marginBottom: "20px" }}>
                    Bạn chưa đăng nhập. Vui lòng{" "}
                    <button
                      type="button"
                      onClick={() => openAuthModal("login")}
                      style={{ background: "none", border: "none", color: "#2563eb", fontWeight: 700, textDecoration: "underline", cursor: "pointer", padding: 0 }}
                    >
                      Đăng nhập tài khoản
                    </button>{" "}
                    để hoàn tất gửi yêu cầu đặt lịch và theo dõi tiến độ sửa chữa.
                  </div>
                )}
              </div>
            )}
          </div>

          {/* RIGHT COLUMN: STICKY BOOKING SUMMARY (MATCHING SCREENSHOT 2) */}
          <aside
            style={{
              background: "#ffffff",
              border: "1px solid #e2e8f0",
              borderRadius: "20px",
              padding: "22px",
              position: "sticky",
              top: "90px",
              boxShadow: "0 2px 10px rgba(15,23,42,0.03)",
            }}
          >
            {/* HEADER */}
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "16px", borderBottom: "1px solid #f1f5f9", paddingBottom: "12px" }}>
              <h3 style={{ fontSize: "1.1rem", fontWeight: 800, color: "#0f172a", margin: 0 }}>
                Thông tin đặt lịch
              </h3>
              <button
                type="button"
                onClick={() => setActiveStep(0)}
                style={{ background: "none", border: "none", color: "#2563eb", fontSize: "0.82rem", fontWeight: 600, cursor: "pointer", display: "flex", alignItems: "center", gap: "4px" }}
              >
                <span>✏️ Chỉnh sửa</span>
              </button>
            </div>

            {/* BLOCK 1: THIẾT BỊ CỦA BẠN */}
            <div style={{ marginBottom: "16px" }}>
              <span style={{ fontSize: "0.82rem", fontWeight: 700, color: "#0f172a", display: "block", marginBottom: "6px" }}>
                Thiết bị
              </span>
              <div
                style={{
                  background: "#f8fafc",
                  border: "1px solid #e2e8f0",
                  borderRadius: "12px",
                  padding: "10px 12px",
                  display: "flex",
                  alignItems: "flex-start",
                  gap: "12px",
                }}
              >
                <img
                  src={
                    (BRAND_MODELS_CATALOG[selectedBrandName] || []).find((m) => m.name.toLowerCase() === selectedModelName.toLowerCase())?.image ||
                    getPhoneImage(selectedModelName) ||
                    getPhoneImage(selectedBrandName)
                  }
                  alt={selectedModelName}
                  style={{ width: "36px", height: "46px", objectFit: "contain", flexShrink: 0 }}
                />
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: "6px", marginBottom: "4px" }}>
                    <strong style={{ fontSize: "0.92rem", color: "#0f172a" }}>{selectedModelName}</strong>
                    <span style={{ fontSize: "0.68rem", background: "#e2e8f0", color: "#475569", padding: "1px 6px", borderRadius: "4px" }}>
                      {selectedBrandName}
                    </span>
                  </div>

                  {(selectedStorage || selectedColor || selectedCondition) ? (
                    <div style={{ fontSize: "0.74rem", color: "#64748b", display: "flex", flexDirection: "column", gap: "2px", marginTop: "6px", borderTop: "1px dashed #e2e8f0", paddingTop: "6px" }}>
                      {selectedStorage ? (
                        <div style={{ display: "flex", justifyContent: "space-between" }}>
                          <span>Dung lượng</span>
                          <strong style={{ color: "#334155" }}>{selectedStorage}</strong>
                        </div>
                      ) : null}
                      {selectedColor ? (
                        <div style={{ display: "flex", justifyContent: "space-between" }}>
                          <span>Màu sắc</span>
                          <strong style={{ color: "#334155" }}>{selectedColor}</strong>
                        </div>
                      ) : null}
                      {selectedCondition ? (
                        <div style={{ display: "flex", justifyContent: "space-between" }}>
                          <span>Tình trạng</span>
                          <strong style={{ color: "#334155", textAlign: "right" }}>{selectedCondition}</strong>
                        </div>
                      ) : null}
                    </div>
                  ) : null}
                </div>
              </div>
            </div>

            {/* BLOCK 2: DỊCH VỤ SỬA CHỮA */}
            <div style={{ marginBottom: "16px" }}>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "8px" }}>
                <span style={{ fontSize: "0.82rem", fontWeight: 700, color: "#0f172a" }}>
                  Dịch vụ sửa chữa
                </span>
              </div>

              {selectedServiceNames.length === 0 ? (
                <p style={{ fontSize: "0.78rem", color: "#94a3b8", margin: 0, fontStyle: "italic" }}>
                  Chưa chọn dịch vụ nào
                </p>
              ) : (
                <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
                  {selectedServiceNames.map((sName) => {
                    const template = SERVICE_TEMPLATES.find((t) => t.name === sName)
                    return (
                      <div
                        key={sName}
                        style={{
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "space-between",
                          padding: "6px 0",
                          borderBottom: "1px dashed #f1f5f9",
                        }}
                      >
                        <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                          {/* RED X / DELETE BUTTON (MATCHING SCREENSHOT) */}
                          <button
                            type="button"
                            onClick={() => removeService(sName)}
                            title="Xóa dịch vụ"
                            style={{
                              width: "18px",
                              height: "18px",
                              borderRadius: "4px",
                              background: "#ef4444",
                              border: "none",
                              color: "#ffffff",
                              fontSize: "0.7rem",
                              fontWeight: 800,
                              cursor: "pointer",
                              display: "flex",
                              alignItems: "center",
                              justifyContent: "center",
                              padding: 0,
                            }}
                          >
                            ✕
                          </button>
                          <div>
                            <span style={{ fontSize: "0.84rem", fontWeight: 700, color: "#0f172a", display: "block" }}>
                              {sName}
                            </span>
                            <span style={{ fontSize: "0.72rem", color: "#94a3b8" }}>
                              Linh kiện chính hãng
                            </span>
                          </div>
                        </div>

                        <strong style={{ fontSize: "0.86rem", color: "#0f172a" }}>
                          {formatVnd(template?.price ?? 0)}
                        </strong>
                      </div>
                    )
                  })}
                </div>
              )}
            </div>

            {/* BLOCK 3: TẠM TÍNH, GIẢM GIÁ & TỔNG CỘNG */}
            <div style={{ borderTop: "1px solid #f1f5f9", paddingTop: "12px", marginBottom: "16px" }}>
              <div style={{ display: "flex", justifyContent: "space-between", fontSize: "0.82rem", color: "#64748b", marginBottom: "6px" }}>
                <span>Tạm tính</span>
                <strong style={{ color: "#0f172a" }}>{formatVnd(totalAmount)}</strong>
              </div>
              <div style={{ display: "flex", justifyContent: "space-between", fontSize: "0.82rem", color: "#64748b", marginBottom: "10px" }}>
                <span>Giảm giá</span>
                <span style={{ color: "#0f172a" }}>- 0đ</span>
              </div>
              <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", paddingTop: "8px", borderTop: "1px dashed #e2e8f0" }}>
                <span style={{ fontSize: "0.95rem", fontWeight: 800, color: "#0f172a" }}>Tổng cộng</span>
                <strong style={{ fontSize: "1.35rem", fontWeight: 900, color: "#2563eb" }}>
                  {formatVnd(totalAmount)}
                </strong>
              </div>
            </div>

            {/* BLOCK 4: CHI NHÁNH & NGÀY GIỜ (WHEN ON STEP 1 OR LATER) */}
            {activeStep >= 1 && (
              <div style={{ borderTop: "1px solid #f1f5f9", paddingTop: "12px", marginBottom: "14px" }}>
                {/* CHI NHÁNH */}
                <div style={{ marginBottom: "12px" }}>
                  <span style={{ fontSize: "0.8rem", fontWeight: 700, color: "#0f172a", display: "block", marginBottom: "6px" }}>
                    Chi nhánh
                  </span>
                  <div style={{ display: "flex", alignItems: "center", gap: "10px", background: "#f8fafc", padding: "8px 10px", borderRadius: "10px", border: "1px solid #e2e8f0" }}>
                    <img
                      src={activeBranch.image}
                      alt={activeBranch.name}
                      style={{ width: "36px", height: "36px", borderRadius: "6px", objectFit: "cover" }}
                    />
                    <div>
                      <strong style={{ fontSize: "0.84rem", color: "#0f172a", display: "block" }}>{activeBranch.name}</strong>
                      <span style={{ fontSize: "0.72rem", color: "#64748b" }}>📍 {activeBranch.address}</span>
                    </div>
                  </div>
                </div>

                {/* NGÀY & GIỜ (CHỈ HIỂN THỊ TỪ BƯỚC 3 TRỞ ĐI) */}
                {activeStep >= 2 && (
                  <div>
                    <span style={{ fontSize: "0.8rem", fontWeight: 700, color: "#0f172a", display: "block", marginBottom: "6px" }}>
                      Ngày & giờ
                    </span>
                    <div style={{ background: "#f8fafc", padding: "8px 10px", borderRadius: "10px", border: "1px solid #e2e8f0", fontSize: "0.82rem", color: "#334155" }}>
                      <div style={{ display: "flex", alignItems: "center", gap: "6px", marginBottom: "4px" }}>
                        <span>📅</span>
                        <strong style={{ color: "#0f172a" }}>{formatVietnameseDate(appointmentDate)}</strong>
                      </div>
                      <div style={{ display: "flex", alignItems: "center", gap: "6px" }}>
                        <span>🕒</span>
                        <strong style={{ color: "#2563eb" }}>{activeSlotObj.start} - {activeSlotObj.end}</strong>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* INFO ALERT BOX */}
            <div
              style={{
                background: "#f0f9ff",
                border: "1px solid #bae6fd",
                borderRadius: "10px",
                padding: "10px 12px",
                display: "flex",
                gap: "8px",
                fontSize: "0.72rem",
                color: "#0369a1",
                lineHeight: 1.45,
                marginBottom: "18px",
              }}
            >
              <span>ℹ️</span>
              <span>
                Vui lòng đến đúng giờ hẹn. Nếu có thay đổi, bạn có thể hủy hoặc đổi lịch trước 2 giờ.
              </span>
            </div>

            {/* ACTION BUTTONS (QUAY LẠI & TIẾP TỤC) */}
            {activeStep < 5 && (
              <div style={{ display: "flex", gap: "10px" }}>
                <button
                  type="button"
                  disabled={activeStep === 0}
                  onClick={handlePrevStep}
                  style={{
                    height: "42px",
                    padding: "0 18px",
                    borderRadius: "10px",
                    border: "1px solid #cbd5e1",
                    background: "#ffffff",
                    color: activeStep === 0 ? "#94a3b8" : "#334155",
                    fontSize: "0.86rem",
                    fontWeight: 600,
                    cursor: activeStep === 0 ? "not-allowed" : "pointer",
                  }}
                >
                  Quay lại
                </button>
                <button
                  type="button"
                  disabled={saving}
                  onClick={handleNextStep}
                  style={{
                    flex: 1,
                    height: "42px",
                    borderRadius: "10px",
                    border: "none",
                    background: "#2563eb",
                    color: "#ffffff",
                    fontSize: "0.88rem",
                    fontWeight: 700,
                    cursor: saving ? "wait" : "pointer",
                    boxShadow: "0 4px 12px rgba(37,99,235,0.3)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    gap: "6px",
                  }}
                >
                  <span>{activeStep === 4 ? (saving ? "Đang xử lý..." : "Xác nhận đặt lịch") : "Tiếp tục"}</span>
                  <span>&gt;</span>
                </button>
              </div>
            )}
          </aside>
        </div>
      </div>
    </main>
  )
}
