namespace PhoneRepairBooking.Api.Domain;

public class RepairService
{
    public int Id { get; set; }

    public string Name { get; set; } = string.Empty;

    public string Slug { get; set; } = string.Empty;

    public string? Description { get; set; }

    public PricingType PricingType { get; set; }

    public bool IsActive { get; set; } = true;

    public DateTime CreatedAt { get; set; }

    public ICollection<ServicePrice> ServicePrices { get; set; } = new List<ServicePrice>();
}
