namespace PhoneRepairBooking.Api.Domain;

public class ServicePrice
{
    public int Id { get; set; }

    public int PhoneModelId { get; set; }

    public PhoneModel PhoneModel { get; set; } = null!;

    public int RepairServiceId { get; set; }

    public RepairService RepairService { get; set; } = null!;

    public decimal? Price { get; set; }

    public bool IsActive { get; set; } = true;
}
