using Microsoft.AspNetCore.Mvc;
using PhoneRepairBooking.Api.Domain;
using PhoneRepairBooking.Api.DTOs;
using PhoneRepairBooking.Api.Services;

namespace PhoneRepairBooking.Api.Controllers;

[ApiController]
[Route("api/catalog")]
public class CatalogController : ControllerBase
{
    private readonly CatalogService _catalog;

    public CatalogController(CatalogService catalog)
    {
        _catalog = catalog;
    }

    [HttpGet("brands")]
    public async Task<ActionResult<List<BrandDto>>> Brands([FromQuery] string? search)
    {
        return Ok(await _catalog.GetBrandsAsync(false, search));
    }

    [HttpGet("models")]
    public async Task<ActionResult<List<PhoneModelDto>>> Models([FromQuery] int? brandId, [FromQuery] string? search)
    {
        return Ok(await _catalog.GetModelsAsync(false, brandId, search));
    }

    [HttpGet("services")]
    public async Task<ActionResult<List<RepairServiceDto>>> Services([FromQuery] string? search, [FromQuery] PricingType? pricingType)
    {
        return Ok(await _catalog.GetServicesAsync(false, search, pricingType));
    }

    [HttpGet("prices")]
    public async Task<ActionResult<List<ServicePriceDto>>> Prices([FromQuery] int? modelId, [FromQuery] int? serviceId)
    {
        return Ok(await _catalog.GetPricesAsync(false, modelId, serviceId));
    }

    [HttpGet("search")]
    public async Task<ActionResult<List<CatalogSearchItemDto>>> Search(
        [FromQuery] string? q,
        [FromQuery] int? brandId,
        [FromQuery] PricingType? pricingType)
    {
        return Ok(await _catalog.SearchAsync(q, brandId, pricingType));
    }
}
