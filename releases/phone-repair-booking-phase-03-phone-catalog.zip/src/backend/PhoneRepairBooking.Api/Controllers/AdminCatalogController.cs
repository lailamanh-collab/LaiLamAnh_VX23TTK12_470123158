using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PhoneRepairBooking.Api.Domain;
using PhoneRepairBooking.Api.DTOs;
using PhoneRepairBooking.Api.Services;

namespace PhoneRepairBooking.Api.Controllers;

[ApiController]
[Authorize(Roles = AppRoles.Admin)]
[Route("api/admin/catalog")]
public class AdminCatalogController : ControllerBase
{
    private readonly CatalogService _catalog;

    public AdminCatalogController(CatalogService catalog)
    {
        _catalog = catalog;
    }

    [HttpGet("brands")]
    public async Task<ActionResult<List<BrandDto>>> Brands([FromQuery] string? search) =>
        Ok(await _catalog.GetBrandsAsync(true, search));

    [HttpPost("brands")]
    public async Task<IActionResult> CreateBrand(BrandRequest request) => await Write(await _catalog.CreateBrandAsync(request));

    [HttpPut("brands/{id:int}")]
    public async Task<IActionResult> UpdateBrand(int id, BrandRequest request) => await Write(await _catalog.UpdateBrandAsync(id, request));

    [HttpDelete("brands/{id:int}")]
    public async Task<IActionResult> DeleteBrand(int id)
    {
        var (ok, error, status) = await _catalog.DeleteBrandAsync(id);
        return ok ? NoContent() : StatusCode(status, error);
    }

    [HttpGet("models")]
    public async Task<ActionResult<List<PhoneModelDto>>> Models([FromQuery] int? brandId, [FromQuery] string? search) =>
        Ok(await _catalog.GetModelsAsync(true, brandId, search));

    [HttpPost("models")]
    public async Task<IActionResult> CreateModel(PhoneModelRequest request) => await Write(await _catalog.CreateModelAsync(request));

    [HttpPut("models/{id:int}")]
    public async Task<IActionResult> UpdateModel(int id, PhoneModelRequest request) => await Write(await _catalog.UpdateModelAsync(id, request));

    [HttpGet("services")]
    public async Task<ActionResult<List<RepairServiceDto>>> Services([FromQuery] string? search) =>
        Ok(await _catalog.GetServicesAsync(true, search, null));

    [HttpPost("services")]
    public async Task<IActionResult> CreateService(RepairServiceRequest request) => await Write(await _catalog.SaveServiceAsync(null, request));

    [HttpPut("services/{id:int}")]
    public async Task<IActionResult> UpdateService(int id, RepairServiceRequest request) => await Write(await _catalog.SaveServiceAsync(id, request));

    [HttpGet("prices")]
    public async Task<ActionResult<List<ServicePriceDto>>> Prices([FromQuery] int? modelId, [FromQuery] int? serviceId) =>
        Ok(await _catalog.GetPricesAsync(true, modelId, serviceId));

    [HttpPost("prices")]
    public async Task<IActionResult> CreatePrice(ServicePriceRequest request) => await Write(await _catalog.SavePriceAsync(null, request));

    [HttpPut("prices/{id:int}")]
    public async Task<IActionResult> UpdatePrice(int id, ServicePriceRequest request) => await Write(await _catalog.SavePriceAsync(id, request));

    private async Task<IActionResult> Write<T>((T? Data, ApiError? Error, int Status) result)
    {
        await Task.CompletedTask;
        if (result.Error is not null)
        {
            return StatusCode(result.Status, result.Error);
        }

        return StatusCode(result.Status, result.Data);
    }
}
