using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using PhoneRepairBooking.Api.Domain;

namespace PhoneRepairBooking.Api.Data;

public class AppDbContext : IdentityDbContext<ApplicationUser>
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
    {
    }

    public DbSet<Brand> Brands => Set<Brand>();

    public DbSet<PhoneModel> PhoneModels => Set<PhoneModel>();

    public DbSet<RepairService> RepairServices => Set<RepairService>();

    public DbSet<ServicePrice> ServicePrices => Set<ServicePrice>();

    protected override void OnModelCreating(ModelBuilder builder)
    {
        base.OnModelCreating(builder);

        builder.Entity<Brand>(entity =>
        {
            entity.Property(item => item.Name).HasMaxLength(100).IsRequired();
            entity.Property(item => item.Slug).HasMaxLength(120).IsRequired();
            entity.HasIndex(item => item.Name).IsUnique();
            entity.HasIndex(item => item.Slug).IsUnique();
        });

        builder.Entity<PhoneModel>(entity =>
        {
            entity.Property(item => item.Name).HasMaxLength(120).IsRequired();
            entity.Property(item => item.Slug).HasMaxLength(140).IsRequired();
            entity.Property(item => item.ImageUrl).HasMaxLength(500);
            entity.HasIndex(item => new { item.BrandId, item.Name }).IsUnique();
            entity.HasOne(item => item.Brand)
                .WithMany(item => item.Models)
                .HasForeignKey(item => item.BrandId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        builder.Entity<RepairService>(entity =>
        {
            entity.Property(item => item.Name).HasMaxLength(150).IsRequired();
            entity.Property(item => item.Slug).HasMaxLength(160).IsRequired();
            entity.Property(item => item.PricingType).HasConversion<string>().HasMaxLength(40);
            entity.HasIndex(item => item.Name).IsUnique();
            entity.HasIndex(item => item.Slug).IsUnique();
        });

        builder.Entity<ServicePrice>(entity =>
        {
            entity.Property(item => item.Price).HasColumnType("decimal(18,0)");
            entity.HasIndex(item => new { item.PhoneModelId, item.RepairServiceId }).IsUnique();
            entity.HasOne(item => item.PhoneModel)
                .WithMany(item => item.ServicePrices)
                .HasForeignKey(item => item.PhoneModelId)
                .OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.RepairService)
                .WithMany(item => item.ServicePrices)
                .HasForeignKey(item => item.RepairServiceId)
                .OnDelete(DeleteBehavior.Restrict);
        });
    }
}
