type SiteFooterProps = {
  databaseConnected: boolean | null
}

export function SiteFooter({ databaseConnected }: SiteFooterProps) {
  let statusText = "Đang kiểm tra kết nối hệ thống"
  let statusClass = ""

  if (databaseConnected === true) {
    statusText = "Hệ thống sẵn sàng"
    statusClass = "status-ok"
  }

  if (databaseConnected === false) {
    statusText = "Chưa kết nối được cơ sở dữ liệu"
    statusClass = "status-warn"
  }

  return (
    <footer className="site-footer">
      <div className="site-footer-inner">
        <span>PhoneRepair · Sửa chữa điện thoại tại cửa hàng</span>
        <span className={statusClass}>{statusText}</span>
      </div>
    </footer>
  )
}
