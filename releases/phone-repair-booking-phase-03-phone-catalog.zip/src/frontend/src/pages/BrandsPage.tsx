import { useEffect, useState } from "react"
import { Link } from "react-router-dom"
import { getBrands, type Brand } from "../api/catalog"

export function BrandsPage() {
  const [brands, setBrands] = useState<Brand[]>([])
  const [search, setSearch] = useState("")

  useEffect(() => {
    getBrands(search).then(setBrands).catch(() => setBrands([]))
  }, [search])

  return (
    <main className="page">
      <section className="section-head">
        <h1>Hãng điện thoại</h1>
        <p className="section-intro">Chọn hãng để xem các dòng máy đang nhận sửa.</p>
      </section>
      <label className="field toolbar-single">
        <span>Tìm hãng</span>
        <input className="input" value={search} onChange={(event) => setSearch(event.target.value)} />
      </label>
      <div className="result-list">
        {brands.map((brand) => (
          <article className="card" key={brand.id}>
            <h2>{brand.name}</h2>
            <p>{brand.modelCount} dòng máy</p>
            <Link className="text-link" to={`/dong-may?brandId=${brand.id}`}>Xem dòng máy</Link>
          </article>
        ))}
      </div>
    </main>
  )
}
