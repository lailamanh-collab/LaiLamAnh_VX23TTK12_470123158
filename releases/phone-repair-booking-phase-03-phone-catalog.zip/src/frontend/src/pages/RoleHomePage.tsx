import { useAuth } from "../auth/AuthContext"

export function RoleHomePage({ title, description }: { title: string; description: string }) {
  const { user } = useAuth()

  return (
    <main className="page">
      <section className="hero">
        <div>
          <p className="eyebrow">{title}</p>
          <h1>{user?.fullName}</h1>
          <p className="lede">{description}</p>
        </div>
      </section>
    </main>
  )
}
