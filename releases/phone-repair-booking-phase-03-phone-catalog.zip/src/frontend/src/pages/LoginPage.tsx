import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { Link, Navigate, useNavigate } from "react-router-dom"
import { z } from "zod"
import { homePathForRole, login } from "../api/auth"
import { ApiError } from "../api/client"
import { useAuth } from "../auth/AuthContext"
import { TextField } from "../components/forms/TextField"

const schema = z.object({
  email: z.string().email("Email không hợp lệ."),
  password: z.string().min(1, "Nhập mật khẩu."),
})

type LoginValues = z.infer<typeof schema>

export function LoginPage() {
  const navigate = useNavigate()
  const { user, setSession } = useAuth()
  const { register, handleSubmit, setError, formState: { errors, isSubmitting } } = useForm<LoginValues>({
    resolver: zodResolver(schema),
    defaultValues: { email: "", password: "" },
  })

  if (user) {
    return <Navigate to={homePathForRole(user.role)} replace />
  }

  async function onSubmit(values: LoginValues) {
    try {
      const result = await login(values.email, values.password)
      setSession(result.accessToken, result.user)
      navigate(homePathForRole(result.user.role))
    } catch (error) {
      const message = error instanceof ApiError ? error.message : "Không đăng nhập được."
      setError("root", { message })
    }
  }

  return (
    <main className="page narrow">
      <section className="card form-card">
        <h1>Đăng nhập</h1>
        <p className="section-intro">Dùng tài khoản khách, kỹ thuật viên hoặc quản trị.</p>
        <form className="form" onSubmit={handleSubmit(onSubmit)} noValidate>
          {errors.root ? <p className="form-error">{errors.root.message}</p> : null}
          <TextField label="Email" type="email" autoComplete="email" registration={register("email")} error={errors.email} />
          <TextField label="Mật khẩu" type="password" autoComplete="current-password" registration={register("password")} error={errors.password} />
          <button className="btn" type="submit" disabled={isSubmitting}>
            {isSubmitting ? "Đang đăng nhập..." : "Đăng nhập"}
          </button>
        </form>
        <p className="form-note">
          Chưa có tài khoản? <Link to="/dang-ky">Đăng ký</Link>
        </p>
      </section>
    </main>
  )
}
