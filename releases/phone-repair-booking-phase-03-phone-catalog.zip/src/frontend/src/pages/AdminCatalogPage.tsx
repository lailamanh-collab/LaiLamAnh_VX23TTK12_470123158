import { useEffect, useState } from "react"
import {
  adminBrands,
  adminModels,
  adminPrices,
  adminServices,
  formatPrice,
  saveBrand,
  saveModel,
  savePrice,
  saveService,
  type Brand,
  type PhoneModel,
  type PricingType,
  type RepairService,
  type ServicePrice,
} from "../api/catalog"
import { ApiError } from "../api/client"
import { useAuth } from "../auth/AuthContext"

export function AdminCatalogPage() {
  const { token } = useAuth()
  const [brands, setBrands] = useState<Brand[]>([])
  const [models, setModels] = useState<PhoneModel[]>([])
  const [services, setServices] = useState<RepairService[]>([])
  const [prices, setPrices] = useState<ServicePrice[]>([])
  const [message, setMessage] = useState("")
  const [brandName, setBrandName] = useState("")
  const [modelName, setModelName] = useState("")
  const [modelBrandId, setModelBrandId] = useState("")
  const [serviceName, setServiceName] = useState("")
  const [pricingType, setPricingType] = useState<PricingType>("FixedPrice")
  const [priceModelId, setPriceModelId] = useState("")
  const [priceServiceId, setPriceServiceId] = useState("")
  const [amount, setAmount] = useState("")

  async function reload() {
    if (!token) return
    const [brandRows, modelRows, serviceRows, priceRows] = await Promise.all([
      adminBrands(token),
      adminModels(token),
      adminServices(token),
      adminPrices(token),
    ])
    setBrands(brandRows)
    setModels(modelRows)
    setServices(serviceRows)
    setPrices(priceRows)
  }

  useEffect(() => {
    reload().catch(() => setMessage("Không tải được danh mục."))
  }, [token])

  async function run(action: () => Promise<unknown>) {
    setMessage("")
    try {
      await action()
      await reload()
      setMessage("Đã lưu.")
    } catch (error) {
      setMessage(error instanceof ApiError ? error.message : "Không lưu được.")
    }
  }

  return (
    <main className="page">
      <section className="section-head">
        <h1>Danh mục sửa chữa</h1>
        <p className="section-intro">Hãng, dòng máy, dịch vụ và giá theo từng máy.</p>
      </section>
      {message ? <p className="form-success">{message}</p> : null}
      <div className="admin-grid">
        <form className="card form" onSubmit={(event) => {
          event.preventDefault()
          if (!token) return
          void run(() => saveBrand(token, { name: brandName, description: "", isActive: true }))
        }}>
          <h2>Thêm hãng</h2>
          <input className="input" value={brandName} onChange={(event) => setBrandName(event.target.value)} placeholder="Tên hãng" />
          <button className="btn" type="submit">Lưu hãng</button>
          <ul className="plain-list">{brands.map((brand) => (
            <li key={brand.id}>
              {brand.name}{brand.isActive ? "" : " · đang tắt"}
              <button className="btn btn-quiet" type="button" onClick={() => {
                if (!token) return
                void run(() => saveBrand(token, { name: brand.name, description: brand.description ?? "", isActive: !brand.isActive }, brand.id))
              }}>
                {brand.isActive ? "Tắt" : "Bật"}
              </button>
            </li>
          ))}</ul>
        </form>

        <form className="card form" onSubmit={(event) => {
          event.preventDefault()
          if (!token) return
          void run(() => saveModel(token, { brandId: Number(modelBrandId), name: modelName, imageUrl: "", description: "", releaseYear: null, isActive: true }))
        }}>
          <h2>Thêm dòng máy</h2>
          <select className="input" value={modelBrandId} onChange={(event) => setModelBrandId(event.target.value)}>
            <option value="">Chọn hãng</option>
            {brands.map((brand) => <option key={brand.id} value={brand.id}>{brand.name}</option>)}
          </select>
          <input className="input" value={modelName} onChange={(event) => setModelName(event.target.value)} placeholder="Tên dòng máy" />
          <button className="btn" type="submit">Lưu dòng máy</button>
          <ul className="plain-list">{models.map((model) => <li key={model.id}>{model.brandName} {model.name}</li>)}</ul>
        </form>

        <form className="card form" onSubmit={(event) => {
          event.preventDefault()
          if (!token) return
          void run(() => saveService(token, { name: serviceName, description: "", pricingType, isActive: true }))
        }}>
          <h2>Thêm dịch vụ</h2>
          <input className="input" value={serviceName} onChange={(event) => setServiceName(event.target.value)} placeholder="Tên dịch vụ" />
          <select className="input" value={pricingType} onChange={(event) => setPricingType(event.target.value as PricingType)}>
            <option value="FixedPrice">Giá cố định</option>
            <option value="InspectionRequired">Cần kiểm tra</option>
          </select>
          <button className="btn" type="submit">Lưu dịch vụ</button>
          <ul className="plain-list">{services.map((service) => <li key={service.id}>{service.name}</li>)}</ul>
        </form>

        <form className="card form" onSubmit={(event) => {
          event.preventDefault()
          if (!token) return
          const service = services.find((item) => item.id === Number(priceServiceId))
          void run(() => savePrice(token, {
            phoneModelId: Number(priceModelId),
            repairServiceId: Number(priceServiceId),
            price: service?.pricingType === "InspectionRequired" ? null : Number(amount),
            isActive: true,
          }))
        }}>
          <h2>Giá theo máy</h2>
          <select className="input" value={priceModelId} onChange={(event) => setPriceModelId(event.target.value)}>
            <option value="">Chọn dòng máy</option>
            {models.map((model) => <option key={model.id} value={model.id}>{model.brandName} {model.name}</option>)}
          </select>
          <select className="input" value={priceServiceId} onChange={(event) => setPriceServiceId(event.target.value)}>
            <option value="">Chọn dịch vụ</option>
            {services.map((service) => <option key={service.id} value={service.id}>{service.name}</option>)}
          </select>
          <input className="input" value={amount} onChange={(event) => setAmount(event.target.value)} placeholder="Đơn giá VNĐ" />
          <button className="btn" type="submit">Lưu giá</button>
          <ul className="plain-list">
            {prices.map((price) => (
              <li key={price.id}>{price.brandName} {price.phoneModelName} · {price.repairServiceName} · {formatPrice(price.pricingType, price.price)}</li>
            ))}
          </ul>
        </form>
      </div>
    </main>
  )
}
