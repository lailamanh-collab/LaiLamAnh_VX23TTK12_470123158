import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { Link, Navigate, useNavigate } from "react-router-dom"
import { z } from "zod"
import { register as registerAccount } from "../api/auth"
import { ApiError } from "../api/client"
import { useAuth } from "../auth/AuthContext"
import { TextField } from "../components/forms/TextField"

const schema = z.object({
  fullName: z.string().trim().min(1, "Nhập họ tên.").max(100),
  email: z.string().email("Email không hợp lệ."),
  phoneNumber: z.string().regex(/^[0-9+\s]{8,15}$/, "Số điện thoại không hợp lệ."),
  password: z.string()
    .min(8, "Mật khẩu tối thiểu 8 ký tự.")
    .regex(/[A-Z]/, "Mật khẩu cần một chữ hoa.")
    .regex(/[a-z]/, "Mật khẩu cần một chữ thường.")
    .regex(/[0-9]/, "Mật khẩu cần một chữ số."),
  confirmPassword: z.string(),
}).refine((values) => values.password === values.confirmPassword, {
  message: "Mật khẩu nhập lại chưa khớp.",
  path: ["confirmPassword"],
})

type RegisterValues = z.infer<typeof schema>

export function RegisterPage() {
  const navigate = useNavigate()
  const { user, setSession } = useAuth()
  const { register, handleSubmit, setError, formState: { errors, isSubmitting } } = useForm<RegisterValues>({
    resolver: zodResolver(schema),
  })

  if (user) {
    return <Navigate to="/" replace />
  }

  async function onSubmit(values: RegisterValues) {
    try {
      const result = await registerAccount(values)
      setSession(result.accessToken, result.user)
      navigate("/")
    } catch (error) {
      if (error instanceof ApiError && error.errors) {
        for (const [field, messages] of Object.entries(error.errors)) {
          setError(field as keyof RegisterValues, { message: messages[0] })
        }
        return
      }
      const message = error instanceof ApiError ? error.message : "Không tạo được tài khoản."
      setError("root", { message })
    }
  }

  return (
    <main className="page narrow">
      <section className="card form-card">
        <h1>Đăng ký</h1>
        <p className="section-intro">Tài khoản mới dùng để đặt lịch và theo dõi sửa chữa.</p>
        <form className="form" onSubmit={handleSubmit(onSubmit)} noValidate>
          {errors.root ? <p className="form-error">{errors.root.message}</p> : null}
          <TextField label="Họ tên" autoComplete="name" registration={register("fullName")} error={errors.fullName} />
          <TextField label="Email" type="email" autoComplete="email" registration={register("email")} error={errors.email} />
          <TextField label="Số điện thoại" autoComplete="tel" registration={register("phoneNumber")} error={errors.phoneNumber} />
          <TextField label="Mật khẩu" type="password" autoComplete="new-password" registration={register("password")} error={errors.password} />
          <TextField label="Nhập lại mật khẩu" type="password" autoComplete="new-password" registration={register("confirmPassword")} error={errors.confirmPassword} />
          <button className="btn" type="submit" disabled={isSubmitting}>
            {isSubmitting ? "Đang tạo tài khoản..." : "Tạo tài khoản"}
          </button>
        </form>
        <p className="form-note">
          Đã có tài khoản? <Link to="/dang-nhap">Đăng nhập</Link>
        </p>
      </section>
    </main>
  )
}
