import { api } from "./client"

export type PricingType = "FixedPrice" | "InspectionRequired"

export type Brand = {
  id: number
  name: string
  slug: string
  description: string | null
  isActive: boolean
  modelCount: number
}

export type PhoneModel = {
  id: number
  brandId: number
  brandName: string
  name: string
  slug: string
  imageUrl: string | null
  description: string | null
  releaseYear: number | null
  isActive: boolean
}

export type RepairService = {
  id: number
  name: string
  slug: string
  description: string | null
  pricingType: PricingType
  isActive: boolean
}

export type ServicePrice = {
  id: number
  phoneModelId: number
  phoneModelName: string
  brandName: string
  repairServiceId: number
  repairServiceName: string
  pricingType: PricingType
  price: number | null
  isActive: boolean
}

export type CatalogSearchItem = {
  phoneModelId: number
  brandName: string
  phoneModelName: string
  repairServiceId: number
  repairServiceName: string
  pricingType: PricingType
  price: number | null
}

export function formatPrice(pricingType: PricingType, price: number | null) {
  if (pricingType === "InspectionRequired" || price === null) {
    return "Cần kiểm tra trước"
  }
  return new Intl.NumberFormat("vi-VN", { style: "currency", currency: "VND", maximumFractionDigits: 0 }).format(price)
}

export function pricingLabel(pricingType: PricingType) {
  return pricingType === "FixedPrice" ? "Giá cố định" : "Cần kiểm tra"
}

export const getBrands = (search = "") => api<Brand[]>(`/api/catalog/brands?search=${encodeURIComponent(search)}`)
export const getModels = (brandId?: number, search = "") => {
  const params = new URLSearchParams()
  if (brandId) params.set("brandId", String(brandId))
  if (search) params.set("search", search)
  return api<PhoneModel[]>(`/api/catalog/models?${params.toString()}`)
}
export const getServices = (search = "", pricingType = "") => {
  const params = new URLSearchParams()
  if (search) params.set("search", search)
  if (pricingType) params.set("pricingType", pricingType)
  return api<RepairService[]>(`/api/catalog/services?${params.toString()}`)
}
export const getPrices = (modelId?: number, serviceId?: number) => {
  const params = new URLSearchParams()
  if (modelId) params.set("modelId", String(modelId))
  if (serviceId) params.set("serviceId", String(serviceId))
  return api<ServicePrice[]>(`/api/catalog/prices?${params.toString()}`)
}
export const searchCatalog = (q: string, brandId?: number, pricingType?: string) => {
  const params = new URLSearchParams()
  if (q) params.set("q", q)
  if (brandId) params.set("brandId", String(brandId))
  if (pricingType) params.set("pricingType", pricingType)
  return api<CatalogSearchItem[]>(`/api/catalog/search?${params.toString()}`)
}

export const adminBrands = (token: string) => api<Brand[]>("/api/admin/catalog/brands", {}, token)
export const adminModels = (token: string) => api<PhoneModel[]>("/api/admin/catalog/models", {}, token)
export const adminServices = (token: string) => api<RepairService[]>("/api/admin/catalog/services", {}, token)
export const adminPrices = (token: string) => api<ServicePrice[]>("/api/admin/catalog/prices", {}, token)

export function saveBrand(token: string, body: { name: string; description: string; isActive: boolean }, id?: number) {
  return api<Brand>(`/api/admin/catalog/brands${id ? `/${id}` : ""}`, {
    method: id ? "PUT" : "POST",
    body: JSON.stringify(body),
  }, token)
}

export function saveModel(token: string, body: object, id?: number) {
  return api<PhoneModel>(`/api/admin/catalog/models${id ? `/${id}` : ""}`, {
    method: id ? "PUT" : "POST",
    body: JSON.stringify(body),
  }, token)
}

export function saveService(token: string, body: object, id?: number) {
  return api<RepairService>(`/api/admin/catalog/services${id ? `/${id}` : ""}`, {
    method: id ? "PUT" : "POST",
    body: JSON.stringify(body),
  }, token)
}

export function savePrice(token: string, body: object, id?: number) {
  return api<ServicePrice>(`/api/admin/catalog/prices${id ? `/${id}` : ""}`, {
    method: id ? "PUT" : "POST",
    body: JSON.stringify(body),
  }, token)
}
