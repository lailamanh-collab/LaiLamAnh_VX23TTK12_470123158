using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using HomeRepairBooking.Api.Domain;
using HomeRepairBooking.Api.DTOs;
using HomeRepairBooking.Api.Services;

namespace HomeRepairBooking.Api.Controllers;

[ApiController]
[Authorize(Roles = AppRoles.Technician)]
[Route("api/technician")]
public class TechnicianPortalController : ControllerBase
{
    private readonly BranchService _branches;

    public TechnicianPortalController(BranchService branches)
    {
        _branches = branches;
    }

    [HttpGet("me")]
    public async Task<ActionResult<TechnicianDto>> Me()
    {
        var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
        if (userId is null)
        {
            return Unauthorized(new ApiError { Message = "Bạn cần đăng nhập." });
        }

        var profile = await _branches.GetOwnProfileAsync(userId);
        if (profile is null)
        {
            return NotFound(new ApiError { Message = "Chưa có hồ sơ kỹ thuật viên." });
        }

        return Ok(profile);
    }
}
