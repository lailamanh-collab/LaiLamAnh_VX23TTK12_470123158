import { Link } from "react-router-dom"

export function HomePage() {
  return (
    <main className="page">
      <section className="hero">
        <div>
          <p className="eyebrow">Sửa chữa tại cửa hàng</p>
          <h1>Đặt lịch sửa điện thoại, đúng máy, đúng dịch vụ.</h1>
          <p className="lede">
            Chọn hãng, dòng máy và dịch vụ cần sửa. Xem giá dự kiến, chọn chi nhánh
            và khung giờ còn chỗ, rồi mang máy tới theo lịch.
          </p>
          <div style={{ marginTop: "24px", display: "flex", gap: "12px", flexWrap: "wrap" }}>
            <Link className="btn" to="/dat-lich">Đặt lịch ngay</Link>
            <Link className="btn btn-quiet" to="/dich-vu">Tra cứu giá dịch vụ</Link>
          </div>
        </div>
      </section>

      <section className="section" id="quy-trinh">
        <h2>Quy trình tại cửa hàng</h2>
        <p className="section-intro">Ba bước từ lúc đặt lịch đến lúc nhận lại máy.</p>
        <div className="step-grid">
          <article className="card">
            <span className="step-index">1</span>
            <h3>Đặt lịch</h3>
            <p>Chọn máy, dịch vụ, chi nhánh và khung giờ hệ thống còn nhận.</p>
          </article>
          <article className="card">
            <span className="step-index">2</span>
            <h3>Mang máy tới</h3>
            <p>Cửa hàng nhận máy, kỹ thuật viên kiểm tra rồi tiến hành sửa.</p>
          </article>
          <article className="card">
            <span className="step-index">3</span>
            <h3>Nhận máy</h3>
            <p>Theo dõi trạng thái sửa chữa và đánh giá khi công việc hoàn thành.</p>
          </article>
        </div>
      </section>
    </main>
  )
}
