import { useState } from "react"
import { Link } from "react-router-dom"

type SiteFooterProps = {
  databaseConnected: boolean | null
}

export function SiteFooter({ databaseConnected }: SiteFooterProps) {
  const [emailSub, setEmailSub] = useState("")
  const [subSuccess, setSubSuccess] = useState(false)

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault()
    if (emailSub.trim()) {
      setSubSuccess(true)
      setEmailSub("")
      setTimeout(() => setSubSuccess(false), 4000)
    }
  }

  let statusText = "Hệ thống đang hoạt động"
  if (databaseConnected === true) statusText = "Cơ sở dữ liệu sẵn sàng"
  if (databaseConnected === false) statusText = "Chưa kết nối cơ sở dữ liệu"

  return (
    <footer style={{ background: "#ffffff", borderTop: "1px solid #e2e8f0", paddingTop: "56px", paddingBottom: "32px", marginTop: "auto" }}>
      <div style={{ maxWidth: "1280px", margin: "0 auto", padding: "0 20px" }}>
        {/* MAIN 4-COLUMN FOOTER GRID (IMAGES 3 & 5) */}
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "1.4fr 1fr 1fr 1fr 1.4fr",
            gap: "36px",
            marginBottom: "44px",
          }}
        >
          {/* COL 1: LOGO & ABOUT */}
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "14px" }}>
              <div style={{ width: "32px", height: "32px", borderRadius: "10px", background: "#2563eb", display: "flex", alignItems: "center", justifyContent: "center" }}>
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
                  <rect x="5" y="2" width="14" height="20" rx="3" ry="3" />
                  <line x1="12" y1="18" x2="12.01" y2="18" />
                </svg>
              </div>
              <strong style={{ fontSize: "1.3rem", fontWeight: 800, letterSpacing: "-0.03em", color: "#0f172a" }}>
                Phone<span style={{ color: "#2563eb" }}>Repair</span>
              </strong>
            </div>

            <p style={{ margin: "0 0 20px", color: "#64748b", fontSize: "0.88rem", lineHeight: 1.6, maxWidth: "260px" }}>
              Sửa điện thoại nhanh chóng, uy tín, chuyên nghiệp. Hệ thống tiếp nhận minh bạch hàng đầu.
            </p>

            {/* SOCIAL ICONS */}
            <div style={{ display: "flex", gap: "12px", alignItems: "center" }}>
              <a href="#facebook" style={{ width: "32px", height: "32px", borderRadius: "50%", background: "#eff6ff", color: "#1877F2", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "0.9rem" }}>
                📘
              </a>
              <a href="#youtube" style={{ width: "32px", height: "32px", borderRadius: "50%", background: "#fef2f2", color: "#ef4444", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "0.9rem" }}>
                ▶️
              </a>
              <a href="#tiktok" style={{ width: "32px", height: "32px", borderRadius: "50%", background: "#f1f5f9", color: "#0f172a", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "0.9rem" }}>
                🎵
              </a>
              <a href="#zalo" style={{ width: "32px", height: "32px", borderRadius: "50%", background: "#e0f2fe", color: "#0284c7", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "0.8rem", fontWeight: 800 }}>
                Zalo
              </a>
            </div>
          </div>

          {/* COL 2: VỀ CHÚNG TÔI */}
          <div>
            <strong style={{ display: "block", fontSize: "0.92rem", color: "#0f172a", marginBottom: "16px" }}>
              Về chúng tôi
            </strong>
            <ul style={{ listStyle: "none", padding: 0, margin: 0, display: "flex", flexDirection: "column", gap: "10px", fontSize: "0.88rem" }}>
              <li>
                <Link to="/" style={{ color: "#64748b" }}>Giới thiệu</Link>
              </li>
              <li>
                <Link to="/branches" style={{ color: "#64748b" }}>Hệ thống chi nhánh</Link>
              </li>
              <li>
                <Link to="/support" style={{ color: "#64748b" }}>Tin tức - Khuyến mãi</Link>
              </li>
              <li>
                <Link to="/support" style={{ color: "#64748b" }}>Tuyển dụng kỹ thuật viên</Link>
              </li>
            </ul>
          </div>

          {/* COL 3: DỊCH VỤ */}
          <div>
            <strong style={{ display: "block", fontSize: "0.92rem", color: "#0f172a", marginBottom: "16px" }}>
              Dịch vụ
            </strong>
            <ul style={{ listStyle: "none", padding: 0, margin: 0, display: "flex", flexDirection: "column", gap: "10px", fontSize: "0.88rem" }}>
              <li>
                <Link to="/pricing" style={{ color: "#64748b" }}>Bảng giá dịch vụ</Link>
              </li>
              <li>
                <Link to="/support" style={{ color: "#64748b" }}>Chính sách bảo hành</Link>
              </li>
              <li>
                <Link to="/support" style={{ color: "#64748b" }}>Quy trình sửa chữa</Link>
              </li>
              <li>
                <Link to="/support" style={{ color: "#64748b" }}>Câu hỏi thường gặp</Link>
              </li>
            </ul>
          </div>

          {/* COL 4: HỖ TRỢ KHÁCH HÀNG */}
          <div>
            <strong style={{ display: "block", fontSize: "0.92rem", color: "#0f172a", marginBottom: "16px" }}>
              Hỗ trợ khách hàng
            </strong>
            <ul style={{ listStyle: "none", padding: 0, margin: 0, display: "flex", flexDirection: "column", gap: "10px", fontSize: "0.88rem" }}>
              <li>
                <Link to="/support" style={{ color: "#64748b" }}>Liên hệ hỗ trợ</Link>
              </li>
              <li>
                <Link to="/booking" style={{ color: "#64748b" }}>Hướng dẫn đặt lịch</Link>
              </li>
              <li>
                <Link to="/support" style={{ color: "#64748b" }}>Chính sách bảo mật</Link>
              </li>
              <li>
                <Link to="/support" style={{ color: "#64748b" }}>Điều khoản sử dụng</Link>
              </li>
            </ul>
          </div>

          {/* COL 5: NHẬN THÔNG TIN KHUYẾN MÃI (NEWSLETTER) */}
          <div>
            <strong style={{ display: "block", fontSize: "0.92rem", color: "#0f172a", marginBottom: "8px" }}>
              Nhận thông tin khuyến mãi
            </strong>
            <p style={{ margin: "0 0 14px", fontSize: "0.84rem", color: "#64748b", lineHeight: 1.5 }}>
              Đăng ký email để nhận ưu đãi mới nhất từ HomeRepair
            </p>

            <form onSubmit={handleSubscribe} style={{ display: "flex", gap: "8px" }}>
              <input
                type="email"
                placeholder="Nhập email của bạn"
                value={emailSub}
                onChange={(e) => setEmailSub(e.target.value)}
                style={{
                  flex: 1,
                  height: "40px",
                  border: "1px solid #cbd5e1",
                  borderRadius: "10px",
                  padding: "0 12px",
                  fontSize: "0.85rem",
                  background: "#f8fafc",
                }}
              />
              <button
                type="submit"
                className="btn"
                style={{
                  height: "40px",
                  padding: "0 16px",
                  borderRadius: "10px",
                  background: "#2563eb",
                  fontWeight: 700,
                  fontSize: "0.85rem",
                  flexShrink: 0,
                }}
              >
                Đăng ký
              </button>
            </form>
            {subSuccess && (
              <p style={{ color: "#16a34a", fontSize: "0.78rem", margin: "6px 0 0" }}>
                ✓ Cảm ơn bạn! Chúng tôi sẽ gửi thông báo ưu đãi sớm nhất.
              </p>
            )}
          </div>
        </div>

        {/* BOTTOM COPYRIGHT & DB STATUS ROW */}
        <div
          style={{
            borderTop: "1px solid #f1f5f9",
            paddingTop: "24px",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            flexWrap: "wrap",
            gap: "14px",
            fontSize: "0.82rem",
            color: "#94a3b8",
          }}
        >
          <div>
            © 2024 HomeRepair. All rights reserved.
          </div>

          <div style={{ display: "flex", gap: "20px" }}>
            <Link to="/support" style={{ color: "#94a3b8" }}>Chính sách</Link>
            <Link to="/support" style={{ color: "#94a3b8" }}>Bảo mật</Link>
            <Link to="/support" style={{ color: "#94a3b8" }}>Điều khoản</Link>
          </div>

          <div style={{ display: "inline-flex", alignItems: "center", gap: "6px" }}>
            <span
              style={{
                width: "8px",
                height: "8px",
                borderRadius: "50%",
                background: databaseConnected ? "#16a34a" : "#ca8a04",
              }}
            />
            <span>{statusText}</span>
          </div>
        </div>
      </div>
    </footer>
  )
}
