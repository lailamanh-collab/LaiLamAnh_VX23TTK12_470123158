import { useEffect, useRef, useState } from "react"
import { Link, NavLink, useNavigate } from "react-router-dom"
import { useAuth } from "../../auth/AuthContext"
import { getAvatarImage } from "../../assets"

export function SiteHeader() {
  const { user, logout, openAuthModal } = useAuth()
  const navigate = useNavigate()

  const [mobileOpen, setMobileOpen] = useState(false)
  const [showSearchModal, setShowSearchModal] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const [profileDropdownOpen, setProfileDropdownOpen] = useState(false)
  const [notifDropdownOpen, setNotifDropdownOpen] = useState(false)

  const dropdownRef = useRef<HTMLDivElement>(null)
  const notifRef = useRef<HTMLDivElement>(null)

  const closeMenu = () => {
    setMobileOpen(false)
    setProfileDropdownOpen(false)
    setNotifDropdownOpen(false)
  }

  // Close dropdowns when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setProfileDropdownOpen(false)
      }
      if (notifRef.current && !notifRef.current.contains(event.target as Node)) {
        setNotifDropdownOpen(false)
      }
    }
    document.addEventListener("mousedown", handleClickOutside)
    return () => {
      document.removeEventListener("mousedown", handleClickOutside)
    }
  }, [])

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (searchQuery.trim()) {
      setShowSearchModal(false)
      navigate(`/services?q=${encodeURIComponent(searchQuery.trim())}`)
    }
  }

  const getRoleLabel = (role?: string) => {
    if (role === "Admin") return "Quản trị viên"
    if (role === "Technician") return "Kỹ thuật viên"
    return "Khách hàng"
  }

  const getRoleBadge = (role?: string) => {
    if (role === "Admin") {
      return (
        <span
          style={{
            fontSize: "0.68rem",
            fontWeight: 700,
            padding: "2px 8px",
            borderRadius: "6px",
            background: "#fef3c7",
            color: "#b45309",
            border: "1px solid #fde68a",
          }}
        >
          Admin
        </span>
      )
    }
    if (role === "Technician") {
      return (
        <span
          style={{
            fontSize: "0.68rem",
            fontWeight: 700,
            padding: "2px 8px",
            borderRadius: "6px",
            background: "#f3e8ff",
            color: "#7e22ce",
            border: "1px solid #e9d5ff",
          }}
        >
          KTV
        </span>
      )
    }
    return (
      <span
        style={{
          fontSize: "0.68rem",
          fontWeight: 700,
          padding: "2px 8px",
          borderRadius: "6px",
          background: "#ecfdf5",
          color: "#059669",
          border: "1px solid #a7f3d0",
        }}
      >
        Khách hàng
      </span>
    )
  }

  return (
    <header className="site-header" style={{ background: "#ffffff", borderBottom: "1px solid #e2e8f0", position: "sticky", top: 0, zIndex: 100 }}>
      <div
        className="site-header-inner"
        style={{
          maxWidth: "1340px",
          margin: "0 auto",
          padding: "0 24px",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          minHeight: "70px",
          flexWrap: "nowrap",
          gap: "20px",
        }}
      >
        {/* 1. BRAND LOGO (LEFT) */}
        <NavLink to="/" onClick={closeMenu} style={{ display: "flex", alignItems: "center", gap: "10px", textDecoration: "none", flexShrink: 0 }}>
          <div
            style={{
              width: "36px",
              height: "36px",
              borderRadius: "10px",
              background: "#2563eb",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              boxShadow: "0 4px 10px rgba(37,99,235,0.28)",
            }}
          >
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
              <rect x="5" y="2" width="14" height="20" rx="3" ry="3" />
              <line x1="12" y1="18" x2="12.01" y2="18" />
            </svg>
          </div>
          <span style={{ fontWeight: 800, fontSize: "1.35rem", letterSpacing: "-0.03em", color: "#0f172a" }}>
            Phone<span style={{ color: "#2563eb" }}>Repair</span>
          </span>
        </NavLink>

        {/* 2. NAVIGATION LINKS (CENTER) */}
        <nav
          className="desktop-nav"
          style={{
            display: "flex",
            alignItems: "center",
            gap: "26px",
            whiteSpace: "nowrap",
          }}
        >
          <NavLink
            to="/"
            end
            className={({ isActive }) => (isActive ? "nav-link nav-link-active" : "nav-link")}
            style={{ textDecoration: "none", fontWeight: 600, fontSize: "0.92rem" }}
          >
            Trang chủ
          </NavLink>
          <NavLink
            to="/services"
            className={({ isActive }) => (isActive ? "nav-link nav-link-active" : "nav-link")}
            style={{ textDecoration: "none", fontWeight: 600, fontSize: "0.92rem" }}
          >
            Dịch vụ
          </NavLink>
          <NavLink
            to="/pricing"
            className={({ isActive }) => (isActive ? "nav-link nav-link-active" : "nav-link")}
            style={{ textDecoration: "none", fontWeight: 600, fontSize: "0.92rem" }}
          >
            Bảng giá
          </NavLink>
          <NavLink
            to="/branches"
            className={({ isActive }) => (isActive ? "nav-link nav-link-active" : "nav-link")}
            style={{ textDecoration: "none", fontWeight: 600, fontSize: "0.92rem" }}
          >
            Chi nhánh
          </NavLink>
          <NavLink
            to="/support"
            className={({ isActive }) => (isActive ? "nav-link nav-link-active" : "nav-link")}
            style={{ textDecoration: "none", fontWeight: 600, fontSize: "0.92rem" }}
          >
            Hỗ trợ
          </NavLink>
        </nav>

        {/* 3. ACTIONS & USER PROFILE (RIGHT) */}
        <div style={{ display: "flex", alignItems: "center", gap: "12px", flexShrink: 0 }}>
          {/* SEARCH BUTTON (COMPACT ICON ONLY) */}
          <button
            type="button"
            onClick={() => setShowSearchModal(true)}
            title="Tìm kiếm dịch vụ, dòng máy"
            style={{
              width: "38px",
              height: "38px",
              borderRadius: "50%",
              border: "1px solid #e2e8f0",
              background: "#ffffff",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              color: "#64748b",
              cursor: "pointer",
              transition: "all 0.15s ease",
            }}
          >
            <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="11" cy="11" r="8" />
              <line x1="21" y1="21" x2="16.65" y2="16.65" />
            </svg>
          </button>

          {/* WHEN LOGGED IN */}
          {user ? (
            <>
              {/* NOTIFICATION BELL WITH BADGE */}
              <div ref={notifRef} style={{ position: "relative" }}>
                <button
                  type="button"
                  onClick={() => setNotifDropdownOpen(!notifDropdownOpen)}
                  title="Thông báo"
                  style={{
                    width: "38px",
                    height: "38px",
                    borderRadius: "50%",
                    border: "1px solid #e2e8f0",
                    background: notifDropdownOpen ? "#eff6ff" : "#ffffff",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    position: "relative",
                    cursor: "pointer",
                    color: notifDropdownOpen ? "#2563eb" : "#64748b",
                  }}
                >
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" />
                    <path d="M13.73 21a2 2 0 0 1-3.46 0" />
                  </svg>
                  {/* RED UNREAD BADGE */}
                  <span
                    style={{
                      position: "absolute",
                      top: "7px",
                      right: "7px",
                      width: "7px",
                      height: "7px",
                      borderRadius: "50%",
                      background: "#ef4444",
                      border: "1.5px solid #ffffff",
                    }}
                  />
                </button>

                {/* NOTIFICATIONS POPOVER */}
                {notifDropdownOpen && (
                  <div
                    style={{
                      position: "absolute",
                      top: "48px",
                      right: 0,
                      width: "320px",
                      background: "#ffffff",
                      borderRadius: "14px",
                      border: "1px solid #e2e8f0",
                      boxShadow: "0 10px 30px rgba(15,23,42,0.12)",
                      zIndex: 150,
                      padding: "14px",
                    }}
                  >
                    <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "10px", paddingBottom: "8px", borderBottom: "1px solid #f1f5f9" }}>
                      <strong style={{ fontSize: "0.88rem", color: "#0f172a" }}>Thông báo</strong>
                      <span style={{ fontSize: "0.72rem", color: "#2563eb", fontWeight: 700, cursor: "pointer" }}>Đánh dấu đã đọc</span>
                    </div>

                    <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
                      <Link
                        to="/my-bookings"
                        onClick={closeMenu}
                        style={{
                          textDecoration: "none",
                          padding: "8px",
                          borderRadius: "8px",
                          background: "#eff6ff",
                          border: "1px solid #dbeafe",
                          display: "block",
                        }}
                      >
                        <div style={{ fontSize: "0.8rem", fontWeight: 700, color: "#1e40af", marginBottom: "2px" }}>
                          Lịch hẹn PRB-20241015-001
                        </div>
                        <div style={{ fontSize: "0.74rem", color: "#475569" }}>
                          Kỹ thuật viên đang kiểm tra thiết bị của bạn.
                        </div>
                        <div style={{ fontSize: "0.68rem", color: "#94a3b8", marginTop: "4px" }}>
                          10 phút trước
                        </div>
                      </Link>

                      <Link
                        to="/my-bookings"
                        onClick={closeMenu}
                        style={{
                          textDecoration: "none",
                          padding: "8px",
                          borderRadius: "8px",
                          background: "#f8fafc",
                          border: "1px solid #f1f5f9",
                          display: "block",
                        }}
                      >
                        <div style={{ fontSize: "0.8rem", fontWeight: 700, color: "#0f172a", marginBottom: "2px" }}>
                          Đặt lịch thành công
                        </div>
                        <div style={{ fontSize: "0.74rem", color: "#475569" }}>
                          Bạn đã đặt lịch tại HomeRepair Quận 1.
                        </div>
                        <div style={{ fontSize: "0.68rem", color: "#94a3b8", marginTop: "4px" }}>
                          1 giờ trước
                        </div>
                      </Link>
                    </div>

                    <div style={{ marginTop: "10px", textAlign: "center", paddingTop: "8px", borderTop: "1px solid #f1f5f9" }}>
                      <Link to="/my-bookings" onClick={closeMenu} style={{ fontSize: "0.76rem", color: "#2563eb", fontWeight: 700, textDecoration: "none" }}>
                        Xem tất cả lịch hẹn →
                      </Link>
                    </div>
                  </div>
                )}
              </div>

              {/* USER PROFILE PILL WITH DROPDOWN (MATCHING MOCKUP) */}
              <div ref={dropdownRef} style={{ position: "relative" }}>
                <div
                  onClick={() => setProfileDropdownOpen(!profileDropdownOpen)}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: "10px",
                    padding: "4px 12px 4px 6px",
                    borderRadius: "999px",
                    background: profileDropdownOpen ? "#f1f5f9" : "#f8fafc",
                    border: "1px solid #e2e8f0",
                    cursor: "pointer",
                    userSelect: "none",
                    transition: "all 0.15s ease",
                  }}
                >
                  <img
                    src={getAvatarImage(user.fullName, user.role === "Technician")}
                    alt={user.fullName}
                    style={{
                      width: "32px",
                      height: "32px",
                      borderRadius: "50%",
                      objectFit: "cover",
                    }}
                  />
                  <div style={{ display: "flex", flexDirection: "column", lineHeight: 1.25, textAlign: "left" }}>
                    <span style={{ fontSize: "0.84rem", fontWeight: 700, color: "#0f172a" }}>
                      {user.fullName}
                    </span>
                    <span style={{ fontSize: "0.7rem", color: "#64748b" }}>
                      {getRoleLabel(user.role)}
                    </span>
                  </div>
                  <span
                    style={{
                      fontSize: "0.68rem",
                      color: "#64748b",
                      marginLeft: "2px",
                      transform: profileDropdownOpen ? "rotate(180deg)" : "none",
                      transition: "transform 0.2s ease",
                    }}
                  >
                    ▼
                  </span>
                </div>

                {/* USER DROPDOWN MENU */}
                {profileDropdownOpen && (
                  <div
                    style={{
                      position: "absolute",
                      top: "48px",
                      right: 0,
                      width: "250px",
                      background: "#ffffff",
                      borderRadius: "14px",
                      border: "1px solid #e2e8f0",
                      boxShadow: "0 10px 30px rgba(15,23,42,0.12)",
                      zIndex: 150,
                      padding: "8px 0",
                    }}
                  >
                    {/* USER HEADER INFO */}
                    <div style={{ padding: "10px 16px 12px", borderBottom: "1px solid #f1f5f9" }}>
                      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "4px" }}>
                        <strong style={{ fontSize: "0.88rem", color: "#0f172a" }}>{user.fullName}</strong>
                        {getRoleBadge(user.role)}
                      </div>
                      <div style={{ fontSize: "0.75rem", color: "#64748b", wordBreak: "break-all" }}>
                        {user.email}
                      </div>
                    </div>

                    {/* MENU LINKS */}
                    <div style={{ padding: "6px 0" }}>
                      <Link
                        to="/my-bookings"
                        onClick={closeMenu}
                        style={{
                          display: "flex",
                          alignItems: "center",
                          gap: "10px",
                          padding: "8px 16px",
                          fontSize: "0.84rem",
                          color: "#334155",
                          textDecoration: "none",
                          fontWeight: 600,
                          transition: "background 0.15s ease",
                        }}
                        onMouseEnter={(e) => (e.currentTarget.style.background = "#f8fafc")}
                        onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
                      >
                        <span>📋</span>
                        <span>Lịch hẹn của tôi</span>
                      </Link>

                      <Link
                        to="/profile"
                        onClick={closeMenu}
                        style={{
                          display: "flex",
                          alignItems: "center",
                          gap: "10px",
                          padding: "8px 16px",
                          fontSize: "0.84rem",
                          color: "#334155",
                          textDecoration: "none",
                          fontWeight: 600,
                          transition: "background 0.15s ease",
                        }}
                        onMouseEnter={(e) => (e.currentTarget.style.background = "#f8fafc")}
                        onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
                      >
                        <span>👤</span>
                        <span>Thông tin cá nhân</span>
                      </Link>

                      {/* ROLE SHORTCUTS */}
                      {user.role === "Admin" && (
                        <>
                          <Link
                            to="/admin/dashboard"
                            onClick={closeMenu}
                            style={{
                              display: "flex",
                              alignItems: "center",
                              gap: "10px",
                              padding: "8px 16px",
                              fontSize: "0.84rem",
                              color: "#2563eb",
                              textDecoration: "none",
                              fontWeight: 700,
                              transition: "background 0.15s ease",
                            }}
                            onMouseEnter={(e) => (e.currentTarget.style.background = "#eff6ff")}
                            onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
                          >
                            <span>📊</span>
                            <span>Trang quản trị (Admin)</span>
                          </Link>
                          <Link
                            to="/admin/bookings"
                            onClick={closeMenu}
                            style={{
                              display: "flex",
                              alignItems: "center",
                              gap: "10px",
                              padding: "8px 16px",
                              fontSize: "0.84rem",
                              color: "#334155",
                              textDecoration: "none",
                              fontWeight: 600,
                              transition: "background 0.15s ease",
                            }}
                            onMouseEnter={(e) => (e.currentTarget.style.background = "#f8fafc")}
                            onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
                          >
                            <span>🗓️</span>
                            <span>Quản lý lịch hẹn</span>
                          </Link>
                        </>
                      )}

                      {user.role === "Technician" && (
                        <Link
                          to="/technician"
                          onClick={closeMenu}
                          style={{
                            display: "flex",
                            alignItems: "center",
                            gap: "10px",
                            padding: "8px 16px",
                            fontSize: "0.84rem",
                            color: "#7e22ce",
                            textDecoration: "none",
                            fontWeight: 700,
                            transition: "background 0.15s ease",
                          }}
                          onMouseEnter={(e) => (e.currentTarget.style.background = "#f5f3ff")}
                          onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
                        >
                          <span>🔧</span>
                          <span>Bàn làm việc KTV</span>
                        </Link>
                      )}
                    </div>

                    {/* DIVIDER & LOGOUT */}
                    <div style={{ borderTop: "1px solid #f1f5f9", paddingTop: "4px" }}>
                      <button
                        type="button"
                        onClick={() => {
                          closeMenu()
                          logout()
                          navigate("/login")
                        }}
                        style={{
                          width: "100%",
                          display: "flex",
                          alignItems: "center",
                          gap: "10px",
                          padding: "8px 16px",
                          fontSize: "0.84rem",
                          color: "#ef4444",
                          background: "none",
                          border: "none",
                          fontWeight: 700,
                          cursor: "pointer",
                          textAlign: "left",
                          transition: "background 0.15s ease",
                        }}
                        onMouseEnter={(e) => (e.currentTarget.style.background = "#fef2f2")}
                        onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
                      >
                        <span>🚪</span>
                        <span>Đăng xuất</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </>
          ) : (
            /* NOT LOGGED IN */
            <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
              <Link
                to="/booking"
                style={{
                  height: "38px",
                  padding: "0 18px",
                  borderRadius: "8px",
                  background: "#2563eb",
                  color: "#ffffff",
                  fontWeight: 700,
                  fontSize: "0.86rem",
                  boxShadow: "0 2px 8px rgba(37,99,235,0.25)",
                  display: "inline-flex",
                  alignItems: "center",
                  justifyContent: "center",
                  textDecoration: "none",
                  whiteSpace: "nowrap",
                }}
              >
                Đặt lịch ngay
              </Link>
              <button
                type="button"
                onClick={() => openAuthModal("login")}
                style={{
                  height: "38px",
                  padding: "0 18px",
                  borderRadius: "8px",
                  background: "#f1f5f9",
                  color: "#0f172a",
                  fontWeight: 700,
                  fontSize: "0.86rem",
                  display: "inline-flex",
                  alignItems: "center",
                  justifyContent: "center",
                  whiteSpace: "nowrap",
                  border: "1px solid #e2e8f0",
                  cursor: "pointer",
                }}
              >
                Đăng nhập
              </button>
            </div>
          )}

          {/* MOBILE MENU TOGGLE BUTTON */}
          <button
            className="mobile-menu-toggle"
            type="button"
            aria-label="Mở trình đơn"
            aria-expanded={mobileOpen}
            onClick={() => setMobileOpen(!mobileOpen)}
            style={{
              width: "38px",
              height: "38px",
              borderRadius: "8px",
              border: "1px solid #e2e8f0",
              background: "#ffffff",
              display: "none",
              alignItems: "center",
              justifyContent: "center",
              fontSize: "1.2rem",
              cursor: "pointer",
            }}
          >
            {mobileOpen ? "✕" : "☰"}
          </button>
        </div>
      </div>

      {/* MOBILE DRAWER */}
      {mobileOpen && (
        <div
          style={{
            background: "#ffffff",
            borderTop: "1px solid #e2e8f0",
            padding: "16px 20px 24px",
            display: "flex",
            flexDirection: "column",
            gap: "10px",
          }}
        >
          <NavLink to="/" end className="nav-link" onClick={closeMenu} style={{ padding: "8px 12px", textDecoration: "none", fontWeight: 600 }}>
            Trang chủ
          </NavLink>
          <NavLink to="/services" className="nav-link" onClick={closeMenu} style={{ padding: "8px 12px", textDecoration: "none", fontWeight: 600 }}>
            Dịch vụ
          </NavLink>
          <NavLink to="/pricing" className="nav-link" onClick={closeMenu} style={{ padding: "8px 12px", textDecoration: "none", fontWeight: 600 }}>
            Bảng giá
          </NavLink>
          <NavLink to="/branches" className="nav-link" onClick={closeMenu} style={{ padding: "8px 12px", textDecoration: "none", fontWeight: 600 }}>
            Chi nhánh
          </NavLink>
          <NavLink to="/support" className="nav-link" onClick={closeMenu} style={{ padding: "8px 12px", textDecoration: "none", fontWeight: 600 }}>
            Hỗ trợ
          </NavLink>

          {user && (
            <div style={{ borderTop: "1px solid #f1f5f9", paddingTop: "10px", display: "flex", flexDirection: "column", gap: "6px" }}>
              <Link to="/my-bookings" onClick={closeMenu} style={{ padding: "8px 12px", textDecoration: "none", fontWeight: 600, color: "#2563eb" }}>
                📋 Lịch hẹn của tôi
              </Link>
              <Link to="/profile" onClick={closeMenu} style={{ padding: "8px 12px", textDecoration: "none", fontWeight: 600, color: "#334155" }}>
                👤 Thông tin cá nhân
              </Link>
              {user.role === "Admin" && (
                <Link to="/admin/dashboard" onClick={closeMenu} style={{ padding: "8px 12px", textDecoration: "none", fontWeight: 700, color: "#2563eb" }}>
                  📊 Trang quản trị (Admin)
                </Link>
              )}
              {user.role === "Technician" && (
                <Link to="/technician" onClick={closeMenu} style={{ padding: "8px 12px", textDecoration: "none", fontWeight: 700, color: "#7e22ce" }}>
                  🔧 Bàn làm việc KTV
                </Link>
              )}
              <button
                type="button"
                onClick={() => {
                  closeMenu()
                  logout()
                  navigate("/login")
                }}
                style={{
                  padding: "8px 12px",
                  background: "none",
                  border: "none",
                  color: "#ef4444",
                  fontWeight: 700,
                  cursor: "pointer",
                  textAlign: "left",
                }}
              >
                🚪 Đăng xuất
              </button>
            </div>
          )}

          {!user && (
            <div style={{ borderTop: "1px solid #f1f5f9", paddingTop: "10px", display: "flex", flexDirection: "column", gap: "8px" }}>
              <Link
                to="/booking"
                onClick={closeMenu}
                style={{
                  padding: "10px 14px",
                  borderRadius: "8px",
                  background: "#2563eb",
                  color: "#ffffff",
                  fontWeight: 700,
                  textAlign: "center",
                  textDecoration: "none",
                }}
              >
                Đặt lịch ngay
              </Link>
              <button
                type="button"
                onClick={() => {
                  closeMenu()
                  openAuthModal("login")
                }}
                style={{
                  padding: "10px 14px",
                  borderRadius: "8px",
                  background: "#f1f5f9",
                  color: "#0f172a",
                  fontWeight: 700,
                  textAlign: "center",
                  border: "1px solid #e2e8f0",
                  cursor: "pointer",
                }}
              >
                Đăng nhập
              </button>
            </div>
          )}
        </div>
      )}

      {/* QUICK SEARCH POPUP MODAL */}
      {showSearchModal && (
        <div
          style={{
            position: "fixed",
            inset: 0,
            background: "rgba(15, 23, 42, 0.6)",
            backdropFilter: "blur(4px)",
            zIndex: 999,
            display: "flex",
            alignItems: "flex-start",
            justifyContent: "center",
            paddingTop: "100px",
          }}
          onClick={() => setShowSearchModal(false)}
        >
          <div
            style={{
              background: "#ffffff",
              borderRadius: "18px",
              padding: "20px",
              width: "90%",
              maxWidth: "560px",
              boxShadow: "0 20px 50px rgba(0,0,0,0.3)",
            }}
            onClick={(e) => e.stopPropagation()}
          >
            <form onSubmit={handleSearch} style={{ display: "flex", gap: "10px" }}>
              <input
                type="text"
                autoFocus
                placeholder="Tìm kiếm dịch vụ (màn hình, pin, camera, loa...)..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                style={{
                  flex: 1,
                  height: "46px",
                  border: "1px solid #cbd5e1",
                  borderRadius: "12px",
                  padding: "0 16px",
                  fontSize: "0.95rem",
                  outline: "none",
                }}
              />
              <button
                type="submit"
                className="btn"
                style={{ background: "#2563eb", color: "#ffffff", padding: "0 20px", borderRadius: "12px", fontWeight: 700 }}
              >
                Tìm
              </button>
            </form>
          </div>
        </div>
      )}
    </header>
  )
}
