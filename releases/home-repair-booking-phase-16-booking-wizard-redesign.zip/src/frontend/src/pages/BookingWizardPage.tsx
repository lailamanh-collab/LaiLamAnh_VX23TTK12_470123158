import { useEffect, useMemo, useState } from "react"
import { Link, useSearchParams } from "react-router-dom"
import { getBrands, getModels, getPrices, type Brand, type PhoneModel, type ServicePrice } from "../api/catalog"
import { getBranches, type Branch } from "../api/branches"
import { createBooking, getSlots, type BookingDetail, type Slot } from "../api/bookings"
import { ApiError } from "../api/client"
import { useAuth } from "../auth/AuthContext"

interface MockupModel {
  name: string
  year: number
  image: string
}

const MOCKUP_IPHONE_MODELS: MockupModel[] = [
  { name: "iPhone 16", year: 2024, image: "https://images.unsplash.com/photo-1592750475338-74b7b21085ab?auto=format&fit=crop&w=260&q=80" },
  { name: "iPhone 15", year: 2023, image: "https://images.unsplash.com/photo-1695048133142-1a20484d2569?auto=format&fit=crop&w=260&q=80" },
  { name: "iPhone 14", year: 2022, image: "https://images.unsplash.com/photo-1663499482523-1c0c1bae4ce1?auto=format&fit=crop&w=260&q=80" },
  { name: "iPhone 13", year: 2021, image: "https://images.unsplash.com/photo-1632661674596-df8be070a5c5?auto=format&fit=crop&w=260&q=80" },
  { name: "iPhone 12", year: 2020, image: "https://images.unsplash.com/photo-1605236453806-6ff36851218e?auto=format&fit=crop&w=260&q=80" },
  { name: "iPhone 11", year: 2019, image: "https://images.unsplash.com/photo-1574944985070-8f3ebc6b79d2?auto=format&fit=crop&w=260&q=80" },
  { name: "iPhone XS", year: 2018, image: "https://images.unsplash.com/photo-1510557880182-3d4d3cba35a5?auto=format&fit=crop&w=260&q=80" },
  { name: "iPhone XR", year: 2018, image: "https://images.unsplash.com/photo-1530319067432-f2a729c03db5?auto=format&fit=crop&w=260&q=80" },
  { name: "iPhone X", year: 2017, image: "https://images.unsplash.com/photo-1519389950473-47ba0277781c?auto=format&fit=crop&w=260&q=80" },
  { name: "iPhone 8", year: 2017, image: "https://images.unsplash.com/photo-1523206489230-c012c64b2b48?auto=format&fit=crop&w=260&q=80" },
  { name: "iPhone 8 Plus", year: 2017, image: "https://images.unsplash.com/photo-1565849904461-04a58ad377e0?auto=format&fit=crop&w=260&q=80" },
  { name: "iPhone SE", year: 2022, image: "https://images.unsplash.com/photo-1589492477829-5e65395b66cc?auto=format&fit=crop&w=260&q=80" },
]

interface ServiceTemplate {
  key: string
  name: string
  desc: string
  price: number
  icon: string
  iconBg: string
  isPopular?: boolean
}

const SERVICE_TEMPLATES: ServiceTemplate[] = [
  { key: "screen", name: "Thay màn hình", desc: "Màn hình chính hãng, hiển thị sắc nét, cảm ứng mượt mà", price: 3500000, icon: "📱", iconBg: "#eff6ff", isPopular: true },
  { key: "battery", name: "Thay pin", desc: "Pin chính hãng, dung lượng chuẩn, bảo hành dài hạn", price: 1500000, icon: "🔋", iconBg: "#ecfdf5", isPopular: true },
  { key: "camera", name: "Thay camera", desc: "Camera chính hãng, chụp ảnh sắc nét, lấy nét nhanh", price: 800000, icon: "📷", iconBg: "#eff6ff" },
  { key: "speaker", name: "Sửa loa", desc: "Khôi phục âm thanh rõ ràng, không rè, không nhỏ", price: 300000, icon: "🔊", iconBg: "#f5f3ff" },
  { key: "port", name: "Sửa cổng sạc", desc: "Sạc ổn định, tiếp xúc tốt, không lỏng lẻo", price: 400000, icon: "🔌", iconBg: "#eff6ff" },
  { key: "case", name: "Thay vỏ", desc: "Vỏ chính hãng, khôi phục ngoại hình như mới", price: 1200000, icon: "📱", iconBg: "#f5f3ff" },
  { key: "power", name: "Sửa nút nguồn", desc: "Khắc phục lỗi nút nguồn, nhạy và bền bỉ", price: 350000, icon: "⏻", iconBg: "#eff6ff" },
  { key: "clean", name: "Vệ sinh máy", desc: "Vệ sinh tổng thể, tản nhiệt tốt hơn, tăng hiệu năng", price: 200000, icon: "🪄", iconBg: "#eff6ff" },
  { key: "software", name: "Cài đặt phần mềm", desc: "Cài đặt iOS, khôi phục dữ liệu, kiểm tra phần mềm", price: 150000, icon: "⚙️", iconBg: "#eff6ff" },
]

const BRAND_TABS = [
  { name: "Apple", logo: "apple" },
  { name: "Samsung", logo: "samsung" },
  { name: "Xiaomi", logo: "xiaomi" },
  { name: "Oppo", logo: "oppo" },
  { name: "Vivo", logo: "vivo" },
  { name: "Realme", logo: "realme" },
  { name: "Google", logo: "google" },
  { name: "Honor", logo: "honor" },
]

export function BookingWizardPage() {
  const { token, user } = useAuth()
  const [searchParams] = useSearchParams()
  const initialBranchParam = searchParams.get("branchId")

  // Wizard state: 0 = Chọn máy & dịch vụ, 1 = Chọn chi nhánh, 2 = Ngày & giờ, 3 = Thông tin, 4 = Xác nhận, 5 = Thành công
  const [activeStep, setActiveStep] = useState(0)

  // Data from backend
  const [brands, setBrands] = useState<Brand[]>([])
  const [models, setModels] = useState<PhoneModel[]>([])
  const [prices, setPrices] = useState<ServicePrice[]>([])
  const [branches, setBranches] = useState<Branch[]>([])
  const [slots, setSlots] = useState<Slot[]>([])

  // User selections
  const [selectedBrandName, setSelectedBrandName] = useState("Apple")
  const [selectedModelName, setSelectedModelName] = useState("iPhone 16")
  const [modelSearch, setModelSearch] = useState("")
  const [selectedServiceNames, setSelectedServiceNames] = useState<string[]>(["Thay màn hình", "Thay pin"])
  const [selectedBranchId, setSelectedBranchId] = useState<number | null>(initialBranchParam ? Number(initialBranchParam) : null)
  const [appointmentDate, setAppointmentDate] = useState(() => new Date().toISOString().slice(0, 10))
  const [selectedSlot, setSelectedSlot] = useState("")
  const [customerName, setCustomerName] = useState(user?.fullName || "Nguyễn Văn A")
  const [customerPhone, setCustomerPhone] = useState(user?.phoneNumber || "0901234567")
  const [problemDescription, setProblemDescription] = useState("Thay màn hình và vệ sinh điều hòa chính hãng, máy dùng nhanh hết pin và nứt kính.")

  const [saving, setSaving] = useState(false)
  const [errorMessage, setErrorMessage] = useState("")
  const [createdBooking, setCreatedBooking] = useState<BookingDetail | null>(null)
  const [copiedCode, setCopiedCode] = useState(false)

  // Fetch catalog brands & branches
  useEffect(() => {
    getBrands().then(setBrands).catch(() => {})
    getBranches()
      .then((brList) => {
        setBranches(brList)
        if (!selectedBranchId && brList.length > 0) {
          setSelectedBranchId(brList[0].id)
        }
      })
      .catch(() => {})
  }, [selectedBranchId])

  // Fetch models for brand
  useEffect(() => {
    const brand = brands.find((b) => b.name.toLowerCase() === selectedBrandName.toLowerCase())
    if (brand) {
      getModels(brand.id)
        .then(setModels)
        .catch(() => setModels([]))
    }
  }, [brands, selectedBrandName])

  // Fetch prices for selected model
  const activeModel = models.find((m) => m.name.toLowerCase() === selectedModelName.toLowerCase())
  useEffect(() => {
    if (activeModel) {
      getPrices(activeModel.id)
        .then(setPrices)
        .catch(() => setPrices([]))
    }
  }, [activeModel])

  // Fetch time slots when branch and date change
  useEffect(() => {
    if (selectedBranchId && appointmentDate) {
      getSlots(selectedBranchId, appointmentDate)
        .then((s) => {
          setSlots(s)
          if (s.length > 0 && (!selectedSlot || !s.some((item) => item.start === selectedSlot && !item.isFull))) {
            const available = s.find((item) => !item.isFull)
            if (available) setSelectedSlot(available.start)
          }
        })
        .catch(() => setSlots([]))
    }
  }, [selectedBranchId, appointmentDate, selectedSlot])

  // Calculate pricing
  const totalAmount = useMemo(() => {
    return selectedServiceNames.reduce((sum, sName) => {
      const template = SERVICE_TEMPLATES.find((t) => t.name === sName)
      const serverPrice = prices.find((p) => p.repairServiceName.toLowerCase() === sName.toLowerCase() && p.price)
      return sum + (serverPrice?.price ?? template?.price ?? 0)
    }, 0)
  }, [selectedServiceNames, prices])

  const toggleService = (sName: string) => {
    setSelectedServiceNames((prev) =>
      prev.includes(sName) ? prev.filter((n) => n !== sName) : [...prev, sName]
    )
  }

  const removeService = (sName: string) => {
    setSelectedServiceNames((prev) => prev.filter((n) => n !== sName))
  }

  const resetAll = () => {
    setSelectedServiceNames([])
  }

  const handleNextStep = () => {
    setErrorMessage("")
    if (activeStep === 0) {
      if (selectedServiceNames.length === 0) {
        setErrorMessage("Vui lòng chọn ít nhất một dịch vụ sửa chữa.")
        return
      }
      setActiveStep(1)
    } else if (activeStep === 1) {
      if (!selectedBranchId) {
        setErrorMessage("Vui lòng chọn một chi nhánh.")
        return
      }
      setActiveStep(2)
    } else if (activeStep === 2) {
      if (!appointmentDate || !selectedSlot) {
        setErrorMessage("Vui lòng chọn ngày và giờ hẹn.")
        return
      }
      setActiveStep(3)
    } else if (activeStep === 3) {
      if (!problemDescription.trim()) {
        setErrorMessage("Vui lòng nhập mô tả tình trạng máy.")
        return
      }
      setActiveStep(4)
    } else if (activeStep === 4) {
      handleSubmitBooking()
    }
  }

  const handlePrevStep = () => {
    setErrorMessage("")
    if (activeStep > 0) setActiveStep((prev) => prev - 1)
  }

  const handleSubmitBooking = async () => {
    if (!token) {
      setErrorMessage("Vui lòng đăng nhập để hoàn tất đặt lịch.")
      return
    }

    const modelToBook = models.find((m) => m.name.toLowerCase() === selectedModelName.toLowerCase()) || models[0]
    if (!modelToBook || !selectedBranchId || !appointmentDate || !selectedSlot) {
      setErrorMessage("Thông tin đặt lịch chưa đầy đủ.")
      return
    }

    const serviceIdsToBook = prices
      .filter((p) => selectedServiceNames.some((sn) => sn.toLowerCase() === p.repairServiceName.toLowerCase()))
      .map((p) => p.repairServiceId)

    setSaving(true)
    setErrorMessage("")
    try {
      const created = await createBooking(token, {
        phoneModelId: modelToBook.id,
        repairServiceIds: serviceIdsToBook.length > 0 ? serviceIdsToBook : [1],
        branchId: selectedBranchId,
        appointmentDate,
        slotStart: selectedSlot,
        problemDescription: problemDescription.trim(),
      })
      setCreatedBooking(created)
      setActiveStep(5)
    } catch (err) {
      if (err instanceof ApiError) {
        setErrorMessage(err.message)
      } else {
        setErrorMessage("Không thể tạo lịch hẹn. Vui lòng thử lại.")
      }
    } finally {
      setSaving(false)
    }
  }

  const formatVnd = (price: number) => {
    return price.toLocaleString("vi-VN") + "đ"
  }

  const selectedBranchObj = branches.find((b) => b.id === selectedBranchId) || branches[0]

  return (
    <main style={{ background: "#f8fafc", minHeight: "100vh", padding: "30px 20px 60px" }}>
      <div style={{ maxWidth: "1340px", margin: "0 auto" }}>
        {/* TITLE & 5-STEPPER HEADER (MATCHING SCREENSHOT) */}
        <div style={{ marginBottom: "26px" }}>
          <h1 style={{ fontSize: "1.65rem", fontWeight: 800, color: "#0f172a", margin: "0 0 20px", letterSpacing: "-0.02em" }}>
            Đặt lịch sửa chữa
          </h1>

          {/* STEPPER PROGRESS BAR */}
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", maxWidth: "860px", position: "relative" }}>
            {[
              { num: 1, label: "Chọn máy & dịch vụ" },
              { num: 2, label: "Chọn chi nhánh" },
              { num: 3, label: "Ngày & giờ" },
              { num: 4, label: "Thông tin" },
              { num: 5, label: "Xác nhận" },
            ].map((st, i) => {
              const isCurrent = activeStep === i
              const isDone = activeStep > i
              return (
                <div key={st.num} style={{ display: "flex", flexDirection: "column", alignItems: "center", position: "relative", zIndex: 2 }}>
                  <div
                    onClick={() => {
                      if (activeStep < 5 && i < activeStep) setActiveStep(i)
                    }}
                    style={{
                      width: "32px",
                      height: "32px",
                      borderRadius: "50%",
                      background: isCurrent || isDone ? "#2563eb" : "#ffffff",
                      border: isCurrent || isDone ? "2px solid #2563eb" : "2px solid #cbd5e1",
                      color: isCurrent || isDone ? "#ffffff" : "#64748b",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      fontSize: "0.85rem",
                      fontWeight: 800,
                      cursor: i < activeStep ? "pointer" : "default",
                      boxShadow: isCurrent ? "0 4px 12px rgba(37,99,235,0.35)" : "none",
                      transition: "all 0.2s ease",
                    }}
                  >
                    {isDone ? "✓" : st.num}
                  </div>
                  <span
                    style={{
                      fontSize: "0.82rem",
                      fontWeight: isCurrent ? 800 : 600,
                      color: isCurrent ? "#0f172a" : "#64748b",
                      marginTop: "6px",
                      whiteSpace: "nowrap",
                    }}
                  >
                    {st.label}
                  </span>
                </div>
              )
            })}

            {/* CONNECTING STEP LINE */}
            <div
              style={{
                position: "absolute",
                top: "16px",
                left: "40px",
                right: "40px",
                height: "2px",
                background: "#e2e8f0",
                zIndex: 1,
              }}
            />
          </div>
        </div>

        {errorMessage && (
          <div style={{ background: "#fef2f2", border: "1px solid #fecaca", color: "#dc2626", borderRadius: "10px", padding: "12px 16px", marginBottom: "20px", fontSize: "0.88rem" }}>
            {errorMessage}
          </div>
        )}

        {/* MAIN 2-COLUMN LAYOUT: WIZARD BODY (LEFT) & STICKY SUMMARY (RIGHT) */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 350px", gap: "28px", alignItems: "flex-start" }}>
          {/* LEFT COLUMN */}
          <div style={{ background: "#ffffff", border: "1px solid #e2e8f0", borderRadius: "20px", padding: "26px", boxShadow: "0 2px 10px rgba(15,23,42,0.03)" }}>
            {/* ================= STEP 0: CHỌN MÁY & DỊCH VỤ ================= */}
            {activeStep === 0 && (
              <div>
                {/* 1. CHỌN HÃNG VÀ DÒNG MÁY */}
                <div style={{ marginBottom: "28px" }}>
                  <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "4px" }}>
                    <div style={{ width: "24px", height: "24px", borderRadius: "50%", background: "#2563eb", color: "#ffffff", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "0.8rem", fontWeight: 800 }}>
                      1
                    </div>
                    <h2 style={{ fontSize: "1.05rem", fontWeight: 800, color: "#0f172a", margin: 0 }}>
                      Chọn hãng và dòng máy
                    </h2>
                  </div>
                  <p style={{ fontSize: "0.82rem", color: "#64748b", margin: "0 0 16px 34px" }}>
                    Chọn thương hiệu điện thoại và model thiết bị của bạn
                  </p>

                  {/* 8 BRAND PILL BUTTONS */}
                  <div style={{ display: "flex", gap: "10px", overflowX: "auto", paddingBottom: "6px", marginBottom: "22px" }}>
                    {BRAND_TABS.map((b) => {
                      const isActive = selectedBrandName === b.name
                      return (
                        <button
                          key={b.name}
                          type="button"
                          onClick={() => setSelectedBrandName(b.name)}
                          style={{
                            padding: "8px 18px",
                            borderRadius: "10px",
                            border: isActive ? "1.5px solid #2563eb" : "1px solid #e2e8f0",
                            background: isActive ? "#eff6ff" : "#ffffff",
                            color: isActive ? "#2563eb" : "#334155",
                            fontWeight: isActive ? 700 : 500,
                            fontSize: "0.86rem",
                            cursor: "pointer",
                            display: "flex",
                            alignItems: "center",
                            gap: "8px",
                            whiteSpace: "nowrap",
                            transition: "all 0.15s ease",
                          }}
                        >
                          {b.logo === "apple" && (
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
                              <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.81-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M15.97 6.37c.63-.76 1.05-1.82.93-2.87-.9.04-2 .6-2.65 1.36-.58.67-.99 1.76-.85 2.78 1 .08 2.05-.51 2.57-1.27z" />
                            </svg>
                          )}
                          {b.logo === "samsung" && <span style={{ fontWeight: 800, fontSize: "0.76rem", color: "#1428a0" }}>SAMSUNG</span>}
                          {b.logo === "xiaomi" && <span style={{ background: "#ff6700", color: "white", padding: "1px 3px", borderRadius: "3px", fontSize: "0.6rem", fontWeight: 800 }}>mi</span>}
                          {b.logo === "oppo" && <span style={{ fontWeight: 800, fontSize: "0.76rem", color: "#008853" }}>Oppo</span>}
                          {b.logo === "vivo" && <span style={{ fontWeight: 800, fontSize: "0.76rem", color: "#415fff" }}>Vivo</span>}
                          {b.logo === "realme" && <span style={{ background: "#ffc915", color: "#000", padding: "1px 4px", borderRadius: "3px", fontSize: "0.62rem", fontWeight: 900 }}>R</span>}
                          {b.logo === "google" && <span style={{ fontWeight: 800, fontSize: "0.76rem", color: "#4285F4" }}>Google</span>}
                          {b.logo === "honor" && <span style={{ fontWeight: 800, fontSize: "0.76rem" }}>Honor</span>}
                          <span>{b.name}</span>
                        </button>
                      )
                    })}
                  </div>

                  {/* CHỌN DÒNG MÁY IPHONE HEADER & SEARCH */}
                  <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "16px" }}>
                    <span style={{ fontSize: "0.95rem", fontWeight: 800, color: "#0f172a" }}>
                      Chọn dòng máy {selectedBrandName}
                    </span>

                    <div style={{ position: "relative", width: "230px" }}>
                      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#94a3b8" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" style={{ position: "absolute", left: "10px", top: "10px" }}>
                        <circle cx="11" cy="11" r="8" />
                        <line x1="21" y1="21" x2="16.65" y2="16.65" />
                      </svg>
                      <input
                        type="text"
                        placeholder={`Tìm kiếm model ${selectedBrandName}...`}
                        value={modelSearch}
                        onChange={(e) => setModelSearch(e.target.value)}
                        style={{
                          width: "100%",
                          height: "34px",
                          padding: "0 10px 0 32px",
                          borderRadius: "8px",
                          border: "1px solid #cbd5e1",
                          fontSize: "0.82rem",
                          background: "#f8fafc",
                          outline: "none",
                        }}
                      />
                    </div>
                  </div>

                  {/* 12 PHONE MODEL CARDS (6 COLUMNS X 2 ROWS MATCHING SCREENSHOT) */}
                  <div style={{ display: "grid", gridTemplateColumns: "repeat(6, 1fr)", gap: "12px" }}>
                    {MOCKUP_IPHONE_MODELS.filter((m) => m.name.toLowerCase().includes(modelSearch.toLowerCase())).map((m) => {
                      const isSelected = selectedModelName.toLowerCase() === m.name.toLowerCase()
                      return (
                        <div
                          key={m.name}
                          onClick={() => setSelectedModelName(m.name)}
                          style={{
                            background: isSelected ? "#eff6ff" : "#ffffff",
                            border: isSelected ? "1.5px solid #2563eb" : "1px solid #e2e8f0",
                            borderRadius: "12px",
                            padding: "12px 8px 10px",
                            display: "flex",
                            flexDirection: "column",
                            alignItems: "center",
                            cursor: "pointer",
                            position: "relative",
                            transition: "all 0.15s ease",
                            boxShadow: isSelected ? "0 4px 12px rgba(37,99,235,0.12)" : "none",
                          }}
                        >
                          {/* CHECKBOX INDICATOR TOP-LEFT */}
                          <div
                            style={{
                              position: "absolute",
                              top: "6px",
                              left: "6px",
                              width: "16px",
                              height: "16px",
                              borderRadius: "4px",
                              border: isSelected ? "none" : "1px solid #cbd5e1",
                              background: isSelected ? "#2563eb" : "#ffffff",
                              display: "flex",
                              alignItems: "center",
                              justifyContent: "center",
                              color: "#ffffff",
                              fontSize: "0.65rem",
                              fontWeight: 800,
                            }}
                          >
                            {isSelected ? "✓" : ""}
                          </div>

                          <img
                            src={m.image}
                            alt={m.name}
                            style={{
                              width: "50px",
                              height: "65px",
                              objectFit: "contain",
                              marginBottom: "8px",
                            }}
                          />
                          <strong style={{ fontSize: "0.82rem", color: "#0f172a", textAlign: "center", lineHeight: 1.2 }}>
                            {m.name}
                          </strong>
                          <span style={{ fontSize: "0.72rem", color: "#64748b", marginTop: "2px" }}>
                            ({m.year})
                          </span>
                        </div>
                      )
                    })}
                  </div>
                </div>

                <div style={{ borderTop: "1px solid #f1f5f9", margin: "24px 0" }} />

                {/* 2. CHỌN DỊCH VỤ SỬA CHỮA */}
                <div>
                  <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "4px" }}>
                    <div style={{ width: "24px", height: "24px", borderRadius: "50%", background: "#2563eb", color: "#ffffff", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "0.8rem", fontWeight: 800 }}>
                      2
                    </div>
                    <h2 style={{ fontSize: "1.05rem", fontWeight: 800, color: "#0f172a", margin: 0 }}>
                      Chọn dịch vụ sửa chữa
                    </h2>
                  </div>
                  <p style={{ fontSize: "0.82rem", color: "#64748b", margin: "0 0 18px 34px" }}>
                    Chọn một hoặc nhiều dịch vụ cần sửa chữa cho {selectedModelName}. Bạn có thể chọn nhiều dịch vụ cùng lúc.
                  </p>

                  {/* 9 REPAIR SERVICE CARDS (3 COLUMNS X 3 ROWS) */}
                  <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "14px" }}>
                    {SERVICE_TEMPLATES.map((svc) => {
                      const isChecked = selectedServiceNames.includes(svc.name)
                      return (
                        <div
                          key={svc.key}
                          onClick={() => toggleService(svc.name)}
                          style={{
                            background: isChecked ? "#eff6ff" : "#ffffff",
                            border: isChecked ? "1.5px solid #2563eb" : "1px solid #e2e8f0",
                            borderRadius: "14px",
                            padding: "14px",
                            display: "flex",
                            flexDirection: "column",
                            justifyContent: "space-between",
                            cursor: "pointer",
                            position: "relative",
                            transition: "all 0.15s ease",
                            minHeight: "115px",
                          }}
                        >
                          <div style={{ display: "flex", alignItems: "flex-start", gap: "10px" }}>
                            {/* Checkbox box */}
                            <div
                              style={{
                                width: "18px",
                                height: "18px",
                                borderRadius: "4px",
                                border: isChecked ? "none" : "1.5px solid #cbd5e1",
                                background: isChecked ? "#2563eb" : "#ffffff",
                                display: "flex",
                                alignItems: "center",
                                justifyContent: "center",
                                color: "#ffffff",
                                fontSize: "0.72rem",
                                fontWeight: 800,
                                flexShrink: 0,
                                marginTop: "2px",
                              }}
                            >
                              {isChecked ? "✓" : ""}
                            </div>

                            {/* Service icon box */}
                            <div
                              style={{
                                width: "36px",
                                height: "36px",
                                borderRadius: "8px",
                                background: svc.iconBg,
                                display: "flex",
                                alignItems: "center",
                                justifyContent: "center",
                                fontSize: "1.2rem",
                                flexShrink: 0,
                              }}
                            >
                              {svc.icon}
                            </div>

                            {/* Service text */}
                            <div style={{ flex: 1 }}>
                              <h3 style={{ fontSize: "0.92rem", fontWeight: 800, color: "#0f172a", margin: "0 0 4px" }}>
                                {svc.name}
                              </h3>
                              <p style={{ fontSize: "0.75rem", color: "#64748b", margin: 0, lineHeight: 1.35 }}>
                                {svc.desc}
                              </p>
                            </div>
                          </div>

                          {/* Price & Tag */}
                          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginTop: "12px", paddingLeft: "28px" }}>
                            <strong style={{ fontSize: "0.95rem", fontWeight: 800, color: "#0f172a" }}>
                              {formatVnd(svc.price)}
                            </strong>
                            {svc.isPopular && (
                              <span style={{ fontSize: "0.68rem", fontWeight: 700, color: "#dc2626", background: "#fef2f2", padding: "2px 8px", borderRadius: "999px", border: "1px solid #fecaca" }}>
                                Phổ biến
                              </span>
                            )}
                          </div>
                        </div>
                      )
                    })}
                  </div>
                </div>
              </div>
            )}

            {/* ================= STEP 1: CHỌN CHI NHÁNH ================= */}
            {activeStep === 1 && (
              <div>
                <h2 style={{ fontSize: "1.25rem", fontWeight: 800, color: "#0f172a", marginBottom: "6px" }}>
                  Bước 2: Chọn chi nhánh khảo sát sự cố
                </h2>
                <p style={{ fontSize: "0.86rem", color: "#64748b", marginBottom: "20px" }}>
                  Chọn cửa hàng thuận tiện nhất cho bạn để được phục vụ chu đáo:
                </p>

                <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
                  {branches.map((b) => {
                    const isSelected = selectedBranchId === b.id
                    return (
                      <div
                        key={b.id}
                        onClick={() => setSelectedBranchId(b.id)}
                        style={{
                          background: isSelected ? "#eff6ff" : "#ffffff",
                          border: isSelected ? "1.5px solid #2563eb" : "1px solid #e2e8f0",
                          borderRadius: "14px",
                          padding: "16px",
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "space-between",
                          cursor: "pointer",
                        }}
                      >
                        <div style={{ display: "flex", alignItems: "center", gap: "14px" }}>
                          <div
                            style={{
                              width: "20px",
                              height: "20px",
                              borderRadius: "50%",
                              border: isSelected ? "5px solid #2563eb" : "2px solid #cbd5e1",
                              background: "#ffffff",
                            }}
                          />
                          <div>
                            <strong style={{ fontSize: "1rem", color: "#0f172a", display: "block" }}>{b.name}</strong>
                            <span style={{ fontSize: "0.82rem", color: "#64748b" }}>📍 {b.address}</span>
                          </div>
                        </div>
                        <span style={{ fontSize: "0.82rem", color: "#2563eb", fontWeight: 700 }}>
                          📞 {b.phone}
                        </span>
                      </div>
                    )
                  })}
                </div>
              </div>
            )}

            {/* ================= STEP 2: NGÀY & GIỜ ================= */}
            {activeStep === 2 && (
              <div>
                <h2 style={{ fontSize: "1.25rem", fontWeight: 800, color: "#0f172a", marginBottom: "6px" }}>
                  Bước 3: Chọn ngày và khung giờ hẹn
                </h2>
                <p style={{ fontSize: "0.86rem", color: "#64748b", marginBottom: "20px" }}>
                  Hệ thống kiểm soát số lượng theo khung giờ để đảm bảo không phải chờ đợi:
                </p>

                <div style={{ marginBottom: "20px" }}>
                  <label style={{ display: "block", fontSize: "0.88rem", fontWeight: 700, color: "#0f172a", marginBottom: "8px" }}>
                    Chọn ngày hẹn:
                  </label>
                  <input
                    type="date"
                    min={new Date().toISOString().slice(0, 10)}
                    value={appointmentDate}
                    onChange={(e) => setAppointmentDate(e.target.value)}
                    style={{
                      padding: "10px 14px",
                      borderRadius: "10px",
                      border: "1px solid #cbd5e1",
                      fontSize: "0.9rem",
                      fontWeight: 600,
                      outline: "none",
                    }}
                  />
                </div>

                <div>
                  <label style={{ display: "block", fontSize: "0.88rem", fontWeight: 700, color: "#0f172a", marginBottom: "12px" }}>
                    Chọn khung giờ còn chỗ:
                  </label>
                  <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: "10px" }}>
                    {slots.map((s) => {
                      const isSelected = selectedSlot === s.start
                      const isFull = s.isFull
                      return (
                        <button
                          key={s.start}
                          type="button"
                          disabled={isFull}
                          onClick={() => setSelectedSlot(s.start)}
                          style={{
                            padding: "12px 10px",
                            borderRadius: "10px",
                            border: isSelected ? "1.5px solid #2563eb" : "1px solid #e2e8f0",
                            background: isFull ? "#f1f5f9" : isSelected ? "#eff6ff" : "#ffffff",
                            color: isFull ? "#94a3b8" : isSelected ? "#2563eb" : "#0f172a",
                            fontWeight: isSelected ? 800 : 600,
                            cursor: isFull ? "not-allowed" : "pointer",
                            fontSize: "0.85rem",
                            textAlign: "center",
                          }}
                        >
                          <div>{s.start} - {s.end}</div>
                          <span style={{ fontSize: "0.72rem", color: isFull ? "#ef4444" : "#16a34a" }}>
                            {isFull ? "Đã kín chỗ" : `Còn ${s.capacity - s.booked} chỗ`}
                          </span>
                        </button>
                      )
                    })}
                  </div>
                </div>
              </div>
            )}

            {/* ================= STEP 3: THÔNG TIN LIÊN HỆ ================= */}
            {activeStep === 3 && (
              <div>
                <h2 style={{ fontSize: "1.25rem", fontWeight: 800, color: "#0f172a", marginBottom: "6px" }}>
                  Bước 4: Thông tin khách hàng & mô tả lỗi
                </h2>
                <p style={{ fontSize: "0.86rem", color: "#64748b", marginBottom: "20px" }}>
                  Cung cấp thông tin liên hệ và mô tả ngắn gọn về tình trạng máy:
                </p>

                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "16px", marginBottom: "18px" }}>
                  <div>
                    <label style={{ display: "block", fontSize: "0.85rem", fontWeight: 700, color: "#0f172a", marginBottom: "6px" }}>
                      Họ và tên
                    </label>
                    <input
                      type="text"
                      value={customerName}
                      onChange={(e) => setCustomerName(e.target.value)}
                      style={{ width: "100%", padding: "10px 14px", borderRadius: "10px", border: "1px solid #cbd5e1", fontSize: "0.88rem" }}
                    />
                  </div>
                  <div>
                    <label style={{ display: "block", fontSize: "0.85rem", fontWeight: 700, color: "#0f172a", marginBottom: "6px" }}>
                      Số điện thoại
                    </label>
                    <input
                      type="tel"
                      value={customerPhone}
                      onChange={(e) => setCustomerPhone(e.target.value)}
                      style={{ width: "100%", padding: "10px 14px", borderRadius: "10px", border: "1px solid #cbd5e1", fontSize: "0.88rem" }}
                    />
                  </div>
                </div>

                <div>
                  <label style={{ display: "block", fontSize: "0.85rem", fontWeight: 700, color: "#0f172a", marginBottom: "6px" }}>
                    Mô tả tình trạng lỗi của máy
                  </label>
                  <textarea
                    rows={4}
                    value={problemDescription}
                    onChange={(e) => setProblemDescription(e.target.value)}
                    placeholder="Ví dụ: Màn hình bị nứt kính, hiển thị sọc xanh, pin sạc nhanh tụt..."
                    style={{ width: "100%", padding: "12px 14px", borderRadius: "10px", border: "1px solid #cbd5e1", fontSize: "0.88rem", outline: "none" }}
                  />
                </div>
              </div>
            )}

            {/* ================= STEP 4: XÁC NHẬN ================= */}
            {activeStep === 4 && (
              <div>
                <h2 style={{ fontSize: "1.25rem", fontWeight: 800, color: "#0f172a", marginBottom: "6px" }}>
                  Bước 5: Xác nhận thông tin lịch hẹn
                </h2>
                <p style={{ fontSize: "0.86rem", color: "#64748b", marginBottom: "20px" }}>
                  Vui lòng kiểm tra lại toàn bộ chi tiết trước khi hoàn tất:
                </p>

                <div style={{ background: "#f8fafc", border: "1px solid #e2e8f0", borderRadius: "14px", padding: "18px", display: "flex", flexDirection: "column", gap: "10px", fontSize: "0.88rem" }}>
                  <div><strong>Thiết bị:</strong> {selectedModelName} ({selectedBrandName})</div>
                  <div><strong>Dịch vụ:</strong> {selectedServiceNames.join(", ")}</div>
                  <div><strong>Chi nhánh:</strong> {selectedBranchObj?.name} ({selectedBranchObj?.address})</div>
                  <div><strong>Thời gian:</strong> {appointmentDate} lúc {selectedSlot}</div>
                  <div><strong>Khách hàng:</strong> {customerName} - {customerPhone}</div>
                  <div><strong>Mô tả:</strong> {problemDescription}</div>
                  <div style={{ borderTop: "1px solid #e2e8f0", paddingTop: "10px", display: "flex", justifyContent: "space-between", fontSize: "1rem" }}>
                    <strong>Ước tính chi phí:</strong>
                    <strong style={{ color: "#2563eb", fontSize: "1.2rem" }}>{formatVnd(totalAmount)}</strong>
                  </div>
                </div>
              </div>
            )}

            {/* ================= STEP 5: THÀNH CÔNG ================= */}
            {activeStep === 5 && createdBooking && (
              <div style={{ textAlign: "center", padding: "30px 10px" }}>
                <div style={{ width: "64px", height: "64px", borderRadius: "50%", background: "#dcfce7", color: "#16a34a", fontSize: "2rem", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 16px" }}>
                  ✓
                </div>
                <h2 style={{ fontSize: "1.5rem", fontWeight: 800, color: "#0f172a", marginBottom: "8px" }}>
                  Đặt lịch thành công!
                </h2>
                <p style={{ fontSize: "0.92rem", color: "#64748b", marginBottom: "20px" }}>
                  Cảm ơn bạn đã lựa chọn HomeRepair. Kỹ thuật viên sẽ chuẩn bị sẵn linh kiện để tiếp đón bạn.
                </p>

                <div style={{ background: "#eff6ff", border: "1px solid #bfdbfe", borderRadius: "12px", padding: "16px", maxWidth: "400px", margin: "0 auto 24px" }}>
                  <span style={{ fontSize: "0.82rem", color: "#64748b", display: "block" }}>Mã lịch hẹn của bạn:</span>
                  <div style={{ fontSize: "1.6rem", fontWeight: 900, color: "#2563eb", letterSpacing: "1px", margin: "4px 0" }}>
                    {createdBooking.bookingCode}
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      navigator.clipboard?.writeText(createdBooking.bookingCode)
                      setCopiedCode(true)
                      setTimeout(() => setCopiedCode(false), 2000)
                    }}
                    style={{ background: "#ffffff", border: "1px solid #cbd5e1", borderRadius: "6px", padding: "4px 12px", fontSize: "0.78rem", cursor: "pointer", color: "#334155" }}
                  >
                    {copiedCode ? "Đã sao chép ✓" : "Sao chép mã"}
                  </button>
                </div>

                <div style={{ display: "flex", gap: "12px", justifyContent: "center" }}>
                  <Link to={`/my-bookings/${createdBooking.id}`} className="btn" style={{ background: "#2563eb", color: "#ffffff", padding: "10px 22px", borderRadius: "10px", fontWeight: 700 }}>
                    Xem chi tiết lịch hẹn
                  </Link>
                  <Link to="/" style={{ background: "#ffffff", border: "1px solid #cbd5e1", color: "#334155", padding: "10px 22px", borderRadius: "10px", fontWeight: 600, textDecoration: "none" }}>
                    Về trang chủ
                  </Link>
                </div>
              </div>
            )}
          </div>

          {/* RIGHT COLUMN: STICKY BOOKING SUMMARY (MATCHING SCREENSHOT) */}
          <aside
            style={{
              background: "#ffffff",
              border: "1px solid #e2e8f0",
              borderRadius: "20px",
              padding: "22px",
              position: "sticky",
              top: "90px",
              boxShadow: "0 2px 10px rgba(15,23,42,0.03)",
            }}
          >
            {/* HEADER */}
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "16px", borderBottom: "1px solid #f1f5f9", paddingBottom: "12px" }}>
              <h3 style={{ fontSize: "1.1rem", fontWeight: 800, color: "#0f172a", margin: 0 }}>
                Thông tin đặt lịch
              </h3>
              <button
                type="button"
                onClick={resetAll}
                style={{ background: "none", border: "none", color: "#2563eb", fontSize: "0.8rem", fontWeight: 600, cursor: "pointer", display: "flex", alignItems: "center", gap: "4px" }}
              >
                <span>Làm mới</span>
                <span>↻</span>
              </button>
            </div>

            {/* BLOCK 1: THIẾT BỊ CỦA BẠN */}
            <div style={{ marginBottom: "16px" }}>
              <span style={{ fontSize: "0.82rem", fontWeight: 700, color: "#0f172a", display: "block", marginBottom: "6px" }}>
                Thiết bị của bạn
              </span>
              <div
                style={{
                  background: "#f8fafc",
                  border: "1px solid #e2e8f0",
                  borderRadius: "12px",
                  padding: "10px 12px",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                }}
              >
                <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                  <img
                    src={MOCKUP_IPHONE_MODELS.find((m) => m.name.toLowerCase() === selectedModelName.toLowerCase())?.image || MOCKUP_IPHONE_MODELS[0].image}
                    alt={selectedModelName}
                    style={{ width: "28px", height: "36px", objectFit: "contain" }}
                  />
                  <div>
                    <strong style={{ fontSize: "0.88rem", color: "#0f172a", display: "block" }}>{selectedModelName}</strong>
                    <span style={{ fontSize: "0.74rem", color: "#64748b" }}>{selectedBrandName}</span>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setActiveStep(0)}
                  style={{ background: "#ffffff", border: "1px solid #cbd5e1", borderRadius: "8px", padding: "4px 10px", fontSize: "0.76rem", fontWeight: 600, color: "#0f172a", cursor: "pointer" }}
                >
                  Thay đổi
                </button>
              </div>
            </div>

            {/* BLOCK 2: DỊCH VỤ ĐÃ CHỌN */}
            <div style={{ marginBottom: "16px" }}>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "8px" }}>
                <span style={{ fontSize: "0.82rem", fontWeight: 700, color: "#0f172a" }}>
                  Dịch vụ đã chọn ({selectedServiceNames.length})
                </span>
                {selectedServiceNames.length > 0 && (
                  <button
                    type="button"
                    onClick={() => setSelectedServiceNames([])}
                    style={{ background: "none", border: "none", color: "#ef4444", fontSize: "0.74rem", fontWeight: 600, cursor: "pointer", display: "flex", alignItems: "center", gap: "2px" }}
                  >
                    <span>Xóa tất cả</span>
                    <span>🗑️</span>
                  </button>
                )}
              </div>

              {selectedServiceNames.length === 0 ? (
                <p style={{ fontSize: "0.78rem", color: "#94a3b8", margin: 0, fontStyle: "italic" }}>
                  Chưa chọn dịch vụ nào
                </p>
              ) : (
                <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
                  {selectedServiceNames.map((sName) => {
                    const template = SERVICE_TEMPLATES.find((t) => t.name === sName)
                    return (
                      <div
                        key={sName}
                        style={{
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "space-between",
                          padding: "6px 0",
                          borderBottom: "1px dashed #f1f5f9",
                        }}
                      >
                        <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                          <span style={{ fontSize: "1rem" }}>{template?.icon || "🔧"}</span>
                          <span style={{ fontSize: "0.82rem", fontWeight: 600, color: "#0f172a" }}>{sName}</span>
                        </div>
                        <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                          <strong style={{ fontSize: "0.82rem", color: "#0f172a" }}>
                            {formatVnd(template?.price ?? 0)}
                          </strong>
                          <button
                            type="button"
                            onClick={() => removeService(sName)}
                            style={{ background: "none", border: "none", color: "#ef4444", cursor: "pointer", fontSize: "0.82rem", padding: "2px" }}
                            title="Xóa"
                          >
                            🗑️
                          </button>
                        </div>
                      </div>
                    )
                  })}
                </div>
              )}
            </div>

            {/* BLOCK 3: TẠM TÍNH */}
            <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", margin: "16px 0", paddingTop: "12px", borderTop: "1px solid #f1f5f9" }}>
              <span style={{ fontSize: "0.95rem", fontWeight: 700, color: "#0f172a" }}>Tạm tính</span>
              <strong style={{ fontSize: "1.3rem", fontWeight: 900, color: "#0f172a" }}>
                {formatVnd(totalAmount)}
              </strong>
            </div>

            {/* INFO BANNER */}
            <div
              style={{
                background: "#f0f9ff",
                border: "1px solid #bae6fd",
                borderRadius: "10px",
                padding: "10px 12px",
                display: "flex",
                gap: "8px",
                fontSize: "0.72rem",
                color: "#0369a1",
                lineHeight: 1.45,
                marginBottom: "18px",
              }}
            >
              <span>ℹ️</span>
              <span>
                Giá có thể thay đổi sau khi kỹ thuật viên kiểm tra thực tế tình trạng máy. Chúng tôi sẽ liên hệ xác nhận trước khi tiến hành sửa chữa.
              </span>
            </div>

            {/* CAM KẾT CỦA PHONEREPAIR */}
            <div style={{ marginBottom: "20px" }}>
              <div style={{ display: "flex", alignItems: "center", gap: "6px", marginBottom: "8px" }}>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#2563eb" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
                  <path d="M9 12l2 2 4-4" />
                </svg>
                <strong style={{ fontSize: "0.86rem", color: "#0f172a" }}>Cam kết của HomeRepair</strong>
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: "6px", fontSize: "0.76rem", color: "#475569" }}>
                <div>✓ Linh kiện chính hãng, chất lượng đảm bảo</div>
                <div>✓ Bảo hành rõ ràng, minh bạch</div>
                <div>✓ Kiểm tra và tư vấn miễn phí</div>
                <div>✓ Không phát sinh chi phí ẩn</div>
              </div>
            </div>

            {/* ACTION BUTTONS (MATCHING SCREENSHOT) */}
            {activeStep < 5 && (
              <div style={{ display: "flex", gap: "10px" }}>
                <button
                  type="button"
                  disabled={activeStep === 0}
                  onClick={handlePrevStep}
                  style={{
                    height: "42px",
                    padding: "0 16px",
                    borderRadius: "10px",
                    border: "1px solid #cbd5e1",
                    background: "#ffffff",
                    color: activeStep === 0 ? "#94a3b8" : "#334155",
                    fontSize: "0.86rem",
                    fontWeight: 600,
                    cursor: activeStep === 0 ? "not-allowed" : "pointer",
                  }}
                >
                  &lt; Quay lại
                </button>
                <button
                  type="button"
                  disabled={saving}
                  onClick={handleNextStep}
                  style={{
                    flex: 1,
                    height: "42px",
                    borderRadius: "10px",
                    border: "none",
                    background: "#2563eb",
                    color: "#ffffff",
                    fontSize: "0.88rem",
                    fontWeight: 700,
                    cursor: saving ? "wait" : "pointer",
                    boxShadow: "0 4px 12px rgba(37,99,235,0.3)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    gap: "6px",
                  }}
                >
                  <span>{activeStep === 4 ? (saving ? "Đang xử lý..." : "Xác nhận đặt lịch") : "Tiếp tục"}</span>
                  <span>&gt;</span>
                </button>
              </div>
            )}
          </aside>
        </div>
      </div>
    </main>
  )
}
