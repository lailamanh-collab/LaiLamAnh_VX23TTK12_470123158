import { useState } from "react"
import { Link, useNavigate } from "react-router-dom"
import {
  branchCauGiay,
  branchDongDa,
  branchHaiBaTrung,
  customer1,
  customer2,
  customer3,
  tech1,
  BRAND_LOGOS,
  SERVICE_ICONS,
} from "../assets"

interface ServiceQuickItem {
  id: number
  title: string
  price: string
  icon: string
  bg: string
  color: string
  key: string
}

const QUICK_SERVICES: ServiceQuickItem[] = [
  { id: 1, title: "Thay màn hình", price: "Từ 1.500.000đ", icon: "📱", bg: "#eff6ff", color: "#2563eb", key: "screen" },
  { id: 2, title: "Thay pin", price: "Từ 500.000đ", icon: "🔋", bg: "#f0fdf4", color: "#16a34a", key: "battery" },
  { id: 3, title: "Sửa cổng sạc", price: "Từ 300.000đ", icon: "🔌", bg: "#f0f9ff", color: "#0284c7", key: "port" },
  { id: 4, title: "Sửa camera", price: "Từ 400.000đ", icon: "📷", bg: "#faf5ff", color: "#9333ea", key: "camera" },
  { id: 5, title: "Sửa loa", price: "Từ 250.000đ", icon: "🔊", bg: "#fdf4ff", color: "#c026d3", key: "speaker" },
  { id: 6, title: "Vệ sinh máy", price: "Từ 150.000đ", icon: "🧹", bg: "#ecfeff", color: "#0891b2", key: "clean" },
]

interface BrandQuickItem {
  name: string
  sub: string
  logo: string
  brandId?: number
}

const POPULAR_BRANDS: BrandQuickItem[] = [
  { name: "Apple", sub: "iPhone", logo: "🍎", brandId: 1 },
  { name: "Samsung", sub: "Galaxy", logo: "📱", brandId: 2 },
  { name: "Xiaomi", sub: "", logo: "🟠", brandId: 3 },
  { name: "Oppo", sub: "", logo: "🟢", brandId: 4 },
  { name: "Vivo", sub: "", logo: "🔷", brandId: 5 },
  { name: "Realme", sub: "", logo: "🟡", brandId: 6 },
  { name: "Google", sub: "Pixel", logo: "🌐", brandId: 7 },
  { name: "Honor", sub: "", logo: "💠", brandId: 8 },
]

interface StoreBranchPreview {
  id: number
  name: string
  address: string
  hours: string
  phone: string
  image: string
}

const FEATURED_BRANCHES: StoreBranchPreview[] = [
  {
    id: 1,
    name: "PhoneRepair Cầu Giấy",
    address: "123 Cầu Giấy, Cầu Giấy, Hà Nội",
    hours: "08:00 - 20:00",
    phone: "024 1234 5678",
    image: branchCauGiay,
  },
  {
    id: 2,
    name: "PhoneRepair Đống Đa",
    address: "456 Xã Đàn, Đống Đa, Hà Nội",
    hours: "08:00 - 20:00",
    phone: "024 2345 6789",
    image: branchDongDa,
  },
  {
    id: 3,
    name: "PhoneRepair Hai Bà Trưng",
    address: "789 Phố Huế, Hai Bà Trưng, Hà Nội",
    hours: "08:00 - 20:00",
    phone: "024 3456 7890",
    image: branchHaiBaTrung,
  },
]

interface CustomerReviewPreview {
  name: string
  timeAgo: string
  avatar: string
  comment: string
  rating: number
}

const CUSTOMER_REVIEWS: CustomerReviewPreview[] = [
  {
    name: "Nguyễn Minh Tuấn",
    timeAgo: "2 tuần trước",
    avatar: customer1,
    comment: "Sửa nhanh, nhân viên rất nhiệt tình. Máy hoạt động tốt, giá hợp lý.",
    rating: 5,
  },
  {
    name: "Trần Thị Lan",
    timeAgo: "1 tháng trước",
    avatar: customer2,
    comment: "Đặt lịch online rất tiện, không phải chờ đợi. Dịch vụ chuyên nghiệp.",
    rating: 5,
  },
  {
    name: "Lê Hoàng Nam",
    timeAgo: "3 tuần trước",
    avatar: customer3,
    comment: "Thay pin iPhone nhanh chóng, bảo hành rõ ràng. Sẽ quay lại.",
    rating: 5,
  },
]

export function HomePage() {
  const navigate = useNavigate()
  const [heroSearch, setHeroSearch] = useState("")

  const handleHeroSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (heroSearch.trim()) {
      navigate(`/services?q=${encodeURIComponent(heroSearch.trim())}`)
    } else {
      navigate("/services")
    }
  }

  return (
    <main className="home-page-container">
      {/* 1. HERO SECTION (MATCHING SCREENSHOT) */}
      <section className="home-hero-section">
        <div>
          <h1 className="home-hero-title">
            Sửa điện thoại nhanh chóng,
            <br />
            uy tín, chuyên nghiệp
          </h1>
          <p className="home-hero-subtitle">
            Đặt lịch trước – Không chờ đợi – Lấy máy đúng hẹn
          </p>

          {/* SEARCH BAR */}
          <form onSubmit={handleHeroSearch} className="home-hero-search-box">
            <span style={{ color: "#94a3b8", marginRight: "10px", fontSize: "1.1rem" }}>🔍</span>
            <input
              type="text"
              className="home-hero-search-input"
              placeholder="Tìm kiếm dịch vụ, thiết bị hoặc chi nhánh..."
              value={heroSearch}
              onChange={(e) => setHeroSearch(e.target.value)}
            />
            <button type="submit" className="home-hero-search-btn">
              Tìm kiếm
            </button>
          </form>

          {/* 4 QUALITY BADGES ROW */}
          <div className="home-quality-badges-row">
            <div className="home-quality-badge-item">
              <div className="home-quality-badge-icon">🛡️</div>
              <div>
                <strong style={{ display: "block", fontSize: "0.85rem", color: "white" }}>Linh kiện chính hãng</strong>
                <span style={{ fontSize: "0.75rem", color: "#94a3b8" }}>Chất lượng đảm bảo</span>
              </div>
            </div>

            <div className="home-quality-badge-item">
              <div className="home-quality-badge-icon">👨‍💼</div>
              <div>
                <strong style={{ display: "block", fontSize: "0.85rem", color: "white" }}>Kỹ thuật viên chuyên nghiệp</strong>
                <span style={{ fontSize: "0.75rem", color: "#94a3b8" }}>Nhiều năm kinh nghiệm</span>
              </div>
            </div>

            <div className="home-quality-badge-item">
              <div className="home-quality-badge-icon">🛡️</div>
              <div>
                <strong style={{ display: "block", fontSize: "0.85rem", color: "white" }}>Bảo hành rõ ràng</strong>
                <span style={{ fontSize: "0.75rem", color: "#94a3b8" }}>An tâm sau sửa chữa</span>
              </div>
            </div>

            <div className="home-quality-badge-item">
              <div className="home-quality-badge-icon">📍</div>
              <div>
                <strong style={{ display: "block", fontSize: "0.85rem", color: "white" }}>Hệ thống chi nhánh</strong>
                <span style={{ fontSize: "0.75rem", color: "#94a3b8" }}>Thuận tiện, dễ tìm</span>
              </div>
            </div>
          </div>
        </div>

        {/* HERO RIGHT VISUAL: PHONES CLUSTER WITH FLOATING CTA PILL */}
        <div className="home-hero-visual-col">
          <div className="home-hero-phones-cluster">
            {/* PHONE 1: LEFT BLUE */}
            <div
              style={{
                width: "90px",
                height: "170px",
                background: "#1e293b",
                borderRadius: "18px 18px 0 0",
                border: "2px solid #334155",
                borderBottom: "none",
                padding: "6px",
                boxShadow: "0 10px 30px rgba(0,0,0,0.5)",
              }}
            >
              <div style={{ width: "24px", height: "3px", background: "#475569", borderRadius: "2px", margin: "0 auto 6px" }} />
              <div
                style={{
                  width: "100%",
                  height: "calc(100% - 9px)",
                  background: "linear-gradient(180deg, #0284c7 0%, #0f172a 100%)",
                  borderRadius: "12px",
                }}
              />
            </div>

            {/* PHONE 2: CENTER TITANIUM PRO MAX */}
            <div
              style={{
                width: "130px",
                height: "230px",
                background: "#0f172a",
                borderRadius: "24px 24px 0 0",
                border: "3px solid #64748b",
                borderBottom: "none",
                padding: "8px",
                boxShadow: "0 20px 45px rgba(0,0,0,0.6)",
              }}
            >
              <div style={{ width: "36px", height: "4px", background: "#64748b", borderRadius: "2px", margin: "0 auto 8px" }} />
              <div
                style={{
                  width: "100%",
                  height: "calc(100% - 12px)",
                  background: "linear-gradient(180deg, #1e3a8a 0%, #0f172a 100%)",
                  borderRadius: "16px",
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <span style={{ fontSize: "1.4rem", fontWeight: 800, color: "white" }}>9:41</span>
                <span style={{ fontSize: "0.72rem", color: "#93c5fd" }}>PhoneRepair</span>
              </div>
            </div>

            {/* PHONE 3: RIGHT MID */}
            <div
              style={{
                width: "100px",
                height: "190px",
                background: "#1e293b",
                borderRadius: "20px 20px 0 0",
                border: "2px solid #475569",
                borderBottom: "none",
                padding: "6px",
                boxShadow: "0 14px 35px rgba(0,0,0,0.5)",
              }}
            >
              <div style={{ width: "28px", height: "3px", background: "#475569", borderRadius: "2px", margin: "0 auto 6px" }} />
              <div
                style={{
                  width: "100%",
                  height: "calc(100% - 9px)",
                  background: "linear-gradient(180deg, #2563eb 0%, #1e293b 100%)",
                  borderRadius: "14px",
                }}
              />
            </div>
          </div>

          {/* FLOATING BLUE PILL WITH WRENCH */}
          <Link to="/booking" className="home-floating-cta-pill">
            <div>
              <strong style={{ display: "block", fontSize: "0.95rem", color: "white" }}>Đặt lịch ngay</strong>
              <span style={{ fontSize: "0.76rem", color: "#bfdbfe" }}>chỉ với vài bước →</span>
            </div>
            <div
              style={{
                width: "36px",
                height: "36px",
                borderRadius: "10px",
                background: "rgba(255,255,255,0.2)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                fontSize: "1.2rem",
              }}
            >
              🔧
            </div>
          </Link>
        </div>
      </section>

      {/* 2. DUAL CARDS SECTION: DỊCH VỤ PHỔ BIẾN & CÁC HÃNG PHỔ BIẾN */}
      <section className="home-dual-cards-row">
        {/* LEFT CARD: DỊCH VỤ SỬA CHỮA PHỔ BIẾN */}
        <div className="home-section-card">
          <div className="home-section-card-header">
            <h2 className="home-section-card-title">Dịch vụ sửa chữa phổ biến</h2>
            <Link to="/services" className="home-section-card-link">
              Xem tất cả →
            </Link>
          </div>

          <div className="home-popular-services-grid">
            {QUICK_SERVICES.map((s) => (
              <Link key={s.id} to={`/pricing?service=${s.key}`} className="home-popular-service-item">
                <div className="home-popular-service-icon" style={{ background: s.bg, color: s.color }}>
                  {SERVICE_ICONS[s.key] ? (
                    <img src={SERVICE_ICONS[s.key]} alt={s.title} style={{ width: "20px", height: "20px" }} />
                  ) : (
                    s.icon
                  )}
                </div>
                <strong style={{ fontSize: "0.85rem", color: "#0f172a", marginBottom: "4px" }}>
                  {s.title}
                </strong>
                <span style={{ fontSize: "0.72rem", color: "#64748b" }}>
                  {s.price}
                </span>
              </Link>
            ))}
          </div>
        </div>

        {/* RIGHT CARD: CÁC HÃNG ĐIỆN THOẠI PHỔ BIẾN */}
        <div className="home-section-card">
          <div className="home-section-card-header">
            <h2 className="home-section-card-title">Các hãng điện thoại phổ biến</h2>
            <Link to="/brands" className="home-section-card-link">
              Xem tất cả →
            </Link>
          </div>

          <div className="home-popular-brands-grid">
            {POPULAR_BRANDS.map((b) => (
              <Link key={b.name} to={`/booking?brand=${encodeURIComponent(b.name)}`} className="home-popular-brand-item">
                <div
                  style={{
                    height: "30px",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    marginBottom: "8px",
                    width: "100%",
                  }}
                >
                  {BRAND_LOGOS[b.name] ? (
                    <img
                      src={BRAND_LOGOS[b.name]}
                      alt={b.name}
                      style={{
                        maxHeight: "24px",
                        maxWidth: "76px",
                        width: "auto",
                        height: "auto",
                        objectFit: "contain",
                        display: "block",
                      }}
                    />
                  ) : (
                    <span style={{ fontSize: "1.4rem" }}>{b.logo}</span>
                  )}
                </div>

                <strong
                  style={{
                    fontSize: "0.84rem",
                    fontWeight: 700,
                    color: "#0f172a",
                    lineHeight: "1.2",
                    display: "block",
                  }}
                >
                  {b.name}
                </strong>

                <span
                  style={{
                    fontSize: "0.72rem",
                    color: "#94a3b8",
                    minHeight: "16px",
                    lineHeight: "16px",
                    marginTop: "3px",
                    display: "block",
                  }}
                >
                  {b.sub || "\u00A0"}
                </span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* 3. PROCESS CARD: QUY TRÌNH SỬA CHỮA TẠI PHONEREPAIR */}
      <section className="home-process-card">
        <h2 style={{ fontSize: "1.35rem", fontWeight: 800, color: "#0f172a", margin: "0 0 28px" }}>
          Quy trình sửa chữa tại PhoneRepair
        </h2>

        <div className="home-process-split">
          {/* 4 STEPS TIMELINE */}
          <div className="home-process-steps-row">
            {/* STEP 1 */}
            <div className="home-process-step-col">
              <div className="home-process-icon-circle">
                📅
                <span className="home-process-badge-number">1</span>
              </div>
              <strong style={{ fontSize: "0.95rem", color: "#0f172a", marginBottom: "4px" }}>
                Đặt lịch
              </strong>
              <span style={{ fontSize: "0.78rem", color: "#64748b", lineHeight: 1.4 }}>
                Chọn dịch vụ, chi nhánh, ngày giờ phù hợp
              </span>
            </div>

            <span className="home-process-arrow">›</span>

            {/* STEP 2 */}
            <div className="home-process-step-col">
              <div className="home-process-icon-circle">
                📋
                <span className="home-process-badge-number">2</span>
              </div>
              <strong style={{ fontSize: "0.95rem", color: "#0f172a", marginBottom: "4px" }}>
                Tiếp nhận
              </strong>
              <span style={{ fontSize: "0.78rem", color: "#64748b", lineHeight: 1.4 }}>
                Kiểm tra tình trạng máy
              </span>
            </div>

            <span className="home-process-arrow">›</span>

            {/* STEP 3 */}
            <div className="home-process-step-col">
              <div className="home-process-icon-circle">
                🔧
                <span className="home-process-badge-number">3</span>
              </div>
              <strong style={{ fontSize: "0.95rem", color: "#0f172a", marginBottom: "4px" }}>
                Sửa chữa
              </strong>
              <span style={{ fontSize: "0.78rem", color: "#64748b", lineHeight: 1.4 }}>
                Kỹ thuật viên thực hiện
              </span>
            </div>

            <span className="home-process-arrow">›</span>

            {/* STEP 4 */}
            <div className="home-process-step-col">
              <div className="home-process-icon-circle">
                🛡️
                <span className="home-process-badge-number">4</span>
              </div>
              <strong style={{ fontSize: "0.95rem", color: "#0f172a", marginBottom: "4px" }}>
                Kiểm tra & bàn giao
              </strong>
              <span style={{ fontSize: "0.78rem", color: "#64748b", lineHeight: 1.4 }}>
                Kiểm tra chức năng, nhận máy và bảo hành
              </span>
            </div>
          </div>

          {/* ONLINE BOOKING FEATURE BOX */}
          <div className="home-booking-feature-box">
            <div style={{ flex: 1, zIndex: 2 }}>
              <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "6px" }}>
                <span style={{ fontSize: "1.4rem" }}>📱</span>
                <div>
                  <strong style={{ fontSize: "1.05rem", color: "#1e3a8a", display: "block" }}>
                    Đặt lịch trực tuyến
                  </strong>
                  <span style={{ fontSize: "0.78rem", color: "#0284c7" }}>Nhanh chóng, tiện lợi</span>
                </div>
              </div>

              <ul style={{ listStyle: "none", padding: 0, margin: "14px 0 16px", display: "flex", flexDirection: "column", gap: "6px", fontSize: "0.8rem", color: "#334155" }}>
                <li style={{ display: "flex", alignItems: "center", gap: "6px" }}>
                  <span style={{ color: "#16a34a", fontWeight: "bold" }}>✓</span>
                  <span>Chọn chi nhánh gần bạn</span>
                </li>
                <li style={{ display: "flex", alignItems: "center", gap: "6px" }}>
                  <span style={{ color: "#16a34a", fontWeight: "bold" }}>✓</span>
                  <span>Chọn dịch vụ và thời gian</span>
                </li>
                <li style={{ display: "flex", alignItems: "center", gap: "6px" }}>
                  <span style={{ color: "#16a34a", fontWeight: "bold" }}>✓</span>
                  <span>Không cần chờ đợi</span>
                </li>
                <li style={{ display: "flex", alignItems: "center", gap: "6px" }}>
                  <span style={{ color: "#16a34a", fontWeight: "bold" }}>✓</span>
                  <span>Nhận xác nhận ngay lập tức</span>
                </li>
              </ul>

              <Link
                to="/booking"
                className="btn"
                style={{
                  background: "#2563eb",
                  color: "#ffffff",
                  padding: "8px 20px",
                  borderRadius: "10px",
                  fontSize: "0.85rem",
                  fontWeight: 700,
                  boxShadow: "0 4px 12px rgba(37,99,235,0.3)",
                }}
              >
                Đặt lịch ngay →
              </Link>
            </div>

            {/* ILLUSTRATION OF SUPPORT SPECIALIST */}
            <div style={{ width: "120px", textAlign: "center", flexShrink: 0 }}>
              <img
                src={tech1}
                alt="Chuyên viên hỗ trợ PhoneRepair"
                style={{ width: "110px", height: "135px", objectFit: "cover", borderRadius: "14px", boxShadow: "0 8px 20px rgba(0,0,0,0.15)" }}
              />
            </div>
          </div>
        </div>
      </section>

      {/* 4. DUAL BOTTOM CARDS: CHI NHÁNH CỦA CHÚNG TÔI & KHÁCH HÀNG NÓI GÌ */}
      <section className="home-branches-reviews-row">
        {/* LEFT: CHI NHÁNH CỦA CHÚNG TÔI */}
        <div className="home-section-card">
          <div className="home-section-card-header">
            <h2 className="home-section-card-title">Chi nhánh của chúng tôi</h2>
            <Link to="/branches" className="home-section-card-link">
              Xem tất cả →
            </Link>
          </div>

          <div className="home-branch-triplet-grid">
            {FEATURED_BRANCHES.map((b) => (
              <Link key={b.id} to="/branches" className="home-branch-mini-card">
                <img src={b.image} alt={b.name} className="home-branch-mini-img" />
                <div className="home-branch-mini-body">
                  <strong style={{ fontSize: "0.92rem", color: "#0f172a", marginBottom: "2px" }}>
                    {b.name}
                  </strong>
                  <div style={{ fontSize: "0.76rem", color: "#64748b" }}>📍 {b.address}</div>
                  <div style={{ fontSize: "0.76rem", color: "#64748b" }}>🕒 {b.hours}</div>
                  <div style={{ fontSize: "0.76rem", color: "#64748b" }}>📞 {b.phone}</div>
                </div>
              </Link>
            ))}
          </div>
        </div>

        {/* RIGHT: KHÁCH HÀNG NÓI GÌ VỀ CHÚNG TÔI */}
        <div className="home-section-card">
          <div className="home-section-card-header">
            <h2 className="home-section-card-title">Khách hàng nói gì về chúng tôi</h2>
            <Link to="/support" className="home-section-card-link">
              Xem tất cả →
            </Link>
          </div>

          <div className="home-reviews-triplet-grid">
            {CUSTOMER_REVIEWS.map((r, i) => (
              <div key={i} className="home-review-mini-card">
                <div>
                  <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "8px" }}>
                    <img
                      src={r.avatar}
                      alt={r.name}
                      style={{ width: "36px", height: "36px", borderRadius: "50%", objectFit: "cover" }}
                    />
                    <div>
                      <strong style={{ display: "block", fontSize: "0.85rem", color: "#0f172a" }}>
                        {r.name}
                      </strong>
                      <span style={{ fontSize: "0.72rem", color: "#94a3b8" }}>{r.timeAgo}</span>
                    </div>
                  </div>

                  <div style={{ color: "#eab308", fontSize: "0.85rem", marginBottom: "8px" }}>
                    {"★".repeat(r.rating)}
                  </div>

                  <p style={{ margin: 0, fontSize: "0.8rem", color: "#475569", lineHeight: 1.5 }}>
                    "{r.comment}"
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </main>
  )
}
