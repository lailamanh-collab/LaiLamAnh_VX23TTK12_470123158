import { zodResolver } from "@hookform/resolvers/zod"
import { useState } from "react"
import { useForm } from "react-hook-form"
import { Link, Navigate, useNavigate } from "react-router-dom"
import { z } from "zod"
import { homePathForRole, login } from "../api/auth"
import { ApiError } from "../api/client"
import { useAuth } from "../auth/AuthContext"

const schema = z.object({
  email: z.string().min(1, "Vui lòng nhập email hoặc số điện thoại."),
  password: z.string().min(1, "Vui lòng nhập mật khẩu."),
  rememberMe: z.boolean().optional(),
})

type LoginValues = z.infer<typeof schema>

export function LoginPage() {
  const navigate = useNavigate()
  const { user, setSession } = useAuth()
  const [showPassword, setShowPassword] = useState(false)

  const {
    register,
    handleSubmit,
    setValue,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<LoginValues>({
    resolver: zodResolver(schema),
    defaultValues: { email: "", password: "", rememberMe: true },
  })

  if (user) {
    return <Navigate to={homePathForRole(user.role)} replace />
  }

  async function onSubmit(values: LoginValues) {
    try {
      const result = await login(values.email, values.password)
      setSession(result.accessToken, result.user)
      navigate(homePathForRole(result.user.role))
    } catch (error) {
      const message = error instanceof ApiError ? error.message : "Email hoặc mật khẩu không chính xác."
      setError("root", { message })
    }
  }

  const fillDemoAccount = (email: string, pass: string) => {
    setValue("email", email, { shouldValidate: true })
    setValue("password", pass, { shouldValidate: true })
  }

  return (
    <main className="auth-page-container">
      <div className="auth-split-card">
        {/* LEFT SHOWCASE PANEL (IMAGE 2) */}
        <div className="auth-showcase-side">
          <div>
            <div className="auth-trust-pill">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#38bdf8" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
                <path d="m9 12 2 2 4-4" />
              </svg>
              <span>Hơn 50.000+ khách hàng tin tưởng</span>
            </div>

            <h1 className="auth-showcase-title">
              Sửa điện thoại <span>nhanh chóng,</span>
              <br />
              uy tín, chuyên nghiệp
            </h1>

            <p className="auth-showcase-desc">
              Đặt lịch trước – Không chờ đợi – Lấy máy đúng hẹn
            </p>

            {/* 4 PILLARS GRID */}
            <div className="auth-pillars-grid">
              <div className="auth-pillar-box">
                <div style={{ width: "36px", height: "36px", borderRadius: "10px", background: "rgba(56, 189, 248, 0.2)", display: "flex", alignItems: "center", justifyContent: "center", color: "#38bdf8" }}>
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
                    <path d="m9 12 2 2 4-4" />
                  </svg>
                </div>
                <strong>Linh kiện chính hãng</strong>
                <span>Chất lượng đảm bảo</span>
              </div>

              <div className="auth-pillar-box">
                <div style={{ width: "36px", height: "36px", borderRadius: "10px", background: "rgba(56, 189, 248, 0.2)", display: "flex", alignItems: "center", justifyContent: "center", color: "#38bdf8" }}>
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                    <circle cx="12" cy="12" r="10" />
                    <polyline points="12 6 12 12 16 14" />
                  </svg>
                </div>
                <strong>Kỹ thuật viên chuyên nghiệp</strong>
                <span>Nhiều năm kinh nghiệm</span>
              </div>

              <div className="auth-pillar-box">
                <div style={{ width: "36px", height: "36px", borderRadius: "10px", background: "rgba(56, 189, 248, 0.2)", display: "flex", alignItems: "center", justifyContent: "center", color: "#38bdf8" }}>
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                    <circle cx="12" cy="12" r="3" />
                    <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z" />
                  </svg>
                </div>
                <strong>Bảo hành rõ ràng</strong>
                <span>An tâm sau sửa chữa</span>
              </div>

              <div className="auth-pillar-box">
                <div style={{ width: "36px", height: "36px", borderRadius: "10px", background: "rgba(56, 189, 248, 0.2)", display: "flex", alignItems: "center", justifyContent: "center", color: "#38bdf8" }}>
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z" />
                    <circle cx="12" cy="10" r="3" />
                  </svg>
                </div>
                <strong>Hệ thống chi nhánh</strong>
                <span>Thuận tiện, dễ tìm</span>
              </div>
            </div>
          </div>

          {/* PHONE VISUAL SHOWCASE */}
          <div className="auth-phone-visual">
            <div style={{ display: "flex", gap: "12px", alignItems: "flex-end" }}>
              <div
                style={{
                  width: "110px",
                  height: "150px",
                  background: "#1e293b",
                  borderRadius: "20px 20px 0 0",
                  border: "2px solid #334155",
                  borderBottom: "none",
                  padding: "8px",
                  boxShadow: "0 10px 30px rgba(0,0,0,0.5)",
                }}
              >
                <div style={{ width: "26px", height: "4px", background: "#475569", borderRadius: "2px", margin: "0 auto 8px" }} />
                <div style={{ width: "100%", height: "calc(100% - 12px)", background: "linear-gradient(180deg, #2563eb 0%, #0f172a 100%)", borderRadius: "12px" }} />
              </div>

              <div
                style={{
                  width: "135px",
                  height: "185px",
                  background: "#0f172a",
                  borderRadius: "24px 24px 0 0",
                  border: "3px solid #475569",
                  borderBottom: "none",
                  padding: "10px",
                  boxShadow: "0 16px 40px rgba(0,0,0,0.6)",
                }}
              >
                <div style={{ width: "36px", height: "4px", background: "#64748b", borderRadius: "2px", margin: "0 auto 10px" }} />
                <div
                  style={{
                    width: "100%",
                    height: "calc(100% - 14px)",
                    background: "linear-gradient(180deg, #0284c7 0%, #1e3a8a 100%)",
                    borderRadius: "14px",
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <span style={{ fontSize: "1.2rem", fontWeight: 800, color: "white" }}>9:41</span>
                  <span style={{ fontSize: "0.68rem", color: "#93c5fd" }}>PhoneRepair</span>
                </div>
              </div>
            </div>

            {/* FLOATING BLUE PILL */}
            <div className="auth-floating-badge">
              <div style={{ width: "30px", height: "30px", borderRadius: "8px", background: "#0284c7", display: "flex", alignItems: "center", justifyContent: "center" }}>
                🔧
              </div>
              <div>
                <strong style={{ display: "block", fontSize: "0.82rem", color: "white" }}>Đặt lịch ngay</strong>
                <span style={{ fontSize: "0.72rem", color: "#93c5fd" }}>chỉ với vài bước</span>
              </div>
            </div>
          </div>

          {/* STATS ROW */}
          <div className="auth-stats-bar">
            <div className="auth-stat-col">
              <strong>50.000+</strong>
              <span>Khách hàng tin tưởng</span>
            </div>
            <div style={{ width: "1px", height: "28px", background: "rgba(255,255,255,0.15)" }} />
            <div className="auth-stat-col">
              <strong>15+</strong>
              <span>Chi nhánh toàn quốc</span>
            </div>
            <div style={{ width: "1px", height: "28px", background: "rgba(255,255,255,0.15)" }} />
            <div className="auth-stat-col">
              <strong>4.9/5</strong>
              <span>Đánh giá trung bình</span>
            </div>
          </div>
        </div>

        {/* RIGHT LOGIN FORM (IMAGE 2) */}
        <div className="auth-form-side">
          <div className="auth-form-header" style={{ textAlign: "center" }}>
            <div style={{ display: "inline-flex", alignItems: "center", gap: "10px", marginBottom: "16px" }}>
              <div style={{ width: "36px", height: "36px", borderRadius: "10px", background: "#2563eb", display: "flex", alignItems: "center", justifyContent: "center", color: "white" }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
                  <rect x="5" y="2" width="14" height="20" rx="3" ry="3" />
                  <line x1="12" y1="18" x2="12.01" y2="18" />
                </svg>
              </div>
              <strong style={{ fontSize: "1.45rem", letterSpacing: "-0.03em", color: "#0f172a" }}>PhoneRepair</strong>
            </div>

            <h2 className="auth-form-title">Đăng nhập</h2>
            <p className="auth-form-subtitle">
              Chào mừng bạn quay trở lại!
              <br />
              Đăng nhập để quản lý lịch sửa chữa và theo dõi đơn hàng.
            </p>
          </div>

          {/* QUICK DEMO SELECTOR */}
          <div style={{ background: "#f8fafc", border: "1px solid #e2e8f0", borderRadius: "12px", padding: "10px 14px", marginBottom: "20px" }}>
            <span style={{ fontSize: "0.76rem", fontWeight: 700, color: "#64748b", display: "block", marginBottom: "6px" }}>
              ⚡ CHỌN NHANH TÀI KHOẢN MẪU:
            </span>
            <div style={{ display: "flex", gap: "6px", flexWrap: "wrap" }}>
              <button
                type="button"
                style={{ padding: "4px 10px", fontSize: "0.78rem", background: "#ffffff", border: "1px solid #cbd5e1", borderRadius: "6px", cursor: "pointer", fontWeight: 600 }}
                onClick={() => fillDemoAccount("admin@phonerepair.local", "Admin@12345")}
              >
                👑 Quản trị viên
              </button>
              <button
                type="button"
                style={{ padding: "4px 10px", fontSize: "0.78rem", background: "#ffffff", border: "1px solid #cbd5e1", borderRadius: "6px", cursor: "pointer", fontWeight: 600 }}
                onClick={() => fillDemoAccount("technician@phonerepair.local", "Tech@12345")}
              >
                🔧 Kỹ thuật viên
              </button>
              <button
                type="button"
                style={{ padding: "4px 10px", fontSize: "0.78rem", background: "#ffffff", border: "1px solid #cbd5e1", borderRadius: "6px", cursor: "pointer", fontWeight: 600 }}
                onClick={() => fillDemoAccount("customer@phonerepair.local", "Customer@12345")}
              >
                📱 Khách hàng
              </button>
            </div>
          </div>

          <form onSubmit={handleSubmit(onSubmit)} noValidate>
            {errors.root && (
              <div style={{ padding: "12px", background: "#fef2f2", border: "1px solid #fecaca", borderRadius: "10px", color: "#b91c1c", fontSize: "0.88rem", marginBottom: "16px" }}>
                {errors.root.message}
              </div>
            )}

            {/* EMAIL / PHONE */}
            <div className="auth-input-group">
              <label className="auth-input-label">Email hoặc số điện thoại</label>
              <div className="auth-input-wrapper">
                <span className="auth-input-icon">✉️</span>
                <input
                  type="text"
                  className="auth-input"
                  placeholder="Nhập email hoặc số điện thoại của bạn"
                  {...register("email")}
                />
              </div>
              {errors.email && <p style={{ color: "#dc2626", fontSize: "0.78rem", margin: "4px 0 0" }}>{errors.email.message}</p>}
            </div>

            {/* MẬT KHẨU */}
            <div className="auth-input-group">
              <label className="auth-input-label">Mật khẩu</label>
              <div className="auth-input-wrapper">
                <span className="auth-input-icon">🔒</span>
                <input
                  type={showPassword ? "text" : "password"}
                  className="auth-input"
                  placeholder="Nhập mật khẩu"
                  {...register("password")}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  style={{ position: "absolute", right: "12px", background: "none", border: "none", color: "#94a3b8", cursor: "pointer", fontSize: "1rem" }}
                  title="Hiện/ẩn mật khẩu"
                >
                  {showPassword ? "👁️" : "👁️‍🗨️"}
                </button>
              </div>
              {errors.password && <p style={{ color: "#dc2626", fontSize: "0.78rem", margin: "4px 0 0" }}>{errors.password.message}</p>}
            </div>

            {/* REMEMBER & FORGOT */}
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", margin: "14px 0 20px" }}>
              <label style={{ display: "flex", alignItems: "center", gap: "8px", fontSize: "0.85rem", color: "#475569", cursor: "pointer" }}>
                <input
                  type="checkbox"
                  style={{ width: "16px", height: "16px", accentColor: "#2563eb" }}
                  {...register("rememberMe")}
                />
                <span>Ghi nhớ đăng nhập</span>
              </label>

              <button
                type="button"
                style={{ background: "none", border: "none", color: "#2563eb", fontSize: "0.85rem", fontWeight: 600, cursor: "pointer" }}
                onClick={() => alert("Tính năng khôi phục mật khẩu: Vui lòng liên hệ hotline 1900 8899.")}
              >
                Quên mật khẩu?
              </button>
            </div>

            <button type="submit" className="auth-btn-primary" disabled={isSubmitting}>
              {isSubmitting ? "Đang đăng nhập..." : "Đăng nhập →"}
            </button>
          </form>

          <div className="auth-divider">Hoặc đăng nhập với</div>

          <div className="auth-social-row">
            <button
              type="button"
              className="auth-social-btn"
              onClick={() => alert("Tính năng đăng nhập với Apple sẽ sớm ra mắt.")}
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
                <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.81-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M15.97 6.47c.61-.75 1.04-1.8 1.01-2.87-.96.04-2.11.64-2.77 1.41-.58.68-.99 1.74-.95 2.79 1.07.08 2.1-.58 2.71-1.33z" />
              </svg>
              <span>Apple</span>
            </button>

            <button
              type="button"
              className="auth-social-btn"
              onClick={() => alert("Tính năng đăng nhập với Google sẽ sớm ra mắt.")}
            >
              <svg width="18" height="18" viewBox="0 0 24 24">
                <path fill="#4285F4" d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17z" />
                <path fill="#34A853" d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.34 24 12 24z" />
                <path fill="#FBBC05" d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.18 0 10.03 0 12s.45 3.82 1.25 5.42l4.03-3.15z" />
                <path fill="#EA4335" d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.34 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z" />
              </svg>
              <span>Google</span>
            </button>

            <button
              type="button"
              className="auth-social-btn"
              onClick={() => alert("Tính năng đăng nhập với Facebook sẽ sớm ra mắt.")}
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="#1877F2">
                <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
              </svg>
              <span>Facebook</span>
            </button>
          </div>

          <div style={{ textAlign: "center", fontSize: "0.88rem", color: "#64748b" }}>
            Chưa có tài khoản?{" "}
            <Link to="/register" style={{ color: "#2563eb", fontWeight: 700 }}>
              Đăng ký ngay
            </Link>
          </div>
        </div>
      </div>
    </main>
  )
}
