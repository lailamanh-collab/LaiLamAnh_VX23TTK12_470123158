import { useState } from "react"
import { Link } from "react-router-dom"

interface FaqItem {
  id: string
  category: "booking" | "pricing" | "workflow" | "warranty" | "policy"
  question: string
  answer: string
}

const FAQ_LIST: FaqItem[] = [
  {
    id: "b1",
    category: "booking",
    question: "Tôi có cần thanh toán tiền trước khi đặt lịch không?",
    answer:
      "Không. Hệ thống đặt lịch trực tuyến của PhoneRepair hoàn toàn miễn phí và không yêu cầu thanh toán trước. Lịch hẹn giúp giữ chỗ khung giờ kỹ thuật viên cho bạn. Bạn chỉ thanh toán tại cửa hàng sau khi kỹ thuật viên hoàn thành sửa chữa và bạn đã nghiệm thu máy hài lòng.",
  },
  {
    id: "b2",
    category: "booking",
    question: "Một lịch hẹn tôi có thể sửa nhiều dịch vụ hoặc nhiều máy cùng lúc không?",
    answer:
      "Theo nguyên tắc vận hành chuẩn của hệ thống (RULE 01 & 02): Mỗi một lượt đặt lịch áp dụng cho đúng 1 chiếc điện thoại (1 dòng máy cụ thể). Tuy nhiên, trên chiếc điện thoại đó bạn có thể chọn đồng thời nhiều dịch vụ sửa chữa khác nhau (ví dụ: vừa thay pin vừa ép kính). Nếu bạn có từ 2 máy trở lên, vui lòng tạo riêng từng lịch hẹn để kỹ thuật viên bố trí đủ thời gian xử lý chu đáo.",
  },
  {
    id: "b3",
    category: "booking",
    question: "Tôi có thể chọn đích danh kỹ thuật viên sửa cho mình không?",
    answer:
      "Khi đặt lịch, bạn chọn chi nhánh và khung giờ (time slot) còn chỗ tiếp nhận. Nhằm đảm bảo tiến độ và chuyên môn hóa (RULE 10), Quản trị viên chi nhánh sẽ điều phối kỹ thuật viên có tay nghề và lịch trực phù hợp nhất cho dòng máy và lỗi của bạn ngay khi tiếp nhận.",
  },
  {
    id: "p1",
    category: "pricing",
    question: "Sự khác biệt giữa 'Giá cố định' (Fixed Price) và 'Cần kiểm tra trước' (Inspection Required)?",
    answer:
      "Với các lỗi tiêu chuẩn như thay pin, thay màn hình, ép kính... hệ thống áp dụng bảng giá cố định theo từng dòng máy cụ thể (RULE 15). Với các lỗi phức tạp như mất nguồn, vô nước, lỗi vi mạch (IC main)... kỹ thuật viên cần mở máy đo đạc phần cứng trước, sau đó chẩn đoán và báo giá thực tế chính xác cho bạn duyệt trước khi tiến hành sửa chữa (RULE 14).",
  },
  {
    id: "p2",
    category: "pricing",
    question: "Giá hiển thị trên hệ thống đã bao gồm công thợ và linh kiện chưa?",
    answer:
      "Tất cả mức giá hiển thị trong bảng giá dịch vụ đã bao gồm trọn gói: linh kiện thay thế, công lắp ráp kiểm tra và gói bảo hành tiêu chuẩn. Cửa hàng cam kết không phát sinh bất kỳ phụ phí ẩn nào mà chưa được khách hàng đồng ý.",
  },
  {
    id: "w1",
    category: "workflow",
    question: "Thời gian cho một ca sửa chữa thường mất bao lâu?",
    answer:
      "Các dịch vụ thay linh kiện thông thường (pin, màn hình, chân sạc) thường hoàn thành trong vòng 30 - 60 phút. Đối với các ca sửa chữa phức tạp trên bo mạch, thời gian kiểm tra và xử lý sẽ được kỹ thuật viên cập nhật trực tiếp trên hệ thống để bạn theo dõi qua mã lịch hẹn.",
  },
  {
    id: "w2",
    category: "workflow",
    question: "Nếu tôi đến muộn hơn khung giờ đã đặt hẹn thì có được sửa không?",
    answer:
      "Chúng tôi khuyến khích quý khách đến đúng trong khung giờ đã chọn để được tiếp nhận ngay lập tức mà không phải chờ đợi. Nếu đến muộn quá 15 phút, cửa hàng vẫn tiếp đón nhưng có thể cần xếp ca của bạn xen kẽ giữa các khung giờ còn chỗ tiếp theo của chi nhánh.",
  },
  {
    id: "wa1",
    category: "warranty",
    question: "Chính sách bảo hành sau khi sửa chữa như thế nào?",
    answer:
      "Tùy theo linh kiện và dịch vụ, thời gian bảo hành dao động từ 3 tháng đến 12 tháng. Thông tin bảo hành được lưu trữ đồng bộ theo mã lịch hẹn và số điện thoại của bạn, bạn có thể đến bất kỳ chi nhánh nào trong hệ thống của chúng tôi để được hỗ trợ bảo hành nhanh chóng.",
  },
  {
    id: "wa2",
    category: "warranty",
    question: "Linh kiện thay thế có đảm bảo chất lượng và nguồn gốc không?",
    answer:
      "PhoneRepair cam kết 100% linh kiện có nguồn gốc xuất xứ rõ ràng, chuẩn zin bóc máy hoặc linh kiện thương hiệu đạt tiêu chuẩn kiểm định cao cấp nhất. Khách hàng được ký tên lên linh kiện và quan sát trực tiếp quy trình tháo lắp.",
  },
  {
    id: "po1",
    category: "policy",
    question: "Tôi có thể hủy lịch hẹn đã đặt không? Có bị mất phí không?",
    answer:
      "Bạn hoàn toàn có thể hủy lịch hẹn đã đặt bất cứ lúc nào trước khi cửa hàng tiếp nhận máy (trạng thái Pending hoặc Confirmed). Bạn chỉ cần vào mục 'Lịch của tôi', chọn lịch hẹn và bấm 'Hủy lịch hẹn' kèm lý do. Việc hủy lịch là hoàn toàn miễn phí.",
  },
  {
    id: "po2",
    category: "policy",
    question: "Làm thế nào để tôi đánh giá chất lượng phục vụ sau khi sửa chữa?",
    answer:
      "Sau khi ca sửa hoàn tất (trạng thái 'Đã hoàn thành' - RULE 11), khi bạn truy cập vào chi tiết lịch hẹn tại 'Lịch của tôi', hệ thống sẽ mở phần Đánh giá & Phản hồi (1 đến 5 sao kèm nhận xét). Đánh giá chân thực của bạn giúp chúng tôi liên tục nâng cao tay nghề và chất lượng phục vụ.",
  },
]

const CATEGORIES = [
  { id: "all", label: "Tất cả câu hỏi" },
  { id: "booking", label: "Đặt lịch & Tiếp nhận" },
  { id: "pricing", label: "Chi phí & Bảng giá" },
  { id: "workflow", label: "Thời gian & Tiến độ" },
  { id: "warranty", label: "Chính sách Bảo hành" },
  { id: "policy", label: "Hủy lịch & Đánh giá" },
]

export function SupportPage() {
  const [activeCategory, setActiveCategory] = useState<string>("all")
  const [searchQuery, setSearchQuery] = useState<string>("")
  const [openItems, setOpenItems] = useState<Record<string, boolean>>({ b1: true, p1: true, w1: true })

  const toggleItem = (id: string) => {
    setOpenItems((prev) => ({ ...prev, [id]: !prev[id] }))
  }

  const filteredFaqs = FAQ_LIST.filter((item) => {
    const matchCategory = activeCategory === "all" || item.category === activeCategory
    const matchSearch =
      !searchQuery.trim() ||
      item.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.answer.toLowerCase().includes(searchQuery.toLowerCase())
    return matchCategory && matchSearch
  })

  return (
    <main className="page">
      <div style={{ marginBottom: "16px" }}>
        <Link className="text-link" to="/">
          ← Về Trang chủ
        </Link>
      </div>

      <section className="hero" style={{ paddingBottom: "32px" }}>
        <div>
          <span className="eyebrow">Giải đáp thắc mắc</span>
          <h1>Trung tâm Hỗ trợ & FAQ (42.7)</h1>
          <p className="lede">
            Tìm câu trả lời nhanh chóng về quy trình đặt lịch, kiểm tra máy, bảng giá linh kiện, bảo hành và chính sách phục vụ tại hệ thống PhoneRepair.
          </p>

          <div style={{ marginTop: "20px", maxWidth: "560px" }}>
            <input
              type="search"
              className="input"
              placeholder="🔍 Tìm nhanh câu hỏi (ví dụ: hủy lịch, bảo hành, thanh toán...)"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              style={{ width: "100%", padding: "12px 16px", fontSize: "0.95rem" }}
            />
          </div>
        </div>
      </section>

      {/* QUICK CONTACT CHANNELS */}
      <section style={{ margin: "32px 0" }}>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))", gap: "16px" }}>
          <div className="card" style={{ padding: "20px", display: "flex", alignItems: "flex-start", gap: "14px" }}>
            <div style={{ fontSize: "2rem" }}>📞</div>
            <div>
              <strong style={{ fontSize: "1.05rem", display: "block" }}>Tổng đài hỗ trợ</strong>
              <p style={{ margin: "4px 0", color: "var(--color-accent-strong)", fontWeight: 700, fontSize: "1.1rem" }}>
                1900 8899
              </p>
              <span className="muted" style={{ fontSize: "0.85rem" }}>Hỗ trợ từ 08:00 – 20:00 hàng ngày</span>
            </div>
          </div>

          <div className="card" style={{ padding: "20px", display: "flex", alignItems: "flex-start", gap: "14px" }}>
            <div style={{ fontSize: "2rem" }}>📧</div>
            <div>
              <strong style={{ fontSize: "1.05rem", display: "block" }}>Hòm thư tư vấn</strong>
              <p style={{ margin: "4px 0", color: "var(--color-ink)", fontWeight: 600, fontSize: "0.95rem" }}>
                hotro@phonerepair.local
              </p>
              <span className="muted" style={{ fontSize: "0.85rem" }}>Giải đáp thắc mắc trong vòng 2h</span>
            </div>
          </div>

          <div className="card" style={{ padding: "20px", display: "flex", alignItems: "flex-start", gap: "14px" }}>
            <div style={{ fontSize: "2rem" }}>🏪</div>
            <div>
              <strong style={{ fontSize: "1.05rem", display: "block" }}>Hệ thống chi nhánh</strong>
              <p style={{ margin: "4px 0", fontSize: "0.9rem", color: "var(--color-muted)" }}>
                Hà Nội & TP. Hồ Chí Minh
              </p>
              <Link to="/branches" className="text-link" style={{ fontSize: "0.88rem", fontWeight: 600 }}>
                Xem chi tiết các điểm phục vụ →
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ CATEGORY SELECTOR */}
      <section style={{ margin: "24px 0" }}>
        <div style={{ display: "flex", gap: "8px", flexWrap: "wrap", marginBottom: "20px" }}>
          {CATEGORIES.map((cat) => (
            <button
              key={cat.id}
              className={`btn ${activeCategory === cat.id ? "" : "btn-quiet"}`}
              type="button"
              onClick={() => setActiveCategory(cat.id)}
              style={{ borderRadius: "20px", padding: "6px 16px", fontSize: "0.88rem" }}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* ACCORDION LIST */}
        <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
          {filteredFaqs.length === 0 ? (
            <div className="card empty" style={{ padding: "36px", textAlign: "center" }}>
              <p style={{ margin: 0, color: "var(--color-muted)" }}>
                Không tìm thấy câu hỏi phù hợp với từ khóa "{searchQuery}".
              </p>
              <button
                className="btn btn-quiet"
                type="button"
                onClick={() => {
                  setSearchQuery("")
                  setActiveCategory("all")
                }}
                style={{ marginTop: "12px" }}
              >
                Đặt lại tìm kiếm
              </button>
            </div>
          ) : (
            filteredFaqs.map((faq) => {
              const isOpen = !!openItems[faq.id]
              return (
                <div
                  key={faq.id}
                  className="card"
                  style={{
                    padding: "0",
                    overflow: "hidden",
                    border: isOpen ? "1px solid var(--color-accent-strong)" : "1px solid var(--color-line)",
                    transition: "border-color 0.15s ease",
                  }}
                >
                  <button
                    type="button"
                    onClick={() => toggleItem(faq.id)}
                    style={{
                      width: "100%",
                      padding: "16px 20px",
                      background: "none",
                      border: "none",
                      display: "flex",
                      justifyContent: "space-between",
                      alignItems: "center",
                      textAlign: "left",
                      cursor: "pointer",
                      fontSize: "1rem",
                      fontWeight: 600,
                      color: isOpen ? "var(--color-accent-strong)" : "var(--color-ink)",
                    }}
                  >
                    <span>{faq.question}</span>
                    <span style={{ fontSize: "1.2rem", marginLeft: "12px", color: "var(--color-muted)" }}>
                      {isOpen ? "−" : "+"}
                    </span>
                  </button>
                  {isOpen ? (
                    <div
                      style={{
                        padding: "0 20px 18px",
                        color: "var(--color-muted)",
                        fontSize: "0.95rem",
                        lineHeight: 1.65,
                        borderTop: "1px solid #f1f5f9",
                        marginTop: "2px",
                      }}
                    >
                      <p style={{ margin: "10px 0 0" }}>{faq.answer}</p>
                    </div>
                  ) : null}
                </div>
              )
            })
          )}
        </div>
      </section>

      {/* BOTTOM CTA */}
      <section
        className="card"
        style={{
          marginTop: "48px",
          padding: "36px 28px",
          textAlign: "center",
          background: "linear-gradient(135deg, #f0fdf4 0%, #ffffff 100%)",
          border: "1px solid #bbf7d0",
        }}
      >
        <h2 style={{ fontSize: "1.5rem", marginBottom: "8px" }}>Bạn đã sẵn sàng sửa máy hôm nay?</h2>
        <p style={{ margin: "0 auto 20px", maxWidth: "560px", color: "var(--color-muted)", fontSize: "0.95rem" }}>
          Đặt hẹn trước chỉ mất 1 phút để giữ chỗ kỹ thuật viên tại chi nhánh gần bạn nhất, không lo chờ đợi xếp hàng.
        </p>
        <div style={{ display: "flex", gap: "12px", justifyContent: "center", flexWrap: "wrap" }}>
          <Link to="/booking" className="btn" style={{ padding: "10px 24px" }}>
            Đặt lịch sửa chữa ngay
          </Link>
          <Link to="/pricing" className="btn btn-quiet" style={{ padding: "10px 24px" }}>
            Tra cứu bảng giá dịch vụ
          </Link>
        </div>
      </section>
    </main>
  )
}
