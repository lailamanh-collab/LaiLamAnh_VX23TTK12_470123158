import { useState } from "react"
import { NavLink, useNavigate } from "react-router-dom"
import { useAuth } from "../../auth/AuthContext"

export function SiteHeader() {
  const { user, logout } = useAuth()
  const navigate = useNavigate()
  const [mobileOpen, setMobileOpen] = useState(false)
  const [showSearchModal, setShowSearchModal] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")

  const closeMenu = () => setMobileOpen(false)

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (searchQuery.trim()) {
      setShowSearchModal(false)
      navigate(`/services?q=${encodeURIComponent(searchQuery.trim())}`)
    }
  }

  const getRoleBadge = (role?: string) => {
    if (role === "Admin") return <span className="badge badge-confirmed" style={{ fontSize: "0.72rem", padding: "2px 8px" }}>Admin</span>
    if (role === "Technician") return <span className="badge badge-inspecting" style={{ fontSize: "0.72rem", padding: "2px 8px" }}>KTV</span>
    return null
  }

  return (
    <header className="site-header" style={{ background: "#ffffff", borderBottom: "1px solid #e2e8f0" }}>
      <div className="site-header-inner" style={{ maxWidth: "1280px", margin: "0 auto", padding: "0 20px" }}>
        {/* BRAND LOGO */}
        <NavLink to="/" className="brand" onClick={closeMenu} style={{ display: "flex", alignItems: "center", gap: "10px" }}>
          <div className="brand-mark" style={{ width: "34px", height: "34px", borderRadius: "10px", background: "#2563eb", display: "flex", alignItems: "center", justifyContent: "center" }}>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
              <rect x="5" y="2" width="14" height="20" rx="3" ry="3" />
              <line x1="12" y1="18" x2="12.01" y2="18" />
            </svg>
          </div>
          <span style={{ fontWeight: 800, fontSize: "1.35rem", letterSpacing: "-0.03em", color: "#0f172a" }}>
            Phone<span style={{ color: "#2563eb" }}>Repair</span>
          </span>
        </NavLink>

        <button
          className="mobile-menu-toggle"
          type="button"
          aria-label="Mở trình đơn"
          aria-expanded={mobileOpen}
          onClick={() => setMobileOpen(!mobileOpen)}
        >
          {mobileOpen ? "✕" : "☰"}
        </button>

        {/* MAIN NAV LINKS (EXACT ENGLISH PATHS MATCHING SCREENSHOTS) */}
        <nav className={`nav ${mobileOpen ? "nav-mobile-open" : ""}`} aria-label="Điều hướng chính" style={{ alignItems: "center", gap: "20px" }}>
          <NavLink to="/" end className={({ isActive }) => (isActive ? "nav-link nav-link-active" : "nav-link")} onClick={closeMenu}>
            Trang chủ
          </NavLink>
          <NavLink to="/services" className={({ isActive }) => (isActive ? "nav-link nav-link-active" : "nav-link")} onClick={closeMenu}>
            Dịch vụ ⌄
          </NavLink>
          <NavLink to="/pricing" className={({ isActive }) => (isActive ? "nav-link nav-link-active" : "nav-link")} onClick={closeMenu}>
            Bảng giá
          </NavLink>
          <NavLink to="/branches" className={({ isActive }) => (isActive ? "nav-link nav-link-active" : "nav-link")} onClick={closeMenu}>
            Chi nhánh
          </NavLink>
          <NavLink to="/support" className={({ isActive }) => (isActive ? "nav-link nav-link-active" : "nav-link")} onClick={closeMenu}>
            Hỗ trợ
          </NavLink>

          {/* INLINE SEARCH BAR */}
          <form
            onSubmit={handleSearch}
            style={{
              display: "flex",
              alignItems: "center",
              background: "#f8fafc",
              border: "1px solid #e2e8f0",
              borderRadius: "999px",
              padding: "6px 14px",
              gap: "8px",
              width: "230px",
            }}
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#94a3b8" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" style={{ flexShrink: 0 }}>
              <circle cx="11" cy="11" r="8" />
              <line x1="21" y1="21" x2="16.65" y2="16.65" />
            </svg>
            <input
              type="text"
              placeholder="Tìm kiếm dịch vụ, dòng máy..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              style={{
                border: "none",
                background: "transparent",
                outline: "none",
                fontSize: "0.82rem",
                color: "#0f172a",
                width: "100%",
              }}
            />
          </form>

          {/* PRIMARY BLUE CTA "ĐẶT LỊCH NGAY" */}
          <NavLink
            to="/booking"
            className="btn"
            style={{
              padding: "0 20px",
              height: "38px",
              borderRadius: "8px",
              background: "#2563eb",
              color: "#ffffff",
              fontWeight: 700,
              fontSize: "0.88rem",
              boxShadow: "0 2px 8px rgba(37, 99, 235, 0.28)",
              display: "inline-flex",
              alignItems: "center",
              justifyContent: "center",
              textDecoration: "none",
            }}
            onClick={closeMenu}
          >
            Đặt lịch ngay
          </NavLink>

          {/* NOTIFICATION BELL WITH BADGE */}
          <div
            style={{
              width: "36px",
              height: "36px",
              borderRadius: "50%",
              border: "1px solid #e2e8f0",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              position: "relative",
              cursor: "pointer",
              color: "#64748b",
              background: "#ffffff",
            }}
            title="Thông báo"
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" />
              <path d="M13.73 21a2 2 0 0 1-3.46 0" />
            </svg>
            <span
              style={{
                position: "absolute",
                top: "8px",
                right: "8px",
                width: "6px",
                height: "6px",
                borderRadius: "50%",
                background: "#ef4444",
              }}
            />
          </div>

          {user ? (
            <>
              {/* ADMIN ROLE LINKS */}
              {user.role === "Admin" ? (
                <>
                  <NavLink to="/admin/dashboard" className={({ isActive }) => (isActive ? "nav-link nav-link-active" : "nav-link")} onClick={closeMenu}>
                    Dashboard
                  </NavLink>
                  <NavLink to="/admin/bookings" className={({ isActive }) => (isActive ? "nav-link nav-link-active" : "nav-link")} onClick={closeMenu}>
                    Lịch hẹn
                  </NavLink>
                </>
              ) : null}

              {/* TECHNICIAN WORKSPACE */}
              {user.role === "Technician" ? (
                <NavLink to="/technician" className={({ isActive }) => (isActive ? "nav-link nav-link-active" : "nav-link")} onClick={closeMenu}>
                  KTV bàn làm việc
                </NavLink>
              ) : null}

              {/* USER PROFILE PILL */}
              <NavLink
                to="/profile"
                className={({ isActive }) => (isActive ? "nav-link nav-link-active" : "nav-link")}
                style={{
                  display: "inline-flex",
                  alignItems: "center",
                  gap: "8px",
                  background: "#f1f5f9",
                  borderRadius: "20px",
                  padding: "3px 12px 3px 4px",
                  fontSize: "0.86rem",
                  fontWeight: 600,
                  color: "#0f172a",
                  textDecoration: "none",
                }}
                onClick={closeMenu}
              >
                <img
                  src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=100&q=80"
                  alt={user.fullName}
                  style={{
                    width: "28px",
                    height: "28px",
                    borderRadius: "50%",
                    objectFit: "cover",
                  }}
                />
                <span>{user.fullName}</span>
                <span style={{ fontSize: "0.75rem", color: "#64748b" }}>⌄</span>
                {getRoleBadge(user.role)}
              </NavLink>

              <button
                className="btn btn-quiet"
                type="button"
                style={{ minHeight: "34px", padding: "0 10px", fontSize: "0.82rem", borderRadius: "8px" }}
                onClick={() => {
                  closeMenu()
                  logout()
                }}
              >
                Đăng xuất
              </button>
            </>
          ) : (
            <>
              {/* NOT LOGGED IN DEFAULT USER AVATAR / SIGN IN */}
              <NavLink
                to="/login"
                style={{
                  display: "inline-flex",
                  alignItems: "center",
                  gap: "8px",
                  background: "#f1f5f9",
                  borderRadius: "20px",
                  padding: "3px 12px 3px 4px",
                  fontSize: "0.86rem",
                  fontWeight: 600,
                  color: "#0f172a",
                  textDecoration: "none",
                }}
                onClick={closeMenu}
              >
                <img
                  src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=100&q=80"
                  alt="Nguyễn Văn A"
                  style={{
                    width: "28px",
                    height: "28px",
                    borderRadius: "50%",
                    objectFit: "cover",
                  }}
                />
                <span>Nguyễn Văn A</span>
                <span style={{ fontSize: "0.75rem", color: "#64748b" }}>⌄</span>
              </NavLink>
            </>
          )}
        </nav>
      </div>

      {/* QUICK SEARCH POPUP MODAL */}
      {showSearchModal && (
        <div
          style={{
            position: "fixed",
            inset: 0,
            background: "rgba(15, 23, 42, 0.6)",
            backdropFilter: "blur(4px)",
            zIndex: 999,
            display: "flex",
            alignItems: "flex-start",
            justifyContent: "center",
            paddingTop: "100px",
          }}
          onClick={() => setShowSearchModal(false)}
        >
          <div
            style={{
              background: "#ffffff",
              borderRadius: "18px",
              padding: "20px",
              width: "90%",
              maxWidth: "560px",
              boxShadow: "0 20px 50px rgba(0,0,0,0.3)",
            }}
            onClick={(e) => e.stopPropagation()}
          >
            <form onSubmit={handleSearch} style={{ display: "flex", gap: "10px" }}>
              <input
                type="text"
                autoFocus
                placeholder="Tìm kiếm dịch vụ (màn hình, pin, camera...)..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                style={{
                  flex: 1,
                  height: "46px",
                  border: "1px solid #cbd5e1",
                  borderRadius: "12px",
                  padding: "0 16px",
                  fontSize: "0.95rem",
                  outline: "none",
                }}
              />
              <button
                type="submit"
                className="btn"
                style={{ background: "#2563eb", padding: "0 20px", borderRadius: "12px" }}
              >
                Tìm
              </button>
            </form>
          </div>
        </div>
      )}
    </header>
  )
}
