import { useEffect, useState, useMemo } from "react"
import { useNavigate, useSearchParams } from "react-router-dom"
import { getBranches, type Branch } from "../api/branches"
import {
  branchCauGiay,
  branchDongDa,
  branchHaiBaTrung,
  branchThanhXuan,
  branchBaDinh,
  branchLongBien,
  getBranchImage,
  workshopBg,
} from "../assets"

interface BranchItem extends Branch {
  distance: string
  image: string
  city: string
  district: string
  rating: number
  hasParking: boolean
  featuredServices: Array<{ name: string; icon: string }>
  mapCoordinates: { x: number; y: number }
}

function parseBranchMeta(name: string, address: string): { city: string; district: string } {
  let city = "TP. Hồ Chí Minh"
  const text = `${name} ${address}`.toLowerCase()
  if (text.includes("hà nội")) {
    city = "Hà Nội"
  } else if (text.includes("đà nẵng")) {
    city = "Đà Nẵng"
  }

  let district = "Quận 1"
  if (text.includes("quận 10")) district = "Quận 10"
  else if (text.includes("quận 1")) district = "Quận 1"
  else if (text.includes("quận 3")) district = "Quận 3"
  else if (text.includes("quận 5")) district = "Quận 5"
  else if (text.includes("quận 7")) district = "Quận 7"
  else if (text.includes("bình thạnh")) district = "Bình Thạnh"
  else if (text.includes("gò vấp")) district = "Gò Vấp"
  else if (text.includes("tân bình")) district = "Tân Bình"
  else if (text.includes("phú nhuận")) district = "Phú Nhuận"
  else if (text.includes("thủ đức")) district = "TP. Thủ Đức"
  else if (text.includes("cầu giấy")) district = "Cầu Giấy"
  else if (text.includes("đống đa")) district = "Đống Đa"
  else if (text.includes("hai bà trưng")) district = "Hai Bà Trưng"
  else if (text.includes("ba đình")) district = "Ba Đình"
  else if (text.includes("thanh xuân")) district = "Thanh Xuân"
  else if (text.includes("long biên")) district = "Long Biên"
  else if (text.includes("hải châu")) district = "Hải Châu"
  else if (text.includes("thanh khê")) district = "Thanh Khê"

  return { city, district }
}

const COMMON_SERVICES = [
  { name: "Thay màn hình", icon: "📱" },
  { name: "Thay pin", icon: "🔋" },
  { name: "Sửa camera", icon: "📷" },
  { name: "Sửa loa", icon: "🔊" },
  { name: "Vệ sinh máy", icon: "🪄" },
]

const FALLBACK_BRANCHES: BranchItem[] = [
  // TP. Hồ Chí Minh
  {
    id: 1,
    name: "HomeRepair Quận 1",
    address: "12 Nguyễn Huệ, P. Bến Nghé, Quận 1, TP.HCM",
    phone: "028 1111 0001",
    capacityPerSlot: 4,
    slotMinutes: 30,
    isActive: true,
    openingHours: [],
    city: "TP. Hồ Chí Minh",
    district: "Quận 1",
    distance: "0.8 km",
    image: branchDongDa,
    rating: 4.9,
    hasParking: true,
    featuredServices: COMMON_SERVICES,
    mapCoordinates: { x: 50, y: 50 },
  },
  {
    id: 2,
    name: "HomeRepair Quận 3",
    address: "368 Cách Mạng Tháng 8, Phường 10, Quận 3, TP.HCM",
    phone: "028 1111 0003",
    capacityPerSlot: 4,
    slotMinutes: 30,
    isActive: true,
    openingHours: [],
    city: "TP. Hồ Chí Minh",
    district: "Quận 3",
    distance: "2.3 km",
    image: branchCauGiay,
    rating: 4.8,
    hasParking: true,
    featuredServices: COMMON_SERVICES,
    mapCoordinates: { x: 45, y: 48 },
  },
  {
    id: 3,
    name: "HomeRepair Quận 5",
    address: "145 Trần Hưng Đạo, Phường 6, Quận 5, TP.HCM",
    phone: "028 1111 0005",
    capacityPerSlot: 4,
    slotMinutes: 30,
    isActive: true,
    openingHours: [],
    city: "TP. Hồ Chí Minh",
    district: "Quận 5",
    distance: "3.7 km",
    image: branchHaiBaTrung,
    rating: 4.9,
    hasParking: true,
    featuredServices: COMMON_SERVICES,
    mapCoordinates: { x: 42, y: 55 },
  },
  {
    id: 4,
    name: "HomeRepair Quận 7",
    address: "45 Nguyễn Văn Linh, Tân Phong, Quận 7, TP.HCM",
    phone: "028 1111 0007",
    capacityPerSlot: 4,
    slotMinutes: 30,
    isActive: true,
    openingHours: [],
    city: "TP. Hồ Chí Minh",
    district: "Quận 7",
    distance: "4.5 km",
    image: branchThanhXuan,
    rating: 4.8,
    hasParking: true,
    featuredServices: COMMON_SERVICES,
    mapCoordinates: { x: 55, y: 65 },
  },
  {
    id: 5,
    name: "HomeRepair Quận 10",
    address: "285 Đường 3 Tháng 2, Phường 10, Quận 10, TP.HCM",
    phone: "028 1111 0010",
    capacityPerSlot: 4,
    slotMinutes: 30,
    isActive: true,
    openingHours: [],
    city: "TP. Hồ Chí Minh",
    district: "Quận 10",
    distance: "3.2 km",
    image: branchHaiBaTrung,
    rating: 4.9,
    hasParking: true,
    featuredServices: COMMON_SERVICES,
    mapCoordinates: { x: 46, y: 52 },
  },
  {
    id: 6,
    name: "HomeRepair Bình Thạnh",
    address: "207 Phan Đăng Lưu, Phường 1, Bình Thạnh, TP.HCM",
    phone: "028 1111 0021",
    capacityPerSlot: 4,
    slotMinutes: 30,
    isActive: true,
    openingHours: [],
    city: "TP. Hồ Chí Minh",
    district: "Bình Thạnh",
    distance: "4.1 km",
    image: branchBaDinh,
    rating: 4.8,
    hasParking: true,
    featuredServices: COMMON_SERVICES,
    mapCoordinates: { x: 58, y: 40 },
  },
  {
    id: 7,
    name: "HomeRepair Gò Vấp",
    address: "598 Quang Trung, Phường 11, Gò Vấp, TP.HCM",
    phone: "028 1111 0022",
    capacityPerSlot: 4,
    slotMinutes: 30,
    isActive: true,
    openingHours: [],
    city: "TP. Hồ Chí Minh",
    district: "Gò Vấp",
    distance: "6.5 km",
    image: branchBaDinh,
    rating: 4.7,
    hasParking: true,
    featuredServices: COMMON_SERVICES,
    mapCoordinates: { x: 52, y: 35 },
  },
  {
    id: 8,
    name: "HomeRepair Tân Bình",
    address: "420 Cộng Hòa, Phường 13, Tân Bình, TP.HCM",
    phone: "028 1111 0023",
    capacityPerSlot: 4,
    slotMinutes: 30,
    isActive: true,
    openingHours: [],
    city: "TP. Hồ Chí Minh",
    district: "Tân Bình",
    distance: "5.2 km",
    image: branchLongBien,
    rating: 4.9,
    hasParking: true,
    featuredServices: COMMON_SERVICES,
    mapCoordinates: { x: 40, y: 45 },
  },
  {
    id: 9,
    name: "HomeRepair Phú Nhuận",
    address: "182 Phan Xích Long, Phường 2, Phú Nhuận, TP.HCM",
    phone: "028 1111 0024",
    capacityPerSlot: 4,
    slotMinutes: 30,
    isActive: true,
    openingHours: [],
    city: "TP. Hồ Chí Minh",
    district: "Phú Nhuận",
    distance: "3.9 km",
    image: branchThanhXuan,
    rating: 4.9,
    hasParking: true,
    featuredServices: COMMON_SERVICES,
    mapCoordinates: { x: 48, y: 44 },
  },
  {
    id: 10,
    name: "HomeRepair Thủ Đức",
    address: "89 Võ Văn Ngân, Linh Chiểu, TP. Thủ Đức",
    phone: "028 1111 0008",
    capacityPerSlot: 4,
    slotMinutes: 30,
    isActive: true,
    openingHours: [],
    city: "TP. Hồ Chí Minh",
    district: "TP. Thủ Đức",
    distance: "9.2 km",
    image: branchLongBien,
    rating: 4.8,
    hasParking: true,
    featuredServices: COMMON_SERVICES,
    mapCoordinates: { x: 68, y: 42 },
  },
  // Hà Nội
  {
    id: 11,
    name: "HomeRepair Cầu Giấy",
    address: "123 Cầu Giấy, Quan Hoa, Cầu Giấy, Hà Nội",
    phone: "024 1234 5678",
    capacityPerSlot: 4,
    slotMinutes: 30,
    isActive: true,
    openingHours: [],
    city: "Hà Nội",
    district: "Cầu Giấy",
    distance: "2.1 km",
    image: branchCauGiay,
    rating: 4.9,
    hasParking: true,
    featuredServices: COMMON_SERVICES,
    mapCoordinates: { x: 58, y: 50 },
  },
  {
    id: 12,
    name: "HomeRepair Đống Đa",
    address: "456 Xã Đàn, Nam Đồng, Đống Đa, Hà Nội",
    phone: "024 2345 6789",
    capacityPerSlot: 4,
    slotMinutes: 30,
    isActive: true,
    openingHours: [],
    city: "Hà Nội",
    district: "Đống Đa",
    distance: "3.5 km",
    image: branchDongDa,
    rating: 4.8,
    hasParking: true,
    featuredServices: COMMON_SERVICES,
    mapCoordinates: { x: 49, y: 48 },
  },
  {
    id: 13,
    name: "HomeRepair Hai Bà Trưng",
    address: "789 Phố Huế, Hàng Bài, Hai Bà Trưng, Hà Nội",
    phone: "024 3456 7890",
    capacityPerSlot: 4,
    slotMinutes: 30,
    isActive: true,
    openingHours: [],
    city: "Hà Nội",
    district: "Hai Bà Trưng",
    distance: "5.3 km",
    image: branchHaiBaTrung,
    rating: 4.9,
    hasParking: true,
    featuredServices: COMMON_SERVICES,
    mapCoordinates: { x: 81, y: 60 },
  },
  {
    id: 14,
    name: "HomeRepair Ba Đình",
    address: "567 Đội Cấn, Liễu Giai, Ba Đình, Hà Nội",
    phone: "024 6789 1234",
    capacityPerSlot: 4,
    slotMinutes: 30,
    isActive: true,
    openingHours: [],
    city: "Hà Nội",
    district: "Ba Đình",
    distance: "6.2 km",
    image: branchBaDinh,
    rating: 4.7,
    hasParking: true,
    featuredServices: COMMON_SERVICES,
    mapCoordinates: { x: 34, y: 35 },
  },
  {
    id: 15,
    name: "HomeRepair Thanh Xuân",
    address: "321 Nguyễn Trãi, Thanh Xuân, Hà Nội",
    phone: "024 3456 1122",
    capacityPerSlot: 4,
    slotMinutes: 30,
    isActive: true,
    openingHours: [],
    city: "Hà Nội",
    district: "Thanh Xuân",
    distance: "7.8 km",
    image: branchThanhXuan,
    rating: 4.8,
    hasParking: true,
    featuredServices: COMMON_SERVICES,
    mapCoordinates: { x: 80, y: 17 },
  },
  {
    id: 16,
    name: "HomeRepair Long Biên",
    address: "890 Nguyễn Văn Cừ, Long Biên, Hà Nội",
    phone: "024 6789 5678",
    capacityPerSlot: 4,
    slotMinutes: 30,
    isActive: true,
    openingHours: [],
    city: "Hà Nội",
    district: "Long Biên",
    distance: "8.1 km",
    image: branchLongBien,
    rating: 4.8,
    hasParking: true,
    featuredServices: COMMON_SERVICES,
    mapCoordinates: { x: 45, y: 16 },
  },
  // Đà Nẵng
  {
    id: 17,
    name: "HomeRepair Hải Châu",
    address: "152 Hàm Nghi, Thạc Gián, Hải Châu, Đà Nẵng",
    phone: "0236 3888 123",
    capacityPerSlot: 4,
    slotMinutes: 30,
    isActive: true,
    openingHours: [],
    city: "Đà Nẵng",
    district: "Hải Châu",
    distance: "1.8 km",
    image: branchBaDinh,
    rating: 4.9,
    hasParking: true,
    featuredServices: COMMON_SERVICES,
    mapCoordinates: { x: 50, y: 50 },
  },
  {
    id: 18,
    name: "HomeRepair Thanh Khê",
    address: "345 Điện Biên Phủ, Thanh Khê, Đà Nẵng",
    phone: "0236 3888 456",
    capacityPerSlot: 4,
    slotMinutes: 30,
    isActive: true,
    openingHours: [],
    city: "Đà Nẵng",
    district: "Thanh Khê",
    distance: "3.4 km",
    image: branchLongBien,
    rating: 4.8,
    hasParking: true,
    featuredServices: COMMON_SERVICES,
    mapCoordinates: { x: 48, y: 52 },
  },
]

export function BranchesPage() {
  const navigate = useNavigate()
  const [searchParams] = useSearchParams()
  const initialBranchParam = searchParams.get("branchId")

  const [branches, setBranches] = useState<BranchItem[]>(FALLBACK_BRANCHES)
  const [selectedBranchId, setSelectedBranchId] = useState<number>(() => {
    return initialBranchParam ? Number(initialBranchParam) : 1
  })
  const [searchKeyword, setSearchKeyword] = useState("")
  const [selectedCity, setSelectedCity] = useState("TP. Hồ Chí Minh")
  const [selectedDistrict, setSelectedDistrict] = useState("all")
  const [selectedService, setSelectedService] = useState("all")
  const [showDetail, setShowDetail] = useState(false)

  useEffect(() => {
    getBranches()
      .then((serverBranches) => {
        if (serverBranches && serverBranches.length > 0) {
          const enriched: BranchItem[] = serverBranches.map((b, index) => {
            const fallback = FALLBACK_BRANCHES.find((f) => f.id === b.id || f.name.toLowerCase() === b.name.toLowerCase())
            const meta = parseBranchMeta(b.name, b.address)
            return {
              ...b,
              city: fallback?.city || meta.city,
              district: fallback?.district || meta.district,
              distance: fallback?.distance || `${((index % 8) + 1) * 1.5 + 0.3} km`,
              image: getBranchImage(`${b.name} ${b.address}`),
              rating: fallback?.rating || 4.9,
              hasParking: fallback?.hasParking ?? true,
              featuredServices: fallback?.featuredServices || COMMON_SERVICES,
              mapCoordinates: fallback?.mapCoordinates || { x: 30 + (index % 4) * 15, y: 30 + (index % 3) * 15 },
            }
          })
          setBranches(enriched)
          if (!initialBranchParam && enriched[0]) {
            setSelectedBranchId(enriched[0].id)
          }
        }
      })
      .catch(() => {})
  }, [initialBranchParam])

  // Reset district filter if not found in newly selected city
  const availableDistricts = useMemo(() => {
    const relevantBranches = selectedCity === "all" ? branches : branches.filter((b) => b.city === selectedCity)
    const set = new Set<string>()
    relevantBranches.forEach((b) => {
      if (b.district) set.add(b.district)
    })
    return Array.from(set).sort()
  }, [branches, selectedCity])

  const handleCityChange = (newCity: string) => {
    setSelectedCity(newCity)
    setSelectedDistrict("all")
  }

  // Filtered list
  const filteredBranches = useMemo(() => {
    return branches.filter((b) => {
      // 1. City check
      if (selectedCity !== "all" && b.city !== selectedCity) {
        return false
      }
      // 2. District check
      if (selectedDistrict !== "all" && b.district !== selectedDistrict) {
        return false
      }
      // 3. Service check
      if (selectedService !== "all") {
        const hasSvc = b.featuredServices.some((s) => s.name.toLowerCase().includes(selectedService.toLowerCase()))
        if (!hasSvc) return false
      }
      // 4. Keyword check
      if (searchKeyword.trim()) {
        const q = searchKeyword.toLowerCase().trim()
        const match =
          b.name.toLowerCase().includes(q) ||
          b.address.toLowerCase().includes(q) ||
          b.district.toLowerCase().includes(q) ||
          b.city.toLowerCase().includes(q)
        if (!match) return false
      }
      return true
    })
  }, [branches, selectedCity, selectedDistrict, selectedService, searchKeyword])

  // Keep selected branch valid if filter reduces list
  useEffect(() => {
    if (filteredBranches.length > 0) {
      const exists = filteredBranches.some((b) => b.id === selectedBranchId)
      if (!exists) {
        setSelectedBranchId(filteredBranches[0].id)
      }
    }
  }, [filteredBranches, selectedBranchId])

  const selectedBranch =
    branches.find((b) => b.id === selectedBranchId) ||
    filteredBranches[0] ||
    branches[0] ||
    FALLBACK_BRANCHES[0]

  const handleSelectBranch = (branchId: number) => {
    setSelectedBranchId(branchId)
  }

  const handleBookAtBranch = (branchId: number) => {
    navigate(`/booking?branchId=${branchId}`)
  }

  const resetFilters = () => {
    setSearchKeyword("")
    setSelectedCity("all")
    setSelectedDistrict("all")
    setSelectedService("all")
  }

  // Branch counts per city
  const cityCounts = useMemo(() => {
    const map: Record<string, number> = {}
    branches.forEach((b) => {
      if (b.city) {
        map[b.city] = (map[b.city] || 0) + 1
      }
    })
    return {
      total: branches.length,
      map,
    }
  }, [branches])

  // Count per district in current city
  const districtCounts = useMemo(() => {
    const list = selectedCity === "all" ? branches : branches.filter((b) => b.city === selectedCity)
    const map: Record<string, number> = {}
    list.forEach((b) => {
      map[b.district] = (map[b.district] || 0) + 1
    })
    return {
      total: list.length,
      items: availableDistricts.map((d) => ({ name: d, count: map[d] || 0 })),
    }
  }, [branches, selectedCity, availableDistricts])

  return (
    <main style={{ background: "#f8fafc", minHeight: "100vh", paddingBottom: "50px" }}>
      {/* 1. HERO HEADER */}
      <section
        style={{
          background: `linear-gradient(180deg, rgba(239, 246, 255, 0.90) 0%, rgba(248, 250, 252, 0.96) 100%), url('${workshopBg}') center/cover no-repeat`,
          padding: "44px 20px 36px",
          borderBottom: "1px solid #e2e8f0",
          marginBottom: "24px",
        }}
      >
        <div style={{ maxWidth: "1340px", margin: "0 auto" }}>
          <h1 style={{ fontSize: "2.35rem", fontWeight: 800, color: "#0f172a", margin: "0 0 10px", letterSpacing: "-0.03em" }}>
            Hệ thống chi nhánh HomeRepair
          </h1>
          <p style={{ fontSize: "1rem", color: "#475569", margin: "0 0 28px", lineHeight: 1.5 }}>
            Mạng lưới 18+ chi nhánh tại TP. Hồ Chí Minh, Hà Nội và Đà Nẵng - Sẵn sàng phục vụ chu đáo, chuyên nghiệp
          </p>

          {/* 4 FEATURE PILLS */}
          <div style={{ display: "flex", flexWrap: "wrap", gap: "16px" }}>
            <div
              style={{
                background: "#ffffff",
                border: "1px solid #e2e8f0",
                borderRadius: "999px",
                padding: "8px 18px",
                display: "flex",
                alignItems: "center",
                gap: "10px",
                boxShadow: "0 2px 6px rgba(15,23,42,0.03)",
              }}
            >
              <div style={{ width: "26px", height: "26px", borderRadius: "50%", background: "#eff6ff", color: "#2563eb", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "0.85rem" }}>
                📍
              </div>
              <div style={{ fontSize: "0.86rem" }}>
                <strong style={{ color: "#0f172a" }}>18 chi nhánh</strong>
                <span style={{ color: "#64748b", marginLeft: "6px" }}>Phủ rộng các quận huyện</span>
              </div>
            </div>

            <div
              style={{
                background: "#ffffff",
                border: "1px solid #e2e8f0",
                borderRadius: "999px",
                padding: "8px 18px",
                display: "flex",
                alignItems: "center",
                gap: "10px",
                boxShadow: "0 2px 6px rgba(15,23,42,0.03)",
              }}
            >
              <div style={{ width: "26px", height: "26px", borderRadius: "50%", background: "#eff6ff", color: "#0284c7", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "0.85rem" }}>
                🕒
              </div>
              <div style={{ fontSize: "0.86rem" }}>
                <strong style={{ color: "#0f172a" }}>Mở cửa liên tục</strong>
                <span style={{ color: "#64748b", marginLeft: "6px" }}>8:00 - 20:00 hàng ngày</span>
              </div>
            </div>

            <div
              style={{
                background: "#ffffff",
                border: "1px solid #e2e8f0",
                borderRadius: "999px",
                padding: "8px 18px",
                display: "flex",
                alignItems: "center",
                gap: "10px",
                boxShadow: "0 2px 6px rgba(15,23,42,0.03)",
              }}
            >
              <div style={{ width: "26px", height: "26px", borderRadius: "50%", background: "#eff6ff", color: "#16a34a", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "0.85rem" }}>
                🛡️
              </div>
              <div style={{ fontSize: "0.86rem" }}>
                <strong style={{ color: "#0f172a" }}>Kỹ thuật viên lành nghề</strong>
                <span style={{ color: "#64748b", marginLeft: "6px" }}>Được chứng nhận</span>
              </div>
            </div>

            <div
              style={{
                background: "#ffffff",
                border: "1px solid #e2e8f0",
                borderRadius: "999px",
                padding: "8px 18px",
                display: "flex",
                alignItems: "center",
                gap: "10px",
                boxShadow: "0 2px 6px rgba(15,23,42,0.03)",
              }}
            >
              <div style={{ width: "26px", height: "26px", borderRadius: "50%", background: "#fef9c3", color: "#eab308", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "0.85rem" }}>
                ⭐
              </div>
              <div style={{ fontSize: "0.86rem" }}>
                <strong style={{ color: "#0f172a" }}>Đồng bộ toàn diện</strong>
                <span style={{ color: "#64748b", marginLeft: "6px" }}>Chất lượng & Bảo hành</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 2. SEARCH & MULTI-FILTER TOOLBAR */}
      <div style={{ maxWidth: "1340px", margin: "0 auto 24px", padding: "0 20px" }}>
        <div
          style={{
            background: "#ffffff",
            border: "1px solid #e2e8f0",
            borderRadius: "16px",
            padding: "14px 18px",
            boxShadow: "0 4px 14px rgba(15,23,42,0.03)",
            display: "grid",
            gridTemplateColumns: "1.8fr 1.15fr 1.25fr 1.1fr auto",
            gap: "12px",
            alignItems: "center",
          }}
        >
          {/* SEARCH INPUT */}
          <div style={{ position: "relative", display: "flex", alignItems: "center" }}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#94a3b8" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" style={{ position: "absolute", left: "14px" }}>
              <circle cx="11" cy="11" r="8" />
              <line x1="21" y1="21" x2="16.65" y2="16.65" />
            </svg>
            <input
              type="text"
              placeholder="Tìm tên chi nhánh, tên đường, quận/huyện..."
              value={searchKeyword}
              onChange={(e) => setSearchKeyword(e.target.value)}
              style={{
                width: "100%",
                height: "44px",
                padding: "0 14px 0 42px",
                borderRadius: "10px",
                border: "1px solid #cbd5e1",
                background: "#f8fafc",
                fontSize: "0.88rem",
                color: "#0f172a",
                outline: "none",
              }}
            />
          </div>

          {/* CITY DROPDOWN */}
          <div style={{ position: "relative" }}>
            <select
              value={selectedCity}
              onChange={(e) => handleCityChange(e.target.value)}
              style={{
                width: "100%",
                height: "44px",
                padding: "0 12px",
                borderRadius: "10px",
                border: selectedCity !== "all" ? "1.5px solid #2563eb" : "1px solid #cbd5e1",
                background: selectedCity !== "all" ? "#eff6ff" : "#f8fafc",
                fontSize: "0.86rem",
                color: selectedCity !== "all" ? "#2563eb" : "#0f172a",
                fontWeight: 600,
                outline: "none",
                cursor: "pointer",
              }}
            >
              <option value="all">📍 Toàn quốc ({cityCounts.total})</option>
              <option value="TP. Hồ Chí Minh">📍 TP. Hồ Chí Minh ({cityCounts.map["TP. Hồ Chí Minh"] || 0})</option>
              <option value="Hà Nội">📍 Hà Nội ({cityCounts.map["Hà Nội"] || 0})</option>
              <option value="Đà Nẵng">📍 Đà Nẵng ({cityCounts.map["Đà Nẵng"] || 0})</option>
            </select>
          </div>

          {/* DISTRICT DROPDOWN */}
          <div style={{ position: "relative" }}>
            <select
              value={selectedDistrict}
              onChange={(e) => setSelectedDistrict(e.target.value)}
              style={{
                width: "100%",
                height: "44px",
                padding: "0 12px",
                borderRadius: "10px",
                border: selectedDistrict !== "all" ? "1.5px solid #2563eb" : "1px solid #cbd5e1",
                background: selectedDistrict !== "all" ? "#eff6ff" : "#f8fafc",
                fontSize: "0.86rem",
                color: selectedDistrict !== "all" ? "#2563eb" : "#0f172a",
                fontWeight: 600,
                outline: "none",
                cursor: "pointer",
              }}
            >
              <option value="all">🏢 Tất cả quận / huyện ({districtCounts.total})</option>
              {districtCounts.items.map((d) => (
                <option key={d.name} value={d.name}>
                  🏢 {d.name} ({d.count})
                </option>
              ))}
            </select>
          </div>

          {/* SERVICE DROPDOWN */}
          <div style={{ position: "relative" }}>
            <select
              value={selectedService}
              onChange={(e) => setSelectedService(e.target.value)}
              style={{
                width: "100%",
                height: "44px",
                padding: "0 12px",
                borderRadius: "10px",
                border: selectedService !== "all" ? "1.5px solid #2563eb" : "1px solid #cbd5e1",
                background: selectedService !== "all" ? "#eff6ff" : "#f8fafc",
                fontSize: "0.86rem",
                color: selectedService !== "all" ? "#2563eb" : "#0f172a",
                fontWeight: 600,
                outline: "none",
                cursor: "pointer",
              }}
            >
              <option value="all">⚙️ Tất cả dịch vụ</option>
              <option value="màn hình">Thay màn hình</option>
              <option value="pin">Thay pin</option>
              <option value="camera">Sửa camera</option>
              <option value="loa">Sửa loa</option>
              <option value="vệ sinh">Vệ sinh máy</option>
            </select>
          </div>

          {/* RESET / CLEAR FILTERS BUTTON */}
          {(searchKeyword || selectedCity !== "all" || selectedDistrict !== "all" || selectedService !== "all") ? (
            <button
              type="button"
              onClick={resetFilters}
              style={{
                height: "44px",
                padding: "0 16px",
                borderRadius: "10px",
                background: "#f1f5f9",
                color: "#475569",
                border: "1px solid #cbd5e1",
                fontWeight: 600,
                fontSize: "0.84rem",
                cursor: "pointer",
                whiteSpace: "nowrap",
              }}
            >
              ✕ Đặt lại
            </button>
          ) : (
            <button
              type="button"
              style={{
                height: "44px",
                padding: "0 18px",
                borderRadius: "10px",
                background: "#2563eb",
                color: "#ffffff",
                border: "none",
                fontWeight: 700,
                fontSize: "0.86rem",
                cursor: "default",
                whiteSpace: "nowrap",
              }}
            >
              Tìm chi nhánh
            </button>
          )}
        </div>
      </div>

      {/* 3. MAIN 2-COLUMN SPLIT VIEW: LIST (LEFT) & MAP + DETAILS (RIGHT) */}
      <div style={{ maxWidth: "1340px", margin: "0 auto", padding: "0 20px" }}>
        <div style={{ display: "grid", gridTemplateColumns: "520px 1fr", gap: "24px", alignItems: "flex-start" }}>
          {/* LEFT LIST COLUMN */}
          <div>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "14px" }}>
              <strong style={{ fontSize: "1.05rem", color: "#0f172a" }}>
                {selectedCity === "all" ? "Tất cả chi nhánh" : `Chi nhánh tại ${selectedCity}`}
                {selectedDistrict !== "all" && ` - ${selectedDistrict}`} ({filteredBranches.length} chi nhánh)
              </strong>
              <span style={{ fontSize: "0.84rem", color: "#64748b" }}>
                Sắp xếp: <strong style={{ color: "#0f172a" }}>Gần nhất ⌄</strong>
              </span>
            </div>

            {/* EMPTY STATE IF 0 MATCHES */}
            {filteredBranches.length === 0 ? (
              <div
                style={{
                  background: "#ffffff",
                  borderRadius: "16px",
                  border: "1px solid #e2e8f0",
                  padding: "48px 24px",
                  textAlign: "center",
                  boxShadow: "0 2px 8px rgba(15,23,42,0.02)",
                }}
              >
                <div style={{ fontSize: "2.8rem", marginBottom: "12px" }}>🔍</div>
                <h3 style={{ fontSize: "1.08rem", fontWeight: 800, color: "#0f172a", margin: "0 0 6px" }}>
                  Không tìm thấy chi nhánh phù hợp
                </h3>
                <p style={{ fontSize: "0.84rem", color: "#64748b", margin: "0 0 18px", lineHeight: 1.5 }}>
                  Không có chi nhánh nào khớp với bộ lọc hoặc từ khóa bạn vừa nhập.
                </p>
                <button
                  type="button"
                  onClick={resetFilters}
                  style={{
                    padding: "8px 20px",
                    borderRadius: "10px",
                    background: "#2563eb",
                    color: "#ffffff",
                    border: "none",
                    fontWeight: 700,
                    fontSize: "0.84rem",
                    cursor: "pointer",
                  }}
                >
                  Xóa bộ lọc & xem tất cả chi nhánh
                </button>
              </div>
            ) : (
              <div style={{ display: "flex", flexDirection: "column", gap: "14px" }}>
                {filteredBranches.map((b) => {
                  const isSelected = b.id === selectedBranchId
                  return (
                    <article
                      key={b.id}
                      onClick={() => handleSelectBranch(b.id)}
                      style={{
                        background: "#ffffff",
                        border: isSelected ? "1.5px solid #2563eb" : "1px solid #e2e8f0",
                        borderRadius: "16px",
                        padding: "14px",
                        display: "flex",
                        gap: "14px",
                        boxShadow: isSelected ? "0 4px 16px rgba(37,99,235,0.12)" : "0 2px 8px rgba(15,23,42,0.02)",
                        cursor: "pointer",
                        transition: "all 0.15s ease",
                      }}
                    >
                      <img
                        src={b.image}
                        alt={b.name}
                        style={{
                          width: "115px",
                          height: "90px",
                          borderRadius: "10px",
                          objectFit: "cover",
                          flexShrink: 0,
                        }}
                      />

                      <div style={{ flex: 1, display: "flex", flexDirection: "column", justifyContent: "space-between" }}>
                        <div>
                          <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: "8px", marginBottom: "4px" }}>
                            <div style={{ display: "flex", alignItems: "center", gap: "6px", flexWrap: "wrap" }}>
                              <h2 style={{ fontSize: "0.98rem", fontWeight: 800, color: "#0f172a", margin: 0 }}>
                                {b.name}
                              </h2>
                              <span
                                style={{
                                  fontSize: "0.7rem",
                                  fontWeight: 700,
                                  color: "#0369a1",
                                  background: "#f0f9ff",
                                  padding: "1px 6px",
                                  borderRadius: "4px",
                                  border: "1px solid #bae6fd",
                                }}
                              >
                                {b.district}
                              </span>
                            </div>
                            <span
                              style={{
                                fontSize: "0.76rem",
                                fontWeight: 700,
                                color: "#2563eb",
                                background: "#eff6ff",
                                padding: "2px 8px",
                                borderRadius: "6px",
                                display: "inline-flex",
                                alignItems: "center",
                                gap: "3px",
                                whiteSpace: "nowrap",
                              }}
                            >
                              ↗ {b.distance}
                            </span>
                          </div>

                          <div style={{ fontSize: "0.78rem", color: "#64748b", display: "flex", flexDirection: "column", gap: "2px" }}>
                            <div>📍 {b.address}</div>
                            <div>🕒 08:00 - 20:00 (T2 - CN)</div>
                            <div>📞 {b.phone}</div>
                          </div>
                        </div>

                        <div style={{ display: "flex", gap: "8px", marginTop: "10px" }}>
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation()
                              setSelectedBranchId(b.id)
                              setShowDetail(true)
                            }}
                            style={{
                              padding: "6px 14px",
                              borderRadius: "8px",
                              background: "#2563eb",
                              color: "#ffffff",
                              border: "none",
                              fontSize: "0.78rem",
                              fontWeight: 700,
                              cursor: "pointer",
                            }}
                          >
                            Xem chi tiết
                          </button>
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation()
                              handleBookAtBranch(b.id)
                            }}
                            style={{
                              padding: "6px 14px",
                              borderRadius: "8px",
                              background: "#ffffff",
                              color: "#2563eb",
                              border: "1px solid #cbd5e1",
                              fontSize: "0.78rem",
                              fontWeight: 700,
                              cursor: "pointer",
                              display: "inline-flex",
                              alignItems: "center",
                              gap: "4px",
                            }}
                          >
                            <span>↗</span>
                            <span>Chọn chi nhánh</span>
                          </button>
                        </div>
                      </div>
                    </article>
                  )
                })}
              </div>
            )}
          </div>

          {/* RIGHT MAP COLUMN WITH REAL GOOGLE MAP & CONDITIONAL BRANCH DETAIL */}
          <div
            style={{
              background: "#ffffff",
              border: "1px solid #e2e8f0",
              borderRadius: "18px",
              overflow: "hidden",
              boxShadow: "0 2px 10px rgba(15,23,42,0.03)",
              position: "sticky",
              top: "20px",
            }}
          >
            {/* MAP HEADER */}
            <div
              style={{
                padding: "12px 18px",
                background: "#f8fafc",
                borderBottom: "1px solid #e2e8f0",
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                gap: "12px",
              }}
            >
              <div style={{ display: "flex", alignItems: "center", gap: "8px", minWidth: 0 }}>
                <span style={{ fontSize: "1rem" }}>📍</span>
                <div style={{ minWidth: 0 }}>
                  <strong style={{ fontSize: "0.88rem", color: "#0f172a", display: "block", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                    {selectedBranch.name}
                  </strong>
                  <span style={{ fontSize: "0.74rem", color: "#64748b", display: "block", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                    {selectedBranch.address}
                  </span>
                </div>
              </div>

              <div style={{ display: "flex", alignItems: "center", gap: "8px", flexShrink: 0 }}>
                <a
                  href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
                    `${selectedBranch.name}, ${selectedBranch.address}`
                  )}`}
                  target="_blank"
                  rel="noreferrer"
                  style={{
                    fontSize: "0.78rem",
                    color: "#2563eb",
                    textDecoration: "none",
                    fontWeight: 700,
                    background: "#eff6ff",
                    padding: "6px 12px",
                    borderRadius: "8px",
                    border: "1px solid #bfdbfe",
                    display: "inline-flex",
                    alignItems: "center",
                    gap: "4px",
                  }}
                >
                  <span>Chỉ đường</span>
                  <span>↗</span>
                </a>
              </div>
            </div>

            {/* REAL GOOGLE MAP IFRAME */}
            <div
              style={{
                width: "100%",
                height: showDetail ? "300px" : "540px",
                transition: "height 0.3s ease",
                background: "#f1f5f9",
              }}
            >
              <iframe
                title={`Google Map - ${selectedBranch.name}`}
                width="100%"
                height="100%"
                style={{ border: 0, display: "block" }}
                loading="lazy"
                allowFullScreen
                referrerPolicy="no-referrer-when-downgrade"
                src={`https://maps.google.com/maps?q=${encodeURIComponent(
                  `${selectedBranch.name}, ${selectedBranch.address}`
                )}&t=&z=16&ie=UTF8&iwloc=&output=embed`}
              />
            </div>

            {/* DOCKED SELECTED BRANCH CARD WHEN showDetail IS TRUE */}
            {showDetail && (
              <div style={{ padding: "20px", borderTop: "1px solid #e2e8f0", background: "#ffffff" }}>
                <div style={{ marginBottom: "14px" }}>
                  <span style={{ fontSize: "0.82rem", fontWeight: 700, color: "#2563eb", textTransform: "uppercase", letterSpacing: "0.04em" }}>
                    Thông tin chi tiết chi nhánh
                  </span>
                </div>

                <div style={{ display: "grid", gridTemplateColumns: "140px 1fr", gap: "16px", alignItems: "flex-start", marginBottom: "16px" }}>
                  <img
                    src={selectedBranch.image}
                    alt={selectedBranch.name}
                    style={{
                      width: "140px",
                      height: "110px",
                      borderRadius: "12px",
                      objectFit: "cover",
                    }}
                  />

                  <div>
                    <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "6px" }}>
                      <h3 style={{ fontSize: "1.15rem", fontWeight: 800, margin: 0, color: "#0f172a" }}>
                        {selectedBranch.name}
                      </h3>
                      <span
                        style={{
                          background: "#eff6ff",
                          color: "#2563eb",
                          fontSize: "0.74rem",
                          fontWeight: 700,
                          padding: "2px 8px",
                          borderRadius: "999px",
                          border: "1px solid #bfdbfe",
                          display: "inline-flex",
                          alignItems: "center",
                          gap: "4px",
                        }}
                      >
                        📍 {selectedBranch.district} ({selectedBranch.city})
                      </span>
                    </div>

                    <div style={{ display: "flex", flexDirection: "column", gap: "4px", fontSize: "0.8rem", color: "#64748b", marginBottom: "8px" }}>
                      <div>📍 {selectedBranch.address}</div>
                      <div>🕒 08:00 - 20:00 (Thứ 2 - Chủ nhật)</div>
                      <div>📞 {selectedBranch.phone}</div>
                    </div>

                    <div style={{ display: "flex", gap: "8px", flexWrap: "wrap" }}>
                      <span style={{ color: "#0284c7", background: "#f0f9ff", border: "1px solid #bae6fd", padding: "2px 8px", borderRadius: "6px", fontSize: "0.74rem", fontWeight: 600 }}>
                        🚗 Có chỗ đỗ xe
                      </span>
                      <span style={{ color: "#16a34a", background: "#f0fdf4", border: "1px solid #bbf7d0", padding: "2px 8px", borderRadius: "6px", fontSize: "0.74rem", fontWeight: 600 }}>
                        ⭐ Đánh giá {selectedBranch.rating || "4.9"}/5
                      </span>
                    </div>
                  </div>
                </div>

                {/* HIGHLIGHT SERVICES OF THIS BRANCH */}
                {selectedBranch.featuredServices && selectedBranch.featuredServices.length > 0 && (
                  <div style={{ marginBottom: "16px" }}>
                    <span style={{ fontSize: "0.8rem", fontWeight: 700, color: "#0f172a", display: "block", marginBottom: "8px" }}>
                      Dịch vụ sửa chữa tại chi nhánh:
                    </span>
                    <div style={{ display: "flex", gap: "8px", overflowX: "auto", paddingBottom: "4px" }}>
                      {selectedBranch.featuredServices.map((svc, i) => (
                        <div
                          key={i}
                          style={{
                            padding: "6px 12px",
                            background: "#f8fafc",
                            border: "1px solid #e2e8f0",
                            borderRadius: "8px",
                            display: "flex",
                            alignItems: "center",
                            gap: "6px",
                            flexShrink: 0,
                            fontSize: "0.78rem",
                            color: "#334155",
                            fontWeight: 600,
                          }}
                        >
                          <span>{svc.icon}</span>
                          <span>{svc.name}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* ACTION BUTTONS */}
                <div style={{ display: "flex", gap: "10px" }}>
                  <button
                    type="button"
                    onClick={() => setShowDetail(false)}
                    style={{
                      flex: 1,
                      height: "38px",
                      borderRadius: "10px",
                      border: "1px solid #cbd5e1",
                      background: "#ffffff",
                      fontSize: "0.84rem",
                      fontWeight: 600,
                      color: "#475569",
                      cursor: "pointer",
                    }}
                  >
                    Ẩn chi tiết
                  </button>
                  <button
                    type="button"
                    onClick={() => handleBookAtBranch(selectedBranch.id)}
                    style={{
                      flex: 2,
                      height: "38px",
                      borderRadius: "10px",
                      border: "none",
                      background: "#2563eb",
                      color: "#ffffff",
                      fontSize: "0.86rem",
                      fontWeight: 700,
                      cursor: "pointer",
                      display: "inline-flex",
                      alignItems: "center",
                      justifyContent: "center",
                      gap: "8px",
                      boxShadow: "0 4px 12px rgba(37,99,235,0.3)",
                    }}
                  >
                    <span>📅</span>
                    <span>Đặt lịch tại chi nhánh này</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </main>
  )
}
