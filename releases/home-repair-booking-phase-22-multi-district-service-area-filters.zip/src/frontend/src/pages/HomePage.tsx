import { useState } from "react"
import { Link, useNavigate } from "react-router-dom"
import {
  branchQuan1,
  branchQuan7,
  branchThuDuc,
  customer1,
  customer2,
  customer3,
  workshopBg,
  heroPhones,
  bookingAdvisor,
  BRAND_LOGOS,
  SERVICE_ICONS,
} from "../assets"

interface ServiceQuickItem {
  id: number
  title: string
  price: string
  icon: string
  bg: string
  color: string
  key: string
}

const QUICK_SERVICES: ServiceQuickItem[] = [
  { id: 1, title: "Thay màn hình", price: "Từ 1.500.000đ", icon: "📱", bg: "#eff6ff", color: "#2563eb", key: "screen" },
  { id: 2, title: "Thay pin", price: "Từ 500.000đ", icon: "🔋", bg: "#f0fdf4", color: "#16a34a", key: "battery" },
  { id: 3, title: "Sửa cổng sạc", price: "Từ 300.000đ", icon: "🔌", bg: "#f0f9ff", color: "#0284c7", key: "port" },
  { id: 4, title: "Sửa camera", price: "Từ 400.000đ", icon: "📷", bg: "#faf5ff", color: "#9333ea", key: "camera" },
  { id: 5, title: "Sửa loa", price: "Từ 250.000đ", icon: "🔊", bg: "#fdf4ff", color: "#c026d3", key: "speaker" },
  { id: 6, title: "Vệ sinh máy", price: "Từ 150.000đ", icon: "🧹", bg: "#ecfeff", color: "#0891b2", key: "clean" },
]

interface BrandQuickItem {
  name: string
  sub: string
  logo: string
  brandId?: number
}

const POPULAR_BRANDS: BrandQuickItem[] = [
  { name: "Apple", sub: "iPhone", logo: "🍎", brandId: 1 },
  { name: "Samsung", sub: "Galaxy", logo: "📱", brandId: 2 },
  { name: "Xiaomi", sub: "", logo: "🟠", brandId: 3 },
  { name: "Oppo", sub: "", logo: "🟢", brandId: 4 },
  { name: "Vivo", sub: "", logo: "🔷", brandId: 5 },
  { name: "Realme", sub: "", logo: "🟡", brandId: 6 },
  { name: "Google", sub: "Pixel", logo: "🌐", brandId: 7 },
  { name: "Honor", sub: "", logo: "💠", brandId: 8 },
]

interface StoreBranchPreview {
  id: number
  name: string
  address: string
  hours: string
  phone: string
  image: string
}

const FEATURED_BRANCHES: StoreBranchPreview[] = [
  {
    id: 1,
    name: "HomeRepair Quận 1",
    address: "123 Nguyễn Huệ, Quận 1, TP.HCM",
    hours: "08:00 - 20:00",
    phone: "028 1234 5678",
    image: branchQuan1,
  },
  {
    id: 2,
    name: "HomeRepair Quận 7",
    address: "456 Nguyễn Thị Thập, Quận 7",
    hours: "08:00 - 20:00",
    phone: "028 2345 6789",
    image: branchQuan7,
  },
  {
    id: 3,
    name: "HomeRepair Thủ Đức",
    address: "789 Võ Văn Ngân, Thủ Đức",
    hours: "08:00 - 20:00",
    phone: "028 3456 7890",
    image: branchThuDuc,
  },
]

interface CustomerReviewPreview {
  name: string
  timeAgo: string
  avatar: string
  comment: string
  rating: number
}

const CUSTOMER_REVIEWS: CustomerReviewPreview[] = [
  {
    name: "Nguyễn Minh Tuấn",
    timeAgo: "2 tuần trước",
    avatar: customer1,
    comment: "Sửa nhanh, nhân viên rất nhiệt tình. Máy hoạt động tốt, giá hợp lý.",
    rating: 5,
  },
  {
    name: "Trần Thị Lan",
    timeAgo: "1 tháng trước",
    avatar: customer2,
    comment: "Đặt lịch online rất tiện, không phải chờ đợi. Dịch vụ chuyên nghiệp.",
    rating: 5,
  },
  {
    name: "Lê Hoàng Nam",
    timeAgo: "3 tuần trước",
    avatar: customer3,
    comment: "Thay pin iPhone nhanh chóng, bảo hành rõ ràng. Sẽ quay lại.",
    rating: 5,
  },
]

export function HomePage() {
  const navigate = useNavigate()
  const [heroSearch, setHeroSearch] = useState("")

  const handleHeroSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (heroSearch.trim()) {
      navigate(`/services?q=${encodeURIComponent(heroSearch.trim())}`)
    } else {
      navigate("/services")
    }
  }

  return (
    <main className="home-page-container">
      {/* 1. HERO SECTION (MATCHING SCREENSHOT) */}
      <section
        className="home-hero-section"
        style={{
          background: `linear-gradient(90deg, rgba(15, 23, 42, 0.94) 0%, rgba(15, 23, 42, 0.85) 44%, rgba(15, 23, 42, 0.35) 75%, rgba(15, 23, 42, 0.15) 100%), url('${workshopBg}') center/cover no-repeat`,
        }}
      >
        <div>
          <h1 className="home-hero-title">
            Sửa điện thoại nhanh chóng,
            <br />
            uy tín, chuyên nghiệp
          </h1>
          <p className="home-hero-subtitle">
            Đặt lịch trước – Không chờ đợi – Lấy máy đúng hẹn
          </p>

          {/* SEARCH BAR */}
          <form onSubmit={handleHeroSearch} className="home-hero-search-box">
            <svg
              width="18"
              height="18"
              viewBox="0 0 24 24"
              fill="none"
              stroke="#94a3b8"
              strokeWidth="2.2"
              strokeLinecap="round"
              strokeLinejoin="round"
              style={{ marginRight: "10px", flexShrink: 0 }}
            >
              <circle cx="11" cy="11" r="8" />
              <line x1="21" y1="21" x2="16.65" y2="16.65" />
            </svg>
            <input
              type="text"
              className="home-hero-search-input"
              placeholder="Tìm kiếm dịch vụ, thiết bị hoặc chi nhánh..."
              value={heroSearch}
              onChange={(e) => setHeroSearch(e.target.value)}
            />
            <button type="submit" className="home-hero-search-btn">
              Tìm kiếm
            </button>
          </form>

          {/* 4 QUALITY BADGES ROW */}
          <div className="home-quality-badges-row">
            <div className="home-quality-badge-item">
              <div
                style={{
                  width: "34px",
                  height: "34px",
                  borderRadius: "50%",
                  background: "#ffffff",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  flexShrink: 0,
                  boxShadow: "0 2px 8px rgba(0,0,0,0.15)",
                }}
              >
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#2563eb" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
                  <path d="m9 12 2 2 4-4" />
                </svg>
              </div>
              <div>
                <strong style={{ display: "block", fontSize: "0.85rem", color: "#ffffff", fontWeight: 700 }}>
                  Linh kiện chính hãng
                </strong>
                <span style={{ fontSize: "0.75rem", color: "#cbd5e1" }}>Chất lượng đảm bảo</span>
              </div>
            </div>

            <div className="home-quality-badge-item">
              <div
                style={{
                  width: "34px",
                  height: "34px",
                  borderRadius: "50%",
                  background: "#ffffff",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  flexShrink: 0,
                  boxShadow: "0 2px 8px rgba(0,0,0,0.15)",
                }}
              >
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#2563eb" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2" />
                  <circle cx="12" cy="7" r="4" />
                </svg>
              </div>
              <div>
                <strong style={{ display: "block", fontSize: "0.85rem", color: "#ffffff", fontWeight: 700 }}>
                  Kỹ thuật viên chuyên nghiệp
                </strong>
                <span style={{ fontSize: "0.75rem", color: "#cbd5e1" }}>Nhiều năm kinh nghiệm</span>
              </div>
            </div>

            <div className="home-quality-badge-item">
              <div
                style={{
                  width: "34px",
                  height: "34px",
                  borderRadius: "50%",
                  background: "#ffffff",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  flexShrink: 0,
                  boxShadow: "0 2px 8px rgba(0,0,0,0.15)",
                }}
              >
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#2563eb" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
                  <path d="m9 12 2 2 4-4" />
                </svg>
              </div>
              <div>
                <strong style={{ display: "block", fontSize: "0.85rem", color: "#ffffff", fontWeight: 700 }}>
                  Bảo hành rõ ràng
                </strong>
                <span style={{ fontSize: "0.75rem", color: "#cbd5e1" }}>An tâm sau sửa chữa</span>
              </div>
            </div>

            <div className="home-quality-badge-item">
              <div
                style={{
                  width: "34px",
                  height: "34px",
                  borderRadius: "50%",
                  background: "#ffffff",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  flexShrink: 0,
                  boxShadow: "0 2px 8px rgba(0,0,0,0.15)",
                }}
              >
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#2563eb" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z" />
                  <circle cx="12" cy="10" r="3" />
                </svg>
              </div>
              <div>
                <strong style={{ display: "block", fontSize: "0.85rem", color: "#ffffff", fontWeight: 700 }}>
                  Hệ thống chi nhánh
                </strong>
                <span style={{ fontSize: "0.75rem", color: "#cbd5e1" }}>Thuận tiện, dễ tìm</span>
              </div>
            </div>
          </div>
        </div>

        {/* HERO RIGHT VISUAL: PHONES CLUSTER WITH FLOATING CTA PILL */}
        <div className="home-hero-visual-col" style={{ position: "relative", display: "flex", justifyContent: "flex-end", alignItems: "flex-end" }}>
          <div style={{ position: "relative", width: "100%", maxWidth: "470px" }}>
            <img
              src={heroPhones}
              alt="Dịch vụ sửa chữa nhà cửa HomeRepair"
              style={{
                width: "100%",
                height: "auto",
                display: "block",
                borderRadius: "16px",
                filter: "drop-shadow(0 20px 40px rgba(0,0,0,0.45))",
              }}
            />
            {/* CLICKABLE OVERLAY ON THE FLOATING 'ĐẶT LỊCH NGAY' PILL */}
            <Link
              to="/booking"
              title="Đặt lịch ngay chỉ với vài bước"
              style={{
                position: "absolute",
                right: "8%",
                bottom: "12%",
                width: "56%",
                height: "35%",
                borderRadius: "999px",
                display: "block",
                cursor: "pointer",
                zIndex: 10,
              }}
            />
          </div>
        </div>
      </section>

      {/* 2. DUAL CARDS SECTION: DỊCH VỤ PHỔ BIẾN & CÁC HÃNG PHỔ BIẾN */}
      <section className="home-dual-cards-row">
        {/* LEFT CARD: DỊCH VỤ SỬA CHỮA PHỔ BIẾN */}
        <div className="home-section-card">
          <div className="home-section-card-header">
            <h2 className="home-section-card-title">Dịch vụ sửa chữa phổ biến</h2>
            <Link to="/services" className="home-section-card-link">
              Xem tất cả →
            </Link>
          </div>

          <div className="home-popular-services-grid">
            {QUICK_SERVICES.map((s) => (
              <Link key={s.id} to={`/pricing?service=${s.key}`} className="home-popular-service-item">
                <div className="home-popular-service-icon" style={{ background: s.bg, color: s.color }}>
                  {SERVICE_ICONS[s.key] ? (
                    <img src={SERVICE_ICONS[s.key]} alt={s.title} style={{ width: "20px", height: "20px" }} />
                  ) : (
                    s.icon
                  )}
                </div>
                <strong style={{ fontSize: "0.85rem", color: "#0f172a", marginBottom: "4px" }}>
                  {s.title}
                </strong>
                <span style={{ fontSize: "0.72rem", color: "#64748b" }}>
                  {s.price}
                </span>
              </Link>
            ))}
          </div>
        </div>

        {/* RIGHT CARD: CÁC HÃNG ĐIỆN THOẠI PHỔ BIẾN */}
        <div className="home-section-card">
          <div className="home-section-card-header">
            <h2 className="home-section-card-title">Các hãng điện thoại phổ biến</h2>
            <Link to="/brands" className="home-section-card-link">
              Xem tất cả →
            </Link>
          </div>

          <div className="home-popular-brands-grid">
            {POPULAR_BRANDS.map((b) => (
              <Link key={b.name} to={`/booking?brand=${encodeURIComponent(b.name)}`} className="home-popular-brand-item">
                <div
                  style={{
                    height: "30px",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    marginBottom: "8px",
                    width: "100%",
                  }}
                >
                  {BRAND_LOGOS[b.name] ? (
                    <img
                      src={BRAND_LOGOS[b.name]}
                      alt={b.name}
                      style={{
                        maxHeight: "24px",
                        maxWidth: "76px",
                        width: "auto",
                        height: "auto",
                        objectFit: "contain",
                        display: "block",
                      }}
                    />
                  ) : (
                    <span style={{ fontSize: "1.4rem" }}>{b.logo}</span>
                  )}
                </div>

                <strong
                  style={{
                    fontSize: "0.84rem",
                    fontWeight: 700,
                    color: "#0f172a",
                    lineHeight: "1.2",
                    display: "block",
                  }}
                >
                  {b.name}
                </strong>

                <span
                  style={{
                    fontSize: "0.72rem",
                    color: "#94a3b8",
                    minHeight: "16px",
                    lineHeight: "16px",
                    marginTop: "3px",
                    display: "block",
                  }}
                >
                  {b.sub || "\u00A0"}
                </span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* 3. PROCESS CARD: QUY TRÌNH SỬA CHỮA TẠI PHONEREPAIR */}
      <section className="home-process-card">
        <h2 style={{ fontSize: "1.35rem", fontWeight: 800, color: "#0f172a", margin: "0 0 28px" }}>
          Quy trình sửa chữa tại HomeRepair
        </h2>

        <div className="home-process-split">
          {/* 4 STEPS TIMELINE */}
          <div className="home-process-steps-row">
            {/* STEP 1 */}
            <div className="home-process-step-col">
              <div className="home-process-icon-circle">
                📅
                <span className="home-process-badge-number">1</span>
              </div>
              <strong style={{ fontSize: "0.95rem", color: "#0f172a", marginBottom: "4px" }}>
                Đặt lịch
              </strong>
              <span style={{ fontSize: "0.78rem", color: "#64748b", lineHeight: 1.4 }}>
                Chọn dịch vụ, chi nhánh, ngày giờ phù hợp
              </span>
            </div>

            <span className="home-process-arrow">›</span>

            {/* STEP 2 */}
            <div className="home-process-step-col">
              <div className="home-process-icon-circle">
                📋
                <span className="home-process-badge-number">2</span>
              </div>
              <strong style={{ fontSize: "0.95rem", color: "#0f172a", marginBottom: "4px" }}>
                Tiếp nhận
              </strong>
              <span style={{ fontSize: "0.78rem", color: "#64748b", lineHeight: 1.4 }}>
                Kiểm tra tình trạng máy
              </span>
            </div>

            <span className="home-process-arrow">›</span>

            {/* STEP 3 */}
            <div className="home-process-step-col">
              <div className="home-process-icon-circle">
                🔧
                <span className="home-process-badge-number">3</span>
              </div>
              <strong style={{ fontSize: "0.95rem", color: "#0f172a", marginBottom: "4px" }}>
                Sửa chữa
              </strong>
              <span style={{ fontSize: "0.78rem", color: "#64748b", lineHeight: 1.4 }}>
                Kỹ thuật viên thực hiện
              </span>
            </div>

            <span className="home-process-arrow">›</span>

            {/* STEP 4 */}
            <div className="home-process-step-col">
              <div className="home-process-icon-circle">
                🛡️
                <span className="home-process-badge-number">4</span>
              </div>
              <strong style={{ fontSize: "0.95rem", color: "#0f172a", marginBottom: "4px" }}>
                Kiểm tra & bàn giao
              </strong>
              <span style={{ fontSize: "0.78rem", color: "#64748b", lineHeight: 1.4 }}>
                Kiểm tra chức năng, nhận máy và bảo hành
              </span>
            </div>
          </div>

          {/* ONLINE BOOKING FEATURE BOX */}
          <div
            className="home-booking-feature-box"
            style={{
              background: "linear-gradient(135deg, #f0f9ff 0%, #eff6ff 100%)",
              border: "1px solid #dbeafe",
              borderRadius: "20px",
              padding: "20px 22px",
              display: "flex",
              alignItems: "center",
              gap: "18px",
              overflow: "hidden",
              position: "relative",
            }}
          >
            {/* PHONE 3D ILLU */}
            <div
              style={{
                width: "68px",
                height: "88px",
                borderRadius: "16px",
                background: "linear-gradient(180deg, #dbeafe 0%, #bfdbfe 100%)",
                border: "2px solid #ffffff",
                boxShadow: "0 6px 16px rgba(37,99,235,0.12)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                position: "relative",
                flexShrink: 0,
              }}
            >
              <div
                style={{
                  width: "38px",
                  height: "62px",
                  borderRadius: "9px",
                  background: "#2563eb",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#ffffff" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                  <polyline points="20 6 9 17 4 12" />
                </svg>
              </div>
              <div
                style={{
                  position: "absolute",
                  bottom: "-6px",
                  right: "-6px",
                  width: "28px",
                  height: "28px",
                  borderRadius: "50%",
                  background: "#16a34a",
                  border: "2px solid #ffffff",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  boxShadow: "0 4px 10px rgba(22,163,74,0.3)",
                }}
              >
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#ffffff" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round">
                  <polyline points="20 6 9 17 4 12" />
                </svg>
              </div>
            </div>

            <div style={{ flex: 1, zIndex: 2 }}>
              <strong style={{ fontSize: "1.08rem", color: "#0f172a", display: "block", fontWeight: 800 }}>
                Đặt lịch trực tuyến
              </strong>
              <span style={{ fontSize: "0.82rem", color: "#64748b", fontWeight: 600 }}>Nhanh chóng, tiện lợi</span>

              <ul
                style={{
                  listStyle: "none",
                  padding: 0,
                  margin: "10px 0 14px",
                  display: "flex",
                  flexDirection: "column",
                  gap: "5px",
                  fontSize: "0.78rem",
                  color: "#334155",
                }}
              >
                <li style={{ display: "flex", alignItems: "center", gap: "7px" }}>
                  <span style={{ width: "16px", height: "16px", borderRadius: "50%", background: "#16a34a", color: "#ffffff", display: "inline-flex", alignItems: "center", justifyContent: "center", fontSize: "0.65rem", fontWeight: 800 }}>✓</span>
                  <span>Chọn chi nhánh gần bạn</span>
                </li>
                <li style={{ display: "flex", alignItems: "center", gap: "7px" }}>
                  <span style={{ width: "16px", height: "16px", borderRadius: "50%", background: "#16a34a", color: "#ffffff", display: "inline-flex", alignItems: "center", justifyContent: "center", fontSize: "0.65rem", fontWeight: 800 }}>✓</span>
                  <span>Chọn dịch vụ và thời gian</span>
                </li>
                <li style={{ display: "flex", alignItems: "center", gap: "7px" }}>
                  <span style={{ width: "16px", height: "16px", borderRadius: "50%", background: "#16a34a", color: "#ffffff", display: "inline-flex", alignItems: "center", justifyContent: "center", fontSize: "0.65rem", fontWeight: 800 }}>✓</span>
                  <span>Không cần chờ đợi</span>
                </li>
                <li style={{ display: "flex", alignItems: "center", gap: "7px" }}>
                  <span style={{ width: "16px", height: "16px", borderRadius: "50%", background: "#16a34a", color: "#ffffff", display: "inline-flex", alignItems: "center", justifyContent: "center", fontSize: "0.65rem", fontWeight: 800 }}>✓</span>
                  <span>Nhận xác nhận ngay lập tức</span>
                </li>
              </ul>

              <Link
                to="/booking"
                className="btn"
                style={{
                  background: "#2563eb",
                  color: "#ffffff",
                  padding: "8px 20px",
                  borderRadius: "8px",
                  fontSize: "0.82rem",
                  fontWeight: 700,
                  display: "inline-block",
                  boxShadow: "0 4px 12px rgba(37,99,235,0.3)",
                }}
              >
                Đặt lịch ngay →
              </Link>
            </div>

            {/* ADVISOR WOMAN PHOTO MATCHING SCREENSHOT */}
            <div style={{ width: "165px", textAlign: "right", flexShrink: 0, alignSelf: "flex-end", marginBottom: "-20px", marginRight: "-12px" }}>
              <img
                src={bookingAdvisor}
                alt="Chuyên viên hỗ trợ HomeRepair"
                style={{ width: "100%", height: "auto", display: "block", objectFit: "contain" }}
              />
            </div>
          </div>
        </div>
      </section>

      {/* 4. DUAL BOTTOM CARDS: CHI NHÁNH CỦA CHÚNG TÔI & KHÁCH HÀNG NÓI GÌ */}
      <section className="home-branches-reviews-row">
        {/* LEFT: CHI NHÁNH CỦA CHÚNG TÔI */}
        <div className="home-section-card">
          <div className="home-section-card-header">
            <h2 className="home-section-card-title">Chi nhánh của chúng tôi</h2>
            <Link to="/branches" className="home-section-card-link">
              Xem tất cả →
            </Link>
          </div>

          <div className="home-branch-triplet-grid">
            {FEATURED_BRANCHES.map((b) => (
              <Link key={b.id} to="/branches" className="home-branch-mini-card">
                <img src={b.image} alt={b.name} className="home-branch-mini-img" />
                <div className="home-branch-mini-body">
                  <strong style={{ fontSize: "0.92rem", color: "#0f172a", marginBottom: "2px" }}>
                    {b.name}
                  </strong>
                  <div style={{ fontSize: "0.76rem", color: "#64748b" }}>📍 {b.address}</div>
                  <div style={{ fontSize: "0.76rem", color: "#64748b" }}>🕒 {b.hours}</div>
                  <div style={{ fontSize: "0.76rem", color: "#64748b" }}>📞 {b.phone}</div>
                </div>
              </Link>
            ))}
          </div>
        </div>

        {/* RIGHT: KHÁCH HÀNG NÓI GÌ VỀ CHÚNG TÔI */}
        <div className="home-section-card">
          <div className="home-section-card-header">
            <h2 className="home-section-card-title">Khách hàng nói gì về chúng tôi</h2>
            <Link to="/support" className="home-section-card-link">
              Xem tất cả →
            </Link>
          </div>

          <div className="home-reviews-triplet-grid">
            {CUSTOMER_REVIEWS.map((r, i) => (
              <div key={i} className="home-review-mini-card">
                <div>
                  <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "8px" }}>
                    <img
                      src={r.avatar}
                      alt={r.name}
                      style={{ width: "36px", height: "36px", borderRadius: "50%", objectFit: "cover" }}
                    />
                    <div>
                      <strong style={{ display: "block", fontSize: "0.85rem", color: "#0f172a" }}>
                        {r.name}
                      </strong>
                      <span style={{ fontSize: "0.72rem", color: "#94a3b8" }}>{r.timeAgo}</span>
                    </div>
                  </div>

                  <div style={{ color: "#eab308", fontSize: "0.85rem", marginBottom: "8px" }}>
                    {"★".repeat(r.rating)}
                  </div>

                  <p style={{ margin: 0, fontSize: "0.8rem", color: "#475569", lineHeight: 1.5 }}>
                    "{r.comment}"
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </main>
  )
}
