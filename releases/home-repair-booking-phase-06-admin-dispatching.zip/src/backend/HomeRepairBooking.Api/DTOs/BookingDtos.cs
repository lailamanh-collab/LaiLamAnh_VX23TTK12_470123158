using HomeRepairBooking.Api.Domain;

namespace HomeRepairBooking.Api.DTOs;

public record SlotDto(string Start, string End, int Capacity, int Booked, bool IsFull);

public record BookingLineDto(int RepairServiceId, string ServiceName, PricingType PricingType, decimal? UnitPrice);

public record BookingHistoryDto(BookingStatus? FromStatus, BookingStatus ToStatus, string? Note, DateTime ChangedAt);

public record BookingSummaryDto(
    int Id,
    string BookingCode,
    string BrandName,
    string PhoneModelName,
    string BranchName,
    DateOnly AppointmentDate,
    string SlotStart,
    BookingStatus Status,
    decimal EstimatedTotal,
    decimal? ActualCost,
    string? TechnicianName);

public record BookingDetailDto(
    int Id,
    string BookingCode,
    string BrandName,
    string PhoneModelName,
    string BranchName,
    string BranchAddress,
    DateOnly AppointmentDate,
    string SlotStart,
    string SlotEnd,
    BookingStatus Status,
    string ProblemDescription,
    decimal EstimatedTotal,
    decimal? ActualCost,
    string? TechnicianName,
    string? Diagnosis,
    string? RepairNotes,
    string? RepairSolution,
    List<BookingLineDto> Services,
    List<BookingHistoryDto> Timeline);

public class CreateBookingRequest
{
    public int PhoneModelId { get; set; }

    public List<int> RepairServiceIds { get; set; } = [];

    public int BranchId { get; set; }

    public string AppointmentDate { get; set; } = string.Empty;

    public string SlotStart { get; set; } = string.Empty;

    public string ProblemDescription { get; set; } = string.Empty;
}

public class CancelBookingRequest
{
    public string? Reason { get; set; }
}

public record AdminBookingDto(
    int Id,
    string BookingCode,
    string CustomerId,
    string CustomerName,
    string CustomerEmail,
    string? CustomerPhone,
    int PhoneModelId,
    string BrandName,
    string PhoneModelName,
    int BranchId,
    string BranchName,
    DateOnly AppointmentDate,
    string SlotStart,
    string SlotEnd,
    BookingStatus Status,
    string ProblemDescription,
    decimal EstimatedTotal,
    decimal? ActualCost,
    int? TechnicianId,
    string? TechnicianName,
    string? Diagnosis,
    string? RepairNotes,
    string? RepairSolution,
    DateTime CreatedAt,
    List<BookingLineDto> Services,
    List<BookingHistoryDto> Timeline);

public class AdminBookingFilterRequest
{
    public string? Search { get; set; }

    public string? Status { get; set; }

    public int? BranchId { get; set; }

    public int? TechnicianId { get; set; }

    public string? Date { get; set; }

    public string? FromDate { get; set; }

    public string? ToDate { get; set; }
}

public class AssignTechnicianRequest
{
    public int TechnicianId { get; set; }

    public string? Note { get; set; }
}

public class AdminStatusUpdateRequest
{
    public string? Note { get; set; }
}

public record CustomerSummaryDto(
    string Id,
    string FullName,
    string Email,
    string? PhoneNumber,
    bool IsActive,
    DateTime CreatedAt,
    int TotalBookings,
    int CompletedBookings);

public record CustomerDetailDto(
    string Id,
    string FullName,
    string Email,
    string? PhoneNumber,
    bool IsActive,
    DateTime CreatedAt,
    List<BookingSummaryDto> Bookings);

